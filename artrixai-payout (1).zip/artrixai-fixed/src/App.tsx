import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { useDevToolsBlocker } from "@/hooks/useDevToolsBlocker";
import Landing from "./pages/Landing";
import LicenseLogin from "./pages/LicenseLogin";
import Auth from "./pages/Auth";
import Index from "./pages/Index";
import Credits from "./pages/Credits";
import Transactions from "./pages/Transactions";
import Profile from "./pages/Profile";
import LiveSignal from "./pages/LiveSignal";
import FutureSignal from "./pages/FutureSignal";
import Status from "./pages/Status";
import MoneyManagement from "./pages/MoneyManagement";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

function AppContent() {
  useDevToolsBlocker();
  
  return (
    <TooltipProvider>
      <Toaster position="top-center" richColors />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/license" element={<LicenseLogin />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/dashboard" element={<Index />} />
            <Route path="/live-signal" element={<LiveSignal />} />
            <Route path="/future-signal" element={<FutureSignal />} />
            <Route path="/credits" element={<Credits />} />
            <Route path="/transactions" element={<Transactions />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/status" element={<Status />} />
            <Route path="/money-management" element={<MoneyManagement />} />
            <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
