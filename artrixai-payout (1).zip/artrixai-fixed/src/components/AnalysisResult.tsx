import { motion, AnimatePresence } from 'framer-motion';
import { TrendingUp, TrendingDown, Shield, Target, Zap, AlertTriangle, Brain, Activity, BarChart3, GitBranch, ChevronDown, ChevronUp, Layers, Eye, Gauge, Crosshair } from 'lucide-react';
import { AnalysisResult as AnalysisResultType } from '@/types';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

interface AnalysisResultProps {
  result: AnalysisResultType;
  onNewAnalysis?: () => void;
}

function ExpandableCard({ 
  icon: Icon, iconColor, title, badge, children, defaultOpen = false, glowColor, delay = 0,
}: { 
  icon: any; iconColor: string; title: string; badge?: string; children: React.ReactNode; 
  defaultOpen?: boolean; glowColor?: string; delay?: number;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className={`rounded-xl overflow-hidden border border-border/20 ${glowColor || 'bg-card/60'} backdrop-blur-md`}
    >
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-white/[0.02] transition-colors"
      >
        <div className="flex items-center gap-2.5">
          <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${iconColor}`}>
            <Icon className="w-3.5 h-3.5" />
          </div>
          <span className="text-[11px] font-bold uppercase tracking-[0.15em] text-foreground/80">{title}</span>
          {badge && (
            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-primary/10 text-primary border border-primary/20">
              {badge}
            </span>
          )}
        </div>
        <motion.div animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown className="w-3.5 h-3.5 text-muted-foreground/60" />
        </motion.div>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25 }}
            className="border-t border-border/10"
          >
            <div className="px-4 py-3.5">{children}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export function AnalysisResult({ result, onNewAnalysis }: AnalysisResultProps) {
  const isCall = result.signal === 'CALL';
  const isNoSignal = result.signal === 'NO SIGNAL';

  if (isNoSignal || !result.isValid) {
    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mx-4 mt-6 space-y-4 pb-24">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="flex flex-col items-center py-10 rounded-2xl border border-warning/20 bg-gradient-to-b from-warning/5 to-transparent"
        >
          <motion.div
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ repeat: Infinity, duration: 2.5 }}
            className="w-16 h-16 rounded-2xl bg-warning/10 border border-warning/30 flex items-center justify-center mb-4"
          >
            <AlertTriangle className="w-8 h-8 text-warning" />
          </motion.div>
          <span className="text-3xl font-black text-warning tracking-wider mb-2">NO SIGNAL</span>
          <p className="text-sm text-muted-foreground text-center max-w-[280px] leading-relaxed">
            {result.analysis}
          </p>
        </motion.div>
        {onNewAnalysis && (
          <Button onClick={onNewAnalysis} variant="outline" className="w-full py-5 rounded-xl border-border/40">
            New Analysis
          </Button>
        )}
      </motion.div>
    );
  }

  const matchLabel = result.matchStatus === 'DUAL_CONFIRMED' ? '🔗 DUAL CONFIRMED'
    : result.matchStatus === 'AI_OVERRIDE' ? '🧠 AI OVERRIDE'
    : result.matchStatus === 'PILLAR_OVERRIDE' ? '🏛️ PILLAR OVERRIDE'
    : result.matchStatus === 'PILLAR_ONLY' ? '🏛️ PILLAR ONLY'
    : result.matchStatus === 'AI_ONLY' ? '🧠 AI ONLY' : null;

  const signalGradient = isCall
    ? 'from-emerald-500/30 via-emerald-500/10 to-transparent'
    : 'from-red-500/30 via-red-500/10 to-transparent';

  const signalBorder = isCall ? 'border-emerald-500/40' : 'border-red-500/40';
  const signalText = isCall ? 'text-emerald-300' : 'text-red-300';
  const signalBg = isCall ? 'bg-emerald-500' : 'bg-red-500';

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mx-4 mt-4 space-y-2.5 pb-24">
      
      {/* ═══ HERO SIGNAL ═══ */}
      <motion.div
        initial={{ opacity: 0, scale: 0.92 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ type: "spring", stiffness: 180, damping: 20 }}
        className={`rounded-2xl overflow-hidden border ${signalBorder} relative`}
      >
        {/* Scanline effect */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <motion.div
            animate={{ y: ['-100%', '100%'] }}
            transition={{ repeat: Infinity, duration: 4, ease: 'linear' }}
            className={`absolute inset-x-0 h-px ${signalBg}/20`}
          />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-card/80 backdrop-blur-sm border-b border-border/15">
          <div className="flex items-center gap-2">
            <div className={`w-1.5 h-1.5 rounded-full ${signalBg} animate-pulse`} />
            <span className="text-[10px] font-black tracking-[0.2em] text-foreground/60">AI SIGNAL</span>
          </div>
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/8 border border-emerald-500/20">
            <div className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[9px] text-emerald-400 font-bold tracking-wider">LIVE</span>
          </div>
        </div>

        {/* Signal display */}
        <div className={`relative px-6 py-8 bg-gradient-to-b ${signalGradient}`}>
          {/* Extra glow layer behind the signal */}
          <div className={`absolute inset-0 ${isCall ? 'bg-emerald-500/[0.06]' : 'bg-red-500/[0.06]'} rounded-b-2xl`} />
          <div className="flex flex-col items-center relative z-10">
            {/* Direction icon */}
            <motion.div
              initial={{ scale: 0, rotate: -90 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 0.15, type: "spring", stiffness: 200 }}
              className="relative mb-3"
            >
              <div className={`w-16 h-16 rounded-2xl flex items-center justify-center border-2 ${signalBorder} ${isCall ? 'bg-emerald-500/15' : 'bg-red-500/15'} backdrop-blur-sm`}>
                <motion.div
                  animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0, 0.3] }}
                  transition={{ repeat: Infinity, duration: 2.5 }}
                  className={`absolute inset-0 rounded-2xl border-2 ${signalBorder}`}
                />
                {isCall ? <TrendingUp className="w-8 h-8 text-emerald-300" /> : <TrendingDown className="w-8 h-8 text-red-300" />}
              </div>
            </motion.div>

            {/* Signal text */}
            <motion.div
              initial={{ y: 15, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.25 }}
              className="text-center"
            >
              <span
                className={`text-4xl font-black tracking-[0.15em] ${signalText}`}
                style={{ textShadow: isCall ? '0 0 40px rgba(52,211,153,0.5), 0 0 80px rgba(52,211,153,0.2)' : '0 0 40px rgba(248,113,113,0.5), 0 0 80px rgba(248,113,113,0.2)' }}
              >
                {result.signal}
              </span>
              <div className="text-[9px] text-muted-foreground/60 mt-1 uppercase tracking-[0.25em] font-medium">
                Next Candle Prediction
              </div>
            </motion.div>

            {/* Tags */}
            <div className="flex items-center gap-1.5 mt-4">
              <span className="px-2.5 py-1 rounded-lg bg-card/80 border border-border/20 text-[10px] font-bold text-foreground/70 tracking-wider">
                {result.pair}
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-primary/8 border border-primary/15 text-[10px] font-bold text-primary tracking-wider">
                {result.market}
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-card/80 border border-border/20 text-[10px] font-bold text-foreground/50 tracking-wider">
                {result.timeframe}
              </span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* ═══ MATCH STATUS BADGE ═══ */}
      {matchLabel && (
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className={`rounded-xl px-4 py-2.5 flex items-center gap-2 border ${
            result.matchStatus === 'DUAL_CONFIRMED'
              ? 'bg-emerald-500/5 border-emerald-500/20'
              : 'bg-amber-500/5 border-amber-500/20'
          }`}
        >
          <span className={`text-xs font-bold tracking-wide ${
            result.matchStatus === 'DUAL_CONFIRMED' ? 'text-emerald-400' : 'text-amber-400'
          }`}>
            {matchLabel}
          </span>
        </motion.div>
      )}

      {/* ═══ CONFIDENCE METER ═══ */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25 }}
        className="rounded-xl p-3.5 bg-card/60 backdrop-blur-md border border-border/15"
      >
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2">
            <Gauge className="w-3.5 h-3.5 text-muted-foreground/50" />
            <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-foreground/50">Confidence</span>
          </div>
          <div className="flex items-baseline gap-1">
            <span className={`text-2xl font-black tabular-nums ${
              result.confidence >= 80 ? 'text-emerald-400' : result.confidence >= 65 ? 'text-amber-400' : 'text-red-400'
            }`}>
              {result.confidence}
            </span>
            <span className="text-xs text-muted-foreground/40 font-bold">%</span>
          </div>
        </div>
        <div className="h-2 bg-secondary/30 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${result.confidence}%` }}
            transition={{ delay: 0.4, duration: 1.2, ease: "easeOut" }}
            className={`h-full rounded-full ${
              result.confidence >= 80 ? 'bg-gradient-to-r from-emerald-600 to-emerald-400'
              : result.confidence >= 65 ? 'bg-gradient-to-r from-amber-600 to-amber-400'
              : 'bg-gradient-to-r from-red-600 to-red-400'
            }`}
          />
        </div>
        <div className="flex justify-between mt-1.5">
          <span className="text-[9px] text-muted-foreground/40">0</span>
          <span className={`text-[9px] font-bold ${
            result.confidence >= 80 ? 'text-emerald-400' : result.confidence >= 65 ? 'text-amber-400' : 'text-red-400'
          }`}>{result.confidenceLevel}</span>
          <span className="text-[9px] text-muted-foreground/40">100</span>
        </div>
      </motion.div>

      {/* ═══ S/R LEVELS ═══ */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="rounded-xl p-3.5 bg-card/60 backdrop-blur-md border border-border/15"
      >
        <div className="flex items-center gap-2 mb-3">
          <Crosshair className="w-3.5 h-3.5 text-blue-400/60" />
          <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-foreground/50">Key Levels</span>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <div className="rounded-lg bg-emerald-500/5 border border-emerald-500/15 p-2.5 text-center">
            <span className="text-[9px] text-muted-foreground/50 uppercase tracking-wider block mb-0.5">Support</span>
            <span className="text-[11px] font-mono font-black text-emerald-400">{result.support > 0 ? result.support.toFixed(5) : '—'}</span>
          </div>
          <div className="rounded-lg bg-blue-500/5 border border-blue-500/15 p-2.5 text-center">
            <span className="text-[9px] text-muted-foreground/50 uppercase tracking-wider block mb-0.5">Entry</span>
            <span className="text-[11px] font-mono font-black text-blue-400">{result.entryPrice > 0 ? result.entryPrice.toFixed(5) : '—'}</span>
          </div>
          <div className="rounded-lg bg-red-500/5 border border-red-500/15 p-2.5 text-center">
            <span className="text-[9px] text-muted-foreground/50 uppercase tracking-wider block mb-0.5">Resistance</span>
            <span className="text-[11px] font-mono font-black text-red-400">{result.resistance > 0 ? result.resistance.toFixed(5) : '—'}</span>
          </div>
        </div>
      </motion.div>

      {/* ═══ AI ANALYSIS CARDS ═══ */}
      {result.aiAnalysis?.trend && (
        <ExpandableCard
          icon={Activity} iconColor="bg-cyan-500/10 text-cyan-400" title="Trend Analysis"
          badge="STEP 1" defaultOpen={true} delay={0.35}
        >
          <p className="text-[11px] text-muted-foreground/80 leading-[1.7] whitespace-pre-wrap">
            {result.aiAnalysis.trend}
          </p>
        </ExpandableCard>
      )}

      {result.aiAnalysis?.structure && (
        <ExpandableCard
          icon={GitBranch} iconColor="bg-teal-500/10 text-teal-400" title="Market Structure"
          badge="STEP 2" delay={0.38}
        >
          <p className="text-[11px] text-muted-foreground/80 leading-[1.7] whitespace-pre-wrap">
            {result.aiAnalysis.structure}
          </p>
        </ExpandableCard>
      )}

      {result.aiAnalysis?.momentum && (
        <ExpandableCard
          icon={Zap} iconColor="bg-amber-500/10 text-amber-400" title="Momentum"
          badge="STEP 3" delay={0.41}
        >
          <p className="text-[11px] text-muted-foreground/80 leading-[1.7] whitespace-pre-wrap">
            {result.aiAnalysis.momentum}
          </p>
        </ExpandableCard>
      )}

      {result.aiAnalysis?.supportResistance && (
        <ExpandableCard
          icon={Shield} iconColor="bg-blue-500/10 text-blue-400" title="S/R & Liquidity"
          badge="STEP 4-5" delay={0.44}
        >
          <p className="text-[11px] text-muted-foreground/80 leading-[1.7] whitespace-pre-wrap">
            {result.aiAnalysis.supportResistance}
          </p>
        </ExpandableCard>
      )}

      {result.aiAnalysis?.candlePattern && (
        <ExpandableCard
          icon={BarChart3} iconColor="bg-purple-500/10 text-purple-400" title="Candle Patterns"
          badge="STEP 10" delay={0.47}
        >
          <p className="text-[11px] text-muted-foreground/80 leading-[1.7] whitespace-pre-wrap">
            {result.aiAnalysis.candlePattern}
          </p>
        </ExpandableCard>
      )}

      {/* ═══ 4-PILLAR ANALYSIS ═══ */}
      {result.pillarAnalysis && (
        <ExpandableCard
          icon={Layers} iconColor="bg-primary/10 text-primary" title="4-Pillar Analysis"
          glowColor="bg-primary/[0.03]" delay={0.5}
        >
          <div className="space-y-2">
            <div className="flex justify-between items-center py-1.5 px-2 rounded-lg bg-secondary/20">
              <span className="text-[10px] text-muted-foreground/60 font-medium">Active Pillar</span>
              <span className="text-[10px] font-black text-primary">{result.pillarAnalysis.pillar || 'N/A'}</span>
            </div>
            <div className="flex justify-between items-center py-1.5 px-2 rounded-lg bg-secondary/20">
              <span className="text-[10px] text-muted-foreground/60 font-medium">Trend</span>
              <span className={`text-[10px] font-black ${
                result.pillarAnalysis.trend?.includes('UP') ? 'text-emerald-400'
                : result.pillarAnalysis.trend?.includes('DOWN') ? 'text-red-400' : 'text-amber-400'
              }`}>{result.pillarAnalysis.trend || 'RANGING'}</span>
            </div>
            {result.pillarAnalysis.lockedDirection && (
              <div className="flex justify-between items-center py-1.5 px-2 rounded-lg bg-secondary/20">
                <span className="text-[10px] text-muted-foreground/60 font-medium">Direction Lock</span>
                <span className={`text-[10px] font-black px-2 py-0.5 rounded-md ${
                  result.pillarAnalysis.lockedDirection === 'CALL'
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    : 'bg-red-500/10 text-red-400 border border-red-500/20'
                }`}>{result.pillarAnalysis.lockedDirection} ONLY</span>
              </div>
            )}
            <div className="flex justify-between items-center py-1.5 px-2 rounded-lg bg-secondary/20">
              <span className="text-[10px] text-muted-foreground/60 font-medium">Gate Filter</span>
              <span className="text-[10px] font-bold text-muted-foreground/50">
                {result.pillarAnalysis.gatedStrategies}/{result.pillarAnalysis.totalStrategies} filtered
              </span>
            </div>
          </div>
        </ExpandableCard>
      )}

      {/* ═══ AI REASONING — FULL DISPLAY ═══ */}
      {result.aiAnalysis?.reasoning && (
        <ExpandableCard
          icon={Brain} iconColor="bg-violet-500/10 text-violet-400" title="AI Reasoning"
          badge="V7" defaultOpen={true}
          glowColor="bg-violet-500/[0.02]" delay={0.55}
        >
          <p className="text-[11px] text-muted-foreground/80 leading-[1.7] whitespace-pre-wrap font-mono">
            {result.aiAnalysis.reasoning}
          </p>
        </ExpandableCard>
      )}

      {/* ═══ NEW ANALYSIS ═══ */}
      {onNewAnalysis && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.65 }}>
          <Button
            onClick={onNewAnalysis}
            variant="outline"
            className="w-full py-5 rounded-xl text-sm font-bold border-border/20 hover:bg-secondary/30 transition-all"
          >
            New Analysis
          </Button>
        </motion.div>
      )}
    </motion.div>
  );
}
