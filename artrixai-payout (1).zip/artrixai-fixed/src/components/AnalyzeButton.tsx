import { motion } from 'framer-motion';
import { Zap, Loader2, CheckCircle } from 'lucide-react';
import { useState, useEffect } from 'react';

interface AnalyzeButtonProps {
  isLoading: boolean;
  disabled: boolean;
  onClick: () => void;
  isComplete?: boolean;
}

export function AnalyzeButton({ isLoading, disabled, onClick, isComplete = false }: AnalyzeButtonProps) {
  const [elapsedTime, setElapsedTime] = useState(1);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    
    if (isLoading) {
      setElapsedTime(1);
      interval = setInterval(() => {
        setElapsedTime(prev => prev + 1);
      }, 1000);
    } else {
      setElapsedTime(1);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isLoading]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="mx-4 mt-4"
    >
      <motion.button
        whileHover={{ scale: disabled ? 1 : 1.02 }}
        whileTap={{ scale: disabled ? 1 : 0.98 }}
        onClick={onClick}
        disabled={disabled || isLoading}
        className={`w-full py-4 rounded-xl font-semibold text-base flex items-center justify-center gap-2 transition-all ${
          isComplete
            ? 'bg-green-500 text-white'
            : disabled
            ? 'bg-muted text-muted-foreground cursor-not-allowed'
            : 'bg-primary text-primary-foreground btn-glow'
        }`}
      >
        {isComplete ? (
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="flex items-center gap-2"
          >
            <CheckCircle className="w-5 h-5" />
            <span>Analysis Complete</span>
          </motion.div>
        ) : isLoading ? (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center gap-2"
          >
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Analyze Chart {elapsedTime}s</span>
          </motion.div>
        ) : (
          <>
            <Zap className="w-5 h-5" />
            <span>Analyze Chart</span>
          </>
        )}
      </motion.button>
    </motion.div>
  );
}
