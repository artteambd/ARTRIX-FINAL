import { motion } from 'framer-motion';
import { Image, History, TrendingUp, Activity, Sparkles } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';

interface BottomNavProps {
  activeTab: 'gallery' | 'camera' | 'history';
  onTabChange: (tab: 'gallery' | 'camera' | 'history') => void;
  onUpload: () => void;
}

export function BottomNav({ activeTab, onTabChange, onUpload }: BottomNavProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const isLiveSignalPage = location.pathname === '/live-signal';
  const isFutureSignalPage = location.pathname === '/future-signal';
  const isStatusPage = location.pathname === '/status';

  return (
    <motion.nav
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ type: "spring", stiffness: 200, damping: 25 }}
      className="fixed bottom-0 left-0 right-0 z-50"
    >
      <div className="bg-card/95 backdrop-blur-xl border-t border-primary/20 px-4 py-4">
        <div className="flex items-center justify-around max-w-md mx-auto">
          <motion.button
            whileHover={{ scale: 1.1, y: -2 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => {
              if (isLiveSignalPage || isStatusPage || isFutureSignalPage) {
                navigate('/dashboard');
              } else {
                onTabChange('gallery');
                onUpload();
              }
            }}
            className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all duration-300 ${
              activeTab === 'gallery' && !isLiveSignalPage && !isStatusPage && !isFutureSignalPage ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Image className="w-5 h-5" />
            <span className="text-xs font-medium">Gallery</span>
          </motion.button>

          {/* Status Button */}
          <motion.button
            whileHover={{ scale: 1.1, y: -2 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => navigate('/status')}
            className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all duration-300 ${
              isStatusPage ? 'text-success' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Activity className="w-5 h-5" />
            <span className="text-xs font-medium">Status</span>
          </motion.button>

          {/* Live Signal Center Button */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate('/live-signal')}
            className="relative -mt-6"
          >
            <motion.div 
              className={`w-14 h-14 rounded-full flex items-center justify-center ${
                isLiveSignalPage 
                  ? 'bg-gradient-to-br from-success to-success/70' 
                  : 'bg-gradient-to-br from-primary to-primary/70'
              }`}
              animate={{ 
                boxShadow: isLiveSignalPage ? [
                  '0 0 20px hsl(150 100% 45% / 0.4)',
                  '0 0 35px hsl(150 100% 45% / 0.6)',
                  '0 0 20px hsl(150 100% 45% / 0.4)'
                ] : [
                  '0 0 20px hsl(185 100% 50% / 0.4)',
                  '0 0 35px hsl(185 100% 50% / 0.6)',
                  '0 0 20px hsl(185 100% 50% / 0.4)'
                ]
              }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            >
              <TrendingUp className={`w-6 h-6 ${isLiveSignalPage ? 'text-success-foreground' : 'text-primary-foreground'}`} />
            </motion.div>
            <span className={`absolute -bottom-5 left-1/2 -translate-x-1/2 text-xs font-medium whitespace-nowrap ${
              isLiveSignalPage ? 'text-success' : 'text-primary'
            }`}>
              Live Signal
            </span>
          </motion.button>

          {/* Future Signal Button */}
          <motion.button
            whileHover={{ scale: 1.1, y: -2 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => navigate('/future-signal')}
            className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all duration-300 ${
              isFutureSignalPage ? 'text-cyan-400' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Sparkles className={`w-5 h-5 ${isFutureSignalPage ? 'text-cyan-400' : ''}`} />
            <span className={`text-xs font-medium ${isFutureSignalPage ? 'text-cyan-400' : ''}`}>Future</span>
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.1, y: -2 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => {
              if (isLiveSignalPage || isStatusPage || isFutureSignalPage) {
                navigate('/dashboard');
              }
              onTabChange('history');
            }}
            className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all duration-300 ${
              activeTab === 'history' && !isLiveSignalPage && !isStatusPage && !isFutureSignalPage ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <History className="w-5 h-5" />
            <span className="text-xs font-medium">History</span>
          </motion.button>
        </div>
      </div>
    </motion.nav>
  );
}
