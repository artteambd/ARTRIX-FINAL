import { motion } from 'framer-motion';
import { AlertTriangle, ExternalLink, Gift, CreditCard, MessageCircle } from 'lucide-react';

interface CreditExhaustedBannerProps {
  onBuyCredits: () => void;
}

export default function CreditExhaustedBanner({ onBuyCredits }: CreditExhaustedBannerProps) {
  const REFERRAL_LINK = 'https://broker-qx.pro/sign-up/?lid=1648049';
  const MIN_DEPOSIT = '$20';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-panel p-5 rounded-2xl border border-warning/30 bg-gradient-to-br from-warning/10 to-warning/5"
    >
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-xl bg-warning/20 flex items-center justify-center flex-shrink-0">
          <AlertTriangle className="w-6 h-6 text-warning" />
        </div>
        
        <div className="flex-1 space-y-4">
          <div>
            <h3 className="text-lg font-bold text-foreground mb-1">Credits Exhausted</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Your account credits have been exhausted. To continue using the service, please purchase credits, 
              or create an account using our link, make a deposit, and inbox us. You will receive free credits every month.
            </p>
          </div>

          <div className="space-y-3">
            {/* Option 1: Buy Credits */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onBuyCredits}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-primary to-primary/80 text-primary-foreground font-semibold flex items-center justify-center gap-2 shadow-lg"
            >
              <CreditCard className="w-5 h-5" />
              <span>Purchase Credits</span>
            </motion.button>

            {/* Option 2: Free Credits via Referral */}
            <div className="p-4 rounded-xl bg-card/50 border border-border/50 space-y-3">
              <div className="flex items-center gap-2">
                <Gift className="w-5 h-5 text-call" />
                <span className="font-semibold text-call">Get Free Credits Monthly</span>
              </div>
              
              <ol className="text-sm text-muted-foreground space-y-2 ml-1">
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-primary/20 text-primary text-xs flex items-center justify-center flex-shrink-0 mt-0.5">1</span>
                  <span>Create an account using our registration link</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-primary/20 text-primary text-xs flex items-center justify-center flex-shrink-0 mt-0.5">2</span>
                  <span>Make a minimum deposit of <strong className="text-foreground">{MIN_DEPOSIT}</strong></span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-primary/20 text-primary text-xs flex items-center justify-center flex-shrink-0 mt-0.5">3</span>
                  <span>Contact us with your account details</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-call/20 text-call text-xs flex items-center justify-center flex-shrink-0 mt-0.5">✓</span>
                  <span className="text-call">Receive free credits every month!</span>
                </li>
              </ol>

              <motion.a
                href={REFERRAL_LINK}
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-call to-call/80 text-call-foreground font-semibold flex items-center justify-center gap-2 shadow-lg"
              >
                <ExternalLink className="w-5 h-5" />
                <span>Register Now</span>
              </motion.a>

              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <MessageCircle className="w-4 h-4" />
                <span>After deposit, contact us via Telegram or WhatsApp</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
