import { motion, AnimatePresence } from 'framer-motion';
import { useEffect, useState, useRef } from 'react';

// 62-step elite protocol organized into 12 categories
const ANALYSIS_CATEGORIES = [
  {
    name: '🌊 TREND & REGIME',
    color: '#06b6d4',
    steps: [
      '🏗️ EMA Stack Hierarchy + Spacing Analysis',
      '📐 EMA20 Slope + Second Derivative',
      '🔺 Price Structure — BOS/CHoCH Detection',
      '📏 Linear Regression + Channel Position',
      '⚡ ADX Trend Strength + DI Split',
      '🎯 Final Market Regime Verdict',
    ],
  },
  {
    name: '🚀 MOMENTUM BATTERY',
    color: '#8b5cf6',
    steps: [
      '🧭 RSI Multi-Period Gradient + Divergence',
      '⚙️ Stochastic Zone + Crossover Timing',
      '📊 MACD Histogram Momentum Dynamics',
      '💥 Rate of Change Burst Detection',
      '🔋 CCI + Williams %R Dual Extreme',
      '🔍 Multi-Oscillator Divergence Scan',
    ],
  },
  {
    name: '💰 VOLUME & FLOW',
    color: '#f59e0b',
    steps: [
      '📦 Volume Spike + Institutional Footprint',
      '🏋️ OBV + Accumulation/Distribution Line',
      '💎 Money Flow Index Pressure Reading',
      '🔥 Volume Climax & Exhaustion Detection',
    ],
  },
  {
    name: '🕯️ CANDLE PATTERNS',
    color: '#ef4444',
    steps: [
      '🔨 Single-Candle Reversal + Shadow Trap',
      '🐉 Engulfing + Institutional Validation',
      '📌 Pin Bar + Rejection Cluster Analysis',
      '🗜️ Inside Bar Compression + Breakout',
      '🌅 Multi-Candle Formation Scoring',
    ],
  },
  {
    name: '🏰 KEY LEVELS',
    color: '#10b981',
    steps: [
      '🗺️ Dynamic S/R + Role Flip Detection',
      '📡 Bollinger Band + Walk-the-Band',
      '🔢 Fibonacci Confluence + Golden Pocket',
      '💎 Round Number + OTC Manipulation Risk',
    ],
  },
  {
    name: '🌡️ VOLATILITY & RISK',
    color: '#f97316',
    steps: [
      '📡 ATR Regime + Volatility Trend',
      '🔧 BB Squeeze Duration + Fire Direction',
      '🌀 Volatility Cycle Phase + Timing',
      '⚖️ Risk-Reward + Asymmetric Opportunity',
    ],
  },
  {
    name: '🏦 SMC & INSTITUTIONAL',
    color: '#ec4899',
    steps: [
      '🧱 Order Block Detection + Validity',
      '⚡ Fair Value Gap + Imbalance Mapping',
      '🔄 BOS/CHoCH + Structure Shift',
      '🕳️ Liquidity Void + Imbalance Zones',
      '🛡️ Mitigation + Breaker + Propulsion',
    ],
  },
  {
    name: '💧 LIQUIDITY & OTC TRAPS',
    color: '#14b8a6',
    steps: [
      '🎯 Liquidity Pool + EQH/EQL Mapping',
      '🕵️ Stop Hunt & Sweep Detection',
      '🎭 OTC Dealer Manipulation Patterns',
      '🕸️ Smart Money 7-Trap Matrix',
      '💡 Liquidity-Based Entry Optimization',
    ],
  },
  {
    name: '🧬 BACKTEST VALIDATION',
    color: '#3b82f6',
    steps: [
      '🔬 8-Factor Historical Pattern Match',
      '📈 Triple-Filtered Win Rate Analysis',
      '💥 Explosive Move AI Best-Entry',
      '🔄 Mean Reversion + SMC Validation',
    ],
  },
  {
    name: '🎯 MARKET CONDITION',
    color: '#a855f7',
    steps: [
      '🔎 10-Factor Condition Detection',
      '📈 Pure Uptrend + OB Entry',
      '📉 Pure Downtrend + OB Entry',
      '🔄 Pullback — Quad-Confluence Entry',
      '🔲 Wide Range — Liquidity Sweep Entry',
      '📏 Medium Range — Trap-Filtered Entry',
      '⚡ Micro Trend + SMC Alignment',
      '🌫️ FFLC — 4-Gate Breakout Only',
      '🚫 Choppy Market 5-Criteria Filter',
      '🎚️ Confidence Calibration + SMC Bonus',
      '⏰ Entry Time Optimization',
      '🛡️ Risk Summary + SMC Grade',
    ],
  },
  {
    name: '🔮 WYCKOFF & INSTITUTIONS',
    color: '#6366f1',
    steps: [
      '📊 Wyckoff 5-Phase Classification',
      '🧲 Spring & Upthrust Detection',
      '👤 Composite Man Intent Reading',
      '🏆 Wyckoff-SMC Institutional Synthesis',
    ],
  },
  {
    name: '👑 FINAL SYNTHESIS',
    color: '#eab308',
    steps: [
      '🔮 20-Dimension Weighted Confluence',
      '🛡️ 22-Point Anti-Loss Filter Battery',
      '🏆 Final Verdict — Elite Signal Generation',
    ],
  },
];

const TOTAL_STEPS = ANALYSIS_CATEGORIES.reduce((sum, cat) => sum + cat.steps.length, 0);

interface FutureSignalLoadingAnimationProps {
  progress: number;
  isComplete: boolean;
  statusText?: string;
  elapsedSeconds?: number;
  totalPairs?: number;
}

function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

export function FutureSignalLoadingAnimation({
  progress,
  isComplete,
  statusText,
  elapsedSeconds = 0,
  totalPairs = 0,
}: FutureSignalLoadingAnimationProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [activeCategory, setActiveCategory] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  const estimatedTotal = progress > 5 ? Math.round(elapsedSeconds / (progress / 100)) : 0;
  const estimatedRemaining = Math.max(0, estimatedTotal - elapsedSeconds);

  useEffect(() => {
    const targetStep = Math.min(Math.ceil((progress / 100) * TOTAL_STEPS), TOTAL_STEPS);
    if (targetStep > currentStep) {
      setCurrentStep(targetStep);
    }

    let stepCount = 0;
    for (let i = 0; i < ANALYSIS_CATEGORIES.length; i++) {
      stepCount += ANALYSIS_CATEGORIES[i].steps.length;
      if (targetStep <= stepCount) {
        setActiveCategory(i);
        break;
      }
    }
  }, [progress, currentStep]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [currentStep]);

  const currentColor = ANALYSIS_CATEGORIES[activeCategory]?.color || '#06b6d4';

  let stepsShown = 0;

  return (
    <div className="w-full max-w-md mx-auto p-4">
      {/* Neural Core Visualization */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex flex-col items-center mb-4"
      >
        <div className="relative w-24 h-24 flex items-center justify-center mb-3">
          <motion.div
            className="absolute inset-0 rounded-full"
            style={{ border: `2px solid ${currentColor}`, opacity: 0.3 }}
            animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.1, 0.3] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
          <motion.div
            className="absolute inset-2 rounded-full"
            style={{ border: `2px solid ${currentColor}`, opacity: 0.5 }}
            animate={{ scale: [1, 1.15, 1], opacity: [0.5, 0.2, 0.5] }}
            transition={{ duration: 1.5, repeat: Infinity, delay: 0.3 }}
          />
          <motion.div
            className="w-14 h-14 rounded-full flex items-center justify-center"
            style={{
              background: `radial-gradient(circle, ${currentColor}40, ${currentColor}10)`,
              boxShadow: `0 0 30px ${currentColor}60`,
            }}
            animate={{ boxShadow: [`0 0 20px ${currentColor}40`, `0 0 40px ${currentColor}80`, `0 0 20px ${currentColor}40`] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <span className="text-2xl">
              {isComplete ? '🏆' : activeCategory <= 1 ? '🧠' : activeCategory <= 3 ? '⚡' : activeCategory <= 5 ? '🔮' : activeCategory <= 7 ? '💧' : activeCategory <= 9 ? '🎯' : activeCategory <= 10 ? '🔮' : '👑'}
            </span>
          </motion.div>

          <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="46" fill="none" stroke={`${currentColor}20`} strokeWidth="3" />
            <motion.circle
              cx="50" cy="50" r="46" fill="none"
              stroke={currentColor}
              strokeWidth="3"
              strokeLinecap="round"
              strokeDasharray={`${Math.PI * 92}`}
              initial={{ strokeDashoffset: Math.PI * 92 }}
              animate={{ strokeDashoffset: Math.PI * 92 * (1 - progress / 100) }}
              transition={{ duration: 0.5 }}
            />
          </svg>
        </div>

        <motion.p
          className="text-sm font-bold font-mono tracking-wider"
          style={{ color: currentColor }}
          animate={{ opacity: [1, 0.6, 1] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          QUANTUM-NEXUS V14 ELITE
        </motion.p>
      </motion.div>

      {/* Category Progress Cards */}
      <div className="grid grid-cols-4 gap-1 mb-3">
        {ANALYSIS_CATEGORIES.map((cat, i) => {
          const catStart = ANALYSIS_CATEGORIES.slice(0, i).reduce((s, c) => s + c.steps.length, 0);
          const catEnd = catStart + cat.steps.length;
          const catProgress = currentStep >= catEnd ? 100 : currentStep > catStart ? ((currentStep - catStart) / cat.steps.length) * 100 : 0;
          const isActive = i === activeCategory;
          const isDone = catProgress >= 100;

          return (
            <motion.div
              key={i}
              className="rounded-lg p-1 text-center"
              style={{
                background: isDone ? `${cat.color}20` : isActive ? `${cat.color}15` : 'rgba(255,255,255,0.03)',
                border: `1px solid ${isDone ? cat.color + '60' : isActive ? cat.color + '40' : 'rgba(255,255,255,0.06)'}`,
              }}
              animate={isActive ? { borderColor: [`${cat.color}40`, `${cat.color}80`, `${cat.color}40`] } : {}}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              <div className="text-[9px] leading-none mb-0.5 truncate">{cat.name.split(' ')[0]}</div>
              <div className="h-1 rounded-full overflow-hidden" style={{ background: `${cat.color}15` }}>
                <motion.div
                  className="h-full rounded-full"
                  style={{ background: cat.color }}
                  initial={{ width: 0 }}
                  animate={{ width: `${catProgress}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>
              <div className="text-[8px] mt-0.5 font-mono" style={{ color: isDone ? cat.color : 'rgba(255,255,255,0.3)' }}>
                {isDone ? '✅' : `${Math.round(catProgress)}%`}
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Terminal Window */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-xl overflow-hidden border border-cyan-500/30 bg-background/95 backdrop-blur-sm"
        style={{ boxShadow: `0 0 40px ${currentColor}15` }}
      >
        <div className="flex items-center gap-2 px-4 py-2.5 border-b border-cyan-500/20 bg-background/80">
          <div className="flex gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-red-500" />
            <div className="w-2.5 h-2.5 rounded-full bg-yellow-500" />
            <div className="w-2.5 h-2.5 rounded-full bg-green-500" />
          </div>
          <span className="ml-2 font-semibold text-xs tracking-wider" style={{ color: currentColor }}>
            QUANTUM-NEXUS V14 ELITE — 62-Step Analysis
          </span>
        </div>

        <div
          ref={scrollRef}
          className="p-3 max-h-[240px] overflow-y-auto scrollbar-thin scrollbar-thumb-cyan-500/20 scrollbar-track-transparent"
        >
          <div className="space-y-0.5 font-mono text-[11px]">
            {ANALYSIS_CATEGORIES.map((cat, catIdx) => {
              const catStart = stepsShown;
              const catSteps = cat.steps.map((step, stepIdx) => {
                const globalIdx = catStart + stepIdx;
                const isVisible = globalIdx < currentStep;
                const isLatest = globalIdx === currentStep - 1;
                stepsShown++;

                if (!isVisible) return null;

                return (
                  <motion.div
                    key={`${catIdx}-${stepIdx}`}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.2 }}
                    className="flex items-center gap-1.5"
                  >
                    <span style={{ color: cat.color, fontSize: '8px' }}>●</span>
                    <span style={{ color: isLatest && !isComplete ? cat.color : 'rgba(255,255,255,0.4)' }}>
                      {step}
                    </span>
                    {isLatest && !isComplete && (
                      <motion.span
                        animate={{ opacity: [1, 0] }}
                        transition={{ duration: 0.5, repeat: Infinity }}
                        className="w-1.5 h-3 ml-0.5"
                        style={{ background: cat.color }}
                      />
                    )}
                  </motion.div>
                );
              });

              const hasVisible = catStart < currentStep;
              if (!hasVisible) return null;

              return (
                <div key={catIdx} className="mb-1">
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="font-bold text-[10px] mb-0.5 tracking-wider"
                    style={{ color: cat.color }}
                  >
                    ━━ {cat.name} ━━
                  </motion.div>
                  {catSteps}
                </div>
              );
            })}
          </div>
        </div>

        <div className="px-4 pb-3 pt-2 border-t" style={{ borderColor: `${currentColor}20` }}>
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-muted-foreground text-xs font-medium font-mono">
              {statusText || `Step ${currentStep}/${TOTAL_STEPS}`}
            </span>
            <span className="font-bold text-xs font-mono" style={{ color: currentColor }}>
              {Math.round(progress)}%
            </span>
          </div>
          <div className="h-2 bg-muted/30 rounded-full overflow-hidden">
            <motion.div
              className="h-full rounded-full"
              style={{ background: `linear-gradient(90deg, ${currentColor}, ${ANALYSIS_CATEGORIES[Math.min(activeCategory + 1, ANALYSIS_CATEGORIES.length - 1)]?.color || currentColor})` }}
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>

          <div className="flex items-center justify-between mt-2 text-[10px] font-mono">
            <span className="text-muted-foreground">
              🕐 Elapsed: <span style={{ color: currentColor }}>{formatTime(elapsedSeconds)}</span>
            </span>
            {!isComplete && estimatedRemaining > 0 && (
              <span className="text-muted-foreground">
                🔮 Remaining: <span style={{ color: currentColor }}>~{formatTime(estimatedRemaining)}</span>
              </span>
            )}
            {isComplete && (
              <span className="text-green-400 font-bold">🏆 Complete in {formatTime(elapsedSeconds)}</span>
            )}
          </div>
          {totalPairs > 0 && (
            <div className="mt-1 text-[10px] font-mono text-muted-foreground">
              🧬 Analyzing {totalPairs} pairs × 9,000+ candles • SMC + Wyckoff + Liquidity
            </div>
          )}
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="flex items-center justify-center gap-2 mt-3"
      >
        <motion.div
          className="w-2 h-2 rounded-full"
          style={{ background: isComplete ? '#4ade80' : currentColor }}
          animate={isComplete ? {} : { opacity: [1, 0.3, 1], scale: [1, 1.2, 1] }}
          transition={{ duration: 0.8, repeat: Infinity }}
        />
        <span className="text-xs font-mono font-bold" style={{ color: isComplete ? '#4ade80' : currentColor }}>
          {isComplete ? '🏆 Elite Analysis Complete — Signals Ready' : '🏦 Institutional-Grade AI Analysis in Progress...'}
        </span>
      </motion.div>
    </div>
  );
}
