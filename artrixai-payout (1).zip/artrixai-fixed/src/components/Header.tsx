import { motion } from 'framer-motion';
import { TrendingUp, Shield, Zap, User } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { NotificationCenter } from './NotificationCenter';

export function Header() {
  const { user, refreshUser } = useAuth();
  const navigate = useNavigate();

  const handleProfileClick = () => {
    navigate('/profile');
  };

  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center justify-between px-4 sm:px-6 lg:px-8 py-3 sm:py-4 max-w-7xl mx-auto w-full border-b border-border/30"
    >
      {/* Logo Section */}
      <div className="flex items-center gap-3">
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-primary/20 border border-primary/50 flex items-center justify-center"
        >
          <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
        </motion.div>
        <div>
          <h1 className="text-xl sm:text-2xl font-bold">
            <span className="text-foreground">ARTRIX</span>
            <span className="text-primary ml-1">AI</span>
          </h1>
          <span className="text-[10px] sm:text-xs font-medium text-muted-foreground tracking-wider">
            Ultimate Analyst • Enterprise Edition
          </span>
        </div>
      </div>

      {/* Right Section */}
      <div className="flex items-center gap-3 sm:gap-4">
        {/* License Status */}
        <div className="hidden sm:flex items-center gap-2">
          <Shield className="w-4 h-4 text-call" />
          <span className="text-sm font-mono text-call">LICENSE: VALID</span>
        </div>

        {/* Premium Access */}
        <div className="hidden sm:flex items-center gap-2">
          <Zap className="w-4 h-4 text-warning" />
          <span className="text-sm font-semibold text-warning">PREMIUM ACCESS</span>
        </div>

        <NotificationCenter />

        {/* User Profile */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleProfileClick}
          className="flex items-center gap-2 px-3 py-2 rounded-lg bg-secondary/50 border border-border/50 hover:border-primary/30 transition-all"
        >
          <span className="text-sm text-muted-foreground">Admin:</span>
          <span className="text-sm font-medium text-foreground">TRAD WITH JAKARIA</span>
        </motion.button>
      </div>
    </motion.header>
  );
}