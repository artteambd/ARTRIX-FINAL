import { motion } from 'framer-motion';
import { AlertTriangle, Clock, ShieldCheck, XCircle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { isLicenseExpired, isLicenseExpiringSoon, getDaysRemaining, formatExpiryDate } from '@/lib/licenseUtils';

export function LicenseStatus() {
  const { user } = useAuth();

  if (!user || user.isAdmin || !user.expiresAt) {
    return null;
  }

  const expired = isLicenseExpired(user.expiresAt);
  const expiringSoon = isLicenseExpiringSoon(user.expiresAt);
  const daysRemaining = getDaysRemaining(user.expiresAt);

  if (expired) {
    return (
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mx-4 mb-4 p-4 rounded-xl bg-destructive/20 border border-destructive/50"
      >
        <div className="flex items-center gap-3">
          <XCircle className="w-6 h-6 text-destructive flex-shrink-0" />
          <div>
            <p className="font-semibold text-destructive">License Expired</p>
            <p className="text-sm text-destructive/80">
              Your license expired on {formatExpiryDate(user.expiresAt)}. 
              Please renew to continue using credits.
            </p>
          </div>
        </div>
      </motion.div>
    );
  }

  if (expiringSoon) {
    return (
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mx-4 mb-4 p-4 rounded-xl bg-put/20 border border-put/50"
      >
        <div className="flex items-center gap-3">
          <AlertTriangle className="w-6 h-6 text-put flex-shrink-0" />
          <div>
            <p className="font-semibold text-put">License Expiring Soon</p>
            <p className="text-sm text-put/80">
              {daysRemaining} day{daysRemaining !== 1 ? 's' : ''} remaining. 
              Expires on {formatExpiryDate(user.expiresAt)}.
            </p>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="mx-4 mb-4 p-3 rounded-xl bg-call/10 border border-call/30"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-call" />
          <span className="text-sm font-medium text-call">Active License</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Clock className="w-4 h-4" />
          <span>{daysRemaining} days left</span>
        </div>
      </div>
    </motion.div>
  );
}
