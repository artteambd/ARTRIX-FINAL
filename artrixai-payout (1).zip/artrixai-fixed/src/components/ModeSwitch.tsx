import { motion } from 'framer-motion';
import { Link, Target, Lock, BarChart3 } from 'lucide-react';

export function ModeSwitch() {
  const features = [
    { icon: Target, title: '90%+ Precision', subtitle: 'Multi-confirmation analysis' },
    { icon: Link, title: 'Real-time', subtitle: 'Instant chart processing' },
    { icon: Lock, title: 'Encrypted', subtitle: 'Secure data handling' },
    { icon: BarChart3, title: 'Price Action', subtitle: 'Advanced S&R detection' },
  ];

  return (
    <div className="mx-4 mb-6">
      {/* Enterprise Badge */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex justify-center mb-6"
      >
        <div className="flex items-center gap-2 px-4 py-2 rounded-full border border-primary/50 bg-primary/10">
          <Link className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium text-primary">Enterprise Edition Active</span>
        </div>
      </motion.div>

      {/* Hero Title */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="text-center mb-4"
      >
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-2">
          AI-POWERED
        </h2>
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-primary">
          CHART ANALYSIS
        </h2>
      </motion.div>

      {/* Subtitle */}
      <motion.p
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="text-center text-muted-foreground text-sm sm:text-base max-w-2xl mx-auto mb-8"
      >
        Upload any trading chart screenshot and receive professional-grade analysis
        with Candlestick Psychology, Price Action, and Volume Analysis.
      </motion.p>

      {/* Feature Cards */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4"
      >
        {features.map((feature, index) => (
          <div
            key={index}
            className="flex items-center gap-3 px-4 py-3 rounded-xl bg-secondary/30 border border-border/30"
          >
            <feature.icon className="w-5 h-5 text-primary flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-sm font-semibold text-foreground truncate">{feature.title}</p>
              <p className="text-xs text-muted-foreground truncate">{feature.subtitle}</p>
            </div>
          </div>
        ))}
      </motion.div>
    </div>
  );
}
