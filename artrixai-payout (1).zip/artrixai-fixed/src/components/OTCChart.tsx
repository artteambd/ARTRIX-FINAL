import { useEffect, useRef, useState, useCallback } from 'react';
import { createChart, ColorType, IChartApi, ISeriesApi, CandlestickData, LineData, Time, CandlestickSeries, LineSeries } from 'lightweight-charts';
import { motion } from 'framer-motion';
import { RefreshCw, Loader2, Wifi } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

const REALTIME_API_BASE = 'https://ikszeynptbmwkaaldfad.supabase.co/functions/v1/quotex-proxy';
const REALTIME_API_TOKEN = 'qx_jigmqd22eepdn09m9itahf7ipfy3ebvq';

// Convert our internal pair format to the realtime API format
// e.g. EURUSD_otc → EURUSD-OTCq, EURUSD-OTC → EURUSD-OTCq, EURUSD → EURUSD
const convertToRealtimePairFormat = (market: string): string => {
  // Handle underscore OTC format: EURUSD_otc → EURUSD-OTCq
  if (market.endsWith('_otc')) {
    const base = market.replace('_otc', '');
    return `${base}-OTCq`;
  }
  // Handle dash OTC format: EURUSD-OTC → EURUSD-OTCq
  if (market.endsWith('-OTC')) {
    return `${market}q`;
  }
  // Non-OTC pairs stay as-is
  return market;
};

interface OTCChartProps {
  market: string | null;
  onChartCapture?: (captureFunc: () => string | null) => void;
}

interface CandleData {
  time: Time;
  open: number;
  high: number;
  low: number;
  close: number;
}

// Calculate Simple Moving Average
const calculateSMA = (data: CandleData[], period: number): LineData[] => {
  const result: LineData[] = [];
  for (let i = period - 1; i < data.length; i++) {
    let sum = 0;
    for (let j = 0; j < period; j++) {
      sum += data[i - j].close;
    }
    result.push({
      time: data[i].time,
      value: sum / period,
    });
  }
  return result;
};

// Calculate Support and Resistance levels
const calculateSupportResistance = (data: CandleData[], lookback: number = 50) => {
  if (data.length < lookback) return { support: 0, resistance: 0 };
  
  const recentData = data.slice(-lookback);
  const lows = recentData.map(d => d.low);
  const highs = recentData.map(d => d.high);
  
  const support = Math.min(...lows);
  const resistance = Math.max(...highs);
  
  return { support, resistance };
};

export function OTCChart({ market, onChartCapture }: OTCChartProps) {
  const [containerEl, setContainerEl] = useState<HTMLDivElement | null>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candleSeriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);
  const ma20SeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
  const ma50SeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
  const supportLineRef = useRef<ISeriesApi<'Line'> | null>(null);
  const resistanceLineRef = useRef<ISeriesApi<'Line'> | null>(null);
  const candlesDataRef = useRef<CandleData[]>([]); // Track all candle data for real-time updates

  const [chartReady, setChartReady] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [lastCandleCount, setLastCandleCount] = useState<number | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);

  const isOtc = !!market?.endsWith('-OTC');

  const fetchChartData = useCallback(async () => {
    if (!market) return;
    if (!candleSeriesRef.current) {
      console.log('Chart not ready yet, skipping fetch');
      return;
    }

    setIsLoading(true);
    setError(null);

    let candles: CandleData[] = [];

    // Try primary source: edge function (M1 500 candles)
    try {
      console.log('[OTCChart] Fetching chart data for:', market);
      const { data, error: fnError } = await supabase.functions.invoke('live-signal', {
        body: { market, action: 'get-chart-data' },
      });

      if (!fnError && data?.success && Array.isArray(data?.candles) && data.candles.length > 0) {
        candles = data.candles
          .map((item: any) => {
            const ms = new Date(item.datetime || item.time).getTime();
            // Convert to UTC+6 (add 6 hours = 21600 seconds)
            const t = Math.floor(ms / 1000) + 21600;
            return {
              time: t as Time,
              open: Number(item.open),
              high: Number(item.high),
              low: Number(item.low),
              close: Number(item.close),
            };
          })
          .filter((c: CandleData) =>
            Number.isFinite(c.time as number) &&
            Number.isFinite(c.open) &&
            Number.isFinite(c.high) &&
            Number.isFinite(c.low) &&
            Number.isFinite(c.close) &&
            c.open > 0 && c.high > 0 && c.low > 0 && c.close > 0
          );
        console.log('[OTCChart] Primary API candles:', candles.length);
      } else {
        console.warn('[OTCChart] Primary API failed, trying fallback...');
      }
    } catch (err) {
      console.warn('[OTCChart] Primary API error, trying fallback...', err);
    }

    // Fallback: use real-time API with higher limit
    if (candles.length === 0) {
      try {
        const realtimePair = convertToRealtimePairFormat(market);
        const url = `${REALTIME_API_BASE}?symbol=${encodeURIComponent(realtimePair)}&interval=1m&limit=500:${REALTIME_API_TOKEN}`;
        const resp = await fetch(url);
        if (resp.ok) {
          const data = await resp.json();
          const rawCandles = data?.candles || data?.data || (Array.isArray(data) ? data : []);
          if (rawCandles.length > 0) {
            candles = rawCandles
              .map((raw: any) => ({
                // Convert to UTC+6 (+21600 seconds)
                time: (Number(raw.time) + 21600) as Time,
                open: Number(raw.open),
                high: Number(raw.high),
                low: Number(raw.low),
                close: Number(raw.close),
              }))
              .filter((c: CandleData) =>
                Number.isFinite(c.time as number) &&
                Number.isFinite(c.open) && c.open > 0 &&
                Number.isFinite(c.high) && c.high > 0 &&
                Number.isFinite(c.low) && c.low > 0 &&
                Number.isFinite(c.close) && c.close > 0
              );
            console.log('[OTCChart] Fallback API candles:', candles.length);
          }
        }
      } catch (fallbackErr) {
        console.warn('[OTCChart] Fallback API also failed:', fallbackErr);
      }
    }

    if (candles.length === 0) {
      setError('Data source temporarily unavailable. Please try again.');
      setIsLoading(false);
      setLastCandleCount(null);
      return;
    }

    // Sort candles by time (ascending)
    candles.sort((a, b) => (a.time as number) - (b.time as number));

    // Update chart
    candleSeriesRef.current?.setData(candles);
    candlesDataRef.current = candles;

    const ma20Data = calculateSMA(candles, 20);
    if (ma20Data.length > 0) ma20SeriesRef.current?.setData(ma20Data);

    const ma50Data = calculateSMA(candles, 50);
    if (ma50Data.length > 0) ma50SeriesRef.current?.setData(ma50Data);

    const { support, resistance } = calculateSupportResistance(candles);

    if (supportLineRef.current) {
      supportLineRef.current.setData([
        { time: candles[0].time, value: support },
        { time: candles[candles.length - 1].time, value: support },
      ]);
    }

    if (resistanceLineRef.current) {
      resistanceLineRef.current.setData([
        { time: candles[0].time, value: resistance },
        { time: candles[candles.length - 1].time, value: resistance },
      ]);
    }

    // Show last ~50 candles visible (like old chart), rest scrollable
    if (candles.length > 50) {
      const fromCandle = candles[candles.length - 50];
      const toCandle = candles[candles.length - 1];
      chartRef.current?.timeScale().setVisibleRange({
        from: fromCandle.time,
        to: toCandle.time,
      });
    } else {
      chartRef.current?.timeScale().fitContent();
    }
    setLastUpdate(new Date());
    setLastCandleCount(candles.length);
    setError(null);
    setIsLoading(false);
  }, [market]);

  useEffect(() => {
    // Clear previous market info so the badge always matches the selected market
    setLastCandleCount(null);
    setLastUpdate(null);
    setError(null);
  }, [market]);

  // Initialize chart (runs when the container is mounted)
  useEffect(() => {
    if (!containerEl) return;

    setError(null);

    let chart: IChartApi | null = null;

    try {
      const initialWidth = Math.max(containerEl.clientWidth, 320);

      chart = createChart(containerEl, {
        layout: {
          background: { type: ColorType.Solid, color: 'transparent' },
          textColor: '#9ca3af',
        },
        grid: {
          vertLines: { visible: false },
          horzLines: { visible: false },
        },
        width: initialWidth,
        height: window.innerWidth >= 768 ? 350 : 280,
        timeScale: {
          borderColor: 'rgba(34, 197, 94, 0.2)',
          timeVisible: true,
          secondsVisible: false,
          barSpacing: 12,
          minBarSpacing: 8,
        },
        rightPriceScale: {
          borderColor: 'rgba(34, 197, 94, 0.2)',
        },
        crosshair: {
          mode: 1,
          vertLine: {
            color: 'rgba(34, 197, 94, 0.4)',
            width: 1,
            style: 2,
          },
          horzLine: {
            color: 'rgba(34, 197, 94, 0.4)',
            width: 1,
            style: 2,
          },
        },
      });

      chartRef.current = chart;

      // Hide TradingView watermark/logo
      const styleEl = document.createElement('style');
      styleEl.textContent = `
        [data-ref="tv-attr-logo"],
        .tv-lightweight-charts a,
        .tv-lightweight-charts a[href*="tradingview"],
        a[href*="tradingview.com"] {
          display: none !important;
          visibility: hidden !important;
          opacity: 0 !important;
          pointer-events: none !important;
        }
      `;
      containerEl.appendChild(styleEl);

      const chartAny = chart as any;

      // Candlestick series (support both v5 addSeries API and older addCandlestickSeries API)
      const candleSeries =
        typeof chartAny.addSeries === 'function' && typeof CandlestickSeries !== 'undefined'
          ? chartAny.addSeries(CandlestickSeries, {
              upColor: '#00FF00',
              downColor: '#FF0000',
              borderUpColor: '#00FF00',
              borderDownColor: '#FF0000',
              wickUpColor: '#00FF00',
              wickDownColor: '#FF0000',
            })
          : typeof chartAny.addCandlestickSeries === 'function'
            ? chartAny.addCandlestickSeries({
                upColor: '#00FF00',
                downColor: '#FF0000',
                borderUpColor: '#00FF00',
                borderDownColor: '#FF0000',
                wickUpColor: '#00FF00',
                wickDownColor: '#FF0000',
              })
            : null;

      if (!candleSeries) throw new Error('Chart library not supported on this device');
      candleSeriesRef.current = candleSeries as ISeriesApi<'Candlestick'>;

      // Line series helper
      const addLine = (opts: any) => {
        if (typeof chartAny.addSeries === 'function' && typeof LineSeries !== 'undefined') {
          return chartAny.addSeries(LineSeries, opts);
        }
        if (typeof chartAny.addLineSeries === 'function') {
          return chartAny.addLineSeries(opts);
        }
        throw new Error('Line series not supported');
      };

      // MA20 line (yellow/gold)
      ma20SeriesRef.current = addLine({
        color: '#eab308',
        lineWidth: 1,
        priceLineVisible: false,
        lastValueVisible: false,
      }) as ISeriesApi<'Line'>;

      // MA50 line (blue)
      ma50SeriesRef.current = addLine({
        color: '#3b82f6',
        lineWidth: 1,
        priceLineVisible: false,
        lastValueVisible: false,
      }) as ISeriesApi<'Line'>;

      // Support line (green dotted)
      supportLineRef.current = addLine({
        color: '#22c55e',
        lineWidth: 1,
        lineStyle: 2, // Dotted
        priceLineVisible: false,
        lastValueVisible: false,
      }) as ISeriesApi<'Line'>;

      // Resistance line (red dotted)
      resistanceLineRef.current = addLine({
        color: '#ef4444',
        lineWidth: 1,
        lineStyle: 2, // Dotted
        priceLineVisible: false,
        lastValueVisible: false,
      }) as ISeriesApi<'Line'>;

      setChartReady(true);

      // Handle resize (important on mobile where initial width can be 0)
      const container = containerEl;
      const handleResize = () => {
        if (!chartRef.current) return;
        const width = container.clientWidth;
        if (width > 0) chartRef.current.applyOptions({ width });
      };

      const resizeObserver = typeof ResizeObserver !== 'undefined'
        ? new ResizeObserver(handleResize)
        : null;
      resizeObserver?.observe(container);

      window.addEventListener('resize', handleResize);
      requestAnimationFrame(handleResize);

      return () => {
        window.removeEventListener('resize', handleResize);
        resizeObserver?.disconnect();
        chart.remove();
        chartRef.current = null;
        candleSeriesRef.current = null;
        ma20SeriesRef.current = null;
        ma50SeriesRef.current = null;
        supportLineRef.current = null;
        resistanceLineRef.current = null;
        setChartReady(false);
      };
    } catch (e) {
      console.error('[OTCChart] Chart init error:', e);
      setError(e instanceof Error ? e.message : 'Failed to initialize chart');
      setChartReady(false);

      try {
        chart?.remove();
      } catch {
        // ignore
      }

      chartRef.current = null;
      candleSeriesRef.current = null;
      ma20SeriesRef.current = null;
      ma50SeriesRef.current = null;
      supportLineRef.current = null;
      resistanceLineRef.current = null;

      return;
    }
  }, [containerEl]);

  // Fetch data when market changes or chart becomes ready
  useEffect(() => {
    if (market && chartReady && candleSeriesRef.current) {
      fetchChartData();
    }
  }, [market, chartReady, fetchChartData]);

  // Auto-refresh every 70 seconds
  useEffect(() => {
    if (!market) return;
    
    const interval = setInterval(() => {
      fetchChartData();
    }, 70000);

    return () => clearInterval(interval);
  }, [market, fetchChartData]);

  // Real-time candle streaming via per-second API polling
  useEffect(() => {
    if (!market || !chartReady || !candleSeriesRef.current) return;

    const realtimePair = convertToRealtimePairFormat(market);
    let active = true;
    let consecutiveErrors = 0;

    const pollRealtime = async () => {
      if (!active || !candleSeriesRef.current) return;

      try {
        const url = `${REALTIME_API_BASE}?symbol=${encodeURIComponent(realtimePair)}&interval=1m&limit=3:${REALTIME_API_TOKEN}`;
        const resp = await fetch(url);
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        const data = await resp.json();

        if (!data?.candles?.length || !active) return;

        consecutiveErrors = 0;
        setIsStreaming(true);

        for (const raw of data.candles) {
          // Convert to UTC+6 (+21600 seconds)
          const t = (Number(raw.time) + 21600) as Time;
          const candle: CandleData = {
            time: t,
            open: Number(raw.open),
            high: Number(raw.high),
            low: Number(raw.low),
            close: Number(raw.close),
          };

          if (!Number.isFinite(candle.open) || candle.open <= 0) continue;

          const existingIdx = candlesDataRef.current.findIndex(
            c => (c.time as number) === (t as number)
          );

          if (existingIdx >= 0) {
            candlesDataRef.current[existingIdx] = candle;
          } else if ((t as number) > (candlesDataRef.current[candlesDataRef.current.length - 1]?.time as number || 0)) {
            candlesDataRef.current.push(candle);
            if (candlesDataRef.current.length > 600) {
              candlesDataRef.current.shift();
            }
          }

          try {
            candleSeriesRef.current?.update(candle as any);
          } catch {
            candleSeriesRef.current?.setData(candlesDataRef.current as any);
          }
        }

        const allCandles = candlesDataRef.current;
        if (allCandles.length >= 20 && ma20SeriesRef.current) {
          const last20 = allCandles.slice(-20);
          const maVal = last20.reduce((s, c) => s + c.close, 0) / 20;
          try { ma20SeriesRef.current.update({ time: allCandles[allCandles.length - 1].time, value: maVal }); } catch { /* */ }
        }
        if (allCandles.length >= 50 && ma50SeriesRef.current) {
          const last50 = allCandles.slice(-50);
          const maVal = last50.reduce((s, c) => s + c.close, 0) / 50;
          try { ma50SeriesRef.current.update({ time: allCandles[allCandles.length - 1].time, value: maVal }); } catch { /* */ }
        }

        setLastUpdate(new Date());
      } catch (err) {
        consecutiveErrors++;
        if (consecutiveErrors > 10) {
          console.warn('[OTCChart] Realtime polling paused after 10 errors');
          setIsStreaming(false);
        }
      }
    };

    const interval = setInterval(pollRealtime, 1000);
    pollRealtime();

    return () => {
      active = false;
      setIsStreaming(false);
      clearInterval(interval);
    };
  }, [market, chartReady]);


  // NOTE: lightweight-charts can render multiple canvases (price scale, time scale, panes).
  // Some devices/browsers return an incomplete canvas if we only grab the first one.
  // We therefore composite all canvases into one, then scale into a 1920x900 output.
  const captureChart = useCallback((): string | null => {
    console.log('[OTCChart] captureChart called, chartRef:', !!chartRef.current, 'containerEl:', !!containerEl);

    if (!chartRef.current) {
      console.error('[OTCChart] Chart reference is null');
      return null;
    }

    if (!containerEl) {
      console.error('[OTCChart] Container element is null');
      return null;
    }

    try {
      const chartAny = chartRef.current as any;

      // 1) Try official screenshot API first
      let baseCanvas: HTMLCanvasElement | null = null;
      if (typeof chartAny.takeScreenshot === 'function') {
        const shot = chartAny.takeScreenshot();
        if (shot && typeof shot.toDataURL === 'function') {
          baseCanvas = shot as HTMLCanvasElement;
        }
      }

      // 2) Fallback: composite all canvases in the container (more reliable on mobile)
      if (!baseCanvas) {
        const canvases = Array.from(containerEl.querySelectorAll('canvas')) as HTMLCanvasElement[];
        const valid = canvases.filter((c) => c.width > 0 && c.height > 0);
        console.log('[OTCChart] Canvas layers found:', valid.map((c) => `${c.width}x${c.height}`).join(', '));

        if (valid.length === 0) {
          console.error('[OTCChart] No canvases found to capture');
          return null;
        }

        const baseW = Math.max(...valid.map((c) => c.width));
        const baseH = Math.max(...valid.map((c) => c.height));

        const merged = document.createElement('canvas');
        merged.width = baseW;
        merged.height = baseH;
        const mctx = merged.getContext('2d');
        if (!mctx) return null;

        // Fill black background to match reference look
        mctx.fillStyle = '#000000';
        mctx.fillRect(0, 0, baseW, baseH);

        // Draw canvases in DOM order
        for (const c of valid) {
          mctx.drawImage(c, 0, 0);
        }

        baseCanvas = merged;
      }

      // 3) Scale into fixed landscape output (1920x900)
      const outW = 1920;
      const outH = 900;
      const out = document.createElement('canvas');
      out.width = outW;
      out.height = outH;
      const octx = out.getContext('2d');
      if (!octx) return null;

      octx.fillStyle = '#000000';
      octx.fillRect(0, 0, outW, outH);

      const scale = Math.min(outW / baseCanvas.width, outH / baseCanvas.height);
      const drawW = Math.round(baseCanvas.width * scale);
      const drawH = Math.round(baseCanvas.height * scale);
      const dx = Math.round((outW - drawW) / 2);
      const dy = Math.round((outH - drawH) / 2);

      octx.imageSmoothingEnabled = true;
      (octx as any).imageSmoothingQuality = 'high';
      octx.drawImage(baseCanvas, dx, dy, drawW, drawH);

      const dataUrl = out.toDataURL('image/png');
      console.log('[OTCChart] Screenshot captured successfully:', `${outW}x${outH}`, 'length:', dataUrl.length);
      return dataUrl;
    } catch (err) {
      console.error('[OTCChart] Failed to capture chart:', err);
      return null;
    }
  }, [containerEl]);

  // Expose capture function to parent
  useEffect(() => {
    if (onChartCapture) {
      onChartCapture(captureChart);
    }
  }, [onChartCapture, captureChart]);

  if (!market) {
    return (
      <div className="h-[280px] w-full flex items-center justify-center">
        <div className="text-center">
          <motion.div
            className="w-16 h-16 rounded-full bg-success/20 mx-auto mb-3 flex items-center justify-center"
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            <svg className="w-8 h-8 text-success" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="22 7 13.5 15.5 8.5 10.5 2 17" />
              <polyline points="16 7 22 7 22 13" />
            </svg>
          </motion.div>
          <p className="text-muted-foreground text-sm">Select a market to get started</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full">
      {/* Chart Title */}
      <div className="text-center mb-3">
        <h3 className="text-cyan-400 font-bold text-sm">
          {market} - M1 Candlestick Chart
        </h3>
      </div>

      {/* Legend + Data Source */}
      <div className="flex flex-wrap items-center gap-2 mb-2 px-1 text-[10px]">
        <span className="inline-flex items-center rounded-full border border-border/50 bg-muted/40 px-2 py-1 text-[10px] text-foreground">
          {isOtc ? 'Data source: OTC' : 'Data source: Real Market'}
        </span>
        {lastCandleCount !== null && (
          <span className="inline-flex items-center rounded-full border border-border/50 bg-muted/40 px-2 py-1 text-[10px] text-muted-foreground">
            Candles: {lastCandleCount}
          </span>
        )}

        <div className="flex items-center gap-1 ml-1">
          <span className="w-4 h-0.5 bg-[#eab308]"></span>
          <span className="text-[#eab308]">MA20</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-4 h-0.5 bg-[#3b82f6]"></span>
          <span className="text-[#3b82f6]">MA50</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-4 h-0.5 border-t border-dashed border-[#ef4444]"></span>
          <span className="text-[#ef4444]">Resistance</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-4 h-0.5 border-t border-dashed border-[#22c55e]"></span>
          <span className="text-[#22c55e]">Support</span>
        </div>
        <button
          onClick={fetchChartData}
          disabled={isLoading}
          className="ml-auto px-2 py-1 rounded bg-cyan-500 hover:bg-cyan-600 text-black text-[10px] font-bold flex items-center gap-1 transition-colors disabled:opacity-50"
          title="Refresh chart"
        >
          {isLoading ? (
            <Loader2 className="w-3 h-3 animate-spin" />
          ) : (
            <RefreshCw className="w-3 h-3" />
          )}
          Refresh
        </button>
      </div>

      {/* Chart Container */}
      <div className="relative">
        <div
          ref={setContainerEl}
          className="w-full md:min-h-[350px] rounded-lg overflow-hidden border border-cyan-500/20"
          style={{ minHeight: '280px' }}
        />
        {/* Watermark */}
        <div className="absolute bottom-2 right-2 text-right pointer-events-none select-none opacity-30">
          <div className="text-[10px] text-white/50 font-medium">@Tredwithjakaria</div>
          <a 
            href="https://t.me/TRADEWITHARTRADER" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-[8px] text-white/40 pointer-events-auto hover:text-white/60"
          >
            https://t.me/TRADEWITHARTRADER
          </a>
        </div>
      </div>

      {/* Loading Overlay */}
      {isLoading && (
        <div className="absolute inset-0 bg-background/50 flex items-center justify-center rounded-lg">
          <div className="flex flex-col items-center gap-2">
            <Loader2 className="w-6 h-6 text-cyan-400 animate-spin" />
            <span className="text-xs text-muted-foreground">Loading chart...</span>
          </div>
        </div>
      )}

      {/* Error Message - non-blocking banner so chart stays visible */}
      {error && (
        <div className="absolute top-2 left-2 right-2 z-10">
          <div className="flex items-center justify-between gap-2 bg-destructive/20 border border-destructive/40 rounded-md px-3 py-1.5">
            <p className="text-[10px] text-destructive truncate">{error}</p>
            <button
              onClick={fetchChartData}
              className="text-[10px] text-cyan-400 hover:underline whitespace-nowrap"
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {/* Auto-refresh indicator */}
      {lastUpdate && !isLoading && (
        <div className="flex items-center justify-center mt-2 gap-2">
          {isStreaming && (
            <span className="inline-flex items-center gap-1 text-[10px] text-green-400">
              <Wifi className="w-3 h-3" />
              LIVE
            </span>
          )}
          <span className="text-[10px] text-muted-foreground">
            {isStreaming ? 'Real-time (1s)' : 'Auto-Refresh (70s)'}
          </span>
          <span className="text-[10px] text-cyan-400">
            • Updated: {lastUpdate.toLocaleTimeString()}
          </span>
        </div>
      )}
    </div>
  );
}
