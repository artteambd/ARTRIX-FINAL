import { motion } from 'framer-motion';
import { Zap, Star, Crown, Diamond, Sparkles } from 'lucide-react';
import { Package } from '@/types';

interface PackageCardProps {
  pkg: Package;
  onSelect: () => void;
}

const iconMap: Record<string, React.ReactNode> = {
  zap: <Zap className="w-6 h-6" />,
  star: <Star className="w-6 h-6" />,
  crown: <Crown className="w-6 h-6" />,
  diamond: <Diamond className="w-6 h-6" />,
  sparkles: <Sparkles className="w-6 h-6" />,
};

const colorClasses: Record<string, string> = {
  cyan: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/50',
  pink: 'bg-pink-500/20 text-pink-400 border-pink-500/50',
  orange: 'bg-orange-500/20 text-orange-400 border-orange-500/50',
  emerald: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50',
  rose: 'bg-rose-500/20 text-rose-400 border-rose-500/50',
};

const buttonColors: Record<string, string> = {
  cyan: 'bg-cyan-500 hover:bg-cyan-600',
  pink: 'bg-pink-500 hover:bg-pink-600',
  orange: 'bg-orange-500 hover:bg-orange-600',
  emerald: 'bg-emerald-500 hover:bg-emerald-600',
  rose: 'bg-rose-500 hover:bg-rose-600',
};

const priceColors: Record<string, string> = {
  cyan: 'text-cyan-400',
  pink: 'text-pink-400',
  orange: 'text-orange-400',
  emerald: 'text-emerald-400',
  rose: 'text-rose-400',
};

export function PackageCard({ pkg, onSelect }: PackageCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -5 }}
      className={`glass-card p-5 relative overflow-hidden ${
        pkg.popular ? 'border-2 border-orange-500/50' : 'border border-border/50'
      }`}
    >
      {pkg.popular && (
        <div className="absolute top-0 right-0 bg-orange-500 text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
          BEST
        </div>
      )}

      <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${colorClasses[pkg.color]}`}>
        {iconMap[pkg.icon]}
      </div>

      <h3 className="text-lg font-bold text-foreground">{pkg.name}</h3>
      
      <div className="flex items-center gap-2 mt-3">
        <Sparkles className="w-4 h-4 text-primary" />
        <span className="text-2xl font-bold text-foreground">{pkg.credits}</span>
        <span className="text-sm text-muted-foreground">Credits</span>
      </div>

      <p className={`text-3xl font-bold mt-2 ${priceColors[pkg.color]}`}>
        ${pkg.price}
      </p>
      <p className="text-xs text-muted-foreground mt-1">
        ${pkg.pricePerAnalysis.toFixed(3)} per analysis
      </p>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={onSelect}
        className={`w-full mt-4 py-3 rounded-xl font-semibold text-white transition-colors ${buttonColors[pkg.color]}`}
      >
        Select Package
      </motion.button>
    </motion.div>
  );
}
