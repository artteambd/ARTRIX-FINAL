import { motion } from 'framer-motion';
import { AlertTriangle, Shield, TrendingUp, TrendingDown, Eye, ChevronDown, ChevronUp, Zap, BookOpen, Ban } from 'lucide-react';
import { useState } from 'react';

interface CategoryBreakdown {
  name: string;
  callCount: number;
  putCount: number;
  callScore: number;
  putScore: number;
  hasConflict: boolean;
  conflictingSetups: string[];
}

interface ScenarioUsed {
  signal: 'CALL' | 'PUT';
  logic: string;
  confidence: string;
  strategyNumber: number;
  strategyName: string;
}

interface BlockedStrategy {
  name: string;
  category: string;
  reason: string;
  signal: 'CALL' | 'PUT';
}

interface BlockedCounts {
  callBlocked: number;
  putBlocked: number;
}

interface ConflictAnalysis {
  hasInternalConflict: boolean;
  conflictPenalty: number;
  hiddenTrapWarning: boolean;
  highRisk: boolean;
  conflictDetails: CategoryBreakdown[];
  opposingSetups: string[];
  scenarioUsed?: ScenarioUsed | null;
  blockedStrategies?: BlockedStrategy[];
  blockedCounts?: BlockedCounts;
}

interface SignalConflictPanelProps {
  conflictAnalysis: ConflictAnalysis | null;
  direction: 'CALL' | 'PUT';
}

export function SignalConflictPanel({ conflictAnalysis, direction }: SignalConflictPanelProps) {
  const [showDetails, setShowDetails] = useState(false);
  const [showBlockedDetails, setShowBlockedDetails] = useState(false);
  
  if (!conflictAnalysis) return null;
  
  const { hasInternalConflict, conflictPenalty, hiddenTrapWarning, highRisk, conflictDetails, opposingSetups, scenarioUsed, blockedStrategies = [], blockedCounts } = conflictAnalysis;
  
  // Filter categories that have any activity
  const activeCategories = conflictDetails.filter(cat => cat.callCount > 0 || cat.putCount > 0);
  
  // Calculate blocked counts from strategies if not provided
  const callBlocked = blockedCounts?.callBlocked ?? blockedStrategies.filter(s => s.signal === 'CALL').length;
  const putBlocked = blockedCounts?.putBlocked ?? blockedStrategies.filter(s => s.signal === 'PUT').length;
  
  // Group blocked strategies by category
  const blockedByCategory = blockedStrategies.reduce((acc, strategy) => {
    if (!acc[strategy.category]) acc[strategy.category] = [];
    acc[strategy.category].push(strategy);
    return acc;
  }, {} as Record<string, typeof blockedStrategies>);
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="mt-4 space-y-3"
    >
      {/* Scenario Strategy Used - Show FIRST when a strategy matched */}
      {scenarioUsed && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className={`glass-card p-4 rounded-xl border-2 ${
            scenarioUsed.signal === 'CALL' 
              ? 'border-success/50 bg-success/10' 
              : 'border-put/50 bg-put/10'
          }`}
        >
          <div className="flex items-start gap-3">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
              scenarioUsed.signal === 'CALL' ? 'bg-success/20' : 'bg-put/20'
            }`}>
              <BookOpen className={`w-5 h-5 ${scenarioUsed.signal === 'CALL' ? 'text-success' : 'text-put'}`} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h4 className={`font-bold text-sm ${scenarioUsed.signal === 'CALL' ? 'text-success' : 'text-put'}`}>
                  Strategy #{scenarioUsed.strategyNumber} Matched
                </h4>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  scenarioUsed.signal === 'CALL' 
                    ? 'bg-success text-success-foreground' 
                    : 'bg-put text-white'
                }`}>
                  {scenarioUsed.confidence} CONFIDENCE
                </span>
              </div>
              <p className={`text-xs font-semibold mt-1 ${scenarioUsed.signal === 'CALL' ? 'text-success/90' : 'text-put/90'}`}>
                {scenarioUsed.strategyName}
              </p>
              <p className="text-xs text-muted-foreground mt-2 leading-relaxed">
                {scenarioUsed.logic}
              </p>
            </div>
          </div>
        </motion.div>
      )}
      
      {/* No Scenario Match Indicator */}
      {!scenarioUsed && (
        <div className="glass-card p-3 rounded-xl border border-muted/30 bg-muted/5">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">
              No scenario match. Using standard analysis (HTF → SMC → Liquidity → Indicators).
            </span>
          </div>
        </div>
      )}
      
      {/* Category Breakdown */}
      <div className="glass-card p-4 rounded-xl border border-primary/30 bg-primary/5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4 text-primary" />
            <span className="text-sm font-semibold text-foreground">Category Breakdown</span>
          </div>
          <button 
            onClick={() => setShowDetails(!showDetails)}
            className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
          >
            {showDetails ? 'Hide' : 'Show'} Details
            {showDetails ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>
        </div>
        
        <div className="space-y-2">
          {activeCategories.map((cat, index) => (
            <div key={index} className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground font-medium">{cat.name}</span>
              <div className="flex items-center gap-2">
                <span className="text-success font-bold flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" />
                  {cat.callCount}
                </span>
                <span className="text-muted-foreground">/</span>
                <span className="text-put font-bold flex items-center gap-1">
                  <TrendingDown className="w-3 h-3" />
                  {cat.putCount}
                </span>
                {cat.hasConflict && (
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-warning/20 text-warning border border-warning/30">
                    CONFLICT
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Internal Conflict Warning */}
      {hasInternalConflict && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-card p-4 rounded-xl border-2 border-warning/50 bg-warning/10"
        >
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-warning/20 flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="w-5 h-5 text-warning" />
            </div>
            <div className="flex-1">
              <h4 className="font-bold text-warning text-sm">Internal Conflict Detected</h4>
              <p className="text-xs text-warning/80 mt-1">
                Categories have setups pointing in opposite directions. 
                Confidence reduced by <span className="font-bold">{conflictPenalty}%</span>.
              </p>
            </div>
          </div>
        </motion.div>
      )}
      
      {/* Hidden Trap Warning */}
      {hiddenTrapWarning && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-card p-4 rounded-xl border-2 border-put/50 bg-put/10"
        >
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-put/20 flex items-center justify-center flex-shrink-0">
              <Shield className="w-5 h-5 text-put" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h4 className="font-bold text-put text-sm">Hidden Trap Warning</h4>
                {highRisk && (
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-put text-white">
                    HIGH RISK
                  </span>
                )}
              </div>
              <p className="text-xs text-put/80 mt-1">
                {opposingSetups.length} setup(s) in high-priority categories (SMC/HTF/Liquidity) 
                suggest {direction === 'CALL' ? 'PUT' : 'CALL'} direction.
              </p>
            </div>
          </div>
        </motion.div>
      )}
      
      {/* Blocked Strategies (Avoid Rules) - NEW VALIDATION TRANSPARENCY */}
      {blockedStrategies.length > 0 && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-card p-4 rounded-xl border border-muted/40 bg-muted/5"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-muted/20 flex items-center justify-center flex-shrink-0">
                <Ban className="w-4 h-4 text-muted-foreground" />
              </div>
              <div>
                <h4 className="font-semibold text-foreground text-sm">Validation Filter</h4>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-[10px] text-muted-foreground">
                    {blockedStrategies.length} excluded
                  </span>
                  <span className="text-[10px] text-muted-foreground">•</span>
                  <span className="text-[10px] text-success font-bold flex items-center gap-0.5">
                    <TrendingUp className="w-2.5 h-2.5" />
                    {callBlocked} CALL
                  </span>
                  <span className="text-[10px] text-muted-foreground">/</span>
                  <span className="text-[10px] text-put font-bold flex items-center gap-0.5">
                    <TrendingDown className="w-2.5 h-2.5" />
                    {putBlocked} PUT
                  </span>
                </div>
              </div>
            </div>
            <button 
              onClick={() => setShowBlockedDetails(!showBlockedDetails)}
              className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
            >
              {showBlockedDetails ? 'Hide' : 'View'}
              {showBlockedDetails ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>
          </div>
          
          {showBlockedDetails && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="space-y-3 pt-2 border-t border-border/30"
            >
              {Object.entries(blockedByCategory).map(([category, strategies]) => {
                const catCallBlocked = strategies.filter(s => s.signal === 'CALL').length;
                const catPutBlocked = strategies.filter(s => s.signal === 'PUT').length;
                return (
                  <div key={category}>
                    <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                      <span className="text-[10px] font-bold text-muted-foreground uppercase">{category}</span>
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-destructive/10 text-destructive border border-destructive/20">
                        {strategies.length} blocked
                      </span>
                      {catCallBlocked > 0 && (
                        <span className="text-[9px] text-success font-semibold flex items-center gap-0.5">
                          <TrendingUp className="w-2 h-2" />{catCallBlocked}
                        </span>
                      )}
                      {catPutBlocked > 0 && (
                        <span className="text-[9px] text-put font-semibold flex items-center gap-0.5">
                          <TrendingDown className="w-2 h-2" />{catPutBlocked}
                        </span>
                      )}
                    </div>
                    <div className="space-y-1 max-h-24 overflow-y-auto">
                      {strategies.map((strategy, idx) => (
                        <div 
                          key={idx}
                          className={`text-[10px] px-2 py-1.5 rounded flex items-start gap-1.5 ${
                            strategy.signal === 'CALL' ? 'bg-success/10 border border-success/20' : 'bg-put/10 border border-put/20'
                          }`}
                        >
                          <span className={`flex-shrink-0 ${strategy.signal === 'CALL' ? 'text-success' : 'text-put'}`}>
                            {strategy.signal === 'CALL' ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                          </span>
                          <div>
                            <span className="font-medium text-foreground">{strategy.name}</span>
                            <span className="text-muted-foreground ml-1">— {strategy.reason}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </motion.div>
          )}
        </motion.div>
      )}
      
      {/* Opposing Setups Details */}
      {showDetails && opposingSetups.length > 0 && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="glass-card p-4 rounded-xl border border-border/50"
        >
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="w-4 h-4 text-muted-foreground" />
            <span className="text-xs font-semibold text-foreground">Opposing Setups (Transparency)</span>
          </div>
          <div className="space-y-1.5 max-h-32 overflow-y-auto">
            {opposingSetups.map((setup, index) => (
              <div 
                key={index} 
                className="text-[10px] text-muted-foreground bg-muted/30 px-2 py-1.5 rounded font-mono"
              >
                {setup}
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
