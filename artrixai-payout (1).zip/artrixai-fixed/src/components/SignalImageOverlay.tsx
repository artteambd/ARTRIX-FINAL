import { motion } from 'framer-motion';
import signalMascot from '@/assets/signal-mascot.png';

interface SignalImageOverlayProps {
  market: string;
  direction: 'CALL' | 'PUT';
  time: string;
  expiry: string;
}

export const SignalImageOverlay = ({ market, direction, time, expiry }: SignalImageOverlayProps) => {
  // Format market name (remove -OTC suffix and format)
  const formatMarket = (market: string) => {
    return market.replace('-OTC', '').replace('/', '');
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="relative w-full aspect-video rounded-xl overflow-hidden mb-6"
    >
      {/* Background with gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a1628] via-[#0d1f3c] to-[#0a1628]">
        {/* Animated particles/stars effect */}
        <div className="absolute inset-0 opacity-30">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-cyan-400 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                opacity: [0.2, 1, 0.2],
                scale: [1, 1.5, 1],
              }}
              transition={{
                duration: 2 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2,
              }}
            />
          ))}
        </div>

        {/* Radial glow effects */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-full h-32 bg-gradient-to-t from-purple-900/30 to-transparent" />
      </div>

      {/* Mascot/Logo Image */}
      <div className="absolute inset-0 flex items-center justify-center">
        <img
          src={signalMascot}
          alt="Signal Mascot"
          className="w-48 h-48 md:w-64 md:h-64 object-contain opacity-70 drop-shadow-2xl"
        />
      </div>

      {/* Signal Information Overlay */}
      <div className="absolute inset-0 flex flex-col items-center justify-center z-10">
        {/* Market | Direction */}
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-2"
        >
          <span className="text-2xl md:text-4xl font-bold text-cyan-400 tracking-wider drop-shadow-lg">
            {formatMarket(market)} | {direction}
          </span>
        </motion.div>

        {/* Time | Expiry */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-center"
        >
          <span className="text-lg md:text-2xl font-semibold text-green-400 tracking-wide drop-shadow-lg">
            Time: {time} | Expiry: {expiry}
          </span>
        </motion.div>
      </div>

      {/* Bottom branding bar */}
      <div className="absolute bottom-0 left-0 right-0 bg-black/60 py-2 backdrop-blur-sm">
        <p className="text-center text-xs md:text-sm font-medium text-cyan-300 tracking-widest">
          ARTRIX PREMIUM BOT - PROFESSIONAL TRADING
        </p>
      </div>

      {/* Direction indicator glow */}
      <motion.div
        className={`absolute top-2 right-2 px-3 py-1 rounded-full text-xs font-bold ${
          direction === 'CALL'
            ? 'bg-green-500/80 text-white shadow-lg shadow-green-500/50'
            : 'bg-red-500/80 text-white shadow-lg shadow-red-500/50'
        }`}
        animate={{
          scale: [1, 1.05, 1],
          boxShadow: direction === 'CALL'
            ? ['0 0 10px rgba(34, 197, 94, 0.5)', '0 0 20px rgba(34, 197, 94, 0.8)', '0 0 10px rgba(34, 197, 94, 0.5)']
            : ['0 0 10px rgba(239, 68, 68, 0.5)', '0 0 20px rgba(239, 68, 68, 0.8)', '0 0 10px rgba(239, 68, 68, 0.5)']
        }}
        transition={{ duration: 1.5, repeat: Infinity }}
      >
        {direction}
      </motion.div>
    </motion.div>
  );
};
