import { motion } from 'framer-motion';
import { useEffect, useState, useRef } from 'react';
import { 
  Search, BarChart3, Brain, TrendingUp, Zap, Droplets, ShieldCheck, 
  Crosshair, CandlestickChart, Flame, CheckCircle2, Landmark, 
  Ruler, Dna, Link2, FileCheck, Code2, Activity, GitMerge
} from 'lucide-react';

// ── FULL AI MODE (3 min) ───────────────────────────────────────────────────
const AI_PHASES = [
  { label: 'Detecting Trading Pair...', duration: 5, icon: Search, color: '#38bdf8', category: 'init' },
  { label: 'Fetching 500 Fresh Candles...', duration: 8, icon: BarChart3, color: '#38bdf8', category: 'init' },
  { label: 'Stage 1: Deep 13-Step Analysis...', duration: 35, icon: Brain, color: '#06b6d4', category: 'stage1' },
  { label: '→ Trend & Structure Scan', duration: 10, icon: TrendingUp, color: '#06b6d4', category: 'stage1' },
  { label: '→ Momentum & S/R Levels', duration: 10, icon: Zap, color: '#06b6d4', category: 'stage1' },
  { label: '→ Liquidity & Volume Check', duration: 10, icon: Droplets, color: '#06b6d4', category: 'stage1' },
  { label: '→ Risk Assessment & Psychology', duration: 8, icon: ShieldCheck, color: '#06b6d4', category: 'stage1' },
  { label: 'Stage 2: Precision Sniper V8...', duration: 25, icon: Crosshair, color: '#a78bfa', category: 'stage2' },
  { label: '→ Fresh Candle Override Check', duration: 8, icon: CandlestickChart, color: '#a78bfa', category: 'stage2' },
  { label: '→ 6-Signal Rapid-Fire Engine', duration: 10, icon: Flame, color: '#a78bfa', category: 'stage2' },
  { label: '→ Dual-Stage Cross Validation', duration: 5, icon: CheckCircle2, color: '#a78bfa', category: 'stage2' },
  { label: 'Running Pillar Workflow...', duration: 10, icon: Landmark, color: '#f59e0b', category: 'pillar' },
  { label: '→ Trend Detection Engine v3', duration: 5, icon: Ruler, color: '#f59e0b', category: 'pillar' },
  { label: '→ 4-Pillar DNA Cross-Reference', duration: 5, icon: Dna, color: '#f59e0b', category: 'pillar' },
  { label: 'Cross-Validating AI + Pillar...', duration: 5, icon: Link2, color: '#22c55e', category: 'final' },
  { label: 'Compiling Final Signal...', duration: 3, icon: FileCheck, color: '#22c55e', category: 'final' },
];

// ── FAST CODE MODE (60 s) ─────────────────────────────────────────────────
const FAST_PHASES = [
  { label: 'Fetching Live Candle Data...', duration: 4,  icon: BarChart3,   color: '#38bdf8', category: 'fetch' },
  { label: 'Building 7-Category Matrix...', duration: 5, icon: Code2,        color: '#06b6d4', category: 'code' },
  { label: '→ SMC 18-Setup Scanner',         duration: 5, icon: Landmark,     color: '#06b6d4', category: 'code' },
  { label: '→ 35 OTC Liquidity Traps',       duration: 5, icon: Droplets,     color: '#06b6d4', category: 'code' },
  { label: '→ 42 Algo-Trap Indicators',      duration: 4, icon: Activity,     color: '#06b6d4', category: 'code' },
  { label: '→ 235 Setup Database',           duration: 4, icon: Dna,          color: '#06b6d4', category: 'code' },
  { label: '→ HTF 20-Strategy Engine',       duration: 4, icon: TrendingUp,   color: '#06b6d4', category: 'code' },
  { label: '→ 35 Reaction Strategies',       duration: 4, icon: Flame,        color: '#a78bfa', category: 'react' },
  { label: '→ Continuation / Reversal / Trap Detection', duration: 4, icon: Crosshair, color: '#a78bfa', category: 'react' },
  { label: 'Bridge Candle Validation...',    duration: 5, icon: GitMerge,     color: '#f59e0b', category: 'bridge' },
  { label: 'Scenario Filter (100 strategies)...', duration: 4, icon: ShieldCheck, color: '#f59e0b', category: 'bridge' },
  { label: 'AI Direction Confirmation...',   duration: 6, icon: Brain,        color: '#a78bfa', category: 'ai' },
  { label: 'Compiling Final Signal...',      duration: 2, icon: FileCheck,    color: '#22c55e', category: 'final' },
];

const AI_TOTAL    = AI_PHASES.reduce((s, p) => s + p.duration, 0);
const FAST_TOTAL  = FAST_PHASES.reduce((s, p) => s + p.duration, 0);

interface SignalLoadingAnimationProps {
  onComplete?: () => void;
  isRealAnalysis?: boolean;
  fastMode?: boolean;
}

function PhaseIcon({ icon: Icon, color, isActive }: { icon: any; color: string; isActive: boolean }) {
  return (
    <motion.div className="relative flex-shrink-0 w-5 h-5 flex items-center justify-center"
      animate={isActive ? { scale: [1, 1.15, 1] } : {}}
      transition={{ duration: 1.2, repeat: Infinity }}>
      {isActive && (
        <motion.div className="absolute inset-0 rounded-full"
          style={{ background: color, filter: 'blur(6px)', opacity: 0.4 }}
          animate={{ opacity: [0.2, 0.5, 0.2] }}
          transition={{ duration: 1.2, repeat: Infinity }} />
      )}
      <Icon className="w-3.5 h-3.5 relative z-10" style={{ color }} />
    </motion.div>
  );
}

function DNASpinner({ fast }: { fast?: boolean }) {
  return (
    <div className="relative w-10 h-10">
      {[0,1,2,3,4,5].map(i => (
        <motion.div key={i} className="absolute w-2 h-2 rounded-full"
          style={{ background: fast ? `linear-gradient(135deg,#22c55e,#10b981)` : i%2===0 ? 'linear-gradient(135deg,#38bdf8,#06b6d4)' : 'linear-gradient(135deg,#a78bfa,#8b5cf6)', top:'50%', left:'50%' }}
          animate={{ x:[Math.cos(i/6*Math.PI*2)*16,Math.cos(i/6*Math.PI*2+Math.PI)*16,Math.cos(i/6*Math.PI*2)*16], y:[Math.sin(i/6*Math.PI*2)*7,Math.sin(i/6*Math.PI*2+Math.PI)*7,Math.sin(i/6*Math.PI*2)*7], scale:[1,0.6,1] }}
          transition={{ duration: fast ? 1.2 : 2, repeat:Infinity, ease:'easeInOut', delay:i*0.12 }} />
      ))}
      <motion.div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 rounded-full"
        style={{ background: fast ? 'radial-gradient(circle,rgba(34,197,94,0.8)0%,transparent 70%)' : 'radial-gradient(circle,rgba(56,189,248,0.8)0%,transparent 70%)' }}
        animate={{ scale:[1,1.8,1], opacity:[0.6,1,0.6] }}
        transition={{ duration: fast ? 0.8 : 1.5, repeat:Infinity }} />
    </div>
  );
}

export function SignalLoadingAnimation({ onComplete, isRealAnalysis = false, fastMode = false }: SignalLoadingAnimationProps) {
  const phases = fastMode ? FAST_PHASES : AI_PHASES;
  const totalEstimated = fastMode ? FAST_TOTAL : AI_TOTAL;

  const [currentPhaseIndex, setCurrentPhaseIndex] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [isComplete, setIsComplete] = useState(false);
  const startTimeRef = useRef(Date.now());
  const completedRef = useRef(false);

  useEffect(() => {
    startTimeRef.current = Date.now();
    setElapsed(0);
    setCurrentPhaseIndex(0);
    setIsComplete(false);
    completedRef.current = false;
  }, [fastMode]);

  useEffect(() => {
    const interval = setInterval(() => setElapsed(Math.floor((Date.now() - startTimeRef.current) / 1000)), 500);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    let accumulated = 0;
    for (let i = 0; i < phases.length; i++) {
      accumulated += phases[i].duration;
      if (elapsed < accumulated) { setCurrentPhaseIndex(i); return; }
    }
    if (!completedRef.current) {
      completedRef.current = true;
      setCurrentPhaseIndex(phases.length - 1);
      setIsComplete(true);
    }
  }, [elapsed, phases]);

  useEffect(() => {
    if (!isRealAnalysis && onComplete) {
      const timer = setTimeout(() => {
        if (!completedRef.current) { completedRef.current = true; setIsComplete(true); setTimeout(() => onComplete(), 800); }
      }, fastMode ? 3000 : 6000);
      return () => clearTimeout(timer);
    }
  }, [isRealAnalysis, onComplete, fastMode]);

  const progress = Math.min(100, Math.round((elapsed / totalEstimated) * 100));
  const estimatedRemaining = Math.max(0, totalEstimated - elapsed);
  const formatTime = (s: number) => { const m = Math.floor(s/60); const sec = s%60; return m > 0 ? `${m}m ${sec}s` : `${sec}s`; };

  const currentPhase = phases[currentPhaseIndex];
  const activeColor = fastMode ? '#22c55e' : (currentPhase?.color ?? '#38bdf8');
  const titleLabel = fastMode ? 'ARTRIX — Fast Code Engine' : 'ARTRIX AI — Dual Engine';

  return (
    <div className="w-full max-w-md mx-auto p-4 relative">
      <motion.div initial={{ opacity:0, y:20, scale:0.97 }} animate={{ opacity:1, y:0, scale:1 }}
        transition={{ duration:0.5, ease:[0.22,1,0.36,1] }}
        className="rounded-2xl overflow-hidden relative"
        style={{ background:'linear-gradient(180deg,rgba(15,23,42,0.98)0%,rgba(7,11,20,0.99)100%)', border:'1px solid rgba(56,189,248,0.15)', boxShadow:`0 0 40px -10px ${activeColor}33,0 25px 50px -12px rgba(0,0,0,0.5)` }}>

        {/* Animated top border */}
        <motion.div className="absolute top-0 left-0 right-0 h-[2px]"
          style={{ background:`linear-gradient(90deg,transparent,${activeColor},transparent)` }}
          animate={{ opacity:[0.4,1,0.4] }} transition={{ duration: fastMode ? 0.8 : 2, repeat:Infinity }} />

        {/* Header */}
        <div className="flex items-center gap-2 px-4 py-3 border-b border-white/5">
          <div className="flex gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-red-500/90" />
            <div className="w-2.5 h-2.5 rounded-full bg-amber-400/90" />
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400/90" />
          </div>
          <div className="flex-1 flex items-center justify-center gap-2">
            <DNASpinner fast={fastMode} />
            <span className="text-xs font-bold tracking-wider" style={{ background:`linear-gradient(90deg,${activeColor},${fastMode?'#10b981':'#06b6d4'})`, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>
              {titleLabel}
            </span>
          </div>
          {fastMode && (
            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full border border-green-500/40 text-green-400">60s</span>
          )}
        </div>

        {/* Time bar */}
        {isRealAnalysis && (
          <div className="flex items-center justify-between px-4 py-2 border-b border-white/5">
            <div className="flex items-center gap-2">
              <motion.div className="w-2 h-2 rounded-full" style={{ background: activeColor }}
                animate={{ opacity:[1,0.2,1] }} transition={{ duration: fastMode?0.5:1, repeat:Infinity }} />
              <span className="text-xs font-mono font-medium" style={{ color: activeColor }}>{formatTime(elapsed)}</span>
            </div>
            <span className="text-[10px] text-white/40 font-mono">~{formatTime(estimatedRemaining)} left</span>
          </div>
        )}

        {/* Phase list */}
        <div className="p-4 max-h-[240px] overflow-y-auto">
          <div className="space-y-0.5 font-mono text-[12px]">
            {phases.map((phase, index) => {
              if (index > currentPhaseIndex) return null;
              const isCurrent = index === currentPhaseIndex && !isComplete;
              const isPast = index < currentPhaseIndex || isComplete;
              return (
                <motion.div key={index}
                  initial={{ opacity:0, x:-12 }} animate={{ opacity:1, x:0 }}
                  transition={{ duration: fastMode ? 0.2 : 0.4 }}
                  className="flex items-center gap-2 py-0.5">
                  <PhaseIcon icon={phase.icon} color={isPast ? 'rgba(255,255,255,0.25)' : phase.color} isActive={isCurrent} />
                  <span className={`text-[11px] leading-relaxed ${isPast ? 'text-white/30' : 'text-white/85'}`}>{phase.label}</span>
                  {isPast && <motion.span initial={{scale:0}} animate={{scale:1}} className="text-emerald-400 text-xs ml-auto">✓</motion.span>}
                  {isCurrent && <motion.div className="ml-auto flex-shrink-0 w-1 h-3.5 rounded-sm" style={{ background: activeColor }} animate={{ opacity:[1,0.1,1] }} transition={{ duration: fastMode?0.4:0.6, repeat:Infinity }} />}
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Progress */}
        <div className="px-4 pb-4 pt-2 border-t border-white/5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] font-semibold tracking-wide text-white/40 uppercase">{isComplete ? 'Complete' : 'Progress'}</span>
            <motion.span className="font-bold text-xs tabular-nums" style={{ color: isComplete ? '#22c55e' : activeColor }}
              key={progress} initial={{ y:-4, opacity:0 }} animate={{ y:0, opacity:1 }}>
              {isComplete ? '100' : progress}%
            </motion.span>
          </div>
          <div className="h-2 rounded-full overflow-hidden" style={{ background:'rgba(255,255,255,0.04)' }}>
            <motion.div className="h-full rounded-full"
              style={{ background: isComplete ? 'linear-gradient(90deg,#22c55e,#10b981)' : `linear-gradient(90deg,${activeColor}cc,${activeColor})`, boxShadow: `0 0 12px ${activeColor}44` }}
              initial={{ width:0 }} animate={{ width:`${isComplete?100:progress}%` }}
              transition={{ duration: fastMode ? 0.4 : 0.8, ease:'easeOut' }} />
          </div>
        </div>
      </motion.div>

      {/* Status */}
      <motion.div initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }} transition={{ delay:0.4 }}
        className="flex items-center justify-center gap-2 mt-4">
        <motion.div className="relative" animate={{ scale:[1,1.2,1] }} transition={{ duration: fastMode?1:2, repeat:Infinity }}>
          <div className="w-2 h-2 rounded-full" style={{ background: isComplete ? '#22c55e' : activeColor }} />
          <motion.div className="absolute inset-0 rounded-full" style={{ background: isComplete ? '#22c55e' : activeColor }}
            animate={{ scale:[1,2.5], opacity:[0.5,0] }} transition={{ duration: fastMode?0.8:1.5, repeat:Infinity }} />
        </motion.div>
        <span className="text-xs font-medium" style={{ color: isComplete ? '#22c55e' : activeColor }}>
          {isComplete ? '✅ Ready — Loading Signal...' : fastMode ? '⚡ Code Engine Running...' : 'AI Engines Running...'}
        </span>
      </motion.div>
    </div>
  );
}

