import { useEffect, useRef, useState, useCallback, useImperativeHandle, forwardRef } from 'react';
import { createChart, ColorType, IChartApi, ISeriesApi, Time, CandlestickSeries, LineSeries } from 'lightweight-charts';
import { supabase } from '@/integrations/supabase/client';

interface TelegramChartProps {
  market: string | null;
  /** Current signal data for dynamic dashboard */
  signalData?: {
    direction: 'CALL' | 'PUT';
    timestamp: Date;
    pair: string;
  } | null;
  /** Result mode data - when set, dashboard shows WIN/LOSS/MTG instead of BUY/SELL */
  resultData?: {
    resultType: 'WIN' | 'LOSS' | 'MTG';
    pair: string;
    time: string;
    wins: number;
    losses: number;
    winRate: number;
  } | null;
}

export interface TelegramChartHandle {
  capture: () => string | null;
  isReady: () => boolean;
  /** Directly set signal data (bypasses React async prop update — use in auto mode) */
  setSignal: (data: TelegramChartProps['signalData']) => void;
  /** Directly set result data (bypasses React async prop update — use in auto mode) */
  setResult: (data: TelegramChartProps['resultData']) => void;
}

interface CandleData {
  time: Time;
  open: number;
  high: number;
  low: number;
  close: number;
}

// Calculate Exponential Moving Average
const calculateEMA = (data: CandleData[], period: number): { time: Time; value: number }[] => {
  const result: { time: Time; value: number }[] = [];
  if (data.length < period) return result;

  const multiplier = 2 / (period + 1);
  
  // First EMA is SMA
  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += data[i].close;
  }
  let ema = sum / period;
  result.push({ time: data[period - 1].time, value: ema });

  // Calculate EMA for remaining data
  for (let i = period; i < data.length; i++) {
    ema = (data[i].close - ema) * multiplier + ema;
    result.push({ time: data[i].time, value: ema });
  }

  return result;
};

// Calculate RSI (14-period)
const calculateRSI = (data: CandleData[], period: number = 14): { time: Time; value: number }[] => {
  const result: { time: Time; value: number }[] = [];
  if (data.length < period + 1) return result;

  let gains = 0;
  let losses = 0;

  for (let i = 1; i <= period; i++) {
    const change = data[i].close - data[i - 1].close;
    if (change > 0) gains += change;
    else losses += Math.abs(change);
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;
  
  const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
  result.push({ time: data[period].time, value: 100 - (100 / (1 + rs)) });

  for (let i = period + 1; i < data.length; i++) {
    const change = data[i].close - data[i - 1].close;
    const currentGain = change > 0 ? change : 0;
    const currentLoss = change < 0 ? Math.abs(change) : 0;

    avgGain = (avgGain * (period - 1) + currentGain) / period;
    avgLoss = (avgLoss * (period - 1) + currentLoss) / period;

    const rsi = avgLoss === 0 ? 100 : 100 - (100 / (1 + avgGain / avgLoss));
    result.push({ time: data[i].time, value: rsi });
  }

  return result;
};

// Calculate Bollinger Bands for RSI
const calculateRSIBollingerBands = (rsiData: { time: Time; value: number }[], period: number = 20, stdDevMultiplier: number = 2) => {
  const upper: { time: Time; value: number }[] = [];
  const lower: { time: Time; value: number }[] = [];
  const middle: { time: Time; value: number }[] = [];

  for (let i = period - 1; i < rsiData.length; i++) {
    let sum = 0;
    for (let j = 0; j < period; j++) {
      sum += rsiData[i - j].value;
    }
    const sma = sum / period;

    let varianceSum = 0;
    for (let j = 0; j < period; j++) {
      varianceSum += Math.pow(rsiData[i - j].value - sma, 2);
    }
    const stdDev = Math.sqrt(varianceSum / period);

    middle.push({ time: rsiData[i].time, value: sma });
    upper.push({ time: rsiData[i].time, value: Math.min(100, sma + stdDevMultiplier * stdDev) });
    lower.push({ time: rsiData[i].time, value: Math.max(0, sma - stdDevMultiplier * stdDev) });
  }

  return { upper, middle, lower };
};

// Calculate Parabolic SAR
const calculateParabolicSAR = (data: CandleData[], acceleration: number = 0.02, maxAcceleration: number = 0.2): { time: Time; value: number; isBelow: boolean }[] => {
  if (data.length < 2) return [];

  const result: { time: Time; value: number; isBelow: boolean }[] = [];
  
  let isUptrend = data[1].close > data[0].close;
  let sar = isUptrend ? data[0].low : data[0].high;
  let ep = isUptrend ? data[1].high : data[1].low;
  let af = acceleration;

  result.push({ time: data[0].time, value: sar, isBelow: isUptrend });

  for (let i = 1; i < data.length; i++) {
    const prevSar = sar;
    
    // Calculate new SAR
    sar = prevSar + af * (ep - prevSar);

    if (isUptrend) {
      // SAR cannot be above prior two lows
      if (i >= 2) {
        sar = Math.min(sar, data[i - 1].low, data[i - 2].low);
      } else if (i >= 1) {
        sar = Math.min(sar, data[i - 1].low);
      }

      // Check for reversal
      if (data[i].low < sar) {
        isUptrend = false;
        sar = ep;
        ep = data[i].low;
        af = acceleration;
      } else {
        // Update EP and AF
        if (data[i].high > ep) {
          ep = data[i].high;
          af = Math.min(af + acceleration, maxAcceleration);
        }
      }
    } else {
      // SAR cannot be below prior two highs
      if (i >= 2) {
        sar = Math.max(sar, data[i - 1].high, data[i - 2].high);
      } else if (i >= 1) {
        sar = Math.max(sar, data[i - 1].high);
      }

      // Check for reversal
      if (data[i].high > sar) {
        isUptrend = true;
        sar = ep;
        ep = data[i].high;
        af = acceleration;
      } else {
        // Update EP and AF
        if (data[i].low < ep) {
          ep = data[i].low;
          af = Math.min(af + acceleration, maxAcceleration);
        }
      }
    }

    result.push({ time: data[i].time, value: sar, isBelow: isUptrend });
  }

  return result;
};

// Find pivot highs (swing highs) using wick highs for trendline drawing
const findPivotHighs = (data: CandleData[], windowSize: number = 3): { idx: number; price: number }[] => {
  const pivots: { idx: number; price: number }[] = [];
  
  for (let i = windowSize; i < data.length - windowSize; i++) {
    let isPivotHigh = true;
    const wickHigh = data[i].high;
    
    for (let j = 1; j <= windowSize; j++) {
      if (wickHigh <= data[i - j].high || wickHigh <= data[i + j].high) {
        isPivotHigh = false;
        break;
      }
    }
    
    if (isPivotHigh) {
      pivots.push({ idx: i, price: wickHigh });
    }
  }
  
  return pivots;
};

// Find pivot lows (swing lows) using wick lows for parallel channel
const findPivotLows = (data: CandleData[], windowSize: number = 3): { idx: number; price: number }[] => {
  const pivots: { idx: number; price: number }[] = [];
  
  for (let i = windowSize; i < data.length - windowSize; i++) {
    let isPivotLow = true;
    const wickLow = data[i].low;
    
    for (let j = 1; j <= windowSize; j++) {
      if (wickLow >= data[i - j].low || wickLow >= data[i + j].low) {
        isPivotLow = false;
        break;
      }
    }
    
    if (isPivotLow) {
      pivots.push({ idx: i, price: wickLow });
    }
  }
  
  return pivots;
};

// Detect if trend is bearish (lower highs and lower lows) or bullish
const detectTrendDirection = (data: CandleData[]): 'bearish' | 'bullish' | 'neutral' => {
  if (data.length < 10) return 'neutral';
  
  const pivotHighs = findPivotHighs(data, 2);
  const pivotLows = findPivotLows(data, 2);
  
  // Check for lower highs
  let lowerHighsCount = 0;
  for (let i = 1; i < pivotHighs.length; i++) {
    if (pivotHighs[i].price < pivotHighs[i - 1].price) lowerHighsCount++;
  }
  
  // Check for lower lows
  let lowerLowsCount = 0;
  for (let i = 1; i < pivotLows.length; i++) {
    if (pivotLows[i].price < pivotLows[i - 1].price) lowerLowsCount++;
  }
  
  // Check for higher highs
  let higherHighsCount = 0;
  for (let i = 1; i < pivotHighs.length; i++) {
    if (pivotHighs[i].price > pivotHighs[i - 1].price) higherHighsCount++;
  }
  
  // Check for higher lows
  let higherLowsCount = 0;
  for (let i = 1; i < pivotLows.length; i++) {
    if (pivotLows[i].price > pivotLows[i - 1].price) higherLowsCount++;
  }
  
  const bearishScore = lowerHighsCount + lowerLowsCount;
  const bullishScore = higherHighsCount + higherLowsCount;
  
  if (bearishScore > bullishScore + 1) return 'bearish';
  if (bullishScore > bearishScore + 1) return 'bullish';
  return 'neutral';
};

// Calculate linear regression for a set of points to get the best-fit line
const linearRegression = (points: { x: number; y: number }[]): { slope: number; intercept: number } => {
  if (points.length < 2) return { slope: 0, intercept: points[0]?.y || 0 };
  
  const n = points.length;
  let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
  
  for (const p of points) {
    sumX += p.x;
    sumY += p.y;
    sumXY += p.x * p.y;
    sumX2 += p.x * p.x;
  }
  
  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;
  
  return { slope: isNaN(slope) ? 0 : slope, intercept: isNaN(intercept) ? sumY / n : intercept };
};

// Calculate professional descending/ascending parallel channel like reference image
const calculateTrendChannel = (data: CandleData[], lookback: number = 30) => {
  if (data.length < lookback) return null;

  const recentData = data.slice(-lookback);
  const trend = detectTrendDirection(recentData);
  
  // Find swing highs (using wick highs for upper trendline)
  const pivotHighs = findPivotHighs(recentData, 2);
  const pivotLows = findPivotLows(recentData, 2);
  
  if (pivotHighs.length < 2 && pivotLows.length < 2) {
    return null; // Not enough data for channel
  }
  
  // Calculate upper trendline from swing highs using linear regression
  let upperSlope: number, upperIntercept: number;
  if (pivotHighs.length >= 2) {
    const highPoints = pivotHighs.map(p => ({ x: p.idx, y: p.price }));
    const reg = linearRegression(highPoints);
    upperSlope = reg.slope;
    upperIntercept = reg.intercept;
  } else {
    upperSlope = 0;
    upperIntercept = recentData[0].high;
  }
  
  // Calculate parallel lower trendline with same slope (true parallel channel)
  // Find the lowest point relative to the upper trendline for proper channel width
  let maxDistanceBelow = 0;
  for (let i = 0; i < recentData.length; i++) {
    const upperY = upperIntercept + upperSlope * i;
    const distance = upperY - recentData[i].low;
    if (distance > maxDistanceBelow) {
      maxDistanceBelow = distance;
    }
  }
  
  // The lower line is parallel (same slope) but offset by the channel width
  const channelWidth = maxDistanceBelow;
  const lowerIntercept = upperIntercept - channelWidth;
  
  // Calculate prices at start (0) and end (totalBars - 1) of visible range
  const totalBars = recentData.length;
  const upperStartPrice = upperIntercept;
  const upperEndPrice = upperIntercept + upperSlope * (totalBars - 1);
  const lowerStartPrice = lowerIntercept;
  const lowerEndPrice = lowerIntercept + upperSlope * (totalBars - 1);
  
  // 3 internal parallel lines for precision zones (divide into 4 equal parts)
  const line1Start = upperStartPrice - channelWidth * 0.25;
  const line1End = upperEndPrice - channelWidth * 0.25;
  const line2Start = upperStartPrice - channelWidth * 0.5;  // Midline
  const line2End = upperEndPrice - channelWidth * 0.5;
  const line3Start = upperStartPrice - channelWidth * 0.75;
  const line3End = upperEndPrice - channelWidth * 0.75;

  return {
    upperLine: { startPrice: upperStartPrice, endPrice: upperEndPrice },
    lowerLine: { startPrice: lowerStartPrice, endPrice: lowerEndPrice },
    midLine: { startPrice: line2Start, endPrice: line2End },
    innerLine1: { startPrice: line1Start, endPrice: line1End },
    innerLine3: { startPrice: line3Start, endPrice: line3End },
    slope: upperSlope,
    isDescending: upperSlope < 0,
    trend,
    totalBars: recentData.length,
  };
};

/**
 * TelegramChart - High-resolution chart for Telegram signal captures.
 * Features: Big candles, thick EMAs, trend channels, Parabolic SAR, RSI with Bollinger Bands
 */
export const TelegramChart = forwardRef<TelegramChartHandle, TelegramChartProps>(
  ({ market, signalData, resultData }, ref) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const chartRef = useRef<IChartApi | null>(null);
    const candleSeriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);
    const ema9SeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
    const ema21SeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
    
    const [chartReady, setChartReady] = useState(false);
    const [candleData, setCandleData] = useState<CandleData[]>([]);
    const [rsiData, setRsiData] = useState<{ time: Time; value: number }[]>([]);
    const [rsiBBData, setRsiBBData] = useState<{ upper: { time: Time; value: number }[]; middle: { time: Time; value: number }[]; lower: { time: Time; value: number }[] }>({ upper: [], middle: [], lower: [] });
    const [sarData, setSarData] = useState<{ time: Time; value: number; isBelow: boolean }[]>([]);
    const [trendChannel, setTrendChannel] = useState<ReturnType<typeof calculateTrendChannel>>(null);

    // ─── Refs for signal/result data ───────────────────────────────────────────
    // captureChart reads from these refs directly, so auto mode can set them
    // synchronously without waiting for React to re-render and update the closure.
    const signalDataRef = useRef<TelegramChartProps['signalData']>(null);
    const resultDataRef = useRef<TelegramChartProps['resultData']>(null);

    // Sync from props (covers manual mode where parent passes signalData/resultData)
    useEffect(() => { signalDataRef.current = signalData ?? null; }, [signalData]);
    useEffect(() => { resultDataRef.current = resultData ?? null; }, [resultData]);

    // Fixed dimensions for Telegram (desktop-like HD landscape)
    const CHART_WIDTH = 1920;
    const CHART_HEIGHT = 900;

    const fetchChartData = useCallback(async () => {
      if (!market || !candleSeriesRef.current) return;

      try {
        console.log('[TelegramChart] Fetching chart data for:', market);

        const { data, error: fnError } = await supabase.functions.invoke('live-signal', {
          body: { market, action: 'get-chart-data' },
        });

        if (fnError || !data?.success || !Array.isArray(data?.candles)) {
          console.error('[TelegramChart] Failed to fetch data:', fnError || data?.error);
          return;
        }

        let candles: CandleData[] = data.candles
          .map((item: any) => {
            const ms = new Date(item.datetime || item.time).getTime();
            const t = Math.floor(ms / 1000);
            return {
              time: t as Time,
              open: Number(item.open),
              high: Number(item.high),
              low: Number(item.low),
              close: Number(item.close),
            };
          })
          .filter((c: CandleData) =>
            Number.isFinite(c.time as number) &&
            Number.isFinite(c.open) &&
            Number.isFinite(c.high) &&
            Number.isFinite(c.low) &&
            Number.isFinite(c.close) &&
            c.open > 0 && c.high > 0 && c.low > 0 && c.close > 0
          );

        if (candles.length === 0) return;

        // Sort ascending by time
        candles.sort((a, b) => (a.time as number) - (b.time as number));
        
        // Take last 45 candles for bigger display (fewer candles = bigger candles)
        candles = candles.slice(-45);

        setCandleData(candles);

        // Update candle series
        candleSeriesRef.current?.setData(candles);

        // Calculate EMA 9 (thick green line like reference)
        const ema9Data = calculateEMA(candles, 9);
        if (ema9Data.length > 0) ema9SeriesRef.current?.setData(ema9Data);

        // Calculate EMA 21 (thick red line like reference)
        const ema21Data = calculateEMA(candles, 21);
        if (ema21Data.length > 0) ema21SeriesRef.current?.setData(ema21Data);

        // Calculate RSI
        const rsi = calculateRSI(candles, 14);
        setRsiData(rsi);

        // Calculate Bollinger Bands on RSI (for RSI panel only)
        if (rsi.length >= 20) {
          const rsiBB = calculateRSIBollingerBands(rsi, 20, 2);
          setRsiBBData(rsiBB);
        }

        // Calculate Parabolic SAR
        const sar = calculateParabolicSAR(candles);
        setSarData(sar);

        // Calculate trend channel
        const channel = calculateTrendChannel(candles, Math.min(30, candles.length));
        setTrendChannel(channel);

        chartRef.current?.timeScale().fitContent();
        console.log('[TelegramChart] Chart data updated:', candles.length, 'candles');
      } catch (err) {
        console.error('[TelegramChart] Error:', err);
      }
    }, [market]);

    // Initialize chart
    useEffect(() => {
      if (!containerRef.current) return;

      try {
        const chart = createChart(containerRef.current, {
          layout: {
            background: { type: ColorType.Solid, color: '#000000' },
            textColor: '#FFFFFF',
            fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
            fontSize: 14,
          },
          grid: {
            vertLines: { visible: false },
            horzLines: { visible: false },
          },
          width: CHART_WIDTH,
          height: CHART_HEIGHT - 280, // Leave space for much bigger RSI panel
          timeScale: {
            borderColor: '#333333',
            timeVisible: false,
            secondsVisible: false,
            barSpacing: 38, // MUCH BIGGER candles like reference image
            minBarSpacing: 30,
            rightOffset: 12, // Extra space after last candle so arrow is clearly visible
            fixLeftEdge: true,
            fixRightEdge: false, // Allow rightOffset padding to work
          },
          rightPriceScale: {
            borderColor: '#333333',
            scaleMargins: { top: 0.1, bottom: 0.15 },
          },
          leftPriceScale: {
            visible: true,
            borderColor: '#333333',
            scaleMargins: { top: 0.1, bottom: 0.15 },
          },
          crosshair: {
            mode: 0,
          },
          handleScroll: false,
          handleScale: false,
        });

        chartRef.current = chart;
        const chartAny = chart as any;

        // Candlestick series - BIG bright candles
        const candleSeries =
          typeof chartAny.addSeries === 'function' && typeof CandlestickSeries !== 'undefined'
            ? chartAny.addSeries(CandlestickSeries, {
                upColor: '#00FF00',
                downColor: '#FF0000',
                borderUpColor: '#00FF00',
                borderDownColor: '#FF0000',
                wickUpColor: '#00FF00',
                wickDownColor: '#FF0000',
              })
            : typeof chartAny.addCandlestickSeries === 'function'
              ? chartAny.addCandlestickSeries({
                  upColor: '#00FF00',
                  downColor: '#FF0000',
                  borderUpColor: '#00FF00',
                  borderDownColor: '#FF0000',
                  wickUpColor: '#00FF00',
                  wickDownColor: '#FF0000',
                })
              : null;

        if (!candleSeries) {
          console.error('[TelegramChart] Failed to create candle series');
          return;
        }
        candleSeriesRef.current = candleSeries as ISeriesApi<'Candlestick'>;

        // Line series helper
        const addLine = (opts: any) => {
          if (typeof chartAny.addSeries === 'function' && typeof LineSeries !== 'undefined') {
            return chartAny.addSeries(LineSeries, opts);
          }
          if (typeof chartAny.addLineSeries === 'function') {
            return chartAny.addLineSeries(opts);
          }
          return null;
        };

        // EMA 9 - THICK GREEN line (like reference image 3)
        ema9SeriesRef.current = addLine({
          color: '#22C55E',
          lineWidth: 4, // Thick line
          priceLineVisible: false,
          lastValueVisible: false,
        }) as ISeriesApi<'Line'>;

        // EMA 21 - THICK RED line (like reference image 3)
        ema21SeriesRef.current = addLine({
          color: '#EF4444',
          lineWidth: 4, // Thick line
          priceLineVisible: false,
          lastValueVisible: false,
        }) as ISeriesApi<'Line'>;

        setChartReady(true);

        return () => {
          chart.remove();
          chartRef.current = null;
          candleSeriesRef.current = null;
          ema9SeriesRef.current = null;
          ema21SeriesRef.current = null;
          setChartReady(false);
        };
      } catch (e) {
        console.error('[TelegramChart] Init error:', e);
      }
    }, []);

    // Fetch data when market changes
    useEffect(() => {
      if (market && chartReady) {
        fetchChartData();
      }
    }, [market, chartReady, fetchChartData]);

    // Auto-refresh every 70 seconds
    useEffect(() => {
      if (!market) return;
      const interval = setInterval(fetchChartData, 70000);
      return () => clearInterval(interval);
    }, [market, fetchChartData]);

    // Capture function that produces reference-style image with all decorations
    const captureChart = useCallback((): string | null => {
      if (!chartRef.current || !containerRef.current) {
        console.error('[TelegramChart] Cannot capture - chart not ready');
        return null;
      }

      try {
        // Always read from refs — updated synchronously by both prop-sync useEffect
        // AND imperative setSignal/setResult calls (critical for auto mode correctness)
        const signalData = signalDataRef.current;
        const resultData = resultDataRef.current;

        const canvases = Array.from(containerRef.current.querySelectorAll('canvas')) as HTMLCanvasElement[];
        const validCanvases = canvases.filter((c) => c.width > 0 && c.height > 0);

        if (validCanvases.length === 0) {
          console.error('[TelegramChart] No valid canvases found');
          return null;
        }

        // Create output canvas
        const output = document.createElement('canvas');
        output.width = CHART_WIDTH;
        output.height = CHART_HEIGHT;
        const ctx = output.getContext('2d');
        if (!ctx) return null;

        // Black background
        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, CHART_WIDTH, CHART_HEIGHT);

        // Merge chart canvases
        const baseW = Math.max(...validCanvases.map((c) => c.width));
        const baseH = Math.max(...validCanvases.map((c) => c.height));
        
        const merged = document.createElement('canvas');
        merged.width = baseW;
        merged.height = baseH;
        const mctx = merged.getContext('2d');
        if (mctx) {
          mctx.fillStyle = '#000000';
          mctx.fillRect(0, 0, baseW, baseH);
          for (const c of validCanvases) {
            mctx.drawImage(c, 0, 0);
          }
        }

        // Chart area positioning
        const chartAreaY = 0;
        const chartAreaHeight = CHART_HEIGHT - 150; // Space for RSI panel
        
        const scale = Math.min(CHART_WIDTH / baseW, chartAreaHeight / baseH);
        const drawW = Math.round(baseW * scale);
        const drawH = Math.round(baseH * scale);
        const dx = Math.round((CHART_WIDTH - drawW) / 2);
        const dy = chartAreaY + Math.round((chartAreaHeight - drawH) / 2);

        ctx.imageSmoothingEnabled = true;
        (ctx as any).imageSmoothingQuality = 'high';
        ctx.drawImage(merged, dx, dy, drawW, drawH);

        // === DRAW PARABOLIC SAR DOTS (orange dots like reference 4) ===
        if (sarData.length > 0 && candleData.length > 0) {
          const chartPrices = candleData.map(c => ({ high: c.high, low: c.low }));
          const minPrice = Math.min(...chartPrices.map(p => p.low));
          const maxPrice = Math.max(...chartPrices.map(p => p.high));
          const priceRange = maxPrice - minPrice;
          
          const sarStartX = dx + 50;
          const sarEndX = dx + drawW - 50;
          const barWidth = (sarEndX - sarStartX) / Math.max(sarData.length - 1, 1);

          sarData.forEach((point, i) => {
            const x = sarStartX + i * barWidth;
            const normalizedY = (point.value - minPrice) / priceRange;
            const y = dy + drawH - 30 - normalizedY * (drawH - 60);
            
            // Orange dot
            ctx.fillStyle = '#FFA500';
            ctx.beginPath();
            ctx.arc(x, y, 4, 0, Math.PI * 2);
            ctx.fill();
          });
        }

        // === DRAW PROFESSIONAL PARALLEL CHANNEL WITH 3 INTERNAL LINES ===
        if (trendChannel && candleData.length > 0) {
          const chartPrices = candleData.map(c => ({ high: c.high, low: c.low }));
          const minPrice = Math.min(...chartPrices.map(p => p.low));
          const maxPrice = Math.max(...chartPrices.map(p => p.high));
          const priceRange = maxPrice - minPrice;

          const lineStartX = dx + 80; // More space for price axis
          const lineEndX = dx + drawW - 10;

          // Convert price to Y coordinate
          const priceToY = (price: number) => {
            const normalizedY = (price - minPrice) / priceRange;
            return dy + drawH - 30 - normalizedY * (drawH - 60);
          };

          // Thin, smooth, light gray lines for professional look
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
          
          // UPPER TRENDLINE - main descending line from swing highs
          ctx.strokeStyle = 'rgba(180, 180, 180, 0.9)';
          ctx.lineWidth = 1.5;
          ctx.setLineDash([]);
          ctx.beginPath();
          ctx.moveTo(lineStartX, priceToY(trendChannel.upperLine.startPrice));
          ctx.lineTo(lineEndX, priceToY(trendChannel.upperLine.endPrice));
          ctx.stroke();

          // LOWER TRENDLINE - parallel line from swing lows
          ctx.beginPath();
          ctx.moveTo(lineStartX, priceToY(trendChannel.lowerLine.startPrice));
          ctx.lineTo(lineEndX, priceToY(trendChannel.lowerLine.endPrice));
          ctx.stroke();

          // 3 INTERNAL PRECISION LINES - divide channel into 4 equal zones
          ctx.strokeStyle = 'rgba(150, 150, 150, 0.5)';
          ctx.lineWidth = 1;
          ctx.setLineDash([4, 4]);

          // Inner line 1 (25% from top)
          if (trendChannel.innerLine1) {
            ctx.beginPath();
            ctx.moveTo(lineStartX, priceToY(trendChannel.innerLine1.startPrice));
            ctx.lineTo(lineEndX, priceToY(trendChannel.innerLine1.endPrice));
            ctx.stroke();
          }

          // Middle line (50% - center)
          ctx.beginPath();
          ctx.moveTo(lineStartX, priceToY(trendChannel.midLine.startPrice));
          ctx.lineTo(lineEndX, priceToY(trendChannel.midLine.endPrice));
          ctx.stroke();

          // Inner line 3 (75% from top)
          if (trendChannel.innerLine3) {
            ctx.beginPath();
            ctx.moveTo(lineStartX, priceToY(trendChannel.innerLine3.startPrice));
            ctx.lineTo(lineEndX, priceToY(trendChannel.innerLine3.endPrice));
            ctx.stroke();
          }

          ctx.setLineDash([]);
          
          // === DRAW PRICE AXIS ON LEFT SIDE ===
          const priceAxisX = dx + 70;
          const numLabels = 5;
          ctx.font = 'bold 12px "Segoe UI", Arial, sans-serif';
          ctx.fillStyle = '#AAAAAA';
          ctx.textAlign = 'right';
          
          for (let i = 0; i <= numLabels; i++) {
            const price = minPrice + (priceRange * i) / numLabels;
            const y = priceToY(price);
            
            // Price label
            const priceStr = price.toFixed(price < 10 ? 5 : price < 100 ? 4 : 2);
            ctx.fillText(priceStr, priceAxisX - 5, y + 4);
            
            // Small tick mark
            ctx.strokeStyle = '#555555';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(priceAxisX, y);
            ctx.lineTo(priceAxisX + 5, y);
            ctx.stroke();
          }
        }

        // === SIGNAL ARROW MARKER ON LAST RENDERED CANDLE (feature 1) ===
        // Arrow must appear on the LAST (most recent) candle of the chart
        // CRITICAL: Only draw arrow if we're NOT in result mode AND signal data exists
        // This prevents signal overlay from leaking into result captures
        if (!resultData && !resultDataRef.current && candleData.length >= 1 && signalData && chartRef.current && candleSeriesRef.current) {
          const prevCandle = candleData[candleData.length - 1];
          const isCall = signalData.direction === 'CALL';
          const arrowColor = isCall ? '#00FF88' : '#FF3366';
          const glowColor  = isCall ? '#00FF88' : '#FF0055';

          try {
            // Get pixel coords from the chart API (returns coords in the chart canvas space)
            const timeScale = chartRef.current.timeScale();
            const series = candleSeriesRef.current as any;

            // X from time coordinate
            const rawX = timeScale.timeToCoordinate(prevCandle.time);
            // Y from price coordinate  
            const rawHighY = series.priceToCoordinate(prevCandle.high);
            const rawLowY  = series.priceToCoordinate(prevCandle.low);

            if (rawX != null && rawHighY != null && rawLowY != null) {
              // Scale from chart canvas space to output canvas space
              // The chart canvas is baseW x baseH, output is CHART_WIDTH x CHART_HEIGHT
              // We drew it at: ctx.drawImage(merged, dx, dy, drawW, drawH)
              const scaleX = drawW / baseW;
              const scaleY = drawH / baseH;

              const arrowX = dx + rawX * scaleX;
              const highY  = dy + rawHighY * scaleY;
              const lowY   = dy + rawLowY  * scaleY;

              const arrowPad = 30;
              const arrowSize = 32;
              const arrowCenterY = isCall
                ? lowY  + arrowPad + arrowSize   // below wick for UP arrow
                : highY - arrowPad - arrowSize;  // above wick for DOWN arrow

              ctx.save();

              // Radial glow halo
              const gradGlow = ctx.createRadialGradient(arrowX, arrowCenterY, 0, arrowX, arrowCenterY, 55);
              gradGlow.addColorStop(0,   isCall ? 'rgba(0,255,136,0.35)' : 'rgba(255,51,102,0.35)');
              gradGlow.addColorStop(0.5, isCall ? 'rgba(0,255,136,0.12)' : 'rgba(255,51,102,0.12)');
              gradGlow.addColorStop(1,   'transparent');
              ctx.fillStyle = gradGlow;
              ctx.beginPath();
              ctx.arc(arrowX, arrowCenterY, 55, 0, Math.PI * 2);
              ctx.fill();

              // Filled triangle arrow
              ctx.shadowColor = glowColor;
              ctx.shadowBlur = 35;
              ctx.fillStyle = arrowColor;
              ctx.beginPath();
              if (isCall) {
                ctx.moveTo(arrowX,                    arrowCenterY - arrowSize);
                ctx.lineTo(arrowX + arrowSize * 0.9,  arrowCenterY + arrowSize * 0.7);
                ctx.lineTo(arrowX - arrowSize * 0.9,  arrowCenterY + arrowSize * 0.7);
              } else {
                ctx.moveTo(arrowX,                    arrowCenterY + arrowSize);
                ctx.lineTo(arrowX + arrowSize * 0.9,  arrowCenterY - arrowSize * 0.7);
                ctx.lineTo(arrowX - arrowSize * 0.9,  arrowCenterY - arrowSize * 0.7);
              }
              ctx.closePath();
              ctx.fill();

              // White stroke border
              ctx.shadowBlur = 0;
              ctx.strokeStyle = '#FFFFFF';
              ctx.lineWidth = 2.5;
              ctx.stroke();

              // Label text
              ctx.shadowColor = glowColor;
              ctx.shadowBlur = 18;
              ctx.font = 'bold 22px "Segoe UI", Arial, sans-serif';
              ctx.fillStyle = '#FFFFFF';
              ctx.textAlign = 'center';
              const labelY = isCall
                ? arrowCenterY + arrowSize + 26
                : arrowCenterY - arrowSize - 8;
              ctx.fillText(isCall ? '▲ CALL' : '▼ PUT', arrowX, labelY);

              ctx.shadowBlur = 0;
              ctx.restore();

              console.log('[TelegramChart] Arrow drawn at', { arrowX, arrowCenterY, isCall });
            } else {
              console.warn('[TelegramChart] Could not get chart coords for arrow', { rawX, rawHighY, rawLowY });
            }
          } catch (arrowErr) {
            console.error('[TelegramChart] Arrow draw error:', arrowErr);
          }
        }

        // === RESULT BADGE — eye-catching top-right overlay (feature 2) ===
        // When in result mode, signalData arrow is already skipped above
        if (resultData) {
          const badgeW = 320;
          const badgeH = 110;
          const badgeX = CHART_WIDTH - badgeW - 40;
          const badgeY = 40;
          const r = 20;

          let badgeBg: string;
          let badgeBorder: string;
          let badgeGlow: string;
          let badgeText: string;
          let badgeEmoji: string;

          if (resultData.resultType === 'WIN') {
            badgeBg      = 'rgba(0, 25, 10, 0.97)';
            badgeBorder  = '#00FF88';
            badgeGlow    = '#00FF88';
            badgeText    = 'WIN';
            badgeEmoji   = '✅';
          } else if (resultData.resultType === 'MTG') {
            badgeBg      = 'rgba(28, 18, 0, 0.97)';
            badgeBorder  = '#FFB800';
            badgeGlow    = '#FFB800';
            badgeText    = 'MTG WIN';
            badgeEmoji   = '✅';
          } else {
            badgeBg      = 'rgba(28, 0, 0, 0.97)';
            badgeBorder  = '#FF3366';
            badgeGlow    = '#FF0055';
            badgeText    = 'LOSS';
            badgeEmoji   = '❌';
          }

          // Helper: draw rounded rect path (avoids stale path bugs)
          const roundRect = (bx: number, by: number, bw: number, bh: number, br: number) => {
            ctx.beginPath();
            ctx.moveTo(bx + br, by);
            ctx.lineTo(bx + bw - br, by);
            ctx.quadraticCurveTo(bx + bw, by, bx + bw, by + br);
            ctx.lineTo(bx + bw, by + bh - br);
            ctx.quadraticCurveTo(bx + bw, by + bh, bx + bw - br, by + bh);
            ctx.lineTo(bx + br, by + bh);
            ctx.quadraticCurveTo(bx, by + bh, bx, by + bh - br);
            ctx.lineTo(bx, by + br);
            ctx.quadraticCurveTo(bx, by, bx + br, by);
            ctx.closePath();
          };

          ctx.save();

          // 1. Outer neon glow border
          ctx.shadowColor = badgeGlow;
          ctx.shadowBlur = 60;
          ctx.strokeStyle = badgeBorder;
          ctx.lineWidth = 5;
          roundRect(badgeX, badgeY, badgeW, badgeH, r);
          ctx.stroke();
          ctx.shadowBlur = 0;

          // 2. Dark background fill — fresh path
          roundRect(badgeX, badgeY, badgeW, badgeH, r);
          ctx.fillStyle = badgeBg;
          ctx.fill();

          // 3. Shimmer gradient top-half — fresh path
          roundRect(badgeX, badgeY, badgeW, badgeH * 0.55, r);
          const shimmer = ctx.createLinearGradient(badgeX, badgeY, badgeX, badgeY + badgeH * 0.55);
          shimmer.addColorStop(0, badgeBorder + '44');
          shimmer.addColorStop(1, 'transparent');
          ctx.fillStyle = shimmer;
          ctx.fill();

          // 4. Inner accent border — fresh path
          roundRect(badgeX + 3, badgeY + 3, badgeW - 6, badgeH - 6, r - 2);
          ctx.strokeStyle = badgeBorder + '55';
          ctx.lineWidth = 1.5;
          ctx.stroke();

          // 5. Main result text with glow
          ctx.shadowColor = badgeGlow;
          ctx.shadowBlur = 28;
          const fontSize = badgeText === 'MTG WIN' ? 40 : 52;
          ctx.font = `bold ${fontSize}px "Segoe UI", Arial, sans-serif`;
          ctx.fillStyle = badgeBorder;
          ctx.textAlign = 'center';
          const textX = badgeX + badgeW / 2 - 22;
          const textY = badgeY + badgeH / 2 + fontSize * 0.35;
          ctx.fillText(badgeText, textX, textY);
          ctx.shadowBlur = 0;

          // 6. Emoji right side
          ctx.font = '40px "Segoe UI", Arial, sans-serif';
          ctx.fillStyle = '#FFFFFF';
          ctx.textAlign = 'center';
          ctx.fillText(badgeEmoji, badgeX + badgeW - 30, badgeY + badgeH / 2 + 14);

          ctx.restore();
        }

        // === ARTRIX PREMIUM AI DASHBOARD (TOP-LEFT CORNER - moved from right) ===
        const dashboardX = 30; // LEFT side positioning
        const dashboardY = 30;
        const dashboardW = 490;
        const dashboardH = 200;

        // Check if we're in result mode or signal mode
        const isResultMode = !!resultData;
        
        // Get dynamic signal/result info
        // CRITICAL: In result mode, don't use stale signal data for direction/pair
        const signalDirection = isResultMode ? 'CALL' : (signalData?.direction || 'CALL');
        const signalPair = isResultMode ? resultData!.pair : (signalData?.pair || market || 'EUR/USD-OTC');
        const signalTime = isResultMode 
          ? resultData!.time 
          : (signalData?.timestamp 
            ? signalData.timestamp.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false })
            : new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }));
        
        // Colors and text based on mode
        let statusColor: string;
        let statusText: string;
        
        if (isResultMode) {
          // Result mode colors
          if (resultData!.resultType === 'WIN') {
            statusColor = '#22C55E'; // Green for WIN
            statusText = 'WIN ✅';
          } else if (resultData!.resultType === 'MTG') {
            statusColor = '#F59E0B'; // Orange for MTG
            statusText = 'MTG WIN ✅';
          } else {
            statusColor = '#EF4444'; // Red for LOSS
            statusText = 'LOSS ❌';
          }
        } else {
          // Signal mode colors
          const isCall = signalDirection === 'CALL';
          statusColor = isCall ? '#22C55E' : '#EF4444';
          statusText = isCall ? 'BUY' : 'SELL';
        }

        ctx.save();
        
        // Outer glow effect
        ctx.shadowColor = '#00FFFF';
        ctx.shadowBlur = 15;
        ctx.strokeStyle = '#00FFFF';
        ctx.lineWidth = 2;
        ctx.strokeRect(dashboardX, dashboardY, dashboardW, dashboardH);
        
        // Inner background
        ctx.shadowBlur = 0;
        ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
        ctx.fillRect(dashboardX + 2, dashboardY + 2, dashboardW - 4, dashboardH - 4);

        // Brain icon
        const brainX = dashboardX + 50;
        const brainY = dashboardY + 45;
        ctx.strokeStyle = '#00FFFF';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(brainX, brainY, 25, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(brainX - 12, brainY - 5);
        ctx.quadraticCurveTo(brainX, brainY - 15, brainX + 12, brainY - 5);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(brainX - 10, brainY + 5);
        ctx.quadraticCurveTo(brainX, brainY + 12, brainX + 10, brainY + 5);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(brainX, brainY - 20);
        ctx.lineTo(brainX, brainY + 20);
        ctx.stroke();

        // Title - changes based on mode
        ctx.font = 'bold 32px "Segoe UI", Arial, sans-serif';
        ctx.fillStyle = '#00FFFF';
        ctx.textAlign = 'left';
        ctx.shadowColor = '#00FFFF';
        ctx.shadowBlur = 10;
        ctx.fillText(isResultMode ? 'ARTRIX RESULTS' : 'ARTRIX PREMIUM AI', dashboardX + 90, dashboardY + 55);
        
        // Decorative line
        ctx.strokeStyle = '#00FFFF';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(dashboardX + 90, dashboardY + 65);
        ctx.lineTo(dashboardX + dashboardW - 20, dashboardY + 65);
        ctx.stroke();
        
        ctx.shadowBlur = 0;

        // Status box - DYNAMIC color based on result/direction
        const statusBoxX = dashboardX + 20;
        const statusBoxY = dashboardY + 85;
        const statusBoxW = dashboardW - 40;
        const statusBoxH = 50;

        ctx.strokeStyle = statusColor;
        ctx.lineWidth = 2;
        ctx.strokeRect(statusBoxX, statusBoxY, statusBoxW, statusBoxH);
        
        // Hexagon icon with status color
        const hexX = statusBoxX + 30;
        const hexY = statusBoxY + 25;
        const hexR = 12;
        ctx.fillStyle = statusColor;
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
          const angle = (Math.PI / 3) * i - Math.PI / 2;
          const x = hexX + hexR * Math.cos(angle);
          const y = hexY + hexR * Math.sin(angle);
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.fill();
        
        ctx.fillStyle = '#0F172A';
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
          const angle = (Math.PI / 3) * i - Math.PI / 2;
          const x = hexX + (hexR - 4) * Math.cos(angle);
          const y = hexY + (hexR - 4) * Math.sin(angle);
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.fill();

        ctx.font = 'bold 18px "Segoe UI", Arial, sans-serif';
        ctx.fillStyle = '#FFFFFF';
        ctx.textAlign = 'left';
        ctx.fillText(isResultMode ? 'RESULT:' : 'SIGNAL STATUS:', statusBoxX + 55, statusBoxY + 30);

        // Status text with dynamic color - SAME SIZE AS PAIR (22px bold)
        ctx.font = 'bold 22px "Segoe UI", Arial, sans-serif';
        ctx.fillStyle = statusColor;
        ctx.fillText(statusText, statusBoxX + (isResultMode ? 160 : 220), statusBoxY + 32);

        // Expiry circle indicator
        const circleX = statusBoxX + 300;
        const circleY = statusBoxY + 25;
        ctx.strokeStyle = '#00FFFF';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(circleX, circleY, 15, 0, Math.PI * 2);
        ctx.stroke();
        ctx.font = 'bold 14px "Segoe UI", Arial, sans-serif';
        ctx.fillStyle = '#00FFFF';
        ctx.textAlign = 'center';
        ctx.fillText('M1', circleX, circleY + 5);

        // Signal info row - PAIR and TIME - BIGGER SIZE like signal status
        const infoRowY = dashboardY + 160;
        ctx.font = 'bold 22px "Segoe UI", Arial, sans-serif';
        ctx.textAlign = 'left';
        
        // Pair info with cyan color
        ctx.fillStyle = '#38BDF8';
        ctx.fillText('📊', dashboardX + 20, infoRowY);
        ctx.fillStyle = '#38BDF8';
        ctx.fillText(signalPair, dashboardX + 50, infoRowY);
        
        // Time info with status matching color
        ctx.fillStyle = statusColor;
        ctx.fillText('🕐', dashboardX + 260, infoRowY);
        ctx.fillStyle = statusColor;
        ctx.fillText(signalTime, dashboardX + 295, infoRowY);

        // Result mode: Show session stats (Wins/Losses/Win Rate)
        if (isResultMode && resultData) {
          const statsY = dashboardY + 195;
          ctx.font = 'bold 18px "Segoe UI", Arial, sans-serif';
          ctx.textAlign = 'left';
          
          // Wins
          ctx.fillStyle = '#22C55E';
          ctx.fillText(`🏆 Wins: ${resultData.wins}`, dashboardX + 25, statsY);
          
          // Losses
          ctx.fillStyle = '#EF4444';
          ctx.fillText(`❌ Losses: ${resultData.losses}`, dashboardX + 150, statsY);
          
          // Win Rate
          ctx.fillStyle = '#F59E0B';
          ctx.fillText(`📈 ${resultData.winRate}%`, dashboardX + 285, statsY);
        } else {
          // Signal mode: Show indicator legend
          const legendY = dashboardY + 190;
          ctx.font = '13px "Segoe UI", Arial, sans-serif';
          ctx.textAlign = 'left';
          
          ctx.fillStyle = '#22C55E';
          ctx.beginPath();
          ctx.arc(dashboardX + 30, legendY, 5, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillText('EMA 9', dashboardX + 42, legendY + 4);
          
          ctx.fillStyle = '#EF4444';
          ctx.beginPath();
          ctx.arc(dashboardX + 115, legendY, 5, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillText('EMA 21', dashboardX + 127, legendY + 4);
          
          ctx.fillStyle = '#FFA500';
          ctx.beginPath();
          ctx.arc(dashboardX + 205, legendY, 5, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillText('SAR', dashboardX + 217, legendY + 4);
          
          ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
          ctx.beginPath();
          ctx.arc(dashboardX + 275, legendY, 5, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillText('Channel', dashboardX + 287, legendY + 4);
        }

        ctx.restore();

        // === RSI PANEL WITH BOLLINGER BANDS AT BOTTOM - MUCH BIGGER ===
        const rsiPanelY = CHART_HEIGHT - 200;
        const rsiPanelH = 190;
        const rsiPanelX = dx;
        const rsiPanelW = drawW;

        // RSI Panel background
        ctx.fillStyle = 'rgba(10, 15, 35, 0.95)';
        ctx.fillRect(rsiPanelX, rsiPanelY, rsiPanelW, rsiPanelH);

        // RSI Panel border
        ctx.strokeStyle = '#333333';
        ctx.lineWidth = 1;
        ctx.strokeRect(rsiPanelX, rsiPanelY, rsiPanelW, rsiPanelH);

        // RSI Label - Bright cyan color for visibility - BIGGER FONT
        ctx.font = 'bold 20px "Segoe UI", Arial, sans-serif';
        ctx.fillStyle = '#00D4FF';
        ctx.textAlign = 'left';
        ctx.fillText('RSI(14) + BB', rsiPanelX + 10, rsiPanelY + 28);

        const rsiBottom = rsiPanelY + rsiPanelH - 15;
        const rsiTop = rsiPanelY + 40;
        const rsiRange = rsiBottom - rsiTop;

        // Threshold lines (30, 50, 70)
        const y70 = rsiTop + (rsiRange * (100 - 70)) / 100;
        const y50 = rsiTop + (rsiRange * (100 - 50)) / 100;
        const y30 = rsiTop + (rsiRange * (100 - 30)) / 100;

        ctx.setLineDash([4, 4]);
        ctx.strokeStyle = '#EF4444';
        ctx.beginPath();
        ctx.moveTo(rsiPanelX + 90, y70);
        ctx.lineTo(rsiPanelX + rsiPanelW - 10, y70);
        ctx.stroke();
        ctx.fillStyle = '#EF4444';
        ctx.font = '11px "Segoe UI", Arial, sans-serif';
        ctx.fillText('70', rsiPanelX + rsiPanelW - 35, y70 + 4);

        ctx.strokeStyle = '#22C55E';
        ctx.beginPath();
        ctx.moveTo(rsiPanelX + 90, y30);
        ctx.lineTo(rsiPanelX + rsiPanelW - 10, y30);
        ctx.stroke();
        ctx.fillStyle = '#22C55E';
        ctx.fillText('30', rsiPanelX + rsiPanelW - 35, y30 + 4);

        ctx.strokeStyle = '#6B7280';
        ctx.beginPath();
        ctx.moveTo(rsiPanelX + 90, y50);
        ctx.lineTo(rsiPanelX + rsiPanelW - 10, y50);
        ctx.stroke();

        ctx.setLineDash([]);

        // Draw Bollinger Bands on RSI - using cyan color
        if (rsiBBData.upper.length > 1) {
          const bbBarWidth = (rsiPanelW - 100) / rsiBBData.upper.length;

          // Upper BB band (semi-transparent fill area) - cyan tint
          ctx.beginPath();
          ctx.fillStyle = 'rgba(0, 212, 255, 0.15)';
          for (let i = 0; i < rsiBBData.upper.length; i++) {
            const x = rsiPanelX + 90 + i * bbBarWidth;
            const yUpper = rsiTop + (rsiRange * (100 - rsiBBData.upper[i].value)) / 100;
            if (i === 0) ctx.moveTo(x, yUpper);
            else ctx.lineTo(x, yUpper);
          }
          for (let i = rsiBBData.lower.length - 1; i >= 0; i--) {
            const x = rsiPanelX + 90 + i * bbBarWidth;
            const yLower = rsiTop + (rsiRange * (100 - rsiBBData.lower[i].value)) / 100;
            ctx.lineTo(x, yLower);
          }
          ctx.closePath();
          ctx.fill();

          // Upper BB line - cyan
          ctx.strokeStyle = '#00D4FF';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          for (let i = 0; i < rsiBBData.upper.length; i++) {
            const x = rsiPanelX + 90 + i * bbBarWidth;
            const y = rsiTop + (rsiRange * (100 - rsiBBData.upper[i].value)) / 100;
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.stroke();

          // Lower BB line
          ctx.beginPath();
          for (let i = 0; i < rsiBBData.lower.length; i++) {
            const x = rsiPanelX + 90 + i * bbBarWidth;
            const y = rsiTop + (rsiRange * (100 - rsiBBData.lower[i].value)) / 100;
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.stroke();

          // Middle BB line (dashed)
          ctx.setLineDash([3, 3]);
          ctx.beginPath();
          for (let i = 0; i < rsiBBData.middle.length; i++) {
            const x = rsiPanelX + 90 + i * bbBarWidth;
            const y = rsiTop + (rsiRange * (100 - rsiBBData.middle[i].value)) / 100;
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.stroke();
          ctx.setLineDash([]);
        }

        // Draw RSI line - using bright yellow/gold for main visibility
        if (rsiData.length > 1) {
          const rsiBarWidth = (rsiPanelW - 100) / rsiData.length;

          ctx.lineWidth = 3; // Thicker for visibility
          for (let i = 0; i < rsiData.length; i++) {
            const x = rsiPanelX + 90 + i * rsiBarWidth;
            const val = rsiData[i].value;
            const y = rsiTop + (rsiRange * (100 - val)) / 100;

            if (val > 70) {
              ctx.strokeStyle = '#EF4444'; // Red for overbought
            } else if (val < 30) {
              ctx.strokeStyle = '#22C55E'; // Green for oversold
            } else {
              ctx.strokeStyle = '#FFD700'; // Gold/Yellow for normal - much more visible
            }

            if (i === 0) {
              ctx.beginPath();
              ctx.moveTo(x, y);
            } else {
              ctx.lineTo(x, y);
              ctx.stroke();
              ctx.beginPath();
              ctx.moveTo(x, y);
            }
          }
          ctx.stroke();

          // Current RSI value - larger and more visible - MATCH RSI LABEL SIZE
          const lastRsi = rsiData[rsiData.length - 1];
          if (lastRsi) {
            const rsiColor = lastRsi.value > 70 ? '#EF4444' : lastRsi.value < 30 ? '#22C55E' : '#FFD700';
            ctx.font = 'bold 20px "Segoe UI", Arial, sans-serif';
            ctx.fillStyle = rsiColor;
            ctx.textAlign = 'left';
            ctx.fillText(`${lastRsi.value.toFixed(1)}`, rsiPanelX + 155, rsiPanelY + 29);
          }
        }

        // Axis labels
        ctx.font = 'bold 14px "Segoe UI", Arial, sans-serif';
        ctx.fillStyle = '#FFFFFF';
        
        ctx.save();
        ctx.translate(20, (CHART_HEIGHT - 280) / 2);
        ctx.rotate(-Math.PI / 2);
        ctx.textAlign = 'center';
        ctx.fillText('Price', 0, 0);
        ctx.restore();

        ctx.textAlign = 'center';
        ctx.fillText('Time', CHART_WIDTH / 2, CHART_HEIGHT - 5);

        console.log('[TelegramChart] Capture successful with all decorations');
        return output.toDataURL('image/png', 1.0);
      } catch (err) {
        console.error('[TelegramChart] Capture error:', err);
        return null;
      }
    }, [market, rsiData, rsiBBData, sarData, trendChannel, candleData]);

    // Expose methods via ref
    useImperativeHandle(ref, () => ({
      capture: captureChart,
      isReady: () => chartReady && candleData.length > 0,
      setSignal: (data) => {
        // Enter signal mode immediately: clear any stale result overlay from previous trade
        resultDataRef.current = null;
        signalDataRef.current = data ?? null;
      },
      setResult: (data) => {
        // Enter result mode immediately: clear signal arrow so overlays never mix
        signalDataRef.current = null;
        resultDataRef.current = data ?? null;
      },
    }), [captureChart, chartReady, candleData.length]);

    return (
      <div
        style={{
          position: 'fixed',
          left: '-9999px',
          top: '-9999px',
          width: CHART_WIDTH,
          height: CHART_HEIGHT,
          overflow: 'hidden',
          pointerEvents: 'none',
          opacity: 0,
        }}
      >
        <div
          ref={containerRef}
          style={{
            width: CHART_WIDTH,
            height: CHART_HEIGHT - 280,
            background: '#000000',
          }}
        />
      </div>
    );
  }
);

TelegramChart.displayName = 'TelegramChart';
