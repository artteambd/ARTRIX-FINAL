import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Check, X, RefreshCw, Settings, Image, Trophy, AlertTriangle, Bot, BotOff, Zap, ChevronDown, Play, Square, Activity, Radio, TrendingUp, TrendingDown, Clock, Target, BarChart2, ChevronUp, Layers } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

// All 44 OTC pairs
const AUTO_PAIRS = [
  { id: 'EURUSD-OTC', name: 'EUR/USD OTC' },
  { id: 'GBPUSD-OTC', name: 'GBP/USD OTC' },
  { id: 'USDJPY-OTC', name: 'USD/JPY OTC' },
  { id: 'AUDUSD-OTC', name: 'AUD/USD OTC' },
  { id: 'USDCAD-OTC', name: 'USD/CAD OTC' },
  { id: 'USDCHF-OTC', name: 'USD/CHF OTC' },
  { id: 'NZDUSD-OTC', name: 'NZD/USD OTC' },
  { id: 'AUDCAD-OTC', name: 'AUD/CAD OTC' },
  { id: 'AUDJPY-OTC', name: 'AUD/JPY OTC' },
  { id: 'AUDNZD-OTC', name: 'AUD/NZD OTC' },
  { id: 'CADCHF-OTC', name: 'CAD/CHF OTC' },
  { id: 'CADJPY-OTC', name: 'CAD/JPY OTC' },
  { id: 'CHFJPY-OTC', name: 'CHF/JPY OTC' },
  { id: 'EURAUD-OTC', name: 'EUR/AUD OTC' },
  { id: 'EURCAD-OTC', name: 'EUR/CAD OTC' },
  { id: 'EURCHF-OTC', name: 'EUR/CHF OTC' },
  { id: 'EURGBP-OTC', name: 'EUR/GBP OTC' },
  { id: 'EURJPY-OTC', name: 'EUR/JPY OTC' },
  { id: 'EURNZD-OTC', name: 'EUR/NZD OTC' },
  { id: 'EURSGD-OTC', name: 'EUR/SGD OTC' },
  { id: 'GBPAUD-OTC', name: 'GBP/AUD OTC' },
  { id: 'GBPCAD-OTC', name: 'GBP/CAD OTC' },
  { id: 'GBPCHF-OTC', name: 'GBP/CHF OTC' },
  { id: 'GBPJPY-OTC', name: 'GBP/JPY OTC' },
  { id: 'USDARS-OTC', name: 'USD/ARS OTC' },
  { id: 'USDBDT-OTC', name: 'USD/BDT OTC' },
  { id: 'USDEGP-OTC', name: 'USD/EGP OTC' },
  { id: 'USDGBP-OTC', name: 'USD/GBP OTC' },
  { id: 'USDIDR-OTC', name: 'USD/IDR OTC' },
  { id: 'USDINR-OTC', name: 'USD/INR OTC' },
  { id: 'USDMXN-OTC', name: 'USD/MXN OTC' },
  { id: 'USDNGN-OTC', name: 'USD/NGN OTC' },
  { id: 'USDPKR-OTC', name: 'USD/PKR OTC' },
  { id: 'USDTRY-OTC', name: 'USD/TRY OTC' },
  { id: 'BRLUSD-OTC', name: 'BRL/USD OTC' },
  { id: 'BTCUSD-OTC', name: 'BTC/USD OTC' },
  { id: 'XAUUSD-OTC', name: 'XAU/USD OTC' },
  { id: 'AXP-OTC', name: 'American Express OTC' },
  { id: 'PFE-OTC', name: 'Pfizer OTC' },
  { id: 'INTL-OTC', name: 'Intel OTC' },
  { id: 'JNJ-OTC', name: 'J&J OTC' },
  { id: 'MCD-OTC', name: "McDonald's OTC" },
  { id: 'FB-OTC', name: 'Meta OTC' },
  { id: 'BA-OTC', name: 'Boeing OTC' },
];

interface TelegramSignalPanelProps {
  isOpen: boolean;
  onClose: () => void;
  currentSignal: {
    market: string;
    direction: 'CALL' | 'PUT';
    confidence: number;
    entryPrice: number;
    timestamp: Date;
  } | null;
  signalHistory: Array<{
    market: string;
    direction: 'CALL' | 'PUT';
    timestamp: Date;
    status: 'active' | 'won' | 'lost' | 'expired';
  }>;
  onSignalSent?: () => void;
  chartCaptureFunc?: (() => string | null) | null;
  telegramChartCapture?: (() => string | null) | null;
  /** Called by auto mode before capture so LiveSignal can switch TelegramChart to the correct pair */
  onAutoMarketChange?: (pair: string) => void;
  /** Called when auto mode fires a signal — updates TelegramChart dashboard */
  onAutoSignalFired?: (direction: 'CALL' | 'PUT', pair: string, timestamp: Date) => void;
  /** Called when auto mode result is ready — switches TelegramChart to result mode */
  onAutoResultReady?: (resultType: 'WIN' | 'LOSS' | 'MTG', pair: string, time: string, wins: number, losses: number, winRate: number) => void;
  /** Directly sets TelegramChart signal data via ref — synchronous, bypasses React re-render */
  onAutoSetSignal?: (data: { direction: 'CALL' | 'PUT'; timestamp: Date; pair: string } | null) => void;
  /** Directly sets TelegramChart result data via ref — synchronous, bypasses React re-render */
  onAutoSetResult?: (data: { resultType: 'WIN' | 'LOSS' | 'MTG'; pair: string; time: string; wins: number; losses: number; winRate: number } | null) => void;
  /** When false, auto mode S1 skips AI analysis and uses fast live-signal instead */
  aiEnabled?: boolean;
}

interface TradeRecord {
  time: string;
  pair: string;
  direction: 'CALL' | 'PUT';
  result: 'win' | 'loss' | 'mtg';
}

// Auto Mode state
type AutoPhase = 'idle' | 'ai-analyzing' | 'strategy-checking' | 'matched' | 'no-match' | 'sending';

export function TelegramSignalPanel({ 
  isOpen, 
  onClose, 
  currentSignal,
  signalHistory,
  onSignalSent,
  chartCaptureFunc,
  telegramChartCapture,
  onAutoMarketChange,
  onAutoSignalFired,
  onAutoResultReady,
  onAutoSetSignal,
  onAutoSetResult,
  aiEnabled = true,
}: TelegramSignalPanelProps) {
  const [botToken, setBotToken] = useState('');
  const [chatId, setChatId] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [winCount, setWinCount] = useState(0);
  const [lossCount, setLossCount] = useState(0);
  const [mtgCount, setMtgCount] = useState(0);
  const [tradeRecords, setTradeRecords] = useState<TradeRecord[]>([]);

  // Refs to hold LIVE values — avoids stale closure bug in async auto mode callbacks
  const winCountRef = useRef(0);
  const lossCountRef = useRef(0);
  const mtgCountRef = useRef(0);
  const tradeRecordsRef = useRef<TradeRecord[]>([]);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);

  // Auto Mode state
  const [autoMode, setAutoMode] = useState(false);
  const [autoSelectedPairs, setAutoSelectedPairs] = useState<string[]>(['EURUSD-OTC']);
  const [showPairDropdown, setShowPairDropdown] = useState(false);
  const [autoPhase, setAutoPhase] = useState<AutoPhase>('idle');
  const [autoSignal, setAutoSignal] = useState<{ direction: 'CALL' | 'PUT'; confidence: number; pair: string; time: string } | null>(null);
  const [autoLog, setAutoLog] = useState<string>('');
  const [aiCountdown, setAiCountdown] = useState(0);
  const [currentScanIndex, setCurrentScanIndex] = useState(0);
  const autoRunning = useRef(false);
  const autoTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  // Problem 4 fix: guard to prevent concurrent signal fires during wait period
  const signalFiringRef = useRef(false);

  // ═══ Strategy Selector (1 = AI + Strategy, 2 = Indicator + Artix lite) ═══
  const [activeStrategy, setActiveStrategy] = useState<1 | 2>(1);

  // Load settings from localStorage
  useEffect(() => {
    const savedToken = localStorage.getItem('telegram_bot_token');
    const savedChatId = localStorage.getItem('telegram_chat_id');
    const savedWins = localStorage.getItem('telegram_wins');
    const savedLosses = localStorage.getItem('telegram_losses');
    const savedMtg = localStorage.getItem('telegram_mtg');
    const savedRecords = localStorage.getItem('telegram_trade_records');
    const savedAvatar = localStorage.getItem('user_avatar_url');
    const savedAutoPair = localStorage.getItem('auto_selected_pair');
    
    if (savedToken) setBotToken(savedToken);
    if (savedChatId) setChatId(savedChatId);
    if (savedWins) { const v = parseInt(savedWins); setWinCount(v); winCountRef.current = v; }
    if (savedLosses) { const v = parseInt(savedLosses); setLossCount(v); lossCountRef.current = v; }
    if (savedMtg) { const v = parseInt(savedMtg); setMtgCount(v); mtgCountRef.current = v; }
    if (savedRecords) { const v = JSON.parse(savedRecords); setTradeRecords(v); tradeRecordsRef.current = v; }
    if (savedAvatar) setAvatarUrl(savedAvatar);
    if (savedAutoPair) {
      try { setAutoSelectedPairs(JSON.parse(savedAutoPair)); } catch { setAutoSelectedPairs([savedAutoPair]); }
    }
  }, []);

  // Keep refs in sync with state (so async callbacks always read latest values)
  useEffect(() => { winCountRef.current = winCount; }, [winCount]);
  useEffect(() => { lossCountRef.current = lossCount; }, [lossCount]);
  useEffect(() => { mtgCountRef.current = mtgCount; }, [mtgCount]);
  useEffect(() => { tradeRecordsRef.current = tradeRecords; }, [tradeRecords]);

  // Keep autoSelectedPairs ref in sync
  useEffect(() => {
    autoSelectedPairsRef.current = autoSelectedPairs;
  }, [autoSelectedPairs]);

  // Stop auto mode on panel close
  useEffect(() => {
    if (!isOpen) {
      stopAutoMode();
    }
  }, [isOpen]);

  const saveSettings = () => {
    localStorage.setItem('telegram_bot_token', botToken);
    localStorage.setItem('telegram_chat_id', chatId);
    toast.success('Telegram settings saved!');
    setShowSettings(false);
  };

  const getWinRate = () => {
    const total = winCount + lossCount;
    if (total === 0) return 0;
    return Math.round((winCount / total) * 100);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
  };

  const formatDate = () => {
    const now = new Date();
    return `${now.getFullYear()}.${String(now.getMonth() + 1).padStart(2, '0')}.${String(now.getDate()).padStart(2, '0')}`;
  };

  // ============================================================
  // AUTO MODE — AI + Strategy Matchup Engine
  // ============================================================
  const stopAutoMode = () => {
    autoRunning.current = false;
    signalFiringRef.current = false;
    setAutoMode(false);
    setAutoPhase('idle');
    setAutoLog('');
    setAiCountdown(0);
    if (autoTimerRef.current) {
      clearInterval(autoTimerRef.current);
      autoTimerRef.current = null;
    }
  };

  // selectedPairs is captured at call time from the ref so cycle always uses latest selection
  const autoSelectedPairsRef = useRef<string[]>([]);

  const wait = (ms: number) => new Promise(res => setTimeout(res, ms));

  const runAutoSignalCycle = async (indexInSelected: number) => {
    if (!autoRunning.current) return;

    const selected = autoSelectedPairsRef.current;
    if (selected.length === 0) {
      setAutoLog('⚠️ No pairs selected. Stopping auto mode.');
      stopAutoMode();
      return;
    }

    const safeIndex = indexInSelected % selected.length;
    const pair = selected[safeIndex];
    setCurrentScanIndex(safeIndex);

    const nextIndex = (safeIndex + 1) % selected.length;

    let finalDirection: 'CALL' | 'PUT' | null = null;
    let finalConfidence = 0;
    let entryPriceForResult = 0;
    let modeLabel = '';

    // ══════════════════════════════════════════════════════════════
    // AI OFF — Fast Mode: skip analyze-signal, use live-signal directly
    // ══════════════════════════════════════════════════════════════
    if (!aiEnabled) {
      setAutoPhase('strategy-checking');
      setAutoLog(`⚡ [${safeIndex + 1}/${selected.length}] Fast mode — live-signal analysis on ${pair}...`);
      setAiCountdown(30);
      autoTimerRef.current = setInterval(() => {
        setAiCountdown(prev => {
          if (prev <= 1) { if (autoTimerRef.current) clearInterval(autoTimerRef.current); return 0; }
          return prev - 1;
        });
      }, 1000);

      try {
        const fastRes = await supabase.functions.invoke('live-signal', {
          body: { market: pair, action: 'fast-signal' }
        });
        if (autoTimerRef.current) clearInterval(autoTimerRef.current);
        if (!autoRunning.current) return;

        if (fastRes.error || !fastRes.data?.success || !fastRes.data?.analysis) {
          setAutoLog(`⚠️ Fast signal failed on ${pair}. Switching to next pair...`);
          setAutoPhase('no-match');
          await wait(3000);
          if (autoRunning.current) runAutoSignalCycle(nextIndex);
          return;
        }

        const fa = fastRes.data.analysis;
        const rawDir = typeof fa.direction === 'string' ? fa.direction.toUpperCase() : '';
        const fastDir: 'CALL' | 'PUT' | null =
          rawDir === 'CALL' || rawDir === 'UP' ? 'CALL' :
          rawDir === 'PUT' || rawDir === 'DOWN' ? 'PUT' : null;
        const fastConf = Number(fa.confidence ?? 60);

        if (!fastDir || fastConf < 55) {
          setAutoLog(`⚠️ Fast signal too weak on ${pair} (${fastConf}%). → Next pair...`);
          setAutoPhase('no-match');
          await wait(3000);
          if (autoRunning.current) runAutoSignalCycle(nextIndex);
          return;
        }

        finalDirection = fastDir;
        finalConfidence = fastConf;
        entryPriceForResult = Number(fa.currentPrice ?? 0);
        modeLabel = '⚡ AI OFF — Fast Live-Signal';
        setAutoLog(`✅ Fast: ${finalDirection} @ ${finalConfidence}% on ${pair} — Sending...`);
      } catch (e: any) {
        if (autoTimerRef.current) clearInterval(autoTimerRef.current);
        signalFiringRef.current = false;
        setAutoLog(`⚠️ Fast signal error on ${pair}: ${e.message}. → Next pair...`);
        setAutoPhase('no-match');
        await wait(3000);
        if (autoRunning.current) runAutoSignalCycle(nextIndex);
        return;
      }
    } else {
    // ══════════════════════════════════════════════════════════════
    // AI ON — Full Mode: run analyze-signal + live-signal in PARALLEL
    // ══════════════════════════════════════════════════════════════
      setAutoPhase('ai-analyzing');
      setAutoLog(`🧠 [${safeIndex + 1}/${selected.length}] AI analyzing ${pair}... (~3 min)`);
      setAiCountdown(180);
      autoTimerRef.current = setInterval(() => {
        setAiCountdown(prev => {
          if (prev <= 1) { if (autoTimerRef.current) clearInterval(autoTimerRef.current); return 0; }
          return prev - 1;
        });
      }, 1000);

      try {
        // Run AI + live-signal IN PARALLEL (same as manual generateSignal)
        const [aiResult, lsResult] = await Promise.allSettled([
          supabase.functions.invoke('analyze-signal', { body: { pair } }),
          supabase.functions.invoke('live-signal', { body: { market: pair } }),
        ]);

        if (autoTimerRef.current) clearInterval(autoTimerRef.current);
        if (!autoRunning.current) return;

        const rawAiValue = aiResult.status === 'fulfilled' ? aiResult.value : null;
        const aiData = rawAiValue?.data && !rawAiValue?.error ? rawAiValue.data : null;
        const lsData = lsResult.status === 'fulfilled' ? lsResult.value.data : null;

        // Normalize AI direction (can come back as UP/DOWN/CALL/PUT)
        const rawAiDir = typeof (aiData?.aiDirection ?? aiData?.direction) === 'string'
          ? String(aiData?.aiDirection ?? aiData?.direction).toUpperCase()
          : null;
        const aiDir: 'CALL' | 'PUT' | null =
          rawAiDir === 'UP' || rawAiDir === 'CALL' ? 'CALL' :
          rawAiDir === 'DOWN' || rawAiDir === 'PUT' ? 'PUT' : null;
        const aiConf = Number(aiData?.aiConfidence ?? aiData?.confidence ?? 0);
        const aiFiltered = aiData?.filtered === true || aiData?.matchStatus === 'LOW_CONFIDENCE' || aiData?.direction === 'NO_SIGNAL';

        // Normalize live-signal direction
        const rawLsDir = typeof lsData?.analysis?.direction === 'string'
          ? lsData.analysis.direction.toUpperCase()
          : null;
        const lsDir: 'CALL' | 'PUT' | null =
          rawLsDir === 'CALL' ? 'CALL' : rawLsDir === 'PUT' ? 'PUT' : null;
        const lsConf = Number(lsData?.analysis?.confidence ?? 0);

        // Backend fallback direction (pillar/candle resolved by analyze-signal)
        const rawBackendDir = typeof aiData?.direction === 'string' ? aiData.direction.toUpperCase() : null;
        const backendDir: 'CALL' | 'PUT' | null =
          rawBackendDir === 'UP' || rawBackendDir === 'CALL' ? 'CALL' :
          rawBackendDir === 'DOWN' || rawBackendDir === 'PUT' ? 'PUT' : null;
        const backendConf = Number(aiData?.confidence ?? 0);

        setAutoPhase('strategy-checking');

        // Determine final signal direction by authority order:
        // 1. AI direction (if valid + confident) — primary authority
        // 2. Backend pillar/fallback direction
        // 3. Live-signal direction
        if (aiDir && aiConf >= 65 && !aiFiltered) {
          const strategyMatch = lsDir ? aiDir === lsDir : false;
          const pillarData = lsData?.scoring?.pillarAnalysis || null;
          const pillarTrend = pillarData?.trend || 'UNKNOWN';

          setAutoLog(
            `🔬 AI: ${aiDir} @ ${aiConf}% | LiveSignal: ${lsDir ?? 'N/A'} @ ${lsConf}% | Pillar: ${pillarTrend}\n` +
            `${strategyMatch ? '✅ DUAL CONFIRMED' : '🧠 AI AUTHORITY — overriding strategy'}`
          );

          finalDirection = aiDir;
          finalConfidence = strategyMatch
            ? Math.min(98, Math.round((aiConf + lsConf) / 2) + 5)
            : Math.max(55, aiConf - 5);
          entryPriceForResult = Number(lsData?.analysis?.currentPrice ?? aiData?.currentPrice ?? 0);
          modeLabel = strategyMatch ? '🤖 DUAL CONFIRMED (AI + Strategy)' : '🧠 AI AUTHORITY';

        } else if (backendDir && backendConf > 0 && !aiFiltered) {
          setAutoLog(`🔬 Pillar fallback: ${backendDir} @ ${backendConf}% on ${pair}. Live: ${lsDir ?? 'N/A'}`);
          const strategyMatch = lsDir ? backendDir === lsDir : false;
          finalDirection = backendDir;
          finalConfidence = strategyMatch
            ? Math.min(98, Math.round((backendConf + lsConf) / 2) + 5)
            : Math.max(55, backendConf);
          entryPriceForResult = Number(lsData?.analysis?.currentPrice ?? 0);
          modeLabel = '⚙️ PILLAR + Strategy';

        } else if (lsDir && lsConf >= 55) {
          setAutoLog(`🔬 Live-signal only: ${lsDir} @ ${lsConf}% on ${pair}. (AI unavailable)`);
          finalDirection = lsDir;
          finalConfidence = lsConf;
          entryPriceForResult = Number(lsData?.analysis?.currentPrice ?? 0);
          modeLabel = '📊 LIVE-SIGNAL (AI fallback)';

        } else {
          setAutoLog(`⚠️ No valid signal on ${pair} (AI conf: ${aiConf}%, LS conf: ${lsConf}%). → Next pair...`);
          setAutoPhase('no-match');
          await wait(3000);
          if (autoRunning.current) runAutoSignalCycle(nextIndex);
          return;
        }

      } catch (e: any) {
        if (autoTimerRef.current) clearInterval(autoTimerRef.current);
        signalFiringRef.current = false;
        setAutoLog(`⚠️ Error on ${pair}: ${e.message}. → Next pair...`);
        setAutoPhase('no-match');
        await wait(3000);
        if (autoRunning.current) runAutoSignalCycle(nextIndex);
        return;
      }
    } // end AI ON block

    // ── Common signal-fire logic (used by both AI ON and AI OFF paths) ──
    try {
      if (!finalDirection) {
        setAutoLog(`⚠️ No direction resolved for ${pair}. → Next pair...`);
        setAutoPhase('no-match');
        await wait(3000);
        if (autoRunning.current) runAutoSignalCycle(nextIndex);
        return;
      }
      if (signalFiringRef.current) {
        setAutoLog(`⏳ Signal already active, skipping ${pair}. Moving to next pair...`);
        setAutoPhase('no-match');
        await wait(3000);
        if (autoRunning.current) runAutoSignalCycle(nextIndex);
        return;
      }

      signalFiringRef.current = true;
      const now = new Date();
      const entryTime = new Date(now);
      entryTime.setSeconds(0, 0);
      entryTime.setMinutes(entryTime.getMinutes() + 1);
      const timeStr = formatTime(entryTime);
      const pairLabel = pair.replace('-OTC', '');

      setAutoLog(`🚀 ${modeLabel} — ${finalDirection} for ${pairLabel} at ${timeStr} — Sending to Telegram...`);
      setAutoPhase('matched');
      setAutoSignal({ direction: finalDirection, confidence: finalConfidence, pair: pairLabel, time: timeStr });

      if (!autoRunning.current) { signalFiringRef.current = false; return; }
      setAutoPhase('sending');

      const message = buildAutoSignalMessage(pairLabel, finalDirection, timeStr, finalConfidence, aiEnabled);
      await sendAutoToTelegramWithChart(message, pair, finalDirection, entryTime);
      onSignalSent?.();

      setAutoLog(`✅ Signal sent! Checking early WIN at 65s, then full result at 120s...`);

      // ═══ INSTANT WIN DETECTION — Check at 65s for immediate WIN ═══
      await wait(65000);
      if (!autoRunning.current) { signalFiringRef.current = false; return; }

      setAutoLog(`🔍 Early WIN check for ${pairLabel}...`);
      let earlyWinDetected = false;
      try {
        const earlyRes = await supabase.functions.invoke('live-signal', {
          body: {
            action: 'check-result',
            market: pair,
            direction: finalDirection,
            entryPrice: entryPriceForResult,
            entryTime: entryTime.toISOString(),
            expiryTime: new Date(entryTime.getTime() + 65000).toISOString(),
            lastTrade: null,
            checkMtgWindow: false,
          }
        });
        if (earlyRes.data?.success && String(earlyRes.data?.result).toLowerCase() === 'win') {
          earlyWinDetected = true;
          setAutoLog(`🎯 INSTANT WIN detected on ${pairLabel}! Firing result immediately.`);
        }
      } catch (e) {
        console.log('[AUTO] Early check failed, continuing to full check');
      }

      if (earlyWinDetected) {
        // Fire WIN immediately — no need to wait remaining 55s
        await checkAndSendAutoResult(pair, pairLabel, finalDirection, entryPriceForResult, entryTime, timeStr, nextIndex, selected.length);
      } else {
        // Wait remaining ~55s for full MTG check
        setAutoLog(`⏳ No early WIN on ${pairLabel}. Waiting for MTG window...`);
        await wait(55000);
        if (!autoRunning.current) { signalFiringRef.current = false; return; }
        setAutoLog(`🔍 Full result check for ${pairLabel}...`);
        await checkAndSendAutoResult(pair, pairLabel, finalDirection, entryPriceForResult, entryTime, timeStr, nextIndex, selected.length);
      }

      signalFiringRef.current = false;
      if (autoRunning.current) {
        setAutoSignal(null);
        runAutoSignalCycle(nextIndex);
      }

    } catch (e: any) {
      signalFiringRef.current = false;
      console.error('[AUTO-MODE] Error:', e);
      setAutoLog(`⚠️ Error on ${pair}: ${e.message}. → Next pair...`);
      setAutoPhase('no-match');
      await wait(3000);
      if (autoRunning.current) runAutoSignalCycle(nextIndex);
    }
  };


  // ═══════════════════════════════════════════════════════════════
  // STRATEGY 2 AUTO CYCLE — Lightweight indicator-only (4 batches)
  // No AI — runs indicator strategy + Artix lite across all pairs
  // ═══════════════════════════════════════════════════════════════
  const runAutoSignalCycleS2 = async (batchIndex: number) => {
    if (!autoRunning.current) return;

    const selected = autoSelectedPairsRef.current;
    if (selected.length === 0) {
      setAutoLog('⚠️ No pairs selected. Stopping auto mode.');
      stopAutoMode();
      return;
    }

    // Split into 4 batches
    const BATCH_COUNT = 4;
    const batchSize = Math.ceil(selected.length / BATCH_COUNT);
    const safeBatchIdx = batchIndex % BATCH_COUNT;
    const batchStart = safeBatchIdx * batchSize;
    const batchPairs = selected.slice(batchStart, batchStart + batchSize);

    if (batchPairs.length === 0) {
      if (autoRunning.current) runAutoSignalCycleS2((safeBatchIdx + 1) % BATCH_COUNT);
      return;
    }

    // Wait for exact next candle boundary; at :00 it starts immediately
    const nowSync = new Date();
    const msIntoMinute = nowSync.getSeconds() * 1000 + nowSync.getMilliseconds();
    const msUntilCandleOpen = (60000 - msIntoMinute) % 60000;

    if (msUntilCandleOpen > 0) {
      setAutoLog(`⏳ [S2] Waiting ${Math.ceil(msUntilCandleOpen / 1000)}s for next candle open before analyzing...`);
      setAutoPhase('idle');
      await wait(msUntilCandleOpen);
      if (!autoRunning.current) return;
    }

    setCurrentScanIndex(safeBatchIdx);
    setAutoPhase('strategy-checking');
    setAutoLog(`📊 [S2] Batch ${safeBatchIdx + 1}/${BATCH_COUNT} — Scanning ${batchPairs.length} pairs...`);
    setAiCountdown(30);

    autoTimerRef.current = setInterval(() => {
      setAiCountdown(prev => {
        if (prev <= 1) { if (autoTimerRef.current) clearInterval(autoTimerRef.current); return 0; }
        return prev - 1;
      });
    }, 1000);

    const nextBatch = (safeBatchIdx + 1) % BATCH_COUNT;

    try {
      const { data, error } = await supabase.functions.invoke('strategy2-signal', {
        body: { pairs: batchPairs, action: 'batch-scan' }
      });

      if (autoTimerRef.current) clearInterval(autoTimerRef.current);
      if (!autoRunning.current) return;

      if (error || !data?.success) {
        setAutoLog(`⚠️ [S2] Batch ${safeBatchIdx + 1} failed. → Next batch...`);
        setAutoPhase('no-match');
        await wait(3000);
        if (autoRunning.current) runAutoSignalCycleS2(nextBatch);
        return;
      }

      const matched = data.matched as Array<{
        pair: string;
        finalDirection: 'CALL' | 'PUT';
        finalConfidence: number;
        reasons: string[];
        entryPrice?: number;
      }>;

      if (!matched || matched.length === 0) {
        setAutoLog(`❌ [S2] No match in batch ${safeBatchIdx + 1} (${batchPairs.length} pairs). → Next batch...`);
        setAutoPhase('no-match');
        await wait(3000);
        if (autoRunning.current) runAutoSignalCycleS2(nextBatch);
        return;
      }

      const best = matched.sort((a, b) => b.finalConfidence - a.finalConfidence)[0];

      if (signalFiringRef.current) {
        setAutoLog(`⏳ Signal already active, skipping. Moving to next batch...`);
        setAutoPhase('no-match');
        await wait(3000);
        if (autoRunning.current) runAutoSignalCycleS2(nextBatch);
        return;
      }

      signalFiringRef.current = true;
      const now = new Date();
      const entryTime = new Date(now);
      entryTime.setSeconds(0, 0);
      entryTime.setMinutes(entryTime.getMinutes() + 1);
      const timeStr = formatTime(entryTime);
      const pairLabel = best.pair.replace('-OTC', '');
      // FIX 2: Get actual entry price from strategy data (avoid fallback to 0)
      const entryPrice = typeof best.entryPrice === 'number' && best.entryPrice > 0
        ? best.entryPrice : 0;

      // Entry = next minute boundary (analysis started at candle open, so this is candle+1)
      // Send signal immediately — no extra wait needed since we started at candle open

      setAutoLog(`🚀 [S2] Sending ${best.finalDirection} for ${pairLabel} @ ${best.finalConfidence}%...`);
      setAutoPhase('sending');

      if (!autoRunning.current) { signalFiringRef.current = false; return; }

      const message = buildAutoSignalMessage(pairLabel, best.finalDirection, timeStr, best.finalConfidence);
      await sendAutoToTelegramWithChart(message, best.pair, best.finalDirection, entryTime);
      onSignalSent?.();

      setAutoLog(`✅ [S2] Signal sent! Waiting 120s for result on ${pairLabel}...`);

      // FIX 3 & 4: Wait full 120s, then check + send result BEFORE continuing
      await wait(120000);
      if (!autoRunning.current) { signalFiringRef.current = false; return; }

      setAutoLog(`🔍 [S2] Checking result for ${pairLabel}...`);
      await checkAndSendAutoResult(best.pair, pairLabel, best.finalDirection, entryPrice, entryTime, timeStr, nextBatch, BATCH_COUNT);

      // 1-minute pause after result before starting next analysis cycle
      setAutoLog(`⏳ [S2] Result sent. Pausing 60s before next analysis...`);
      await wait(60000);

      signalFiringRef.current = false;
      if (autoRunning.current) {
        setAutoSignal(null);
        runAutoSignalCycleS2(nextBatch);
      }

    } catch (e: any) {
      if (autoTimerRef.current) clearInterval(autoTimerRef.current);
      signalFiringRef.current = false;
      console.error('[S2-AUTO] Error:', e);
      setAutoLog(`⚠️ [S2] Error: ${e.message}. → Next batch...`);
      setAutoPhase('no-match');
      await wait(3000);
      if (autoRunning.current) runAutoSignalCycleS2(nextBatch);
    }
  };

  // Send auto signal — uses the same telegramChartCapture as manual "Send with Chart"
  const sendAutoToTelegramWithChart = async (message: string, pair: string, direction: 'CALL' | 'PUT', entryTime: Date) => {
    if (!botToken || !chatId) {
      toast.error('Configure Bot Token and Chat ID first');
      return;
    }
    try {
      // HARD RESET: clear previous result overlay first so old WIN/LOSS can't leak into new signal chart
      onAutoSetResult?.(null);

      // Switch TelegramChart to the auto-scanned pair BEFORE capturing
      if (onAutoMarketChange) {
        onAutoMarketChange(pair);
        // Wait for TelegramChart to load candle data for the new pair
        await wait(3000);
      }

      // Set signal data DIRECTLY on TelegramChart ref (synchronous — no React re-render needed)
      // This guarantees the arrow + dashboard are set before capture is called
      onAutoSetSignal?.({ direction, timestamp: entryTime, pair });
      // Also fire the React state callback so any UI displays stay in sync
      onAutoSignalFired?.(direction, pair, entryTime);

      // Use the same capture function as manual "Send with Chart"
      const captureFunc = telegramChartCapture ?? chartCaptureFunc;
      const chartBase64 = captureFunc ? captureFunc() : null;

      const { data, error } = await supabase.functions.invoke('telegram-signal', {
        body: {
          botToken,
          chatId,
          message,
          photoUrl: !chartBase64 ? avatarUrl : null,
          chartBase64: chartBase64 ?? null,
          direction,
          signalData: {
            market: pair,
            direction,
            time: formatTime(entryTime),
            expiry: 'M1',
            confidence: 0,
          },
        }
      });
      if (error) throw error;
      if (!data?.success) throw new Error(data?.error || 'Failed');
    } catch (e: any) {
      console.error('[AUTO] Telegram send error:', e);
      toast.error('Failed to auto-send to Telegram: ' + e.message);
    }
  };

  // Check result after 120s — uses the SAME sendToTelegram (with chart) as manual WIN/LOSS/MTG buttons
  const checkAndSendAutoResult = async (
    pair: string,
    pairLabel: string,
    direction: 'CALL' | 'PUT',
    entryPrice: number,
    entryTime: Date,
    timeStr: string,
    nextIndex: number,
    totalSelected: number,
  ) => {
    try {
      const lastTrade = (() => {
        const stored = localStorage.getItem(`artrix_last_trade_${pair}`);
        if (stored) { try { return JSON.parse(stored); } catch { return null; } }
        return null;
      })();

      const { data, error } = await supabase.functions.invoke('live-signal', {
        body: {
          action: 'check-result',
          market: pair,
          direction,
          entryPrice,
          entryTime: entryTime.toISOString(),
          expiryTime: new Date(entryTime.getTime() + 120000).toISOString(),
          lastTrade: lastTrade || null,
          checkMtgWindow: true, // FIX 2: Enable MTG-by-window detection for S2
        }
      });

      if (error || !data?.success) {
        setAutoLog(`⚠️ Could not verify result for ${pairLabel}. Continuing...`);
        return;
      }

      const isMtgFromBackend = data.isMTG === true;
      const raw = String(data.result).toLowerCase();
      const resultType: 'WIN' | 'LOSS' | 'MTG' = isMtgFromBackend ? 'MTG' : (raw === 'mtg' ? 'MTG' : raw === 'win' ? 'WIN' : 'LOSS');
      const isWin = resultType === 'WIN' || resultType === 'MTG';
      const isMtg = resultType === 'MTG';

      // ✅ Use REFS (not state) to avoid stale closure — state captured at call time is stale in async
      const curWins = winCountRef.current;
      const curLosses = lossCountRef.current;
      const curMtg = mtgCountRef.current;
      const curRecords = tradeRecordsRef.current;

      const newWins = isWin ? curWins + 1 : curWins;
      const newLosses = isWin ? curLosses : curLosses + 1;
      const newMtg = isMtg ? curMtg + 1 : curMtg;
      const winRate = newWins + newLosses > 0 ? Math.round((newWins / (newWins + newLosses)) * 100) : 0;

      // Update React state instantly (same as manual buttons) — also updates refs via useEffect
      setWinCount(newWins);
      setLossCount(newLosses);
      if (isMtg) setMtgCount(newMtg);
      // Sync refs immediately so the NEXT async call in same cycle reads correct value
      winCountRef.current = newWins;
      lossCountRef.current = newLosses;
      if (isMtg) mtgCountRef.current = newMtg;

      // Persist to localStorage
      localStorage.setItem('telegram_wins', newWins.toString());
      localStorage.setItem('telegram_losses', newLosses.toString());
      if (isMtg) localStorage.setItem('telegram_mtg', newMtg.toString());

      // Save last trade for MTG detection
      const candleTimeForMtg = data.candleTime || new Date(Math.floor(entryTime.getTime() / 60000) * 60000).toISOString();
      localStorage.setItem(`artrix_last_trade_${pair}`, JSON.stringify({
        result: isWin ? 'WIN' : 'LOSS',
        direction,
        candleTime: candleTimeForMtg,
      }));

      // Add to trade records using ref (avoids stale array)
      const newRecord: TradeRecord = { time: timeStr, pair: pairLabel + '-OTC', direction, result: isMtg ? 'mtg' : isWin ? 'win' : 'loss' };
      const newRecords = [...curRecords, newRecord];
      setTradeRecords(newRecords);
      tradeRecordsRef.current = newRecords;
      localStorage.setItem('telegram_trade_records', JSON.stringify(newRecords));

      setAutoLog(`${resultType === 'WIN' ? '✅ WIN' : resultType === 'MTG' ? '🔄 MTG WIN' : '❌ LOSS'} — ${pairLabel} | W:${newWins} L:${newLosses} (${winRate}%) → [${nextIndex + 1}/${totalSelected}]`);

      // Build result message — same templates as manual generateWinMessage/generateLossMessage/generateMtgWinMessage
      let resultMessage = '';
      if (isMtg) {
        const directionText = direction === 'CALL' ? '🟢 𝗖𝗔𝗟𝗟' : '🔴 𝗣𝗨𝗧';
        resultMessage = `<b>𒆜•——‼️ 𝚁 | 𝙴 | 𝚂 | 𝚄 | 𝙻 | 𝚃 ‼️——•𒆜  

╭━━━━━━━━━・━━━━━━━━━╮ 
🚀𝙰𝚂𝚂𝙴𝚃            ☞ ${pairLabel}-OTC
⏰𝚃𝙸𝙼𝙴               ☞ ${timeStr}
🎯𝙳𝙸𝚁𝙴𝙲𝚃𝙸𝙾𝙽 ☞ ${directionText}  
╰━━━━━━━━━・━━━━━━━━━╯ 
✅✅✅ 𝗠𝗧𝗚 𝗪𝗜𝗡 ✅✅✅
╭━━━━━━━━━・━━━━━━━━━╮ 
🏆 𝚆𝚒𝚗: ${newWins}    |  𝙻𝚘𝚜𝚜: ${newLosses} • ${winRate}%
╰━━━━━━━━━・━━━━━━━━━╯  

𒆜•——‼️ A | R | T | R | I | X ‼️——•𒆜</b>`;
      } else if (isWin) {
        resultMessage = `<b>𒆜•——‼️ 𝚁 | 𝙴 | 𝚂 | 𝚄 | 𝙻 | 𝚃 ‼️——•𒆜  

╭━━━━━━━━𖥠━━━━━━━━╮ 
📊 ${pairLabel}-OTC    | 🕓 ${timeStr}
╰━━━━━━━━𖥠━━━━━━━━╯ 
✅✅✅ 𝗦𝗨𝗥𝗘𝗦𝗛𝗢𝗧 ✅✅✅
╭━━━━━━━━𖥠━━━━━━━━╮ 
🚀 𝚆𝚒𝚗:${newWins} ┃✖️𝙻𝚘𝚜𝚜:${newLosses} ◈ ${winRate}%
╰━━━━━━━━𖥠━━━━━━━━╯  

𒆜•——‼️ A | R | T | R | I | X ‼️——•𒆜</b>`;
      } else {
        resultMessage = `<b>𒆜•——‼️ 𝚁 | 𝙴 | 𝚂 | 𝚄 | 𝙻 | 𝚃 ‼️——•𒆜

╭━━━━━━━ ・ ━━━━━━━╮ 
🐲 ${pairLabel}-OTC  ┃ 🕓 ${timeStr}
╰━━━━━━━ ・ ━━━━━━━╯
❎❎❎ 𝗟𝗢𝗦𝗦 𝗧𝗥𝗔𝗗𝗘 ❎❎❎
╭━━━━━━━━𖥠━━━━━━━━╮ 
🚀 𝚆𝚒𝚗:${newWins} ┃✖️𝙻𝚘𝚜𝚜:${newLosses} ◈ ${winRate}%
╰━━━━━━━━𖥠━━━━━━━━╯  

𒆜•——‼️ A | R | T | R | I | X ‼️——•𒆜</b>`;
      }

      // FIX 1: Clear signal arrow BEFORE setting result — prevents chart overlay conflict
      onAutoSetSignal?.(null);
      
      // Switch TelegramChart to the result pair and wait for candles to load
      if (onAutoMarketChange) {
        onAutoMarketChange(pair);
        await wait(3000); // Wait for chart to fully reload pair candles
      } else {
        await wait(1000);
      }

      // Set result data DIRECTLY on TelegramChart ref (synchronous — no React re-render needed)
      // This guarantees WIN/LOSS/MTG badge + dashboard show correctly before capture
      onAutoSetResult?.({ resultType, pair, time: timeStr, wins: newWins, losses: newLosses, winRate });
      // Also fire React state callback so UI stays in sync
      onAutoResultReady?.(resultType, pair, timeStr, newWins, newLosses, winRate);
      
      // Wait for result overlay to render before capture
      await wait(500);

      const captureFunc = telegramChartCapture ?? chartCaptureFunc;
      const chartBase64 = captureFunc ? captureFunc() : null;

      await supabase.functions.invoke('telegram-signal', {
        body: {
          botToken,
          chatId,
          message: resultMessage,
          photoUrl: !chartBase64 ? avatarUrl : null,
          chartBase64: chartBase64 ?? null,
          direction,
          resultData: {
            market: pair,
            time: timeStr,
            result: resultType,
            wins: newWins,
            losses: newLosses,
            winRate,
          },
        }
      });
      toast.success(`📤 Auto ${resultType} sent to Telegram!`);

    } catch (e: any) {
      console.error('[AUTO] checkAndSendAutoResult error:', e);
      setAutoLog(`⚠️ Result check error for ${pairLabel}: ${e.message}`);
    }
  };

  const buildAutoSignalMessage = (pair: string, direction: 'CALL' | 'PUT', time: string, confidence: number, isAiEnabled: boolean = true) => {
    const action = direction === 'CALL' ? '𝙲𝙰𝙻𝙻 🟢' : '𝙿𝚄𝚃 🔴';
    const modeText = isAiEnabled ? '𝗔𝗨𝗧𝗢 𝗔𝗜 + 𝗦𝗧𝗥𝗔𝗧𝗘𝗚𝗬 𝗠𝗔𝗧𝗖𝗛' : '𝗔𝗨𝗧𝗢 ⚡ 𝗙𝗔𝗦𝗧 𝗟𝗜𝗩𝗘-𝗦𝗜𝗚𝗡𝗔𝗟';
    return `<b>🚧 𝗔𝗥𝗧𝗥𝗜𝗫 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗕𝗢𝗧 🚧

╔════════💠════════╗ 
📊 𝙿𝙰𝙸𝚁             ⊱  ${pair}-OTC         
⌛ 𝚃𝙸𝙼𝙴𝙵𝚁𝙰𝙼𝙴 ⊱  𝙼𝟷             
🎯 𝙰𝙲𝚃𝙸𝙾𝙽        ⊱  ${action}        
🕒 𝙴𝙽𝚃𝚁𝚈 𝚃𝙸𝙼𝙴 ⊱ ${time}          
╚════════💠════════╝ 

⚡️ 𝙲𝙾𝙽𝙵𝙸𝙳𝙴𝙽𝙲𝙴 : ${confidence}% 🔥             
🤖 𝙼𝙾𝙳𝙴 : ${modeText}
⚙️ 𝚂𝚃𝙰𝚃𝚄𝚂 : 𝗧𝗥𝗔𝗗𝗘 𝗦𝗘𝗡𝗧 𝗦𝗨𝗖𝗖𝗘𝗦𝗦𝗙𝗨𝗟𝗟𝗬</b>`;
  };

  const sendAutoToTelegram = async (message: string) => {
    if (!botToken || !chatId) {
      toast.error('Configure Bot Token and Chat ID first');
      return;
    }
    try {
      const { data, error } = await supabase.functions.invoke('telegram-signal', {
        body: { botToken, chatId, message, photoUrl: avatarUrl }
      });
      if (error) throw error;
      if (!data?.success) throw new Error(data?.error || 'Failed');
    } catch (e: any) {
      console.error('[AUTO] Telegram send error:', e);
      toast.error('Failed to auto-send to Telegram: ' + e.message);
    }
  };

  const handleToggleAutoMode = () => {
    if (autoMode) {
      stopAutoMode();
      toast.info('Auto Mode stopped');
    } else {
      if (!botToken || !chatId) {
        toast.error('Please configure Bot Token and Chat ID first');
        setShowSettings(true);
        return;
      }
      autoRunning.current = true;
      setAutoMode(true);
      setAutoPhase('idle');
      setAutoSignal(null);
      setCurrentScanIndex(0);
      autoSelectedPairsRef.current = autoSelectedPairs;
      const pairs = autoSelectedPairs.length > 0 ? autoSelectedPairs : [AUTO_PAIRS[0].id];
      const stratLabel = activeStrategy === 1 ? 'S1 (AI + Strategy)' : 'S2 (Indicator + Artix)';
      toast.success(`Auto Mode [${stratLabel}] started — scanning ${pairs.length} pair${pairs.length > 1 ? 's' : ''}`);
      if (activeStrategy === 2) {
        runAutoSignalCycleS2(0);
      } else {
        runAutoSignalCycle(0);
      }
    }
  };

  const handlePairToggle = (pairId: string) => {
    setAutoSelectedPairs(prev => {
      const next = prev.includes(pairId) ? prev.filter(id => id !== pairId) : [...prev, pairId];
      const result = next.length === 0 ? [pairId] : next; // always keep at least 1
      localStorage.setItem('auto_selected_pair', JSON.stringify(result));
      autoSelectedPairsRef.current = result;
      return result;
    });
  };

  const handleSelectAll = () => {
    const all = AUTO_PAIRS.map(p => p.id);
    setAutoSelectedPairs(all);
    localStorage.setItem('auto_selected_pair', JSON.stringify(all));
    autoSelectedPairsRef.current = all;
  };

  const handleDeselectAll = () => {
    const first = [AUTO_PAIRS[0].id];
    setAutoSelectedPairs(first);
    localStorage.setItem('auto_selected_pair', JSON.stringify(first));
    autoSelectedPairsRef.current = first;
  };

  // ============================================================
  // MANUAL SEND FUNCTIONS
  // ============================================================
  const sendToTelegram = async (
    message: string,
    withPhoto: boolean = true,
    includeSignalOverlay: boolean = false,
    resultInfo?: { result: 'WIN' | 'LOSS' | 'MTG'; newWins: number; newLosses: number; winRate: number },
    useChartImage: boolean = false
  ) => {
    if (!botToken || !chatId) {
      toast.error('Please configure Bot Token and Chat ID first');
      setShowSettings(true);
      return false;
    }
    setIsSending(true);
    try {
      let chartBase64: string | null = null;
      if (useChartImage) {
        const captureFunc = telegramChartCapture || chartCaptureFunc;
        if (!captureFunc) {
          toast.error('Chart is not ready yet. Please wait and try again.');
          setIsSending(false);
          return false;
        }
        chartBase64 = captureFunc();
        if (!chartBase64) {
          toast.error('Failed to capture chart image');
          setIsSending(false);
          return false;
        }
      }

      const signalData = (includeSignalOverlay && !useChartImage && currentSignal) ? {
        market: currentSignal.market,
        direction: currentSignal.direction,
        time: formatTime(currentSignal.timestamp),
        expiry: 'M1',
        confidence: currentSignal.confidence
      } : null;

      const resultData = resultInfo && currentSignal ? {
        market: currentSignal.market,
        time: formatTime(currentSignal.timestamp),
        result: resultInfo.result,
        wins: resultInfo.newWins,
        losses: resultInfo.newLosses,
        winRate: resultInfo.winRate
      } : null;

      const { data, error } = await supabase.functions.invoke('telegram-signal', {
        body: {
          botToken, chatId, message,
          photoUrl: (withPhoto && !useChartImage && !chartBase64) ? avatarUrl : null,
          chartBase64: chartBase64 || null,
          direction: currentSignal?.direction,
          signalData,
          resultData
        }
      });
      if (error) throw error;
      if (data?.success) {
        toast.success('Signal sent to Telegram!');
        return true;
      } else {
        throw new Error(data?.error || 'Failed to send');
      }
    } catch (err: any) {
      console.error('Telegram send error:', err);
      toast.error(err.message || 'Failed to send to Telegram');
      return false;
    } finally {
      setIsSending(false);
    }
  };

  const generateSignalMessage = () => {
    if (!currentSignal) return '';
    const time = formatTime(currentSignal.timestamp);
    const pair = currentSignal.market.replace('/', '-').replace('-OTC', '-OTC');
    const action = currentSignal.direction === 'CALL' ? '𝙲𝙰𝙻𝙻 🟢' : '𝙿𝚄𝚃 🔴';
    return `<b>🚧 𝗔𝗥𝗧𝗥𝗜𝗫 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗕𝗢𝗧 🚧

╔════════💠════════╗ 
📊 𝙿𝙰𝙸𝚁             ⊱  ${pair}         
⌛ 𝚃𝙸𝙼𝙴𝙵𝚁𝙰𝙼𝙴 ⊱  𝙼𝟷             
🎯 𝙰𝙲𝚃𝙸𝙾𝙽        ⊱  ${action}        
🕒 𝙴𝙽𝚃𝚁𝚈 𝚃𝙸𝙼𝙴 ⊱ ${time}          
╚════════💠════════╝ 

⚡️ 𝙲𝙾𝙽𝙵𝙸𝙳𝙴𝙽𝙲𝙴 : ${currentSignal.confidence}% 🔥             
⚙️ 𝚂𝚃𝙰𝚃𝚄𝚂 : 𝗧𝗥𝗔𝗗𝗘 𝗦𝗘𝗡𝗧 𝗦𝗨𝗖𝗖𝗘𝗦𝗦𝙵𝗨𝗟𝗟𝗬</b>`;
  };

  const generateWinMessage = () => {
    if (!currentSignal) return '';
    const time = formatTime(currentSignal.timestamp);
    const pair = currentSignal.market.replace('/', '-').replace('-OTC', '-OTC');
    const newWins = winCount + 1;
    const rate = Math.round((newWins / (newWins + lossCount)) * 100);
    return `<b>𒆜•——‼️ 𝚁 | 𝙴 | 𝚂 | 𝚄 | 𝙻 | 𝚃 ‼️——•𒆜  

╭━━━━━━━━𖥠━━━━━━━━╮ 
📊 ${pair}    | 🕓 ${time}
╰━━━━━━━━𖥠━━━━━━━━╯ 
✅✅✅ 𝗦𝗨𝗥𝗘𝗦𝗛𝗢𝗧 ✅✅✅
╭━━━━━━━━𖥠━━━━━━━━╮ 
🚀 𝚆𝚒𝚗:${newWins} ┃✖️𝙻𝚘𝚜𝚜:${lossCount} ◈ ${rate}%
╰━━━━━━━━𖥠━━━━━━━━╯  

𒆜•——‼️ A | R | T | R | I | X ‼️——•𒆜</b>`;
  };

  const generateLossMessage = () => {
    if (!currentSignal) return '';
    const time = formatTime(currentSignal.timestamp);
    const pair = currentSignal.market.replace('/', '-').replace('-OTC', '-OTC');
    const newLosses = lossCount + 1;
    const rate = Math.round((winCount / (winCount + newLosses)) * 100);
    return `<b>𒆜•——‼️ 𝚁 | 𝙴 | 𝚂 | 𝚄 | 𝙻 | 𝚃 ‼️——•𒆜

╭━━━━━━━ ・ ━━━━━━━╮ 
🐲 ${pair}  ┃ 🕓 ${time}
╰━━━━━━━ ・ ━━━━━━━╯
❎❎❎ 𝗟𝗢𝗦𝗦 𝗧𝗥𝗔𝗗𝗘 ❎❎❎
╭━━━━━━━━𖥠━━━━━━━━╮ 
🚀 𝚆𝚒𝚗:${winCount} ┃✖️𝙻𝚘𝚜𝚜:${newLosses} ◈ ${rate}%
╰━━━━━━━━𖥠━━━━━━━━╯  

𒆜•——‼️ A | R | T | R | I | X ‼️——•𒆜</b>`;
  };

  const generateMtgWinMessage = () => {
    if (!currentSignal) return '';
    const time = formatTime(currentSignal.timestamp);
    const pair = currentSignal.market.replace('/', '-').replace('-OTC', '-OTC');
    const direction = currentSignal.direction === 'CALL' ? '🟢 𝗖𝗔𝗟𝗟' : '🔴 𝗣𝗨𝗧';
    const newWins = winCount + 1;
    const rate = Math.round((newWins / (newWins + lossCount)) * 100);
    return `<b>𒆜•——‼️ 𝚁 | 𝙴 | 𝚂 | 𝚄 | 𝙻 | 𝚃 ‼️——•𒆜  

╭━━━━━━━━━・━━━━━━━━━╮ 
🚀𝙰𝚂𝚂𝙴𝚃            ☞ ${pair}
⏰𝚃𝙸𝙼𝙴               ☞ ${time}
🎯𝙳𝙸𝚁𝙴𝙲𝚃𝙸𝙾𝙽 ☞ ${direction}  
╰━━━━━━━━━・━━━━━━━━━╯ 
✅✅✅ 𝗠𝗧𝗚 𝗪𝗜𝗡 ✅✅✅
╭━━━━━━━━━・━━━━━━━━━╮ 
🏆 𝚆𝚒𝚗: ${newWins}    |  𝙻𝚘𝚜𝚜: ${lossCount} • ${rate}%
╰━━━━━━━━━・━━━━━━━━━╯  

𒆜•——‼️ A | R | T | R | I | X ‼️——•𒆜</b>`;
  };

  const generatePartialMessage = () => {
    const date = formatDate();
    let partialList = '';
    let gale0Wins = 0, gale0Losses = 0, gale1Wins = 0;
    tradeRecords.forEach((record) => {
      const isMtg = record.result === 'mtg';
      const icon = record.result === 'loss' ? '❎' : '✅';
      const mtgIndicator = isMtg ? '¹' : '';
      const direction = record.direction === 'CALL' ? '𝙱𝚄𝚈' : '𝙿𝚄𝚃';
      partialList += `❒ ${record.time} - ${record.pair}- ${direction}  ${icon}${mtgIndicator}\n`;
      if (record.result === 'win') gale0Wins++;
      else if (record.result === 'mtg') gale1Wins++;
      else gale0Losses++;
    });
    const totalWins = gale0Wins + gale1Wins;
    const totalLosses = gale0Losses;
    const gale0Rate = gale0Wins + gale0Losses > 0 ? Math.round((gale0Wins / (gale0Wins + gale0Losses)) * 100) : 0;
    const totalRate = totalWins + totalLosses > 0 ? Math.round((totalWins / (totalWins + totalLosses)) * 100) : 100;
    return `<b>=========== 𝙿𝙰𝚁𝚃𝙸𝙰𝙻 ============

━━━━━━━━━・━━━━━━━━━
                  📆 - ${date}
━━━━━━━━━・━━━━━━━━━
${partialList}━━━━━━━━━・━━━━━━━━━
✨ 𝙶𝙰𝙻𝙴 𝚁𝚎𝚜𝚞𝚕𝚝𝚜:
🔴 𝙶𝙰𝙻𝙴 𝟶→${gale0Wins}𝚡${gale0Losses} ⋅◈⋅ (${gale0Rate}%)
🔴 𝙶𝙰𝙻𝙴 𝟷→${gale1Wins}𝚡𝟶 ⋅◈⋅ (${gale1Wins > 0 ? '100' : '0'}%)
━━━━━━━━━・━━━━━━━━━
📊 𝚃𝚘𝚝𝚊𝚕 𝚁𝚊𝚝𝚎: ${totalWins}𝚡${totalLosses}⋅◈⋅ (${totalRate}%)
━━━━━━━━━・━━━━━━━━━
⚙ 𝙿𝚕𝚊𝚝𝚏𝚘𝚛𝚖: ARTIEX PRIMUM AI
📳𝙿𝚊𝚛𝚝𝚒𝚊𝚕 𝚂𝚎𝚗𝚝 𝚂𝚞𝚌𝚎𝚜𝚜𝚏𝚞𝚕𝚕𝚢</b>`;
  };

  const handleSendSignal = async () => {
    const message = generateSignalMessage();
    if (!message) { toast.error('No active signal to send'); return; }
    const success = await sendToTelegram(message, true, true, undefined, false);
    if (success) onSignalSent?.();
  };

  const handleSendSignalWithChart = async () => {
    const message = generateSignalMessage();
    if (!message) { toast.error('No active signal to send'); return; }
    const captureFunc = telegramChartCapture || chartCaptureFunc;
    if (!captureFunc) { toast.error('Chart not available'); return; }
    const chartBase64 = captureFunc();
    if (!chartBase64) { toast.error('Failed to capture chart image'); return; }
    const success = await sendToTelegram(message, false, false, undefined, true);
    if (success) onSignalSent?.();
  };

  const handleSendWin = async () => {
    if (!currentSignal) { toast.error('No active signal'); return; }
    const newWins = winCount + 1;
    const newLosses = lossCount;
    const winRate = Math.round((newWins / (newWins + newLosses)) * 100);
    const message = generateWinMessage();
    const success = await sendToTelegram(message, false, false, { result: 'WIN', newWins, newLosses, winRate });
    if (success) {
      setWinCount(newWins);
      localStorage.setItem('telegram_wins', newWins.toString());
      const newRecord: TradeRecord = { time: formatTime(currentSignal.timestamp), pair: currentSignal.market.replace('/', '-'), direction: currentSignal.direction, result: 'win' };
      const newRecords = [...tradeRecords, newRecord];
      setTradeRecords(newRecords);
      localStorage.setItem('telegram_trade_records', JSON.stringify(newRecords));
    }
  };

  const handleSendLoss = async () => {
    if (!currentSignal) { toast.error('No active signal'); return; }
    const newWins = winCount;
    const newLosses = lossCount + 1;
    const winRate = Math.round((newWins / (newWins + newLosses)) * 100);
    const message = generateLossMessage();
    const success = await sendToTelegram(message, false, false, { result: 'LOSS', newWins, newLosses, winRate });
    if (success) {
      setLossCount(newLosses);
      localStorage.setItem('telegram_losses', newLosses.toString());
      const newRecord: TradeRecord = { time: formatTime(currentSignal.timestamp), pair: currentSignal.market.replace('/', '-'), direction: currentSignal.direction, result: 'loss' };
      const newRecords = [...tradeRecords, newRecord];
      setTradeRecords(newRecords);
      localStorage.setItem('telegram_trade_records', JSON.stringify(newRecords));
    }
  };

  const handleSendMtgWin = async () => {
    if (!currentSignal) { toast.error('No active signal'); return; }
    const newWins = winCount + 1;
    const newMtg = mtgCount + 1;
    const newLosses = lossCount;
    const winRate = Math.round((newWins / (newWins + newLosses)) * 100);
    const message = generateMtgWinMessage();
    const success = await sendToTelegram(message, false, false, { result: 'MTG', newWins, newLosses, winRate });
    if (success) {
      setWinCount(newWins);
      setMtgCount(newMtg);
      localStorage.setItem('telegram_wins', newWins.toString());
      localStorage.setItem('telegram_mtg', newMtg.toString());
      const newRecord: TradeRecord = { time: formatTime(currentSignal.timestamp), pair: currentSignal.market.replace('/', '-'), direction: currentSignal.direction, result: 'mtg' };
      const newRecords = [...tradeRecords, newRecord];
      setTradeRecords(newRecords);
      localStorage.setItem('telegram_trade_records', JSON.stringify(newRecords));
    }
  };

  const handleSendPartial = async () => {
    if (tradeRecords.length === 0) { toast.error('No trade records to send'); return; }
    const message = generatePartialMessage();
    await sendToTelegram(message, false);
  };

  const handleResetStats = () => {
    setWinCount(0); setLossCount(0); setMtgCount(0); setTradeRecords([]);
    localStorage.removeItem('telegram_wins');
    localStorage.removeItem('telegram_losses');
    localStorage.removeItem('telegram_mtg');
    localStorage.removeItem('telegram_trade_records');
    toast.success('Stats reset successfully');
  };

  const autoPhaseColor = {
    idle: 'text-muted-foreground',
    'ai-analyzing': 'text-primary',
    'strategy-checking': 'text-warning',
    matched: 'text-success',
    'no-match': 'text-warning',
    sending: 'text-primary',
  }[autoPhase];

  const autoPhaseLabel = {
    idle: 'Idle',
    'ai-analyzing': aiEnabled ? `AI Analyzing... ${aiCountdown}s` : `Fast Scan... ${aiCountdown}s`,
    'strategy-checking': aiEnabled ? 'Strategy Check...' : 'Live Signal Check...',
    matched: 'MATCH FOUND!',
    'no-match': 'No Match',
    sending: 'Sending...',
  }[autoPhase];

  const selectedPairLabel = autoSelectedPairs.length === AUTO_PAIRS.length
    ? 'All 44 pairs'
    : autoSelectedPairs.length === 1
      ? (AUTO_PAIRS.find(p => p.id === autoSelectedPairs[0])?.name || autoSelectedPairs[0])
      : `${autoSelectedPairs.length} pairs selected`;

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
          className="w-full max-w-md max-h-[90vh] overflow-y-auto bg-card border border-primary/30 rounded-2xl shadow-2xl"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="sticky top-0 bg-card/95 backdrop-blur-sm border-b border-primary/20 p-4 flex items-center justify-between z-10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary/80 to-accent/80 flex items-center justify-center shadow-[0_0_15px_hsl(var(--primary)/0.4)]">
                <Send className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-foreground">Artrix Telegram</h2>
                <p className="text-xs text-muted-foreground">Signal Broadcasting</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <motion.button whileTap={{ scale: 0.95 }} onClick={() => setShowSettings(!showSettings)} className="p-2 rounded-lg bg-muted/50 hover:bg-muted">
                <Settings className="w-5 h-5 text-muted-foreground" />
              </motion.button>
              <motion.button whileTap={{ scale: 0.95 }} onClick={onClose} className="p-2 rounded-lg bg-destructive/20 hover:bg-destructive/30">
                <X className="w-5 h-5 text-destructive" />
              </motion.button>
            </div>
          </div>

          <div className="p-4 space-y-4">
            {/* Settings Panel */}
            <AnimatePresence>
              {showSettings && (
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                  <div className="p-4 bg-muted/30 rounded-xl border border-border/50 space-y-3">
                    <h3 className="font-semibold text-sm text-foreground flex items-center gap-2">
                      <Settings className="w-4 h-4" /> Telegram Settings
                    </h3>
                    <div className="space-y-2">
                      <input type="text" placeholder="Bot Token" value={botToken} onChange={(e) => setBotToken(e.target.value)} className="w-full px-3 py-2 rounded-lg bg-background border border-border/50 text-sm focus:border-primary/50 outline-none" />
                      <input type="text" placeholder="Chat ID" value={chatId} onChange={(e) => setChatId(e.target.value)} className="w-full px-3 py-2 rounded-lg bg-background border border-border/50 text-sm focus:border-primary/50 outline-none" />
                    </div>
                    <motion.button whileTap={{ scale: 0.95 }} onClick={saveSettings} className="w-full py-2 rounded-lg bg-primary text-primary-foreground font-medium text-sm">
                      Save Settings
                    </motion.button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* ═══════════════════════════════════════════ */}
            {/* AUTO MODE SECTION — PREMIUM UI */}
            {/* ═══════════════════════════════════════════ */}
            <div className={`rounded-2xl border-2 overflow-hidden transition-all duration-500 ${
              autoMode
                ? 'border-primary/60 shadow-[0_0_30px_hsl(var(--primary)/0.2)]'
                : 'border-border/40'
            }`}>
              {/* Auto Header Bar */}
              <div className={`relative px-4 py-3 flex items-center justify-between ${
                autoMode
                  ? 'bg-gradient-to-r from-primary/20 via-primary/10 to-accent/10'
                  : 'bg-muted/30'
              }`}>
                {autoMode && (
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/5 to-transparent animate-pulse pointer-events-none" />
                )}
                <div className="flex items-center gap-2 relative z-10">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                    autoMode ? 'bg-primary/20 border border-primary/40' : 'bg-muted border border-border/40'
                  }`}>
                    <Bot className={`w-4 h-4 ${autoMode ? 'text-primary' : 'text-muted-foreground'}`} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-foreground">Auto Mode</span>
                      {autoMode && (
                        <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary/20 border border-primary/40 text-xs font-bold text-primary">
                          <Radio className="w-2.5 h-2.5 animate-pulse" /> LIVE
                        </span>
                      )}
                      {/* AI ON/OFF badge */}
                      <span className={`flex items-center gap-1 px-1.5 py-0.5 rounded-full border text-[10px] font-bold ${
                        aiEnabled
                          ? 'bg-blue-500/15 border-blue-500/40 text-blue-400'
                          : 'bg-emerald-500/15 border-emerald-500/40 text-emerald-400'
                      }`}>
                        {aiEnabled ? <Bot className="w-2.5 h-2.5" /> : <BotOff className="w-2.5 h-2.5" />}
                        {aiEnabled ? 'AI' : 'FAST'}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {autoMode
                        ? `[S${activeStrategy}] Scanning ${autoSelectedPairs.length} pair${autoSelectedPairs.length > 1 ? 's' : ''}`
                        : activeStrategy === 1 ? (aiEnabled ? 'AI + Strategy match engine' : '⚡ Fast live-signal engine') : 'Indicator + Artix engine'}
                    </p>
                  </div>
                </div>
                <motion.button
                  whileTap={{ scale: 0.93 }}
                  whileHover={{ scale: 1.04 }}
                  onClick={handleToggleAutoMode}
                  className={`relative z-10 flex items-center gap-1.5 px-4 py-2 rounded-xl font-bold text-xs transition-all shadow-lg ${
                    autoMode
                      ? 'bg-destructive/20 text-destructive border border-destructive/40 hover:bg-destructive/30'
                      : 'bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_20px_hsl(var(--primary)/0.4)]'
                  }`}
                >
                  {autoMode
                    ? <><Square className="w-3 h-3" /> STOP</>
                    : <><Play className="w-3 h-3 fill-current" /> START</>}
                </motion.button>
              </div>

              <div className="p-4 space-y-3 bg-card/60">

                {/* ── STRATEGY SELECTOR + PAIR SELECTOR (only when stopped) ── */}
                {!autoMode && (
                  <div>
                    {/* Strategy 1 / 2 Toggle */}
                    <div className="mb-3">
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Strategy</span>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => setActiveStrategy(1)}
                          className={`relative flex flex-col items-center gap-1 px-3 py-3 rounded-xl border-2 text-xs font-bold transition-all ${
                            activeStrategy === 1
                              ? 'border-primary bg-primary/10 text-primary shadow-[0_0_12px_hsl(var(--primary)/0.2)]'
                              : 'border-border/40 bg-background/50 text-muted-foreground hover:border-primary/30'
                          }`}
                        >
                          <div className="flex items-center gap-1.5">
                            <Zap className="w-4 h-4" />
                            <span>S1</span>
                          </div>
                          <span className="text-[10px] font-normal opacity-70">AI + Strategy</span>
                          {activeStrategy === 1 && (
                            <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-primary flex items-center justify-center">
                              <Check className="w-2.5 h-2.5 text-primary-foreground" />
                            </div>
                          )}
                        </button>
                        <button
                          onClick={() => setActiveStrategy(2)}
                          className={`relative flex flex-col items-center gap-1 px-3 py-3 rounded-xl border-2 text-xs font-bold transition-all ${
                            activeStrategy === 2
                              ? 'border-accent bg-accent/10 text-accent shadow-[0_0_12px_hsl(var(--accent)/0.2)]'
                              : 'border-border/40 bg-background/50 text-muted-foreground hover:border-accent/30'
                          }`}
                        >
                          <div className="flex items-center gap-1.5">
                            <BarChart2 className="w-4 h-4" />
                            <span>S2</span>
                          </div>
                          <span className="text-[10px] font-normal opacity-70">Indicator + Artix</span>
                          {activeStrategy === 2 && (
                            <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-accent flex items-center justify-center">
                              <Check className="w-2.5 h-2.5 text-white" />
                            </div>
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Pair Selector */}
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Scan Pairs</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-primary font-bold">{autoSelectedPairs.length}/{AUTO_PAIRS.length}</span>
                        <button onClick={handleSelectAll} className="text-xs text-primary hover:text-primary/80 font-medium underline-offset-2 hover:underline">All</button>
                        <span className="text-xs text-muted-foreground">·</span>
                        <button onClick={handleDeselectAll} className="text-xs text-muted-foreground hover:text-foreground font-medium underline-offset-2 hover:underline">Clear</button>
                      </div>
                    </div>
                    <button
                      onClick={() => setShowPairDropdown(!showPairDropdown)}
                      className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl bg-background/80 border border-border/50 text-sm hover:border-primary/50 transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <Target className="w-3.5 h-3.5 text-primary flex-shrink-0" />
                        <span className="text-foreground font-medium truncate">{selectedPairLabel}</span>
                      </div>
                      <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform flex-shrink-0 ml-2 ${showPairDropdown ? 'rotate-180' : ''}`} />
                    </button>
                    <AnimatePresence>
                      {showPairDropdown && (
                        <motion.div
                          initial={{ opacity: 0, y: -6, scale: 0.98 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: -6, scale: 0.98 }}
                          className="mt-1 bg-card border border-border/60 rounded-xl shadow-xl z-20 max-h-44 overflow-y-auto scrollbar-hide"
                        >
                          {AUTO_PAIRS.map((p) => {
                            const isChecked = autoSelectedPairs.includes(p.id);
                            return (
                              <button
                                key={p.id}
                                onClick={() => handlePairToggle(p.id)}
                                className={`w-full px-3 py-2 flex items-center gap-2.5 text-left text-xs hover:bg-primary/10 transition-colors ${isChecked ? 'text-primary' : 'text-muted-foreground'}`}
                              >
                                <span className={`w-3.5 h-3.5 rounded border flex-shrink-0 flex items-center justify-center transition-colors ${isChecked ? 'bg-primary border-primary text-primary-foreground' : 'border-border/60 bg-background'}`}>
                                  {isChecked && <Check className="w-2.5 h-2.5" />}
                                </span>
                                <span className={isChecked ? 'font-semibold' : ''}>{p.name}</span>
                              </button>
                            );
                          })}
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* How it works — adapts to selected strategy */}
                    <div className="mt-3 grid grid-cols-2 gap-1.5">
                      {(activeStrategy === 1 ? (aiEnabled ? [
                        { icon: <Zap className="w-3 h-3" />, label: 'AI Analysis', color: 'text-primary', bg: 'bg-primary/10 border-primary/20' },
                        { icon: <BarChart2 className="w-3 h-3" />, label: 'Strategy Check', color: 'text-amber-400', bg: 'bg-amber-500/10 border-amber-500/20' },
                        { icon: <Activity className="w-3 h-3" />, label: 'Match Gate', color: 'text-success', bg: 'bg-success/10 border-success/20' },
                        { icon: <Send className="w-3 h-3" />, label: 'Auto Send + Result', color: 'text-accent', bg: 'bg-accent/10 border-accent/20' },
                      ] : [
                        { icon: <Zap className="w-3 h-3" />, label: '⚡ Fast Live-Signal', color: 'text-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/20' },
                        { icon: <Activity className="w-3 h-3" />, label: 'Direction Check', color: 'text-amber-400', bg: 'bg-amber-500/10 border-amber-500/20' },
                        { icon: <BarChart2 className="w-3 h-3" />, label: 'Confidence Gate', color: 'text-success', bg: 'bg-success/10 border-success/20' },
                        { icon: <Send className="w-3 h-3" />, label: 'Auto Send + Result', color: 'text-accent', bg: 'bg-accent/10 border-accent/20' },
                      ]) : [
                        { icon: <BarChart2 className="w-3 h-3" />, label: 'MA/EMA/RSI Scan', color: 'text-accent', bg: 'bg-accent/10 border-accent/20' },
                        { icon: <Activity className="w-3 h-3" />, label: 'Artix Match', color: 'text-success', bg: 'bg-success/10 border-success/20' },
                        { icon: <Layers className="w-3 h-3" />, label: '4-Batch Rotation', color: 'text-primary', bg: 'bg-primary/10 border-primary/20' },
                        { icon: <Send className="w-3 h-3" />, label: 'Auto Send + Result', color: 'text-amber-400', bg: 'bg-amber-500/10 border-amber-500/20' },
                      ]).map((step, i) => (
                        <div key={i} className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg border text-xs ${step.color} ${step.bg}`}>
                          {step.icon}
                          <span className="font-medium">{step.label}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* ── LIVE STATUS (when running) ── */}
                {autoMode && (
                  <div className="space-y-3">

                    {/* Live Stats Row */}
                    <div className="grid grid-cols-4 gap-2">
                      <div className="flex flex-col items-center p-2 rounded-xl bg-success/10 border border-success/20">
                        <TrendingUp className="w-3.5 h-3.5 text-success mb-0.5" />
                        <span className="text-base font-black text-success">{winCount}</span>
                        <span className="text-[10px] text-muted-foreground">WIN</span>
                      </div>
                      <div className="flex flex-col items-center p-2 rounded-xl bg-destructive/10 border border-destructive/20">
                        <TrendingDown className="w-3.5 h-3.5 text-destructive mb-0.5" />
                        <span className="text-base font-black text-destructive">{lossCount}</span>
                        <span className="text-[10px] text-muted-foreground">LOSS</span>
                      </div>
                      <div className="flex flex-col items-center p-2 rounded-xl bg-amber-500/10 border border-amber-500/20">
                        <RefreshCw className="w-3.5 h-3.5 text-amber-400 mb-0.5" />
                        <span className="text-base font-black text-amber-400">{mtgCount}</span>
                        <span className="text-[10px] text-muted-foreground">MTG</span>
                      </div>
                      <div className="flex flex-col items-center p-2 rounded-xl bg-primary/10 border border-primary/20">
                        <Trophy className="w-3.5 h-3.5 text-primary mb-0.5" />
                        <span className="text-base font-black text-primary">{getWinRate()}%</span>
                        <span className="text-[10px] text-muted-foreground">RATE</span>
                      </div>
                    </div>

                    {/* Pair Progress */}
                    <div className="flex items-center gap-3 px-3 py-2 rounded-xl bg-background/60 border border-border/40">
                      <div className="relative w-10 h-10 flex-shrink-0">
                        <svg className="w-10 h-10 -rotate-90" viewBox="0 0 36 36">
                          <circle cx="18" cy="18" r="15" fill="none" stroke="hsl(var(--border))" strokeWidth="3" />
                          <circle
                            cx="18" cy="18" r="15" fill="none"
                            stroke="hsl(var(--primary))" strokeWidth="3"
                            strokeDasharray={`${autoSelectedPairs.length > 0 ? ((currentScanIndex + 1) / autoSelectedPairs.length) * 94.2 : 0} 94.2`}
                            strokeLinecap="round"
                            className="transition-all duration-500"
                          />
                        </svg>
                        <span className="absolute inset-0 flex items-center justify-center text-[9px] font-bold text-primary">
                          {currentScanIndex + 1}/{autoSelectedPairs.length}
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <Zap className={`w-3 h-3 ${autoPhaseColor} flex-shrink-0 ${autoPhase === 'ai-analyzing' || autoPhase === 'strategy-checking' ? 'animate-pulse' : ''}`} />
                          <span className={`text-xs font-bold ${autoPhaseColor} truncate`}>{autoPhaseLabel}</span>
                        </div>
                        <p className="text-[11px] text-muted-foreground truncate mt-0.5">
                          {AUTO_PAIRS.find(p => p.id === autoSelectedPairs[currentScanIndex % autoSelectedPairs.length])?.name || autoSelectedPairs[currentScanIndex % autoSelectedPairs.length] || '—'}
                        </p>
                      </div>
                    </div>

                    {/* AI Countdown Bar */}
                    {autoPhase === 'ai-analyzing' && aiCountdown > 0 && (
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-muted-foreground flex items-center gap-1"><Clock className="w-3 h-3" /> AI Analyzing</span>
                          <span className="text-primary font-bold">{aiCountdown}s</span>
                        </div>
                        <div className="w-full bg-muted/40 rounded-full h-1.5 overflow-hidden">
                          <motion.div
                            className="h-full bg-gradient-to-r from-primary to-accent rounded-full"
                            style={{ width: `${((120 - aiCountdown) / 120) * 100}%` }}
                            transition={{ duration: 0.8 }}
                          />
                        </div>
                      </div>
                    )}

                    {/* Active Signal Card */}
                    <AnimatePresence>
                      {autoSignal && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.95, y: 8 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.95, y: 8 }}
                          className={`relative overflow-hidden rounded-xl border-2 p-3 ${
                            autoSignal.direction === 'CALL'
                              ? 'border-success/50 bg-success/10 shadow-[0_0_20px_hsl(var(--success)/0.2)]'
                              : 'border-destructive/50 bg-destructive/10 shadow-[0_0_20px_hsl(var(--destructive)/0.2)]'
                          }`}
                        >
                          <div className="absolute inset-0 bg-gradient-to-br from-transparent to-black/20 pointer-events-none" />
                          <div className="relative flex items-start justify-between">
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <span className={`text-xs font-black px-2 py-0.5 rounded-lg ${autoSignal.direction === 'CALL' ? 'bg-success/20 text-success' : 'bg-destructive/20 text-destructive'}`}>
                                  {autoSignal.direction === 'CALL' ? '▲ CALL' : '▼ PUT'}
                                </span>
                                <span className="text-xs text-muted-foreground font-mono">MATCHED</span>
                              </div>
                              <p className="text-sm font-black text-foreground">{autoSignal.pair}-OTC</p>
                              <p className="text-xs text-muted-foreground mt-0.5">Entry: <span className="text-foreground font-mono">{autoSignal.time}</span></p>
                            </div>
                            <div className="text-right">
                              <p className="text-xl font-black text-primary">{autoSignal.confidence}%</p>
                              <p className="text-[10px] text-muted-foreground">Confidence</p>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* Log Message */}
                    {autoLog && (
                      <div className="px-3 py-2 rounded-xl bg-background/50 border border-border/30">
                        <p className="text-[11px] text-muted-foreground whitespace-pre-wrap leading-relaxed font-mono">{autoLog}</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Divider */}
            <div className="flex items-center gap-2">
              <div className="flex-1 h-px bg-border/50" />
              <span className="text-xs text-muted-foreground font-medium">MANUAL MODE</span>
              <div className="flex-1 h-px bg-border/50" />
            </div>

            {/* Stats Display */}
            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 rounded-xl bg-success/10 border border-success/30 text-center">
                <Trophy className="w-5 h-5 text-success mx-auto mb-1" />
                <p className="text-lg font-bold text-success">{winCount}</p>
                <p className="text-xs text-muted-foreground">Wins</p>
              </div>
              <div className="p-3 rounded-xl bg-destructive/10 border border-destructive/30 text-center">
                <X className="w-5 h-5 text-destructive mx-auto mb-1" />
                <p className="text-lg font-bold text-destructive">{lossCount}</p>
                <p className="text-xs text-muted-foreground">Losses</p>
              </div>
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-center">
                <RefreshCw className="w-5 h-5 text-amber-500 mx-auto mb-1" />
                <p className="text-lg font-bold text-amber-500">{mtgCount}</p>
                <p className="text-xs text-muted-foreground">MTG</p>
              </div>
            </div>

            {/* Win Rate */}
            <div className="p-3 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Win Rate</span>
              <span className="text-xl font-bold text-primary">{getWinRate()}%</span>
            </div>

            {/* Current Signal Preview */}
            {currentSignal && (
              <div className="p-3 rounded-xl bg-muted/30 border border-border/50">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-foreground">{currentSignal.market}</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-bold ${currentSignal.direction === 'CALL' ? 'bg-success/20 text-success' : 'bg-destructive/20 text-destructive'}`}>
                    {currentSignal.direction}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span>{formatTime(currentSignal.timestamp)}</span>
                  <span>•</span>
                  <span>{currentSignal.confidence}% confidence</span>
                </div>
              </div>
            )}

            {/* Signal Image Preview */}
            {avatarUrl && (
              <div className="p-3 rounded-xl bg-muted/30 border border-border/50">
                <div className="flex items-center gap-2 mb-2">
                  <Image className="w-4 h-4 text-primary" />
                  <span className="text-sm font-medium text-foreground">Signal Image (Profile)</span>
                </div>
                <div className="relative w-full aspect-video rounded-lg overflow-hidden bg-background">
                  <img src={avatarUrl} alt="Signal" className="w-full h-full object-cover" />
                  {currentSignal && (
                    <div className={`absolute bottom-2 right-2 px-3 py-1 rounded-lg font-bold text-white text-sm ${currentSignal.direction === 'CALL' ? 'bg-success' : 'bg-destructive'}`}>
                      {currentSignal.direction}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="space-y-3">
              <motion.button whileTap={{ scale: 0.95 }} onClick={handleSendSignal} disabled={!currentSignal || isSending} className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-bold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed">
                <Send className="w-5 h-5" />
                {isSending ? 'Sending...' : 'Send Signal'}
              </motion.button>

              <motion.button whileTap={{ scale: 0.95 }} onClick={handleSendSignalWithChart} disabled={!currentSignal || isSending || !chartCaptureFunc} className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-green-500 text-white font-bold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed">
                <Image className="w-5 h-5" />
                {isSending ? 'Sending...' : 'Send with Chart'}
              </motion.button>

              {/* Result Buttons (manual) */}
              <div className="grid grid-cols-3 gap-2">
                <motion.button whileTap={{ scale: 0.95 }} onClick={handleSendWin} disabled={!currentSignal || isSending} className="py-2 rounded-xl bg-success/20 border border-success/30 text-success font-bold text-sm disabled:opacity-50">
                  <Check className="w-4 h-4 mx-auto" />
                  <span className="text-xs">WIN</span>
                </motion.button>
                <motion.button whileTap={{ scale: 0.95 }} onClick={handleSendMtgWin} disabled={!currentSignal || isSending} className="py-2 rounded-xl bg-amber-500/20 border border-amber-500/30 text-amber-400 font-bold text-sm disabled:opacity-50">
                  <RefreshCw className="w-4 h-4 mx-auto" />
                  <span className="text-xs">MTG</span>
                </motion.button>
                <motion.button whileTap={{ scale: 0.95 }} onClick={handleSendLoss} disabled={!currentSignal || isSending} className="py-2 rounded-xl bg-destructive/20 border border-destructive/30 text-destructive font-bold text-sm disabled:opacity-50">
                  <X className="w-4 h-4 mx-auto" />
                  <span className="text-xs">LOSS</span>
                </motion.button>
              </div>

              <motion.button whileTap={{ scale: 0.95 }} onClick={handleSendPartial} disabled={tradeRecords.length === 0 || isSending} className="w-full py-3 rounded-xl bg-purple-500/20 border border-purple-500/30 text-purple-400 font-medium flex items-center justify-center gap-2 disabled:opacity-50">
                <AlertTriangle className="w-5 h-5" />
                Send Partial ({tradeRecords.length} trades)
              </motion.button>

              <motion.button whileTap={{ scale: 0.95 }} onClick={handleResetStats} className="w-full py-2 rounded-xl bg-muted/50 text-muted-foreground font-medium text-sm">
                Reset All Stats
              </motion.button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
