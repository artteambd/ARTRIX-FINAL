import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Clock, ChevronRight } from 'lucide-react';
import { AnalysisResult } from '@/types';

interface TradeHistoryProps {
  history: AnalysisResult[];
}

export function TradeHistory({ history }: TradeHistoryProps) {
  if (history.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mx-4 mt-6 glass-card glow-border p-8 text-center"
      >
        <Clock className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-foreground">No Trade History</h3>
        <p className="text-sm text-muted-foreground mt-2">
          Your analyzed trades will appear here
        </p>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="mx-4 mt-6 space-y-3 pb-24"
    >
      <h2 className="text-lg font-semibold text-foreground mb-4">Trade History</h2>
      
      {history.map((trade, index) => (
        <motion.div
          key={trade.id}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.1 }}
          className="glass-card glow-border p-4"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                trade.signal === 'CALL' ? 'bg-call/20' : 'bg-put/20'
              }`}>
                {trade.signal === 'CALL' ? (
                  <TrendingUp className="w-5 h-5 text-call" />
                ) : (
                  <TrendingDown className="w-5 h-5 text-put" />
                )}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className={`font-semibold ${
                    trade.signal === 'CALL' ? 'text-call' : 'text-put'
                  }`}>
                    {trade.signal}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    {trade.confidence}%
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  {trade.market} • {trade.trend}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="text-right">
                <p className="text-xs text-muted-foreground">
                  {new Date(trade.timestamp).toLocaleDateString()}
                </p>
                <p className="text-xs text-muted-foreground">
                  {new Date(trade.timestamp).toLocaleTimeString()}
                </p>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </div>
          </div>
        </motion.div>
      ))}
    </motion.div>
  );
}
