import { motion, AnimatePresence } from 'framer-motion';
import { Upload, X, ImageIcon } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';

interface UploadCardProps {
  onImageSelect: (imageUrl: string) => void;
  selectedImage: string | null;
  onClear: () => void;
}

export function UploadCard({ onImageSelect, selectedImage, onClear }: UploadCardProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        onImageSelect(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        onImageSelect(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePaste = async () => {
    try {
      const clipboardItems = await navigator.clipboard.read();
      for (const item of clipboardItems) {
        for (const type of item.types) {
          if (type.startsWith('image/')) {
            const blob = await item.getType(type);
            const reader = new FileReader();
            reader.onload = (event) => {
              onImageSelect(event.target?.result as string);
            };
            reader.readAsDataURL(blob);
            return;
          }
        }
      }
    } catch (error) {
      console.log('Clipboard access denied or no image found');
    }
  };

  // Listen for paste events
  useEffect(() => {
    const handlePasteEvent = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (items) {
        for (const item of items) {
          if (item.type.startsWith('image/')) {
            const file = item.getAsFile();
            if (file) {
              const reader = new FileReader();
              reader.onload = (event) => {
                onImageSelect(event.target?.result as string);
              };
              reader.readAsDataURL(file);
            }
          }
        }
      }
    };

    window.addEventListener('paste', handlePasteEvent);
    return () => window.removeEventListener('paste', handlePasteEvent);
  }, [onImageSelect]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="mx-4"
      data-allow-paste="true"
    >
      {/* Section Header */}
      <div className="flex items-center gap-2 mb-4">
        <ImageIcon className="w-5 h-5 text-primary" />
        <h3 className="text-lg font-bold text-foreground tracking-wide">CHART INPUT</h3>
      </div>

      {/* Upload Area */}
      <div className="p-4 rounded-xl bg-card/50 border border-border/30">
        <AnimatePresence mode="wait">
          {selectedImage ? (
            <motion.div
              key="preview"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative"
            >
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={onClear}
                className="absolute top-2 right-2 z-10 w-8 h-8 rounded-full bg-destructive/80 flex items-center justify-center"
              >
                <X className="w-4 h-4 text-destructive-foreground" />
              </motion.button>
              <img
                src={selectedImage}
                alt="Chart preview"
                className="w-full h-48 object-contain rounded-xl bg-background"
              />
              <p className="text-center text-sm text-muted-foreground mt-3">Tap to change</p>
            </motion.div>
          ) : (
            <motion.div
              key="upload"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              onClick={() => fileInputRef.current?.click()}
              onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              className={`relative p-8 cursor-pointer transition-all rounded-xl border-2 border-dashed ${
                isDragging 
                  ? 'border-primary bg-primary/10' 
                  : 'border-primary/40 hover:border-primary/60'
              }`}
            >
              <div className="flex flex-col items-center gap-4">
                {/* Upload Icon */}
                <motion.div
                  animate={{ y: [0, -5, 0] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="w-16 h-16 rounded-full bg-secondary/50 border border-border/50 flex items-center justify-center"
                >
                  <Upload className="w-7 h-7 text-primary" />
                </motion.div>
                
                {/* Upload Text */}
                <div className="text-center">
                  <h4 className="text-base font-medium text-foreground font-mono">
                    Upload Trading Chart
                  </h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    or paste from clipboard (Ctrl+V)
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileSelect}
        className="hidden"
      />
    </motion.div>
  );
}
