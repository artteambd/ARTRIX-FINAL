import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, Info, XCircle, X } from 'lucide-react';
import { getUserWarnings, markWarningRead } from '@/lib/backendApi';
import { useAuth } from '@/contexts/AuthContext';

interface Warning {
  _id?: string;
  message: string;
  type: 'info' | 'warning' | 'critical';
  isRead: boolean;
  createdAt: string;
}

export function WarningBanner() {
  const { user } = useAuth();
  const [warnings, setWarnings] = useState<Warning[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (user?.licenseKey) {
      loadWarnings();
    }
  }, [user?.licenseKey]);

  const loadWarnings = async () => {
    if (!user?.licenseKey) return;
    
    const fetchedWarnings = await getUserWarnings(user.licenseKey);
    const unreadWarnings = fetchedWarnings.filter(w => !w.isRead);
    setWarnings(unreadWarnings as Warning[]);
  };

  const handleDismiss = async (warning: Warning) => {
    if (user?.licenseKey && warning._id) {
      await markWarningRead(user.licenseKey, warning._id);
    }
    setWarnings(prev => prev.filter(w => w._id !== warning._id));
    setCurrentIndex(0);
  };

  if (warnings.length === 0) return null;

  const currentWarning = warnings[currentIndex];
  if (!currentWarning) return null;

  const getIcon = (type: string) => {
    switch (type) {
      case 'critical':
        return <XCircle className="w-5 h-5" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5" />;
      default:
        return <Info className="w-5 h-5" />;
    }
  };

  const getColors = (type: string) => {
    switch (type) {
      case 'critical':
        return 'bg-put/20 border-put/50 text-put';
      case 'warning':
        return 'bg-warning/20 border-warning/50 text-warning';
      default:
        return 'bg-primary/20 border-primary/50 text-primary';
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className={`mx-4 mt-2 p-3 rounded-xl border ${getColors(currentWarning.type)} flex items-start gap-3`}
      >
        <div className="flex-shrink-0 mt-0.5">
          {getIcon(currentWarning.type)}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium">{currentWarning.message}</p>
          {warnings.length > 1 && (
            <p className="text-xs opacity-70 mt-1">
              {currentIndex + 1} of {warnings.length} messages
            </p>
          )}
        </div>
        <button
          onClick={() => handleDismiss(currentWarning)}
          className="flex-shrink-0 p-1 hover:bg-white/10 rounded-full transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </motion.div>
    </AnimatePresence>
  );
}
