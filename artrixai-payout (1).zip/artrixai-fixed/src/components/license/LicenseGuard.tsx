import { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ShieldOff, CreditCard, Clock, ArrowRight } from 'lucide-react';
import { useLicense } from '@/hooks/useLicense';
import { User } from '@supabase/supabase-js';
import { getDaysRemaining, formatExpiryDate } from '@/types/license';

interface LicenseGuardProps {
  children: ReactNode;
  user: User | null;
  requireCredits?: boolean;
}

export function LicenseGuard({ children, user, requireCredits = false }: LicenseGuardProps) {
  const navigate = useNavigate();
  const { license, isLoading, isExpired, remainingCredits } = useLicense(user);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!license || isExpired) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-card glow-border p-8 text-center max-w-md w-full"
        >
          <div className="w-16 h-16 rounded-full bg-destructive/20 flex items-center justify-center mx-auto mb-4">
            <ShieldOff className="w-8 h-8 text-destructive" />
          </div>
          <h2 className="text-xl font-bold text-foreground mb-2">
            {!license ? 'No Active License' : 'License Expired'}
          </h2>
          <p className="text-muted-foreground mb-6">
            {!license 
              ? 'You need an active license to access this feature. Purchase a license to get started.'
              : `Your license expired on ${formatExpiryDate(license.expires_at)}. Please renew to continue.`
            }
          </p>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => navigate('/credits')}
            className="w-full py-3 rounded-xl font-semibold bg-primary text-primary-foreground btn-glow flex items-center justify-center gap-2"
          >
            <CreditCard className="w-5 h-5" />
            Get License
            <ArrowRight className="w-5 h-5" />
          </motion.button>
        </motion.div>
      </div>
    );
  }

  if (requireCredits && remainingCredits <= 0) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-card glow-border p-8 text-center max-w-md w-full"
        >
          <div className="w-16 h-16 rounded-full bg-warning/20 flex items-center justify-center mx-auto mb-4">
            <CreditCard className="w-8 h-8 text-warning" />
          </div>
          <h2 className="text-xl font-bold text-foreground mb-2">No Credits Remaining</h2>
          <p className="text-muted-foreground mb-4">
            You've used all your credits. Purchase more to continue analyzing charts.
          </p>
          <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground mb-6">
            <Clock className="w-4 h-4" />
            <span>License valid for {getDaysRemaining(license.expires_at)} more days</span>
          </div>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => navigate('/credits')}
            className="w-full py-3 rounded-xl font-semibold bg-primary text-primary-foreground btn-glow flex items-center justify-center gap-2"
          >
            <CreditCard className="w-5 h-5" />
            Get More Credits
            <ArrowRight className="w-5 h-5" />
          </motion.button>
        </motion.div>
      </div>
    );
  }

  return <>{children}</>;
}
