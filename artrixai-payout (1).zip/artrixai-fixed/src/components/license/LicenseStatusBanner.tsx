import { motion } from 'framer-motion';
import { AlertTriangle, Clock, ShieldCheck, XCircle, Sparkles } from 'lucide-react';
import { License, isLicenseExpired, isLicenseExpiringSoon, getDaysRemaining, formatExpiryDate, getRemainingCredits } from '@/types/license';

interface LicenseStatusBannerProps {
  license: License | null;
}

export function LicenseStatusBanner({ license }: LicenseStatusBannerProps) {
  if (!license) {
    return (
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mx-4 mb-4 p-4 rounded-xl bg-muted/50 border border-border"
      >
        <div className="flex items-center gap-3">
          <XCircle className="w-6 h-6 text-muted-foreground flex-shrink-0" />
          <div>
            <p className="font-semibold text-muted-foreground">No Active License</p>
            <p className="text-sm text-muted-foreground/80">
              Get a license to start analyzing charts.
            </p>
          </div>
        </div>
      </motion.div>
    );
  }

  const expired = isLicenseExpired(license.expires_at);
  const expiringSoon = isLicenseExpiringSoon(license.expires_at);
  const daysRemaining = getDaysRemaining(license.expires_at);
  const remainingCredits = getRemainingCredits(license);

  if (expired) {
    return (
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mx-4 mb-4 p-4 rounded-xl bg-destructive/20 border border-destructive/50"
      >
        <div className="flex items-center gap-3">
          <XCircle className="w-6 h-6 text-destructive flex-shrink-0" />
          <div>
            <p className="font-semibold text-destructive">License Expired</p>
            <p className="text-sm text-destructive/80">
              Your license expired on {formatExpiryDate(license.expires_at)}. 
              Please renew to continue using credits.
            </p>
          </div>
        </div>
      </motion.div>
    );
  }

  if (expiringSoon) {
    return (
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mx-4 mb-4 p-4 rounded-xl bg-put/20 border border-put/50"
      >
        <div className="flex items-center gap-3">
          <AlertTriangle className="w-6 h-6 text-put flex-shrink-0" />
          <div className="flex-1">
            <p className="font-semibold text-put">License Expiring Soon</p>
            <p className="text-sm text-put/80">
              {daysRemaining} day{daysRemaining !== 1 ? 's' : ''} remaining. 
              Expires on {formatExpiryDate(license.expires_at)}.
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm font-medium text-foreground flex items-center gap-1">
              <Sparkles className="w-4 h-4 text-primary" />
              {remainingCredits} credits
            </p>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="mx-4 mb-4 p-3 rounded-xl bg-call/10 border border-call/30"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-call" />
          <span className="text-sm font-medium text-call">Active License</span>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <span className="text-foreground font-medium flex items-center gap-1">
            <Sparkles className="w-4 h-4 text-primary" />
            {remainingCredits} credits
          </span>
          <span className="text-muted-foreground flex items-center gap-1">
            <Clock className="w-4 h-4" />
            {daysRemaining} days left
          </span>
        </div>
      </div>
    </motion.div>
  );
}
