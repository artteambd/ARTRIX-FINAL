import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, MembershipTier, Transaction } from '@/types';
import { supabase } from '@/integrations/supabase/client';
import { isLicenseExpired } from '@/lib/licenseUtils';
import { LICENSE_PACKAGES } from '@/types/license';
import { generateDeviceFingerprint, storeDeviceFingerprint, getStoredFingerprint } from '@/lib/deviceFingerprint';
import { loginUser, registerUser } from '@/lib/backendApi';

const normalizeTier = (raw: unknown): MembershipTier => {
  const v = String(raw ?? '').toLowerCase().trim();
  if (!v) return 'nano';
  if (v === 'free') return 'free';
  if (v.includes('nano')) return 'nano';
  if (v.includes('starter')) return 'starter';
  if (v.includes('popular') || v.includes('most')) return 'popular';
  if (v.includes('expert')) return 'expert';
  if (v.includes('investor')) return 'investor';
  return 'nano';
};

const getCreditsForTier = (tier: MembershipTier): number => {
  // This app grants 5 free credits on email signup.
  if (tier === 'free') return 5;
  const pkg = LICENSE_PACKAGES.find((p) => p.id === tier);
  return pkg?.credits ?? 0;
};

const normalizeUserRecord = (u: any): User => {
  const tier = normalizeTier(u?.membership);
  const rawCredits = Number(u?.credits ?? 0);
  const isAdmin = u?.isAdmin === true;
  const credits = isAdmin ? rawCredits : Math.min(rawCredits, getCreditsForTier(tier));
  return { ...u, membership: tier, credits, isAdmin } as User;
};

interface AuthContextType {
  user: User | null;
  users: User[];
  transactions: Transaction[];
  isLoading: boolean;
  loginWithLicense: (licenseKey: string) => Promise<{ success: boolean; error?: string }>;
  loginWithEmail: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  registerWithEmail: (name: string, email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  loginAdmin: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  createUser: (email: string, membership: MembershipTier, credits: number) => User;
  updateUser: (userId: string, updates: Partial<User>) => void;
  deleteUser: (userId: string) => void;
  updateUserCredits: (userId: string, credits: number) => void;
  updateUserMembership: (userId: string, tier: MembershipTier) => void;
  addTransaction: (transaction: Omit<Transaction, 'id' | 'createdAt'>) => void;
  updateTransactionStatus: (transactionId: string, status: Transaction['status']) => void;
  useCredit: () => boolean;
  refreshUser: () => Promise<void>;
  activateLicenseKey: (licenseKey: string) => Promise<{ success: boolean; error?: string }>;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const generateLicenseKey = (): string => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const segments = [];
  for (let i = 0; i < 5; i++) {
    let segment = '';
    for (let j = 0; j < 5; j++) {
      segment += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    segments.push(segment);
  }
  return segments.join('-');
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('chartx_user');
    const savedUsers = localStorage.getItem('chartx_users');
    const savedTransactions = localStorage.getItem('chartx_transactions');

    if (savedUser) {
      try {
        const parsed = JSON.parse(savedUser);
        const normalized = normalizeUserRecord(parsed);
        setUser(normalized);
        localStorage.setItem('chartx_user', JSON.stringify(normalized));
      } catch {
        localStorage.removeItem('chartx_user');
      }
    }

    if (savedUsers) {
      try {
        const parsed = JSON.parse(savedUsers);
        const normalizedUsers = Array.isArray(parsed) 
          ? parsed.filter(u => !u.email?.includes('demo@') && u.licenseKey !== 'DEMO-1234-5678-ABCD').map(normalizeUserRecord) 
          : [];
        setUsers(normalizedUsers);
        localStorage.setItem('chartx_users', JSON.stringify(normalizedUsers));
      } catch {
        localStorage.removeItem('chartx_users');
      }
    }

    if (savedTransactions) {
      try {
        setTransactions(JSON.parse(savedTransactions));
      } catch {
        localStorage.removeItem('chartx_transactions');
      }
    }

    setIsLoading(false);
  }, []);

  const refreshUser = async () => {
    // Only license-based accounts have an expiry date; email/free accounts should not hit license verification.
    if (!user || user.isAdmin || !user.expiresAt) return;
    
    try {
      const deviceInfo = await generateDeviceFingerprint();
      
      const { data: apiResult, error } = await supabase.functions.invoke('verify-license', {
        body: { 
          license_key: user.licenseKey,
          device_fingerprint: deviceInfo.fingerprint,
          device_info: deviceInfo
        },
      });

      if (error || !apiResult?.valid) {
        logout();
        return;
      }

      const updatedUser = {
        ...user,
        credits: apiResult.credits ?? user.credits,
        expiresAt: apiResult.expiry_date ? new Date(apiResult.expiry_date) : user.expiresAt,
        isActive: apiResult.status === 'active',
      };

      if (!updatedUser.isActive || isLicenseExpired(updatedUser.expiresAt)) {
        logout();
        return;
      }

      setUser(updatedUser);
      localStorage.setItem('chartx_user', JSON.stringify(updatedUser));
    } catch (error) {
      console.error('Failed to refresh user:', error);
    }
  };

  const loginWithLicense = async (licenseKey: string): Promise<{ success: boolean; error?: string }> => {
    try {
      // Generate device fingerprint
      const deviceInfo = await generateDeviceFingerprint();
      
      // Verify license through edge function proxy with device info
      const { data: apiResult, error } = await supabase.functions.invoke('verify-license', {
        body: { 
          license_key: licenseKey,
          device_fingerprint: deviceInfo.fingerprint,
          device_info: deviceInfo
        },
      });

      if (error) {
        console.error('Edge function error:', error);
        return { success: false, error: '❌ License verification failed. Please try again.' };
      }

      if (!apiResult) {
        return { success: false, error: '❌ License verification failed. Please try again.' };
      }

      // Check for device lock
      if (apiResult.deviceLocked) {
        return { 
          success: false, 
          error: '🔒 This license is already registered to another device. Each license can only be used on one device. Contact support if you need to transfer your license.' 
        };
      }

      if (apiResult.valid === false || apiResult.status === false) {
        if (apiResult.message?.toLowerCase().includes('expired')) {
          return { success: false, error: '⏰ License has expired. Please renew your license.' };
        }
        if (apiResult.message?.toLowerCase().includes('blocked') || apiResult.message?.toLowerCase().includes('disabled')) {
          return { success: false, error: '🚫 License has been blocked. Contact support.' };
        }
        if (apiResult.message?.toLowerCase().includes('not found') || apiResult.message?.toLowerCase().includes('invalid')) {
          return { success: false, error: '❌ Invalid license key. Please check and try again.' };
        }
        return { success: false, error: apiResult.message || '❌ License is not active.' };
      }

      if (apiResult.expiry_date && new Date(apiResult.expiry_date) < new Date()) {
        return { success: false, error: '⏰ License has expired. Please renew your license.' };
      }

      // Store device fingerprint on successful login
      storeDeviceFingerprint(deviceInfo.fingerprint);

      let foundUser = users.find((u) => u.licenseKey === licenseKey && u.isAdmin !== true);

      const tier = normalizeTier(apiResult.membership ?? apiResult.tier ?? 'nano');
      const tierCredits = getCreditsForTier(tier);

      if (!foundUser) {
        foundUser = {
          id: crypto.randomUUID(),
          email: apiResult.user_email || apiResult.email || `user_${licenseKey.slice(0, 8)}@artrix.ai`,
          name: apiResult.name || 'ARTRIX User',
          credits: apiResult.credits ?? tierCredits,
          membership: tier,
          licenseKey: licenseKey,
          isAdmin: false,
          isActive: true,
          createdAt: new Date(),
          expiresAt: apiResult.expiry_date ? new Date(apiResult.expiry_date) : undefined,
        };

        const updatedUsers = [...users, foundUser];
        setUsers(updatedUsers);
        localStorage.setItem('chartx_users', JSON.stringify(updatedUsers));
      } else {
        foundUser = {
          ...foundUser,
          credits: apiResult.credits ?? foundUser.credits,
          expiresAt: apiResult.expiry_date ? new Date(apiResult.expiry_date) : foundUser.expiresAt,
          isActive: true,
        };
        
        const updatedUsers = users.map(u => u.id === foundUser!.id ? foundUser! : u);
        setUsers(updatedUsers);
        localStorage.setItem('chartx_users', JSON.stringify(updatedUsers));
      }

      const normalized = normalizeUserRecord(foundUser);
      setUser(normalized);
      localStorage.setItem('chartx_user', JSON.stringify(normalized));
      return { success: true };
    } catch (error) {
      console.error('License verification error:', error);
      return { success: false, error: '❌ Connection error. Please check your internet and try again.' };
    }
  };

  const loginWithEmail = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const deviceInfo = await generateDeviceFingerprint();

      const result = await loginUser(email, password, deviceInfo.fingerprint);

      if (!result.success || !result.user) {
        return { success: false, error: result.error || result.message || 'Login failed' };
      }

      storeDeviceFingerprint(deviceInfo.fingerprint);

      // Store token for authenticated API calls
      if (result.token) {
        localStorage.setItem('chartx_token', result.token);
      }

      const backendUser = result.user;

      const newUser: User = {
        id: backendUser._id,
        email: backendUser.email,
        name: backendUser.name || backendUser.email.split('@')[0],
        credits: backendUser.credits ?? 5,
        membership: normalizeTier(backendUser.membership),
        licenseKey: backendUser.licenseKey || generateLicenseKey(),
        isAdmin: false,
        isActive: backendUser.isActive !== false,
        createdAt: backendUser.createdAt ? new Date(backendUser.createdAt) : new Date(),
        expiresAt: backendUser.expiresAt ? new Date(backendUser.expiresAt) : undefined,
      };

      setUsers((prev) => {
        const idx = prev.findIndex(
          (u) => u.isAdmin !== true && u.email?.toLowerCase() === newUser.email.toLowerCase()
        );
        const next = idx >= 0 ? prev.map((u, i) => (i === idx ? { ...u, ...newUser } : u)) : [...prev, newUser];
        localStorage.setItem('chartx_users', JSON.stringify(next));
        return next;
      });

      const normalized = normalizeUserRecord(newUser);
      setUser(normalized);
      localStorage.setItem('chartx_user', JSON.stringify(normalized));

      return { success: true };
    } catch (error) {
      console.error('Email login error:', error);
      return { success: false, error: 'Connection error. Please try again.' };
    }
  };

  const registerWithEmail = async (name: string, email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const deviceInfo = await generateDeviceFingerprint();

      const result = await registerUser(name, email, password, deviceInfo.fingerprint);

      if (!result.success || !result.user) {
        return { success: false, error: result.error || result.message || 'Registration failed' };
      }

      storeDeviceFingerprint(deviceInfo.fingerprint);

      const backendUser = result.user;

      const newUser: User = {
        id: backendUser._id,
        email: backendUser.email,
        name: backendUser.name || name || backendUser.email.split('@')[0],
        credits: backendUser.credits ?? 5,
        membership: 'free',
        licenseKey: backendUser.licenseKey || generateLicenseKey(),
        isAdmin: false,
        isActive: true,
        createdAt: new Date(),
      };

      setUsers((prev) => {
        const next = [...prev, newUser];
        localStorage.setItem('chartx_users', JSON.stringify(next));
        return next;
      });

      const normalized = normalizeUserRecord(newUser);
      setUser(normalized);
      localStorage.setItem('chartx_user', JSON.stringify(normalized));

      return { success: true };
    } catch (error) {
      console.error('Email registration error:', error);
      return { success: false, error: 'Connection error. Please try again.' };
    }
  };

  const loginAdmin = async (_email: string, _password: string): Promise<{ success: boolean; error?: string }> => {
    return { success: false, error: 'Admin login is not available in this app.' };
  };

  const createUser = (email: string, membership: MembershipTier, credits: number): User => {
    const newUser: User = {
      id: crypto.randomUUID(),
      email,
      name: email.split('@')[0],
      credits,
      membership,
      licenseKey: generateLicenseKey(),
      isAdmin: false,
      isActive: true,
      createdAt: new Date(),
    };

    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    localStorage.setItem('chartx_users', JSON.stringify(updatedUsers));
    return newUser;
  };

  const updateUser = (userId: string, updates: Partial<User>) => {
    const updatedUsers = users.map(u =>
      u.id === userId ? { ...u, ...updates } : u
    );
    setUsers(updatedUsers);
    localStorage.setItem('chartx_users', JSON.stringify(updatedUsers));

    if (user?.id === userId) {
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser as User);
      localStorage.setItem('chartx_user', JSON.stringify(updatedUser));
    }
  };

  const deleteUser = (userId: string) => {
    const updatedUsers = users.filter(u => u.id !== userId);
    setUsers(updatedUsers);
    localStorage.setItem('chartx_users', JSON.stringify(updatedUsers));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('chartx_user');
    localStorage.removeItem('chartx_token');
  };

  const updateUserCredits = (userId: string, credits: number) => {
    updateUser(userId, { credits });
  };

  const updateUserMembership = (userId: string, tier: MembershipTier) => {
    updateUser(userId, { membership: tier });
  };

  const addTransaction = (transaction: Omit<Transaction, 'id' | 'createdAt'>) => {
    const newTransaction: Transaction = {
      ...transaction,
      id: crypto.randomUUID(),
      createdAt: new Date(),
    };
    const updatedTransactions = [...transactions, newTransaction];
    setTransactions(updatedTransactions);
    localStorage.setItem('chartx_transactions', JSON.stringify(updatedTransactions));
  };

  const updateTransactionStatus = (transactionId: string, status: Transaction['status']) => {
    const updatedTransactions = transactions.map(t =>
      t.id === transactionId ? { ...t, status } : t
    );
    setTransactions(updatedTransactions);
    localStorage.setItem('chartx_transactions', JSON.stringify(updatedTransactions));
  };

  const useCredit = (): boolean => {
    if (!user || user.credits <= 0) return false;
    
    if (isLicenseExpired(user.expiresAt)) {
      return false;
    }
    
    updateUserCredits(user.id, user.credits - 1);
    return true;
  };

  const activateLicenseKey = async (licenseKey: string): Promise<{ success: boolean; error?: string }> => {
    if (!user) return { success: false, error: 'Not logged in' };
    
    const result = await loginWithLicense(licenseKey);
    return result;
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        users,
        transactions,
        isLoading,
        loginWithLicense,
        loginWithEmail,
        registerWithEmail,
        loginAdmin,
        logout,
        createUser,
        updateUser,
        deleteUser,
        updateUserCredits,
        updateUserMembership,
        addTransaction,
        updateTransactionStatus,
        useCredit,
        refreshUser,
        activateLicenseKey,
        isAdmin: user?.isAdmin ?? false,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
