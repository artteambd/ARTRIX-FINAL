import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { License, LicenseTier, isLicenseExpired, getRemainingCredits } from '@/types/license';
import { User, Session } from '@supabase/supabase-js';

interface UseLicenseReturn {
  license: License | null;
  isLoading: boolean;
  isExpired: boolean;
  remainingCredits: number;
  useCredit: () => Promise<boolean>;
  refreshLicense: () => Promise<void>;
}

export function useLicense(user: User | null): UseLicenseReturn {
  const [license, setLicense] = useState<License | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchLicense = useCallback(async () => {
    if (!user) {
      setLicense(null);
      setIsLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('licenses')
        .select('*')
        .eq('user_id', user.id)
        .eq('is_active', true)
        .gt('expires_at', new Date().toISOString())
        .order('expires_at', { ascending: false })
        .limit(1)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching license:', error);
      }

      setLicense(data as License | null);
    } catch (error) {
      console.error('Error fetching license:', error);
      setLicense(null);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchLicense();
  }, [fetchLicense]);

  const useCredit = async (): Promise<boolean> => {
    if (!user) return false;

    try {
      const { data, error } = await supabase.rpc('use_credit', {
        _user_id: user.id,
      });

      if (error) {
        console.error('Error using credit:', error);
        return false;
      }

      if (data) {
        await fetchLicense();
      }

      return data as boolean;
    } catch (error) {
      console.error('Error using credit:', error);
      return false;
    }
  };

  const isExpired = license ? isLicenseExpired(license.expires_at) : true;
  const remainingCredits = license ? getRemainingCredits(license) : 0;

  return {
    license,
    isLoading,
    isExpired: !license || isExpired,
    remainingCredits,
    useCredit,
    refreshLicense: fetchLicense,
  };
}
