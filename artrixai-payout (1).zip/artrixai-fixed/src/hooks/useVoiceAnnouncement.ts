import { useCallback, useRef } from 'react';

interface SignalAnnouncement {
  pair: string;
  direction: 'CALL' | 'PUT' | string;
  confidence: number;
  payout?: number | null;
}

export function useVoiceAnnouncement() {
  const isSpeakingRef = useRef(false);

  const announce = useCallback((signal: SignalAnnouncement) => {
    if (!('speechSynthesis' in window)) return;

    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    const pairName = signal.pair
      .replace(/-OTC/gi, ' OTC')
      .replace(/([A-Z]{3})([A-Z]{3})/g, '$1 $2')
      .replace(/_otc/gi, ' OTC')
      .replace(/_/g, ' ');

    const dir = signal.direction === 'CALL' ? 'CALL' : 'PUT';
    const conf = Math.round(signal.confidence);

    let text = `Signal alert! ${pairName}. Direction: ${dir}. Confidence: ${conf} percent.`;

    if (signal.payout != null && signal.payout > 0) {
      text += ` Payout: ${Math.round(signal.payout)} percent.`;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.05;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;
    utterance.lang = 'en-US';

    // Try to pick a good English voice
    const voices = window.speechSynthesis.getVoices();
    const preferred = voices.find(
      (v) => v.lang.startsWith('en') && v.name.toLowerCase().includes('google')
    ) || voices.find((v) => v.lang.startsWith('en-US'))
      || voices.find((v) => v.lang.startsWith('en'));

    if (preferred) utterance.voice = preferred;

    utterance.onstart = () => { isSpeakingRef.current = true; };
    utterance.onend = () => { isSpeakingRef.current = false; };
    utterance.onerror = () => { isSpeakingRef.current = false; };

    window.speechSynthesis.speak(utterance);
  }, []);

  const stop = useCallback(() => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      isSpeakingRef.current = false;
    }
  }, []);

  return { announce, stop, isSpeaking: isSpeakingRef };
}
