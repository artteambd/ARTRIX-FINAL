// =============================================================================
// AVOID RULES VALIDATION ENGINE
// =============================================================================
// This module validates ALL strategies against their specific avoid rules.
// ONLY strategies that PASS their avoid rules are counted as VALID.
// Invalid strategies are 100% EXCLUDED from analysis.
// =============================================================================

import {
  // 235 Setup Avoid Rules
  ALL_AVOID_RULES,
  getAvoidRulesForSetup,
  getAvoidRulesByName,
  
  // 36 Indicator Avoid Rules
  ALL_INDICATOR_AVOID_RULES,
  getIndicatorAvoidRulesForSetup,
  getIndicatorRulesByName,
  
  // 20 HTF Avoid Rules
  ALL_HTF_AVOID_RULES,
  getHTFAvoidRulesForSetup,
  getHTFRulesByName,
  
  // 27 Price Action Avoid Rules
  ALL_PRICE_ACTION_AVOID_RULES,
  getPriceActionAvoidRulesForSetup,
  getPriceActionRulesByName,
  
  // 36 Liquidity Avoid Rules
  ALL_LIQUIDITY_AVOID_RULES,
  getLiquidityAvoidRulesForSetup,
  getLiquidityRulesByName,
  
  // 36 SMC Avoid Rules
  ALL_SMC_AVOID_RULES,
  getSMCAvoidRulesForSetup,
  getSMCAvoidRulesByName,
  
  // Global Rules
  GLOBAL_SALAMI_TREND_FILTER,
  
  // Types
  type AvoidRule,
  type IndicatorAvoidRule,
  type HTFAvoidRule,
  type PriceActionAvoidRule,
  type LiquidityAvoidRule,
  type SMCAvoidRule,
} from './setupAvoidRules';

// =============================================================================
// VALIDATION RESULT INTERFACES
// =============================================================================

export interface AvoidRuleValidationResult {
  isValid: boolean;
  setupId: string | number;
  setupName: string;
  category: 'setup_235' | 'indicator' | 'htf' | 'price_action' | 'liquidity' | 'smc';
  signal: string;
  passedConditions: string[];
  failedConditions: string[];
  blockedReason?: string;
}

export interface ValidationSummary {
  totalStrategiesChecked: number;
  validStrategies: number;
  invalidStrategies: number;
  validationResults: AvoidRuleValidationResult[];
  globalFiltersApplied: string[];
}

export interface MarketConditions {
  // Trend indicators
  adx: number;
  emaAngle: number;
  ema20: number;
  ema50: number;
  ema200: number;
  trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  
  // RSI
  rsi: number;
  rsi4?: number;
  
  // Candle data
  currentPrice: number;
  bodySize: number;
  upperWick: number;
  lowerWick: number;
  range: number;
  avgBody: number;
  isBullishCandle: boolean;
  isBearishCandle: boolean;
  
  // Volume
  volume: number;
  avgVolume: number;
  volumeRatio: number;
  
  // Bollinger Bands
  bbUpper: number;
  bbLower: number;
  bbWidth: number;
  bbExpanding: boolean;
  
  // ATR
  atr: number;
  atrAvg: number;
  
  // MACD
  macdHistogram: number;
  
  // Stochastic
  stochK: number;
  stochD: number;
  
  // Time-based
  minute: number;
  second: number;
  isNewsTime: boolean;
  
  // Levels
  support: number;
  resistance: number;
  nearRoundNumber: boolean;
  roundNumberDistance: number;
  
  // Pattern flags
  consecutiveSameColor: number;
  isMarubozu: boolean;
  isDoji: boolean;
  hasWicks: boolean;
  
  // Historical
  last5CandlesAllBearish?: boolean;
  last5CandlesAllBullish?: boolean;
  last10CandlesSameDirection?: boolean;
}

// =============================================================================
// GLOBAL FILTER: SALAMI TREND RULE
// =============================================================================

export function checkSalamiTrendRule(
  conditions: MarketConditions,
  signal: 'CALL' | 'PUT'
): { blocked: boolean; reason: string } {
  // Salami Trend: 8-10 tiny candles moving in one direction
  // This blocks ALL reversal trades
  
  const isReversalSignal = 
    (signal === 'CALL' && conditions.last10CandlesSameDirection && conditions.isBearishCandle) ||
    (signal === 'PUT' && conditions.last10CandlesSameDirection && conditions.isBullishCandle);
  
  if (isReversalSignal && conditions.consecutiveSameColor >= GLOBAL_SALAMI_TREND_FILTER.candleCount) {
    return {
      blocked: true,
      reason: `GLOBAL: Salami Trend detected (${conditions.consecutiveSameColor} consecutive candles) - Reversal blocked`
    };
  }
  
  return { blocked: false, reason: '' };
}

// =============================================================================
// 235 SETUP VALIDATION
// =============================================================================

export function validate235Setup(
  setupNumber: number,
  setupName: string,
  signal: 'CALL' | 'PUT',
  conditions: MarketConditions
): AvoidRuleValidationResult {
  const rule = getAvoidRulesForSetup(setupNumber) || getAvoidRulesByName(setupName);
  
  const result: AvoidRuleValidationResult = {
    isValid: true,
    setupId: setupNumber,
    setupName: setupName,
    category: 'setup_235',
    signal: signal,
    passedConditions: [],
    failedConditions: [],
  };
  
  if (!rule || rule.avoidConditions.length === 0) {
    result.passedConditions.push('No avoid rules defined - auto-pass');
    return result;
  }
  
  // Check each avoid condition
  for (const avoidCondition of rule.avoidConditions) {
    const conditionLower = avoidCondition.toLowerCase();
    let isBlocked = false;
    
    // EMA/Trend based conditions
    if (conditionLower.includes('ema20 is flat') || conditionLower.includes('flat')) {
      isBlocked = Math.abs(conditions.emaAngle) < 20;
    }
    else if (conditionLower.includes('emas are not parallel') || conditionLower.includes('not parallel')) {
      const ema20Above50 = conditions.ema20 > conditions.ema50;
      const ema50Above200 = conditions.ema50 > conditions.ema200;
      isBlocked = ema20Above50 !== ema50Above200; // Not aligned
    }
    // Engulfing size conditions
    else if (conditionLower.includes('engulfing') && conditionLower.includes('3x')) {
      isBlocked = conditions.bodySize > conditions.avgBody * 3;
    }
    // Volume conditions
    else if (conditionLower.includes('volume is lower') && conditionLower.includes('bigger')) {
      isBlocked = conditions.volume < conditions.avgVolume && conditions.bodySize > conditions.avgBody;
    }
    // Round number conditions
    else if (conditionLower.includes('round number') && (conditionLower.includes('ahead') || conditionLower.includes('within'))) {
      isBlocked = conditions.nearRoundNumber && conditions.roundNumberDistance < 0.0002;
    }
    // BB conditions
    else if (conditionLower.includes('bb') && (conditionLower.includes('expanding') || conditionLower.includes('mouth open'))) {
      isBlocked = conditions.bbExpanding;
    }
    // RSI flat conditions
    else if (conditionLower.includes('rsi') && conditionLower.includes('flat')) {
      isBlocked = conditions.rsi > 40 && conditions.rsi < 60; // RSI in neutral zone = flat
    }
    // Consecutive candle conditions
    else if (conditionLower.includes('5-6 same color') || conditionLower.includes('overextended')) {
      isBlocked = conditions.consecutiveSameColor >= 5;
    }
    // Doji conditions
    else if (conditionLower.includes('doji') && conditionLower.includes('long wick')) {
      isBlocked = conditions.isDoji && (conditions.upperWick > conditions.bodySize || conditions.lowerWick > conditions.bodySize);
    }
    // FVG/Body close conditions
    else if (conditionLower.includes('closes fully') && (conditionLower.includes('below') || conditionLower.includes('inside'))) {
      // This would need FVG context - simplified check
      isBlocked = conditions.bodySize < conditions.avgBody * 0.5;
    }
    // Retrace timing conditions
    else if (conditionLower.includes('30') && conditionLower.includes('second')) {
      isBlocked = conditions.second > 30;
    }
    // Gap conditions
    else if (conditionLower.includes('gap') && conditionLower.includes('pixel')) {
      // Gap too large
      isBlocked = Math.abs(conditions.currentPrice - conditions.ema20) > conditions.atr * 0.5;
    }
    // Range too narrow
    else if (conditionLower.includes('range') && conditionLower.includes('narrow')) {
      isBlocked = conditions.range < 0.0004; // Less than 4 pips
    }
    // Expansion/Exhaustion conditions
    else if (conditionLower.includes('expansion') && conditionLower.includes('5x')) {
      isBlocked = conditions.bodySize > conditions.avgBody * 5;
    }
    
    if (isBlocked) {
      result.failedConditions.push(avoidCondition);
      result.isValid = false;
      result.blockedReason = avoidCondition;
    } else {
      result.passedConditions.push(avoidCondition);
    }
  }
  
  return result;
}

// =============================================================================
// INDICATOR VALIDATION (36 Rules)
// =============================================================================

export function validateIndicatorSetup(
  indicatorNumber: number,
  setupName: string,
  signal: 'CALL' | 'PUT',
  conditions: MarketConditions
): AvoidRuleValidationResult {
  const rule = getIndicatorAvoidRulesForSetup(indicatorNumber) || getIndicatorRulesByName(setupName);
  
  const result: AvoidRuleValidationResult = {
    isValid: true,
    setupId: indicatorNumber,
    setupName: setupName,
    category: 'indicator',
    signal: signal,
    passedConditions: [],
    failedConditions: [],
  };
  
  if (!rule || rule.avoidConditions.length === 0) {
    result.passedConditions.push('No avoid rules defined - auto-pass');
    return result;
  }
  
  for (const avoidCondition of rule.avoidConditions) {
    const conditionLower = avoidCondition.toLowerCase();
    let isBlocked = false;
    
    // ADX trend strength conditions
    if (conditionLower.includes('adx') && conditionLower.includes('> 30')) {
      isBlocked = conditions.adx > 30;
    }
    else if (conditionLower.includes('adx') && conditionLower.includes('< 20')) {
      isBlocked = conditions.adx < 20;
    }
    // Salami trend (5+ same color)
    else if (conditionLower.includes('salami') || (conditionLower.includes('5') && conditionLower.includes('candle'))) {
      isBlocked = conditions.consecutiveSameColor >= 5;
    }
    // EMA slope/angle
    else if (conditionLower.includes('slope') || conditionLower.includes('angle')) {
      if (conditionLower.includes('< 15') || conditionLower.includes('flat')) {
        isBlocked = Math.abs(conditions.emaAngle) < 15;
      }
    }
    // Volume confirmation
    else if (conditionLower.includes('volume') && conditionLower.includes('1.5x')) {
      isBlocked = conditions.volumeRatio < 1.5;
    }
    // BB expanding
    else if (conditionLower.includes('band') && conditionLower.includes('expand')) {
      isBlocked = conditions.bbExpanding;
    }
    // Gap too large (PSAR)
    else if (conditionLower.includes('gap') && conditionLower.includes('2 pip')) {
      isBlocked = Math.abs(conditions.currentPrice - conditions.support) > 0.0002;
    }
    // Histogram not growing
    else if (conditionLower.includes('histogram') && conditionLower.includes('grow')) {
      isBlocked = Math.abs(conditions.macdHistogram) < 0.00001;
    }
    // RSI extremes
    else if (conditionLower.includes('rsi') && conditionLower.includes('> 80')) {
      isBlocked = conditions.rsi > 80;
    }
    else if (conditionLower.includes('rsi') && conditionLower.includes('< 20')) {
      isBlocked = conditions.rsi < 20;
    }
    // Wick requirements
    else if (conditionLower.includes('no wick') || conditionLower.includes('wick') && conditionLower.includes('> 0')) {
      isBlocked = !conditions.hasWicks;
    }
    // Near support/resistance
    else if (conditionLower.includes('near') && conditionLower.includes('resistance')) {
      isBlocked = Math.abs(conditions.currentPrice - conditions.resistance) < conditions.atr * 0.3;
    }
    else if (conditionLower.includes('near') && conditionLower.includes('support')) {
      isBlocked = Math.abs(conditions.currentPrice - conditions.support) < conditions.atr * 0.3;
    }
    // AO bar size
    else if (conditionLower.includes('tiny') && conditionLower.includes('0.0001')) {
      isBlocked = conditions.bodySize < 0.0001;
    }
    // Ichimoku Chikou
    else if (conditionLower.includes('chikou') || conditionLower.includes('lagging span')) {
      // Simplified - would need actual Ichimoku data
      isBlocked = false;
    }
    
    if (isBlocked) {
      result.failedConditions.push(avoidCondition);
      result.isValid = false;
      result.blockedReason = avoidCondition;
    } else {
      result.passedConditions.push(avoidCondition);
    }
  }
  
  return result;
}

// =============================================================================
// HTF VALIDATION (20 Rules)
// =============================================================================

export function validateHTFSetup(
  htfNumber: number,
  setupName: string,
  signal: 'CALL' | 'PUT' | 'REVERSAL' | 'CONTINUATION',
  conditions: MarketConditions
): AvoidRuleValidationResult {
  const rule = getHTFAvoidRulesForSetup(htfNumber) || getHTFRulesByName(setupName);
  
  const result: AvoidRuleValidationResult = {
    isValid: true,
    setupId: htfNumber,
    setupName: setupName,
    category: 'htf',
    signal: signal,
    passedConditions: [],
    failedConditions: [],
  };
  
  if (!rule || rule.avoidConditions.length === 0) {
    result.passedConditions.push('No avoid rules defined - auto-pass');
    return result;
  }
  
  for (const avoidCondition of rule.avoidConditions) {
    const conditionLower = avoidCondition.toLowerCase();
    let isBlocked = false;
    
    // Counter-momentum Marubozu
    if (conditionLower.includes('counter-momentum') || conditionLower.includes('marubozu')) {
      isBlocked = conditions.isMarubozu && 
        ((signal === 'CALL' && conditions.isBearishCandle) || 
         (signal === 'PUT' && conditions.isBullishCandle));
    }
    // RSI overbought/oversold filters
    else if (conditionLower.includes('rsi') && conditionLower.includes('> 70')) {
      isBlocked = conditions.rsi > 70;
    }
    else if (conditionLower.includes('rsi') && conditionLower.includes('< 30')) {
      isBlocked = conditions.rsi < 30;
    }
    // EMA 200 obstacle
    else if (conditionLower.includes('ema 200') && conditionLower.includes('obstacle')) {
      const priceToEma200 = Math.abs(conditions.currentPrice - conditions.ema200);
      isBlocked = priceToEma200 < conditions.atr;
    }
    // OB touch count (freshness)
    else if (conditionLower.includes('touch') && conditionLower.includes('> 0')) {
      // Would need OB touch count tracking - simplified
      isBlocked = false;
    }
    // Volume > 2x
    else if (conditionLower.includes('volume') && conditionLower.includes('2x')) {
      isBlocked = conditions.volumeRatio > 2;
    }
    // Time window conditions
    else if (conditionLower.includes(':00') || conditionLower.includes(':15') || conditionLower.includes(':30') || conditionLower.includes(':45')) {
      const isAtResetTime = [0, 15, 30, 45].includes(conditions.minute) && conditions.second <= 5;
      if (conditionLower.includes('not at')) {
        isBlocked = !isAtResetTime;
      }
    }
    // No wicks (solid block)
    else if (conditionLower.includes('no wick') || conditionLower.includes('solid')) {
      isBlocked = !conditions.hasWicks && conditions.isMarubozu;
    }
    // ADX > 30 (strong trend)
    else if (conditionLower.includes('adx') && conditionLower.includes('> 30')) {
      isBlocked = conditions.adx > 30;
    }
    // ATR > 2x (parabolic)
    else if (conditionLower.includes('atr') && conditionLower.includes('2x')) {
      isBlocked = conditions.atr > conditions.atrAvg * 2;
    }
    // Major level broken
    else if (conditionLower.includes('major') && conditionLower.includes('broken')) {
      isBlocked = conditions.currentPrice > conditions.resistance || conditions.currentPrice < conditions.support;
    }
    // Session open (first 5 mins)
    else if (conditionLower.includes('first 5') || conditionLower.includes('session')) {
      isBlocked = conditions.minute < 5 && (conditions.minute === 0 || conditions.minute === 8 || conditions.minute === 13);
    }
    // Low volume breakout
    else if (conditionLower.includes('low volume') || conditionLower.includes('< average volume')) {
      isBlocked = conditions.volumeRatio < 1;
    }
    // News event
    else if (conditionLower.includes('news')) {
      isBlocked = conditions.isNewsTime;
    }
    
    if (isBlocked) {
      result.failedConditions.push(avoidCondition);
      result.isValid = false;
      result.blockedReason = avoidCondition;
    } else {
      result.passedConditions.push(avoidCondition);
    }
  }
  
  return result;
}

// =============================================================================
// PRICE ACTION VALIDATION (27 Rules)
// =============================================================================

export function validatePriceActionSetup(
  strategyNumber: number,
  setupName: string,
  signal: string,
  conditions: MarketConditions
): AvoidRuleValidationResult {
  const rule = getPriceActionAvoidRulesForSetup(strategyNumber) || getPriceActionRulesByName(setupName);
  
  const result: AvoidRuleValidationResult = {
    isValid: true,
    setupId: strategyNumber,
    setupName: setupName,
    category: 'price_action',
    signal: signal,
    passedConditions: [],
    failedConditions: [],
  };
  
  if (!rule || rule.avoidConditions.length === 0) {
    result.passedConditions.push('No avoid rules defined - auto-pass');
    return result;
  }
  
  for (const avoidCondition of rule.avoidConditions) {
    const conditionLower = avoidCondition.toLowerCase();
    let isBlocked = false;
    
    // RSI extremes
    if (conditionLower.includes('rsi') && (conditionLower.includes('< 10') || conditionLower.includes('> 90'))) {
      isBlocked = conditions.rsi < 10 || conditions.rsi > 90;
    }
    else if (conditionLower.includes('rsi4') && conditionLower.includes('10')) {
      const rsi4 = conditions.rsi4 || conditions.rsi;
      isBlocked = rsi4 < 10 || rsi4 > 90;
    }
    // News candle (3x body)
    else if (conditionLower.includes('3x') && conditionLower.includes('body')) {
      isBlocked = conditions.bodySize > conditions.avgBody * 3;
    }
    // ADX conditions
    else if (conditionLower.includes('adx') && conditionLower.includes('> 40')) {
      isBlocked = conditions.adx > 40;
    }
    else if (conditionLower.includes('adx') && conditionLower.includes('< 30')) {
      isBlocked = conditions.adx < 30;
    }
    // Round number ahead
    else if (conditionLower.includes('round') && conditionLower.includes('ahead')) {
      isBlocked = conditions.nearRoundNumber;
    }
    // BB outside
    else if (conditionLower.includes('bb') && (conditionLower.includes('upper') || conditionLower.includes('lower'))) {
      isBlocked = conditions.currentPrice > conditions.bbUpper || conditions.currentPrice < conditions.bbLower;
    }
    // Godzilla predecessor (3x avg)
    else if (conditionLower.includes('godzilla') || (conditionLower.includes('previous') && conditionLower.includes('3x'))) {
      isBlocked = conditions.bodySize > conditions.avgBody * 3;
    }
    // Steep angle approach
    else if (conditionLower.includes('steep') || conditionLower.includes('angle')) {
      isBlocked = Math.abs(conditions.emaAngle) > 45;
    }
    // Inverted hammer (weak filler)
    else if (conditionLower.includes('inverted hammer') || conditionLower.includes('weak filler')) {
      isBlocked = conditions.upperWick > conditions.bodySize;
    }
    // Zero volume
    else if (conditionLower.includes('zero volume')) {
      isBlocked = conditions.volume <= 0;
    }
    // News time
    else if (conditionLower.includes('news')) {
      isBlocked = conditions.isNewsTime;
    }
    // Flat RSI
    else if (conditionLower.includes('flat') && conditionLower.includes('rsi')) {
      isBlocked = conditions.rsi > 40 && conditions.rsi < 60;
    }
    // Choppy (ADX < 30)
    else if (conditionLower.includes('choppy')) {
      isBlocked = conditions.adx < 30;
    }
    // Slingshot gap
    else if (conditionLower.includes('slingshot')) {
      // Gap > previous body
      isBlocked = Math.abs(conditions.currentPrice - conditions.ema20) > conditions.avgBody;
    }
    // Marubozu (high momentum)
    else if (conditionLower.includes('marubozu') && conditionLower.includes('80%')) {
      isBlocked = conditions.isMarubozu;
    }
    // Breakout < 2 pips
    else if (conditionLower.includes('breakout') && conditionLower.includes('2 pip')) {
      isBlocked = conditions.range < 0.0002;
    }
    // Volume increased
    else if (conditionLower.includes('volume') && conditionLower.includes('increased')) {
      isBlocked = conditions.volumeRatio > 1;
    }
    
    if (isBlocked) {
      result.failedConditions.push(avoidCondition);
      result.isValid = false;
      result.blockedReason = avoidCondition;
    } else {
      result.passedConditions.push(avoidCondition);
    }
  }
  
  return result;
}

// =============================================================================
// LIQUIDITY VALIDATION (36 Rules)
// =============================================================================

export function validateLiquiditySetup(
  liquidityNumber: number,
  setupName: string,
  signal: string,
  conditions: MarketConditions
): AvoidRuleValidationResult {
  const rule = getLiquidityAvoidRulesForSetup(liquidityNumber) || getLiquidityRulesByName(setupName);
  
  const result: AvoidRuleValidationResult = {
    isValid: true,
    setupId: liquidityNumber,
    setupName: setupName,
    category: 'liquidity',
    signal: signal,
    passedConditions: [],
    failedConditions: [],
  };
  
  if (!rule || rule.avoidConditions.length === 0) {
    result.passedConditions.push('No avoid rules defined - auto-pass');
    return result;
  }
  
  for (const avoidCondition of rule.avoidConditions) {
    const conditionLower = avoidCondition.toLowerCase();
    let isBlocked = false;
    
    // ADX < 20 (no trend)
    if (conditionLower.includes('adx') && conditionLower.includes('< 20')) {
      isBlocked = conditions.adx < 20;
    }
    // Already touched
    else if (conditionLower.includes('already touched') || conditionLower.includes('touch count')) {
      // Would need level touch tracking
      isBlocked = false;
    }
    // Marubozu momentum
    else if (conditionLower.includes('marubozu')) {
      isBlocked = conditions.isMarubozu;
    }
    // EMA50 obstacle
    else if (conditionLower.includes('ema50') || conditionLower.includes('ema 50')) {
      const distToEma50 = Math.abs(conditions.currentPrice - conditions.ema50);
      isBlocked = distToEma50 < conditions.atr * 0.5;
    }
    // Gap > 5 pips
    else if (conditionLower.includes('gap') && conditionLower.includes('5 pip')) {
      isBlocked = Math.abs(conditions.currentPrice - conditions.support) > 0.0005;
    }
    // Next candle gaps away
    else if (conditionLower.includes('gaps away')) {
      // Would need next candle data
      isBlocked = false;
    }
    // Break > 5 pips
    else if (conditionLower.includes('break') && conditionLower.includes('5 pip')) {
      const breakDistance = Math.min(
        Math.abs(conditions.currentPrice - conditions.support),
        Math.abs(conditions.currentPrice - conditions.resistance)
      );
      isBlocked = breakDistance > 0.0005;
    }
    // Close back inside mother bar
    else if (conditionLower.includes('mother bar') || conditionLower.includes('inside')) {
      // Would need mother bar reference
      isBlocked = false;
    }
    // RSI thresholds (65/35)
    else if (conditionLower.includes('rsi') && conditionLower.includes('65')) {
      isBlocked = conditions.rsi < 35 || conditions.rsi > 65;
    }
    else if (conditionLower.includes('rsi') && conditionLower.includes('35')) {
      isBlocked = conditions.rsi < 35;
    }
    // Volume validation
    else if (conditionLower.includes('volume') && conditionLower.includes('confirm')) {
      isBlocked = conditions.volumeRatio < 1;
    }
    // Major level broken (Godzilla as momentum)
    else if (conditionLower.includes('major level') && conditionLower.includes('broken')) {
      isBlocked = conditions.currentPrice > conditions.resistance * 1.001 || 
                  conditions.currentPrice < conditions.support * 0.999;
    }
    
    if (isBlocked) {
      result.failedConditions.push(avoidCondition);
      result.isValid = false;
      result.blockedReason = avoidCondition;
    } else {
      result.passedConditions.push(avoidCondition);
    }
  }
  
  return result;
}

// =============================================================================
// SMC VALIDATION (36 Rules)
// =============================================================================

export function validateSMCSetup(
  smcNumber: number,
  setupName: string,
  signal: string,
  conditions: MarketConditions
): AvoidRuleValidationResult {
  const rule = getSMCAvoidRulesForSetup(smcNumber) || getSMCAvoidRulesByName(setupName);
  
  const result: AvoidRuleValidationResult = {
    isValid: true,
    setupId: smcNumber,
    setupName: setupName,
    category: 'smc',
    signal: signal,
    passedConditions: [],
    failedConditions: [],
  };
  
  if (!rule || rule.avoidConditions.length === 0) {
    result.passedConditions.push('No avoid rules defined - auto-pass');
    return result;
  }
  
  for (const avoidCondition of rule.avoidConditions) {
    const conditionLower = avoidCondition.toLowerCase();
    let isBlocked = false;
    
    // Strong momentum (Marubozu)
    if (conditionLower.includes('strong momentum') || conditionLower.includes('marubozu')) {
      isBlocked = conditions.isMarubozu;
    }
    // HTF alignment
    else if (conditionLower.includes('htf') && conditionLower.includes('align')) {
      // Would need HTF data
      isBlocked = false;
    }
    // Close past level
    else if (conditionLower.includes('close') && conditionLower.includes('past')) {
      isBlocked = conditions.currentPrice > conditions.resistance || conditions.currentPrice < conditions.support;
    }
    // 3x average candle
    else if (conditionLower.includes('3x') && conditionLower.includes('average')) {
      isBlocked = conditions.bodySize > conditions.avgBody * 3;
    }
    // Wick < 50% body
    else if (conditionLower.includes('wick') && conditionLower.includes('50%')) {
      const maxWick = Math.max(conditions.upperWick, conditions.lowerWick);
      isBlocked = maxWick < conditions.bodySize * 0.5;
    }
    // Range too wide (> 5 pips)
    else if (conditionLower.includes('range') && conditionLower.includes('5 pip')) {
      isBlocked = conditions.range > 0.0005;
    }
    // Opposite bias
    else if (conditionLower.includes('opposite') && conditionLower.includes('bias')) {
      isBlocked = (signal === 'CALL' && conditions.trend === 'BEARISH') ||
                  (signal === 'PUT' && conditions.trend === 'BULLISH');
    }
    // EMA20 break
    else if (conditionLower.includes('ema20') || conditionLower.includes('ema 20')) {
      const distToEma20 = Math.abs(conditions.currentPrice - conditions.ema20);
      if (conditionLower.includes('break')) {
        isBlocked = distToEma20 > conditions.atr;
      }
    }
    // BB Middle as target
    else if (conditionLower.includes('bb middle') || conditionLower.includes('bb mid')) {
      const bbMiddle = (conditions.bbUpper + conditions.bbLower) / 2;
      const distToBBMiddle = Math.abs(conditions.currentPrice - bbMiddle);
      isBlocked = distToBBMiddle < conditions.atr * 0.2;
    }
    // Stale OB (multiple touches)
    else if (conditionLower.includes('stale') || conditionLower.includes('multiple touch')) {
      // Would need touch tracking
      isBlocked = false;
    }
    
    if (isBlocked) {
      result.failedConditions.push(avoidCondition);
      result.isValid = false;
      result.blockedReason = avoidCondition;
    } else {
      result.passedConditions.push(avoidCondition);
    }
  }
  
  return result;
}

// =============================================================================
// MASTER VALIDATION FUNCTION - VALIDATES ALL STRATEGY TYPES
// =============================================================================

export function validateAllStrategies(
  matchedStrategies: {
    setup235?: { id: number; name: string; signal: 'CALL' | 'PUT' }[];
    indicators?: { id: number; name: string; signal: 'CALL' | 'PUT' }[];
    htf?: { id: number; name: string; signal: 'CALL' | 'PUT' | 'REVERSAL' | 'CONTINUATION' }[];
    priceAction?: { id: number; name: string; signal: string }[];
    liquidity?: { id: number; name: string; signal: string }[];
    smc?: { id: number; name: string; signal: string }[];
  },
  conditions: MarketConditions,
  direction: 'CALL' | 'PUT'
): ValidationSummary {
  const results: AvoidRuleValidationResult[] = [];
  const globalFilters: string[] = [];
  
  // 1. Check Global Salami Trend Rule first
  const salamiCheck = checkSalamiTrendRule(conditions, direction);
  if (salamiCheck.blocked) {
    globalFilters.push(salamiCheck.reason);
  }
  
  // 2. Validate 235 Setups
  if (matchedStrategies.setup235) {
    for (const setup of matchedStrategies.setup235) {
      const result = validate235Setup(setup.id, setup.name, setup.signal, conditions);
      results.push(result);
    }
  }
  
  // 3. Validate Indicator Setups
  if (matchedStrategies.indicators) {
    for (const indicator of matchedStrategies.indicators) {
      const result = validateIndicatorSetup(indicator.id, indicator.name, indicator.signal, conditions);
      results.push(result);
    }
  }
  
  // 4. Validate HTF Setups
  if (matchedStrategies.htf) {
    for (const htf of matchedStrategies.htf) {
      const result = validateHTFSetup(htf.id, htf.name, htf.signal, conditions);
      results.push(result);
    }
  }
  
  // 5. Validate Price Action Setups
  if (matchedStrategies.priceAction) {
    for (const pa of matchedStrategies.priceAction) {
      const result = validatePriceActionSetup(pa.id, pa.name, pa.signal, conditions);
      results.push(result);
    }
  }
  
  // 6. Validate Liquidity Setups
  if (matchedStrategies.liquidity) {
    for (const liq of matchedStrategies.liquidity) {
      const result = validateLiquiditySetup(liq.id, liq.name, liq.signal, conditions);
      results.push(result);
    }
  }
  
  // 7. Validate SMC Setups
  if (matchedStrategies.smc) {
    for (const smc of matchedStrategies.smc) {
      const result = validateSMCSetup(smc.id, smc.name, smc.signal, conditions);
      results.push(result);
    }
  }
  
  // Calculate summary
  const validResults = results.filter(r => r.isValid);
  const invalidResults = results.filter(r => !r.isValid);
  
  return {
    totalStrategiesChecked: results.length,
    validStrategies: validResults.length,
    invalidStrategies: invalidResults.length,
    validationResults: results,
    globalFiltersApplied: globalFilters,
  };
}

// =============================================================================
// FILTER MATCHED SETUPS - Returns ONLY valid strategies
// =============================================================================

export function filterValidStrategies<T extends { id: number; name: string; direction: string }>(
  strategies: T[],
  category: 'setup_235' | 'indicator' | 'htf' | 'price_action' | 'liquidity' | 'smc',
  conditions: MarketConditions,
  direction: 'CALL' | 'PUT'
): { valid: T[]; invalid: T[]; blockedReasons: Map<number, string> } {
  const valid: T[] = [];
  const invalid: T[] = [];
  const blockedReasons = new Map<number, string>();
  
  // First check global filter
  const salamiCheck = checkSalamiTrendRule(conditions, direction);
  if (salamiCheck.blocked) {
    // All reversal strategies are blocked
    return {
      valid: [],
      invalid: strategies,
      blockedReasons: new Map(strategies.map(s => [s.id, salamiCheck.reason]))
    };
  }
  
  for (const strategy of strategies) {
    let result: AvoidRuleValidationResult;
    const signal = strategy.direction as 'CALL' | 'PUT';
    
    switch (category) {
      case 'setup_235':
        result = validate235Setup(strategy.id, strategy.name, signal, conditions);
        break;
      case 'indicator':
        result = validateIndicatorSetup(strategy.id, strategy.name, signal, conditions);
        break;
      case 'htf':
        result = validateHTFSetup(strategy.id, strategy.name, signal as any, conditions);
        break;
      case 'price_action':
        result = validatePriceActionSetup(strategy.id, strategy.name, signal, conditions);
        break;
      case 'liquidity':
        result = validateLiquiditySetup(strategy.id, strategy.name, signal, conditions);
        break;
      case 'smc':
        result = validateSMCSetup(strategy.id, strategy.name, signal, conditions);
        break;
    }
    
    if (result.isValid) {
      valid.push(strategy);
    } else {
      invalid.push(strategy);
      if (result.blockedReason) {
        blockedReasons.set(strategy.id, result.blockedReason);
      }
    }
  }
  
  return { valid, invalid, blockedReasons };
}

// =============================================================================
// GET VALIDATION STATS
// =============================================================================

export function getValidationStats(): {
  total235Rules: number;
  totalIndicatorRules: number;
  totalHTFRules: number;
  totalPriceActionRules: number;
  totalLiquidityRules: number;
  totalSMCRules: number;
  totalAllRules: number;
} {
  return {
    total235Rules: ALL_AVOID_RULES.length,
    totalIndicatorRules: ALL_INDICATOR_AVOID_RULES.length,
    totalHTFRules: ALL_HTF_AVOID_RULES.length,
    totalPriceActionRules: ALL_PRICE_ACTION_AVOID_RULES.length,
    totalLiquidityRules: ALL_LIQUIDITY_AVOID_RULES.length,
    totalSMCRules: ALL_SMC_AVOID_RULES.length,
    totalAllRules: 
      ALL_AVOID_RULES.length +
      ALL_INDICATOR_AVOID_RULES.length +
      ALL_HTF_AVOID_RULES.length +
      ALL_PRICE_ACTION_AVOID_RULES.length +
      ALL_LIQUIDITY_AVOID_RULES.length +
      ALL_SMC_AVOID_RULES.length,
  };
}
