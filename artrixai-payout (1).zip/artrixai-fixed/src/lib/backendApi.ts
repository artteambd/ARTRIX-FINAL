// Backend API Service - connects to Vercel backend
const BACKEND_URL = "https://chartx-9fo4.onrender.com";

export interface BackendUser {
  _id: string;
  email: string;
  name: string;
  licenseKey: string;
  membership: string;
  credits: number;
  isActive: boolean;
  isBlocked: boolean;
  expiresAt: string;
  warnings: Array<{
    _id?: string;
    message: string;
    type: "info" | "warning" | "critical";
    isRead: boolean;
    createdAt: string;
  }>;
  signalsToday: number;
  totalSignals: number;
  lastActiveAt: string;
  createdAt: string;
}

export interface BackendAnalytics {
  totalUsers: number;
  activeUsers: number;
  blockedUsers: number;
  totalSignalsToday: number;
  totalSignalsAllTime: number;
  usersByMembership: Record<string, number>;
}

export interface Notification {
  _id: string;
  message: string;
  type: "info" | "warning" | "critical" | "broadcast";
  isRead: boolean;
  createdAt: string;
}

// Register new user
export async function registerUser(
  name: string,
  email: string,
  password: string,
  deviceFingerprint?: string,
): Promise<{
  success: boolean;
  user?: BackendUser;
  error?: string;
  message?: string;
}> {
  try {
    const response = await fetch(`${BACKEND_URL}/api/auth/register`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ name, email, password, deviceFingerprint }),
    });

    const data = await response.json();
    return {
      success: data.success,
      user: data.user,
      error: data.message,
      message: data.message,
    };
  } catch (error) {
    console.error("Backend register error:", error);
    return { success: false, error: "Connection error", message: "Connection error" };
  }
}

// Login user
export async function loginUser(
  email: string,
  password: string,
  deviceFingerprint?: string,
): Promise<{
  success: boolean;
  user?: BackendUser;
  token?: string;
  error?: string;
  message?: string;
}> {
  try {
    const response = await fetch(`${BACKEND_URL}/api/auth/user-login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password, deviceFingerprint }),
    });

    const data = await response.json();
    return {
      success: data.success,
      user: data.user,
      token: data.token,
      error: data.message,
      message: data.message,
    };
  } catch (error) {
    console.error("Backend login error:", error);
    return { success: false, error: "Connection error", message: "Connection error" };
  }
}

// Verify license through backend
export async function verifyLicense(licenseKey: string): Promise<{
  valid: boolean;
  user?: BackendUser;
  message?: string;
}> {
  try {
    const response = await fetch(`${BACKEND_URL}/api/licenses/verify`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ licenseKey }),
    });

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Backend verify error:", error);
    return { valid: false, message: "Connection error" };
  }
}

// Activate license for a user
export async function activateLicense(
  userId: string,
  licenseKey: string,
): Promise<{
  success: boolean;
  user?: BackendUser;
  message?: string;
}> {
  try {
    const response = await fetch(`${BACKEND_URL}/api/licenses/activate`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ userId, licenseKey }),
    });

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Backend activate license error:", error);
    return { success: false, message: "Connection error" };
  }
}

// Log signal/analysis to backend
export async function logSignal(
  licenseKey: string,
  signalData: {
    pair: string;
    signal: string;
    confidence: number;
    mode: string;
  },
): Promise<boolean> {
  try {
    const response = await fetch(`${BACKEND_URL}/api/analytics/signal`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ licenseKey, ...signalData }),
    });

    return response.ok;
  } catch (error) {
    console.error("Backend log signal error:", error);
    return false;
  }
}

// Get user warnings/notifications by license key
export async function getUserWarnings(licenseKey: string): Promise<Notification[]> {
  try {
    const response = await fetch(`${BACKEND_URL}/api/warnings/license/${encodeURIComponent(licenseKey)}`);

    if (!response.ok) return [];

    const data = await response.json();
    return data.warnings || [];
  } catch (error) {
    console.error("Backend get warnings error:", error);
    return [];
  }
}

// Get user notifications by user ID
export async function getUserNotifications(userId: string): Promise<Notification[]> {
  try {
    const response = await fetch(`${BACKEND_URL}/api/warnings/user-notifications/${encodeURIComponent(userId)}`);

    if (!response.ok) return [];

    const data = await response.json();
    return data.notifications || data.warnings || [];
  } catch (error) {
    console.error("Backend get notifications error:", error);
    return [];
  }
}

// Mark warning as read by license key
export async function markWarningRead(licenseKey: string, warningId: string): Promise<boolean> {
  try {
    const response = await fetch(
      `${BACKEND_URL}/api/warnings/license/${encodeURIComponent(licenseKey)}/${warningId}/read`,
      {
        method: "PATCH",
      },
    );

    return response.ok;
  } catch (error) {
    console.error("Backend mark warning error:", error);
    return false;
  }
}

// Mark notification as read by user ID
export async function markNotificationRead(userId: string, notificationId: string): Promise<boolean> {
  try {
    const response = await fetch(
      `${BACKEND_URL}/api/warnings/user-notifications/${encodeURIComponent(userId)}/${notificationId}/read`,
      {
        method: "PATCH",
      },
    );

    return response.ok;
  } catch (error) {
    console.error("Backend mark notification error:", error);
    return false;
  }
}

// Use credit (deduct from backend)
export async function useBackendCredit(licenseKey: string): Promise<{
  success: boolean;
  remainingCredits?: number;
  message?: string;
}> {
  try {
    const response = await fetch(`${BACKEND_URL}/api/licenses/use-credit`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ licenseKey }),
    });

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Backend use credit error:", error);
    return { success: false, message: "Connection error" };
  }
}

// Get user data by license
export async function getUserByLicense(licenseKey: string): Promise<BackendUser | null> {
  try {
    const response = await fetch(`${BACKEND_URL}/api/users/by-license/${encodeURIComponent(licenseKey)}`);

    if (!response.ok) return null;

    const data = await response.json();
    return data.user || null;
  } catch (error) {
    console.error("Backend get user error:", error);
    return null;
  }
}

// Get user data by ID
export async function getUserById(userId: string): Promise<BackendUser | null> {
  try {
    const response = await fetch(`${BACKEND_URL}/api/users/${encodeURIComponent(userId)}`);

    if (!response.ok) return null;

    const data = await response.json();
    return data.user || null;
  } catch (error) {
    console.error("Backend get user by ID error:", error);
    return null;
  }
}
