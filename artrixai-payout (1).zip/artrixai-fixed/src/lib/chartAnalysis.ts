import { AnalysisResult } from '@/types';
import { supabase } from '@/integrations/supabase/client';

interface AIAnalysisResponse {
  isValid: boolean;
  signal: 'CALL' | 'PUT' | 'NO SIGNAL';
  confidence: number;
  pair: string;
  timeframe: string;
  market: string;
  trend: 'Uptrend' | 'Downtrend' | 'Sideways';
  support: number;
  resistance: number;
  entryPrice: number;
  analysis: string;
  patterns?: string[];
  reasoning?: string;
  error?: string;
  confidenceLevel?: string;
  // V3 additions
  aiAnalysis?: {
    trend: string;
    structure: string;
    momentum: string;
    supportResistance: string;
    candlePattern: string;
    reasoning: string;
    direction: string | null;
    confidence: number;
    stage1Direction?: string | null;
    stage1Confidence?: number | null;
  } | null;
  pillarAnalysis?: {
    pillar: string | null;
    trend: string | null;
    trendScore: number | null;
    confidence: number | null;
    lockedDirection: string | null;
    pillarBoost: number;
    gatedStrategies: number;
    totalStrategies: number;
  } | null;
  matchStatus?: string;
}

// Convert image to base64
async function imageToBase64(imageUrl: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        reject(new Error('Unable to create canvas context'));
        return;
      }

      const maxSize = 1024;
      let width = img.width;
      let height = img.height;
      
      if (width > maxSize || height > maxSize) {
        if (width > height) {
          height = (height / width) * maxSize;
          width = maxSize;
        } else {
          width = (width / height) * maxSize;
          height = maxSize;
        }
      }

      canvas.width = width;
      canvas.height = height;
      ctx.drawImage(img, 0, 0, width, height);

      const base64 = canvas.toDataURL('image/jpeg', 0.8);
      resolve(base64);
    };

    img.onerror = () => {
      reject(new Error('Failed to load image'));
    };

    img.src = imageUrl;
  });
}

// Progress callback type for real-time updates
export type AnalysisProgressCallback = (stage: string, progress: number, detail?: string) => void;

// ── Fast mode: extract market from image with minimal AI, then run live-signal ──
async function extractMarketFromImage(imageBase64: string): Promise<{ pair: string; price: number; timeframe: string } | null> {
  try {
    const { data, error } = await supabase.functions.invoke('analyze-chart', {
      body: { imageBase64, mode: 'extract-only' },
    });
    if (error || !data?.pair || data.pair === 'Unknown') return null;
    return { pair: data.pair, price: data.entryPrice || 0, timeframe: data.timeframe || '1M' };
  } catch {
    return null;
  }
}

// Convert OTC pair display name to live-signal market ID
// Examples: "EUR/USD OTC" → "EURUSD-OTC", "EURUSD-OTC" → "EURUSD-OTC", "USDARS_otc" → "USDARS-OTC"
function pairToMarketId(pair: string): string {
  const cleaned = pair.trim();
  
  // Already in correct format
  if (cleaned.endsWith('-OTC')) return cleaned.toUpperCase();
  
  // Handle _otc suffix (from API internal format)
  if (cleaned.toLowerCase().endsWith('_otc')) {
    return cleaned.replace(/_otc$/i, '-OTC').toUpperCase();
  }
  
  // Handle "EUR/USD OTC" or "EUR/USD" with OTC in name
  const isOtc = /\botc\b/i.test(cleaned);
  const base = cleaned
    .replace(/\s+OTC\s*$/i, '')
    .replace(/\s+/g, '')
    .replace('/', '')
    .toUpperCase();
  
  return isOtc ? `${base}-OTC` : base;
}

// Main analysis function using AI + Pillar dual engine
export async function analyzeChartImage(
  imageUrl: string, 
  mode: 'binary' | 'forex' = 'binary', 
  licenseKey?: string,
  onProgress?: AnalysisProgressCallback,
  fastMode?: boolean
): Promise<AnalysisResult> {
  // ── FAST MODE: code-based analysis via live-signal ──────────────────────
  if (fastMode) {
    try {
      onProgress?.('Reading chart image...', 10, 'Extracting market pair from chart');
      const imageBase64 = await imageToBase64(imageUrl);

      onProgress?.('Identifying trading pair...', 20, 'Quick AI vision scan');
      const extracted = await extractMarketFromImage(imageBase64);
      if (!extracted) {
        return generateNoSignalResult('Could not identify trading pair from chart image.');
      }

      const marketId = pairToMarketId(extracted.pair);
      onProgress?.('Running code-based analysis...', 35, `Analyzing ${marketId}`);

      const { data: fsData, error: fsError } = await supabase.functions.invoke('live-signal', {
        body: { market: marketId, action: 'fast-signal' },
      });

      if (fsError || !fsData?.success || !fsData?.analysis) {
        return generateNoSignalResult(fsData?.error || 'Fast signal analysis failed.');
      }

      onProgress?.('Building result...', 90, 'Compiling signal');

      const fa = fsData.analysis;
      const dir = fa.direction === 'CALL' || fa.direction === 'PUT' ? fa.direction : 'NO SIGNAL' as const;
      const conf = Number(fa.confidence ?? 0);
      const reasoning = fsData.geminiAnalysis?.reasoning || `Fast code analysis: ${dir} ${conf}%`;

      return {
        id: crypto.randomUUID(),
        signal: dir as 'CALL' | 'PUT' | 'NO SIGNAL',
        confidence: conf,
        confidenceLevel: conf >= 80 ? 'HIGH' : conf >= 65 ? 'MEDIUM' : 'LOW',
        market: 'OTC',
        pair: extracted.pair,
        timeframe: extracted.timeframe || '1M',
        trend: fa.trend === 'BULLISH' ? 'Uptrend' : fa.trend === 'BEARISH' ? 'Downtrend' : 'Sideways',
        support: fa.support || 0,
        resistance: fa.resistance || 0,
        entryPrice: fa.currentPrice || extracted.price,
        recommendation: dir === 'CALL' ? 'BUY' : dir === 'PUT' ? 'SELL' : 'NO SIGNAL',
        analysis: `[FAST CODE] ${marketId} → ${dir} at ${conf}% | ${fsData.geminiAnalysis?.m1Smc || ''} | RSI: ${fa.rsi?.toFixed(1) || ''} | ADX: ${fa.atr?.toFixed(5) || ''}`,
        mtfStrategy: reasoning,
        timestamp: new Date(),
        isValid: true,
        imageUrl,
        aiAnalysis: null,
        pillarAnalysis: null,
        matchStatus: 'FAST_CODE',
      };
    } catch (err) {
      console.error('Fast chart analysis error:', err);
      return generateNoSignalResult('Fast analysis failed. Please try again.');
    }
  }
  try {
    // Stage 1: Image processing
    onProgress?.('Preparing chart image...', 5);
    const imageBase64 = await imageToBase64(imageUrl);
    
    onProgress?.('Detecting trading pair...', 10, 'Using AI vision to identify the market pair');
    
    // Call the analyze-chart edge function (which now runs AI + Pillar)
    const { data, error } = await supabase.functions.invoke('analyze-chart', {
      body: { imageBase64, mode, licenseKey },
    });

    if (error) {
      console.error('Analysis error:', error);
      return generateNoSignalResult('Analysis failed. Please try again.');
    }

    const aiResponse = data as AIAnalysisResponse;

    if (aiResponse.error) {
      return generateNoSignalResult(aiResponse.error);
    }

    if (!aiResponse.isValid) {
      return generateNoSignalResult(aiResponse.analysis || 'Invalid chart image');
    }

    let confidenceLevel: 'HIGH' | 'MEDIUM' | 'LOW';
    if (aiResponse.confidence >= 80) {
      confidenceLevel = 'HIGH';
    } else if (aiResponse.confidence >= 65) {
      confidenceLevel = 'MEDIUM';
    } else {
      confidenceLevel = 'LOW';
    }

    let analysisText = aiResponse.analysis || '';
    if (aiResponse.patterns && aiResponse.patterns.length > 0) {
      analysisText += ` Patterns detected: ${aiResponse.patterns.join(', ')}.`;
    }

    let mtfStrategy = aiResponse.reasoning || '';
    if (!mtfStrategy) {
      if (aiResponse.signal === 'CALL') {
        mtfStrategy = `Bullish signal with ${aiResponse.confidence}% confidence. `;
        mtfStrategy += aiResponse.trend === 'Uptrend' ? 'Trend alignment confirmed.' : 'Consider waiting for trend confirmation.';
      } else if (aiResponse.signal === 'PUT') {
        mtfStrategy = `Bearish signal with ${aiResponse.confidence}% confidence. `;
        mtfStrategy += aiResponse.trend === 'Downtrend' ? 'Trend alignment confirmed.' : 'Consider waiting for trend confirmation.';
      } else {
        mtfStrategy = 'No clear signal. Wait for better setup.';
      }
    }

    return {
      id: crypto.randomUUID(),
      signal: aiResponse.signal,
      confidence: aiResponse.confidence,
      confidenceLevel,
      market: aiResponse.market || 'OTC',
      pair: aiResponse.pair || 'Unknown',
      timeframe: aiResponse.timeframe || 'Unknown',
      trend: aiResponse.trend,
      support: aiResponse.support,
      resistance: aiResponse.resistance,
      entryPrice: aiResponse.entryPrice,
      recommendation: aiResponse.signal === 'CALL' ? 'BUY' : aiResponse.signal === 'PUT' ? 'SELL' : 'NO SIGNAL',
      analysis: analysisText,
      mtfStrategy,
      timestamp: new Date(),
      isValid: true,
      // V3 data
      aiAnalysis: aiResponse.aiAnalysis || null,
      pillarAnalysis: aiResponse.pillarAnalysis || null,
      matchStatus: aiResponse.matchStatus || undefined,
    };

  } catch (error) {
    console.error('Chart analysis error:', error);
    return generateNoSignalResult('Failed to analyze image. Please try again.');
  }
}

function generateNoSignalResult(reason: string): AnalysisResult {
  let helpText = 'Please upload a valid trading chart image.';
  
  if (reason.includes('Not a trading chart') || reason.includes('Invalid')) {
    helpText = 'This image does not appear to be a trading chart. Please upload a screenshot of a candlestick chart from your trading platform (e.g., Quotex, Pocket Option, IQ Option).';
  } else if (reason.includes('unclear') || reason.includes('small')) {
    helpText = 'The chart image is unclear or too small. Please upload a clearer, full-screen screenshot of the trading chart.';
  } else if (reason.includes('Rate limit')) {
    helpText = 'Service is busy. Please wait a moment and try again.';
  }
  
  return {
    id: crypto.randomUUID(),
    signal: 'NO SIGNAL',
    confidence: 0,
    confidenceLevel: 'LOW',
    market: 'N/A',
    pair: 'N/A',
    timeframe: 'N/A',
    trend: 'Sideways',
    support: 0,
    resistance: 0,
    entryPrice: 0,
    recommendation: 'NO SIGNAL',
    analysis: reason,
    mtfStrategy: helpText,
    timestamp: new Date(),
    isValid: false,
  };
}
