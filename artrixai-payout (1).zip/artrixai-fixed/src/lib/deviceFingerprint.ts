// Device fingerprinting utility for license locking

export interface DeviceInfo {
  fingerprint: string;
  browser: string;
  os: string;
  screenResolution: string;
  timezone: string;
  language: string;
  platform: string;
}

// Generate a unique device fingerprint
export async function generateDeviceFingerprint(): Promise<DeviceInfo> {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  let canvasFingerprint = '';
  
  if (ctx) {
    ctx.textBaseline = 'top';
    ctx.font = '14px Arial';
    ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = '#f60';
    ctx.fillRect(125, 1, 62, 20);
    ctx.fillStyle = '#069';
    ctx.fillText('ARTRIX-AI-FP', 2, 15);
    ctx.fillStyle = 'rgba(102, 204, 0, 0.7)';
    ctx.fillText('ARTRIX-AI-FP', 4, 17);
    canvasFingerprint = canvas.toDataURL();
  }

  const userAgent = navigator.userAgent;
  const platform = navigator.platform;
  const language = navigator.language;
  const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const screenResolution = `${window.screen.width}x${window.screen.height}x${window.screen.colorDepth}`;
  
  // Get WebGL info
  let webglInfo = '';
  try {
    const glCanvas = document.createElement('canvas');
    const gl = glCanvas.getContext('webgl') || glCanvas.getContext('experimental-webgl');
    if (gl && gl instanceof WebGLRenderingContext) {
      const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
      if (debugInfo) {
        webglInfo = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) || '';
      }
    }
  } catch (e) {
    // WebGL not available
  }

  // Combine all factors into a fingerprint string
  const fingerprintData = [
    userAgent,
    platform,
    language,
    timezone,
    screenResolution,
    canvasFingerprint.slice(0, 100),
    webglInfo,
    navigator.hardwareConcurrency || 0,
    (navigator as any).deviceMemory || 0,
  ].join('|');

  // Hash the fingerprint
  const fingerprint = await hashString(fingerprintData);

  // Detect browser and OS
  const browser = detectBrowser(userAgent);
  const os = detectOS(userAgent);

  return {
    fingerprint,
    browser,
    os,
    screenResolution,
    timezone,
    language,
    platform,
  };
}

// Hash function using Web Crypto API
async function hashString(str: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(str);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// Detect browser from user agent
function detectBrowser(ua: string): string {
  if (ua.includes('Firefox')) return 'Firefox';
  if (ua.includes('SamsungBrowser')) return 'Samsung Browser';
  if (ua.includes('Opera') || ua.includes('OPR')) return 'Opera';
  if (ua.includes('Trident')) return 'Internet Explorer';
  if (ua.includes('Edge')) return 'Edge (Legacy)';
  if (ua.includes('Edg')) return 'Edge';
  if (ua.includes('Chrome')) return 'Chrome';
  if (ua.includes('Safari')) return 'Safari';
  return 'Unknown';
}

// Detect OS from user agent
function detectOS(ua: string): string {
  if (ua.includes('Windows NT 10')) return 'Windows 10/11';
  if (ua.includes('Windows')) return 'Windows';
  if (ua.includes('Android')) return 'Android';
  if (ua.includes('iPhone') || ua.includes('iPad')) return 'iOS';
  if (ua.includes('Mac OS')) return 'macOS';
  if (ua.includes('Linux')) return 'Linux';
  return 'Unknown';
}

// Store device fingerprint in localStorage
export function storeDeviceFingerprint(fingerprint: string): void {
  localStorage.setItem('artrix_device_fp', fingerprint);
}

// Get stored device fingerprint
export function getStoredFingerprint(): string | null {
  return localStorage.getItem('artrix_device_fp');
}
