// ═══════════════════════════════════════════════════════════
// FUTURE SIGNAL WEB WORKER — Inline Blob Worker Code
// Handles the heavy backtest scanning (7100+ candles) off the main thread
// ═══════════════════════════════════════════════════════════

export function getFutureSignalWorkerCode(): string {
  return `
// ═══ WORKER: Future Signal Backtest Engine ═══
// Receives candle data + gate results from edge function
// Performs scanHistoricalSuccess + similarity + MODE calculation
// Returns final signals

let backtestCandles = null; // Stored ONCE per pair
let analysisCandles = null; // 2000-candle for conditions

self.onmessage = function(e) {
  const msg = e.data;
  
  if (msg.type === 'init') {
    // Store candles ONCE — subsequent messages only send gate results
    backtestCandles = msg.backtestCandles;
    self.postMessage({ type: 'ready' });
    return;
  }
  
  if (msg.type === 'analyze') {
    // Process gate results against stored backtest candles
    processAnalysis(msg).then(result => {
      self.postMessage({ type: 'result', ...result });
    }).catch(err => {
      self.postMessage({ type: 'error', error: err.message || 'Worker analysis failed' });
    });
    return;
  }
};

self.onerror = function(err) {
  self.postMessage({ type: 'error', error: 'Worker error: ' + (err.message || 'unknown') });
};

self.onmessageerror = function() {
  self.postMessage({ type: 'error', error: 'Worker message deserialization error' });
};

// ═══════════════════════════════════════
// MARKET CONDITIONS CALCULATOR
// ═══════════════════════════════════════

function ema(data, period) {
  if (data.length < period) return data[data.length - 1] || 0;
  const k = 2 / (period + 1);
  let val = data.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < data.length; i++) {
    val = data[i] * k + val * (1 - k);
  }
  return val;
}

function calculateMarketConditions(candles) {
  if (!candles || candles.length < 120) return null;
  const recent = candles.slice(-200);
  const last50 = candles.slice(-50);
  const last = candles[candles.length - 1];
  const prev = candles[candles.length - 2];
  if (!last || !prev) return null;

  const open = last.open, high = last.high, low = last.low, close = last.close;
  const bodySize = Math.abs(close - open);
  const upperWick = high - Math.max(open, close);
  const lowerWick = Math.min(open, close) - low;
  const range = high - low || 0.00001;
  const isBullish = close > open;
  const isBearish = close < open;
  const closes = recent.map(c => c.close);
  const avgBody = last50.reduce((a, c) => a + Math.abs(c.close - c.open), 0) / last50.length;

  const ema20 = ema(closes, 20);
  const ema50 = ema(closes, 50);
  const ema200 = ema(closes, 200);

  const prev20 = ema(closes.slice(0, -1), 20);
  const emaAngle = ((ema20 - prev20) / (close || 1)) * 10000;

  // RSI
  let gains = 0, losses = 0;
  const rsiPeriod = 14;
  const rsiSlice = closes.slice(-rsiPeriod - 1);
  for (let i = 1; i < rsiSlice.length; i++) {
    const diff = rsiSlice[i] - rsiSlice[i - 1];
    if (diff > 0) gains += diff; else losses -= diff;
  }
  gains /= rsiPeriod; losses /= rsiPeriod;
  const rs = losses === 0 ? 100 : gains / losses;
  const rsi = 100 - (100 / (1 + rs));

  let gains4 = 0, losses4 = 0;
  const rsi4Slice = closes.slice(-5);
  for (let i = 1; i < rsi4Slice.length; i++) {
    const diff = rsi4Slice[i] - rsi4Slice[i - 1];
    if (diff > 0) gains4 += diff; else losses4 -= diff;
  }
  gains4 /= 4; losses4 /= 4;
  const rs4 = losses4 === 0 ? 100 : gains4 / losses4;
  const rsi4 = 100 - (100 / (1 + rs4));

  // BB
  const bb20 = closes.slice(-20);
  const bbMean = bb20.reduce((a, b) => a + b, 0) / bb20.length;
  const bbStd = Math.sqrt(bb20.reduce((a, b) => a + (b - bbMean) ** 2, 0) / bb20.length);
  const bbUpper = bbMean + 2 * bbStd;
  const bbLower = bbMean - 2 * bbStd;
  const bbWidth = bbUpper - bbLower;
  const prevBB20 = closes.slice(-21, -1);
  const prevBBMean = prevBB20.reduce((a, b) => a + b, 0) / prevBB20.length;
  const prevBBStd = Math.sqrt(prevBB20.reduce((a, b) => a + (b - prevBBMean) ** 2, 0) / prevBB20.length);
  const prevBBWidth = (prevBBMean + 2 * prevBBStd) - (prevBBMean - 2 * prevBBStd);
  const bbExpanding = bbWidth > prevBBWidth * 1.1;

  // ATR
  const atrCalc = (data, period) => {
    const trs = data.slice(-period).map((c, i) => {
      if (i === 0) return c.high - c.low;
      const prevC = data[data.length - period + i - 1];
      return Math.max(c.high - c.low, Math.abs(c.high - prevC.close), Math.abs(c.low - prevC.close));
    });
    return trs.reduce((a, b) => a + b, 0) / trs.length;
  };
  const atr = atrCalc(recent, 14);
  const atrAvg = atrCalc(recent.slice(0, -14), 14);

  const volume = last.volume;
  const avgVolume = last50.reduce((a, c) => a + c.volume, 0) / last50.length;
  const volumeRatio = avgVolume > 0 ? volume / avgVolume : 1;

  const ema12 = ema(closes, 12);
  const ema26 = ema(closes, 26);
  const macdHistogram = ema12 - ema26;

  const lowest14 = Math.min(...closes.slice(-14));
  const highest14 = Math.max(...closes.slice(-14));
  const stochK = highest14 !== lowest14 ? ((close - lowest14) / (highest14 - lowest14)) * 100 : 50;
  const stochD = stochK;

  let consecutiveSameColor = 0;
  const lastColor = isBullish;
  for (let i = recent.length - 1; i >= 0; i--) {
    if ((recent[i].close > recent[i].open) === lastColor) consecutiveSameColor++;
    else break;
  }

  const trend = ema20 > ema50 && ema50 > ema200 && close > ema20 ? 'BULLISH' :
    ema20 < ema50 && ema50 < ema200 && close < ema20 ? 'BEARISH' : 'NEUTRAL';

  const srCandles = recent.slice(-100);
  const support = Math.min(...srCandles.map(c => c.low));
  const resistance = Math.max(...srCandles.map(c => c.high));

  const roundDist = Math.min(
    Math.abs((close * 1000) % 1) / 1000,
    Math.abs(1 - (close * 1000) % 1) / 1000
  );
  const halfDist = Math.min(
    Math.abs((close * 1000 - 500) % 1000) / 1000,
    Math.abs(1000 - ((close * 1000 - 500) % 1000)) / 1000
  );
  const roundNumberDistance = Math.min(roundDist, halfDist);
  const nearRoundNumber = roundNumberDistance < 0.0003;

  const candleTime = last.time ? new Date(last.time) : new Date();

  return {
    adx: Math.abs(emaAngle) * 1.5,
    emaAngle, ema20, ema50, ema200, trend, rsi, rsi4,
    currentPrice: close, bodySize, upperWick, lowerWick, range, avgBody,
    isBullishCandle: isBullish, isBearishCandle: isBearish,
    volume, avgVolume, volumeRatio,
    bbUpper, bbLower, bbWidth, bbExpanding,
    atr, atrAvg, macdHistogram, stochK, stochD,
    minute: candleTime.getMinutes(), second: candleTime.getSeconds(),
    isNewsTime: false,
    support, resistance, nearRoundNumber, roundNumberDistance,
    consecutiveSameColor,
    isMarubozu: bodySize > range * 0.85,
    isDoji: bodySize < range * 0.15,
    hasWicks: upperWick > bodySize * 0.1 || lowerWick > bodySize * 0.1,
    last10CandlesSameDirection: consecutiveSameColor >= 10,
  };
}

// ═══════════════════════════════════════
// SIMILARITY CALCULATOR
// ═══════════════════════════════════════

function calculateSimilarity(current, historical) {
  let paScore = 0;
  const paTotal = 10;
  if (current.isBullishCandle === historical.isBullishCandle) paScore += 2;
  if (current.isDoji === historical.isDoji) paScore += 0.5;
  if (current.isMarubozu === historical.isMarubozu) paScore += 0.5;
  const curBodyRatio = current.bodySize / Math.max(current.avgBody, 0.00001);
  const histBodyRatio = historical.bodySize / Math.max(historical.avgBody, 0.00001);
  const bodyRatioDiff = Math.abs(curBodyRatio - histBodyRatio);
  paScore += (bodyRatioDiff < 0.3 ? 3 : bodyRatioDiff < 0.7 ? 2 : bodyRatioDiff < 1.5 ? 1 : 0);
  const curUpperRatio = current.upperWick / Math.max(current.range, 0.00001);
  const histUpperRatio = historical.upperWick / Math.max(historical.range, 0.00001);
  if (Math.abs(curUpperRatio - histUpperRatio) < 0.2) paScore += 1;
  const curLowerRatio = current.lowerWick / Math.max(current.range, 0.00001);
  const histLowerRatio = historical.lowerWick / Math.max(historical.range, 0.00001);
  if (Math.abs(curLowerRatio - histLowerRatio) < 0.2) paScore += 1;
  const ccDiff = Math.abs(current.consecutiveSameColor - historical.consecutiveSameColor);
  paScore += (ccDiff <= 1 ? 2 : ccDiff <= 3 ? 1 : 0);

  let volScore = 0;
  const volTotal = 6;
  const curAtrRatio = current.atr / Math.max(current.atrAvg, 0.00001);
  const histAtrRatio = historical.atr / Math.max(historical.atrAvg, 0.00001);
  const atrDiff = Math.abs(curAtrRatio - histAtrRatio);
  volScore += (atrDiff < 0.2 ? 2 : atrDiff < 0.5 ? 1 : 0);
  const curBBpos = (current.currentPrice - current.bbLower) / Math.max(current.bbWidth, 0.00001);
  const histBBpos = (historical.currentPrice - historical.bbLower) / Math.max(historical.bbWidth, 0.00001);
  const bbDiff = Math.abs(curBBpos - histBBpos);
  volScore += (bbDiff < 0.15 ? 2 : bbDiff < 0.3 ? 1 : bbDiff < 0.5 ? 0.5 : 0);
  const vDiff = Math.abs(current.volumeRatio - historical.volumeRatio);
  volScore += (vDiff < 0.3 ? 2 : vDiff < 0.7 ? 1 : 0);

  let indScore = 0;
  const indTotal = 4;
  const rsiDiff = Math.abs(current.rsi - historical.rsi);
  indScore += (rsiDiff < 5 ? 1.5 : rsiDiff < 10 ? 1 : rsiDiff < 20 ? 0.5 : 0);
  if ((current.ema20 > current.ema50) === (historical.ema20 > historical.ema50)) indScore += 0.5;
  if ((current.ema50 > current.ema200) === (historical.ema50 > historical.ema200)) indScore += 0.5;
  const stochDiff = Math.abs(current.stochK - historical.stochK);
  indScore += (stochDiff < 10 ? 0.75 : stochDiff < 20 ? 0.4 : 0);
  const adxDiff = Math.abs(current.adx - historical.adx);
  indScore += (adxDiff < 5 ? 0.75 : adxDiff < 10 ? 0.4 : 0);

  const paPercent = (paScore / paTotal) * 100;
  const volPercent = (volScore / volTotal) * 100;
  const indPercent = (indScore / indTotal) * 100;

  return Math.round(paPercent * 0.5 + volPercent * 0.3 + indPercent * 0.2);
}

// ═══════════════════════════════════════
// CROSS-REFERENCE for historical scanning (simplified)
// ═══════════════════════════════════════

function getSetupSpecificIds(setupId, row) {
  const idx = row.setupIds.indexOf(setupId);
  if (idx === -1) return { smcIds: [], liquidityIds: [], indicatorIds: [], htfIds: [] };
  return {
    smcIds: [row.smcIds[idx % row.smcIds.length]],
    liquidityIds: [row.liquidityTrapIds[idx % row.liquidityTrapIds.length]],
    indicatorIds: [row.indicatorIds[idx % row.indicatorIds.length]],
    htfIds: [row.htfIds[idx % row.htfIds.length]],
  };
}

// Simplified gate check for historical scanning — just checks if gates >= HISTORY_MIN_GATES
function checkHistoricalGates(conditions, setup, row) {
  const signal = setup.s === 'C' ? 'CALL' : 'PUT';
  const myIds = getSetupSpecificIds(setup.n, row);
  let gatesPassed = 0;
  
  // Gate 1: Setup valid (always pass in historical — avoid rules skipped)
  gatesPassed++;
  
  // Gate 2: SMC — simplified check
  for (const smcId of myIds.smcIds) {
    if (checkSimplePattern(smcId, conditions, signal, 'smc')) { gatesPassed++; break; }
  }
  
  // Gate 3: Liquidity
  for (const liqId of myIds.liquidityIds) {
    if (checkSimplePattern(liqId, conditions, signal, 'liquidity')) { gatesPassed++; break; }
  }
  
  // Gate 4: Indicator
  for (const indId of myIds.indicatorIds) {
    if (checkSimplePattern(indId, conditions, signal, 'indicator')) { gatesPassed++; break; }
  }
  
  // Gate 5: HTF
  for (const htfId of myIds.htfIds) {
    if (checkSimplePattern(htfId, conditions, signal, 'htf')) { gatesPassed++; break; }
  }
  
  return gatesPassed;
}

// Simplified pattern detection for historical scanning
function checkSimplePattern(id, c, signal, category) {
  // Simplified detection — checks key conditions without full strategy database
  // This matches the core detection logic from the edge function
  const isCall = signal === 'CALL';
  const isPut = signal === 'PUT';
  
  if (category === 'smc') {
    switch (id) {
      case 1: return c.range > c.avgBody * 1.5 && c.bodySize > c.avgBody * 0.8 && (isCall ? c.isBullishCandle : c.isBearishCandle);
      case 2: return c.bodySize > c.range * 0.7 && c.bodySize > c.avgBody * 1.5 && (isCall ? c.isBullishCandle : c.isBearishCandle);
      case 3: return c.atr > c.atrAvg * 1.3 && c.bodySize > c.avgBody * 1.2;
      case 4: return c.bodySize > 0.0001 && c.volumeRatio > 1.2;
      case 5: return isCall ? (c.lowerWick > c.bodySize * 1.5 && c.isBullishCandle) : (c.upperWick > c.bodySize * 1.5 && c.isBearishCandle);
      case 6: return c.volumeRatio > 1.3 && c.adx >= 20;
      case 7: return isCall ? (c.isBullishCandle && c.lowerWick > c.bodySize * 1.2) : (c.isBearishCandle && c.upperWick > c.bodySize * 1.2);
      case 8: return c.bodySize > c.avgBody * 1.3 && c.range > c.avgBody * 1.2 && !c.isDoji;
      case 9: return c.consecutiveSameColor <= 2 && c.bodySize > c.avgBody * 1.2;
      case 10: return c.bodySize > c.avgBody * 1.5 && c.volumeRatio >= 1.0 && (isCall ? c.isBullishCandle : c.isBearishCandle);
      case 11: return c.volumeRatio >= 1.2 && c.bodySize > c.avgBody * 0.8;
      case 12: return isCall ? (c.isBullishCandle && c.bodySize > c.avgBody * 2.0) : (c.isBearishCandle && c.bodySize > c.avgBody * 2.0);
      case 13: return isCall ? (c.lowerWick > c.bodySize * 2.5) : (c.upperWick > c.bodySize * 2.5);
      case 14: return c.adx >= 25 && c.bodySize > c.avgBody * 0.8 && (isCall ? c.isBullishCandle : c.isBearishCandle);
      case 15: return c.bodySize > c.avgBody * 3.0 && (isCall ? c.isBullishCandle : c.isBearishCandle);
      case 16: return isCall ? (c.lowerWick > c.bodySize * 2.5 && c.isBullishCandle) : (c.upperWick > c.bodySize * 2.5 && c.isBearishCandle);
      case 17: return c.bodySize > c.avgBody * 1.2 && !c.isDoji && c.volumeRatio >= 1.0;
      case 18: return c.bodySize > c.avgBody * 1.5 && (isCall ? (c.isBullishCandle && c.rsi < 50) : (c.isBearishCandle && c.rsi > 50));
      default: return false;
    }
  }
  
  if (category === 'liquidity') {
    switch (id) {
      case 1: return c.nearRoundNumber && c.roundNumberDistance < 0.0001 && (isCall ? c.isBullishCandle : c.isBearishCandle);
      case 2: return c.nearRoundNumber && c.roundNumberDistance < 0.00005 && c.hasWicks;
      case 3: return isCall ? (c.lowerWick > c.bodySize * 1.2 && c.isBullishCandle) : (c.upperWick > c.bodySize * 1.2 && c.isBearishCandle);
      case 4: return c.bodySize < c.range * 0.2 && c.range > c.avgBody * 1.5;
      case 5: return Math.abs(c.currentPrice - c.ema20) > c.atr * 1.5 && (isCall ? c.isBullishCandle : c.isBearishCandle);
      case 7: return Math.abs(c.currentPrice - c.ema20) > c.atr * 2.0;
      case 8: return isCall ? (c.isBullishCandle && c.lowerWick > c.bodySize * 1.5) : (c.isBearishCandle && c.upperWick > c.bodySize * 1.5);
      case 9: return isCall ? (c.lowerWick > c.range * 0.6 && c.isBullishCandle) : (c.upperWick > c.range * 0.6 && c.isBearishCandle);
      case 10: return c.bodySize > c.avgBody * 1.5 && c.volumeRatio < 0.7;
      case 11: return c.upperWick > c.bodySize * 0.8 && c.isBearishCandle && isPut;
      case 12: return isCall && c.currentPrice < c.ema50 && c.isBullishCandle;
      case 13: return c.isDoji && c.range < c.avgBody * 0.3;
      case 14: return c.bodySize > c.avgBody * 5 && (c.rsi > 80 || c.rsi < 20);
      case 15: return Math.abs(c.currentPrice - c.support) < c.atr * 0.1 && c.isBullishCandle;
      case 16: return isCall ? (c.lowerWick > c.bodySize && c.isBullishCandle) : (c.upperWick > c.bodySize && c.isBearishCandle);
      case 17: return c.range > c.avgBody * 1.3 && c.bodySize > c.avgBody * 0.8;
      case 18: return c.range > c.avgBody * 1.2 && c.bodySize > c.avgBody * 0.6 && c.hasWicks;
      case 19: return c.bodySize > c.avgBody * 1.2 && !c.isDoji && (isCall ? c.isBullishCandle : c.isBearishCandle);
      case 20: return c.bodySize > c.avgBody * 1.3 && (isCall ? c.isBullishCandle : c.isBearishCandle);
      case 21: return c.bodySize > c.avgBody * 0.8 && c.volumeRatio > 1.2;
      case 22: return c.bbWidth < c.atr * 0.3 && c.isDoji;
      case 23: return isCall ? (c.lowerWick > c.bodySize * 3) : (c.upperWick > c.bodySize * 3);
      case 24: return c.bodySize > c.avgBody * 1.5 && c.volumeRatio >= 1.3;
      case 25: return c.minute === 0 && c.hasWicks;
      case 26: return c.minute === 30 && c.hasWicks;
      case 27: return c.bodySize > c.avgBody * 4 && (c.rsi > 75 || c.rsi < 25);
      case 28: return c.consecutiveSameColor >= 4;
      case 29: return c.isDoji && c.bodySize < c.range * 0.1;
      case 31: return c.adx > 30 && c.bodySize > c.avgBody * 1.0;
      case 32: return (c.rsi > 75 && isPut && c.isBearishCandle) || (c.rsi < 25 && isCall && c.isBullishCandle);
      case 33: return c.minute >= 58 && c.bbWidth < c.atr * 0.5;
      case 34: return Math.abs(c.currentPrice - c.resistance) < c.atr * 0.1 && c.rsi > 70 && isPut;
      default: return false;
    }
  }
  
  if (category === 'indicator') {
    switch (id) {
      case 1: return isCall ? (c.lowerWick > c.bodySize * 1.5 && c.rsi < 35) : (c.upperWick > c.bodySize * 1.5 && c.rsi > 65);
      case 2: return Math.abs(c.currentPrice - c.ema20) > c.atr * 2.0;
      case 3: return c.nearRoundNumber && c.roundNumberDistance < 0.0002;
      case 4: return c.volumeRatio > 1.5 && c.isDoji;
      case 5: return c.bodySize < c.avgBody * 0.5 && c.hasWicks;
      case 6: return c.volumeRatio < 0.7 && (isCall ? c.isBullishCandle : c.isBearishCandle);
      case 7: return Math.abs(c.currentPrice - c.ema20) > c.atr * 0.8;
      case 9: return c.isDoji && c.adx > 35;
      case 10: return Math.abs(c.macdHistogram) > 0.00008 && c.adx > 28 && c.bodySize > c.avgBody * 1.3;
      case 11: return c.range > c.avgBody * 1.2 && c.bodySize > c.avgBody * 0.7;
      case 12: return c.bodySize > c.avgBody * 3.5 && c.adx > 25;
      case 13: return (isCall ? (c.rsi < 30) : (c.rsi > 70)) && c.volumeRatio > 1.0;
      case 14: return c.bodySize > c.avgBody * 1.0 && (isCall ? c.isBullishCandle : c.isBearishCandle);
      case 15: return Math.abs(c.currentPrice - c.ema20) < c.atr * 0.1;
      case 16: return Math.abs(c.macdHistogram) > 0.00005 && c.volumeRatio < 0.6;
      case 17: return (isCall ? (c.rsi < 25) : (c.rsi > 75)) && Math.abs(c.currentPrice - c.ema20) > c.atr * 1.2;
      case 18: return c.hasWicks && c.volumeRatio > 1.0 && c.bodySize > c.avgBody * 0.7;
      case 19: return c.volumeRatio > 1.5;
      case 20: return c.bbWidth < c.atr * 0.4 && Math.abs(c.macdHistogram) > 0.00004;
      case 21: return isCall ? (c.currentPrice < c.bbLower && c.rsi < 30) : (c.currentPrice > c.bbUpper && c.rsi > 70);
      case 22: return c.volumeRatio > 1.8 && c.isDoji;
      case 24: return c.bodySize > c.avgBody * 1.0 && !c.isDoji && c.adx > 20;
      case 25: return Math.abs(c.currentPrice - (c.bbUpper + c.bbLower) / 2) < c.atr * 0.1;
      case 26: return Math.abs(c.currentPrice - c.support) < c.atr * 0.05 || Math.abs(c.currentPrice - c.resistance) < c.atr * 0.05;
      case 27: return isCall ? (c.lowerWick > c.bodySize * 1.5 && c.volumeRatio > 1.3) : (c.upperWick > c.bodySize * 1.5 && c.volumeRatio > 1.3);
      case 29: return Math.abs(c.currentPrice - c.ema20) > c.atr * 1.5;
      case 30: return c.isDoji && (isCall ? c.rsi < 30 : c.rsi > 70);
      case 31: return Math.abs(c.currentPrice - c.ema20) > c.atr * 1.2;
      case 32: return c.hasWicks && c.volumeRatio > 1.0;
      case 33: return isCall ? (c.rsi < 25 && c.currentPrice < c.bbLower) : (c.rsi > 75 && c.currentPrice > c.bbUpper);
      case 34: return c.bodySize > c.avgBody * 2.0;
      case 35: return c.volumeRatio > 1.5 && c.bodySize > c.avgBody * 1.3 && !c.isDoji;
      case 36: {
        const aligned = [
          isCall ? c.rsi < 55 : c.rsi > 45,
          isCall ? c.macdHistogram > 0 : c.macdHistogram < 0,
          c.adx > 25,
          isCall ? c.currentPrice > c.ema20 : c.currentPrice < c.ema20,
          isCall ? c.isBullishCandle : c.isBearishCandle,
          c.volumeRatio > 1.0,
          isCall ? c.stochK < 75 : c.stochK > 25,
          c.bodySize > c.avgBody * 0.8,
        ].filter(Boolean).length;
        return aligned >= 7;
      }
      default: return false;
    }
  }
  
  if (category === 'htf') {
    switch (id) {
      case 1: return isCall ? (c.lowerWick > c.bodySize * 1.0 && c.isBullishCandle) : (c.upperWick > c.bodySize * 1.0 && c.isBearishCandle);
      case 2: return c.bodySize > c.avgBody * 2.5;
      case 3: return c.nearRoundNumber && c.roundNumberDistance < 0.0001;
      case 4: return c.consecutiveSameColor <= 2 && c.bodySize > c.avgBody * 0.8;
      case 5: return isCall ? (c.lowerWick > c.bodySize * 0.8 && c.isBullishCandle) : (c.upperWick > c.bodySize * 0.8 && c.isBearishCandle);
      case 6: return c.volumeRatio <= 1.5 && (Math.abs(c.currentPrice - c.support) < c.atr * 0.1 || Math.abs(c.currentPrice - c.resistance) < c.atr * 0.1);
      case 7: return [0, 15, 30, 45].includes(c.minute) && c.hasWicks;
      case 8: return c.bodySize >= c.avgBody * 1.2 && c.hasWicks;
      case 9: return c.adx <= 25 && c.consecutiveSameColor >= 4;
      case 10: return isCall ? c.rsi <= 20 : c.rsi >= 80;
      case 11: return c.volumeRatio < 0.7 && c.bodySize > c.avgBody * 1.3;
      case 12: return isCall ? (c.currentPrice < c.bbLower && c.isBullishCandle) : (c.currentPrice > c.bbUpper && c.isBearishCandle);
      case 13: return c.bodySize >= c.avgBody * 4 && !c.hasWicks;
      case 14: return c.isDoji && c.bbWidth < c.atr * 0.5;
      case 15: return c.bodySize > c.avgBody * 1.8 && (isCall ? c.isBullishCandle : c.isBearishCandle);
      case 16: return isCall ? (Math.abs(c.currentPrice - c.support) < c.atr * 0.1 && c.isBullishCandle) : (Math.abs(c.currentPrice - c.resistance) < c.atr * 0.1 && c.isBearishCandle);
      case 17: return c.bbWidth < c.atr * 0.5 && c.bodySize > c.avgBody * 0.5;
      case 18: return Math.abs(c.currentPrice - c.ema20) > c.atr * 2.0;
      case 19: return c.consecutiveSameColor >= 4 && c.nearRoundNumber;
      case 20: return c.minute === 0 && (Math.abs(c.currentPrice - c.support) < c.atr * 0.1 || Math.abs(c.currentPrice - c.resistance) < c.atr * 0.1);
      default: return false;
    }
  }
  
  return false;
}

// ═══════════════════════════════════════
// HISTORICAL SCAN ENGINE (runs in Worker)
// ═══════════════════════════════════════

const HISTORY_MIN_GATES = 4;

async function scanHistoricalSuccess(candles, setup, row, signal, maxWindowMinutes) {
  const lookAhead = 120; // Extended to 120 candles for peak AND good move detection
  const maxSuccessConditions = 5;
  const SCAN_STEP = 1; // Step 1 for full precision across all 7000+ candles
  const BATCH_SIZE = 500;

  let totalMatches = 0;
  let successCount = 0;
  let totalMoveSize = 0;
  const delayValues = []; // stores the MINUTE of peak displacement for each success
  const successConditions = [];
  const minWindowSize = Math.max(120, maxWindowMinutes + 10);

  // --- Explosive & Good Move Finder ---
  // Tracks both peak (explosive) and good (sustained directional) moves
  const explosiveMoves = [];
  const goodMoves = []; // Good moves: smaller but consistent directional movement
  const explosiveThreshold = 1.8; // ATR multiplier for "explosive" (peak)
  const goodMoveThreshold = 0.5; // ATR multiplier for "good move"

  let evalCount = 0;
  let batchEvalCount = 0;
  let end = minWindowSize;

  while (end <= candles.length - lookAhead) {
    const windowCandles = candles.slice(0, end);
    const conditions = calculateMarketConditions(windowCandles);
    if (!conditions) { end += SCAN_STEP; evalCount++; batchEvalCount++;
      if (batchEvalCount >= BATCH_SIZE) {
        await yieldThread();
        batchEvalCount = 0;
      }
      continue;
    }

    // --- Explosive & Good Move Detection ---
    const currentCandle = candles[end - 1];
    const moveSize = Math.abs(currentCandle.close - currentCandle.open);
    const moveDirection = currentCandle.close > currentCandle.open ? 'CALL' : 'PUT';
    if (conditions.atr > 0 && moveDirection === signal) {
      // Look ahead 120 candles to find peak displacement
      let peakExpMinute = 0;
      let peakExpDisp = 0;
      for (let ahead = 1; ahead <= lookAhead && end + ahead - 1 < candles.length; ahead++) {
        const fc = candles[end + ahead - 1];
        const disp = signal === 'CALL' ? fc.close - currentCandle.close : currentCandle.close - fc.close;
        if (disp > peakExpDisp) {
          peakExpDisp = disp;
          peakExpMinute = ahead;
        }
      }
      // Explosive (peak) move
      if (moveSize > conditions.atr * explosiveThreshold && peakExpMinute > 0 && peakExpDisp > conditions.atr * 0.3) {
        explosiveMoves.push({ minute: peakExpMinute, moveSize, candleIndex: end });
      }
      // Good move (sustained directional, lower threshold)
      if (peakExpMinute > 0 && peakExpDisp > conditions.atr * goodMoveThreshold) {
        goodMoves.push({ minute: peakExpMinute, moveSize: peakExpDisp, candleIndex: end });
      }
    }

    const gatesPassed = checkHistoricalGates(conditions, setup, row);

    if (gatesPassed >= HISTORY_MIN_GATES) {
      totalMatches++;
      const entryPrice = candles[end - 1].close;

      let success = false;
      let peakDisplacement = 0;
      let peakMinute = 1;
      const minWinMargin = conditions.atr * 0.5; // Raised threshold — only count REAL moves, not noise
      for (let ahead = 2; ahead <= lookAhead && end + ahead - 1 < candles.length; ahead++) {
        const futureCandle = candles[end + ahead - 1];
        const displacement = futureCandle.close - entryPrice;
        if (signal === 'CALL' && displacement > minWinMargin) {
          success = true;
          if (displacement > peakDisplacement) { peakDisplacement = displacement; peakMinute = ahead; }
        }
        if (signal === 'PUT' && displacement < -minWinMargin) {
          success = true;
          if (Math.abs(displacement) > peakDisplacement) { peakDisplacement = Math.abs(displacement); peakMinute = ahead; }
        }
      }
      if (success) {
        successCount++;
        totalMoveSize += peakDisplacement;
        // Store delay WITH its displacement weight — bigger moves = more influence
        delayValues.push({ minute: peakMinute, weight: peakDisplacement });
        if (successConditions.length < maxSuccessConditions) {
          successConditions.push(conditions);
        }
      }
    }
    end += SCAN_STEP;
    evalCount++;
    batchEvalCount++;

    if (batchEvalCount >= BATCH_SIZE) {
      await yieldThread();
      batchEvalCount = 0;
    }

    // No early exit — scan ALL 7000+ candles for accurate MODE timing
  }

  // ═══ DISPLACEMENT-WEIGHTED MEDIAN using 100% of ALL successful moves ═══
  // The MEDIAN naturally sits at the true center of peak timing distribution.
  // We weight by displacement so bigger moves have more influence on the result.
  let bestDelay = 0;
  if (delayValues.length > 0) {
    // Build weighted cumulative distribution
    const sorted = [...delayValues].sort((a, b) => a.minute - b.minute);
    const totalWeight = sorted.reduce((s, d) => s + d.weight, 0);
    let cumWeight = 0;
    // Find the displacement-weighted median (50th percentile by weight)
    for (const d of sorted) {
      cumWeight += d.weight;
      if (cumWeight >= totalWeight * 0.5) {
        bestDelay = d.minute;
        break;
      }
    }
    if (bestDelay === 0) bestDelay = sorted[Math.floor(sorted.length / 2)]?.minute || 5;
    
    // If median still <= 3, use 70th percentile fallback
    if (bestDelay <= 3 && delayValues.length >= 10) {
      cumWeight = 0;
      for (const d of sorted) {
        cumWeight += d.weight;
        if (cumWeight >= totalWeight * 0.7) {
          bestDelay = Math.max(bestDelay, d.minute);
          break;
        }
      }
    }
    
    // Absolute minimum: 3 minutes
    bestDelay = Math.max(bestDelay, 3);
  }

  // ═══ EXPLOSIVE & GOOD MOVE FINDER = PRIMARY TIMING SOURCE ═══
  // Scans 120 candles ahead and finds peak AND good move minutes.
  // This is 100% historical, 0% artificial.
  let explosiveDelay = 0;
  let goodMoveDelay = 0;
  
  if (explosiveMoves.length >= 3) {
    const expSorted = [...explosiveMoves].sort((a, b) => a.minute - b.minute);
    const totalExpWeight = expSorted.reduce((s, e) => s + e.moveSize, 0);
    let cumExpW = 0;
    for (const e of expSorted) {
      cumExpW += e.moveSize;
      if (cumExpW >= totalExpWeight * 0.5) {
        explosiveDelay = e.minute;
        break;
      }
    }
    explosiveDelay = Math.max(explosiveDelay, 3);
  }
  
  if (goodMoves.length >= 3) {
    const gmSorted = [...goodMoves].sort((a, b) => a.minute - b.minute);
    const totalGmWeight = gmSorted.reduce((s, e) => s + e.moveSize, 0);
    let cumGmW = 0;
    for (const e of gmSorted) {
      cumGmW += e.moveSize;
      if (cumGmW >= totalGmWeight * 0.5) {
        goodMoveDelay = e.minute;
        break;
      }
    }
    goodMoveDelay = Math.max(goodMoveDelay, 3);
  }

  // Final delay: Explosive > Good Move > Gate-based
  const finalDelay = explosiveDelay > 0
    ? Math.round((explosiveDelay * 0.6) + (bestDelay * 0.4))
    : goodMoveDelay > 0
      ? Math.round((goodMoveDelay * 0.6) + (bestDelay * 0.4))
      : bestDelay;

  const successRate = totalMatches > 0 ? Math.round((successCount / totalMatches) * 100) : 0;
  const avgMoveSize = successCount > 0 ? totalMoveSize / successCount : 0;

  const sortedDelays = delayValues.map(d => d.minute).sort((a, b) => a - b);
  const sortedExplosive = explosiveMoves.map(e => e.minute).sort((a, b) => a - b);
  const sortedGoodMoves = goodMoves.map(e => e.minute).sort((a, b) => a - b);

  return { totalMatches, successCount, successRate, avgMoveSize, avgDelayCandles: Math.max(finalDelay, 3), successConditions, explosiveMoves: explosiveMoves.length, goodMoves: goodMoves.length, delayDistribution: sortedDelays, explosiveDistribution: sortedExplosive, goodMoveDistribution: sortedGoodMoves };
}

// Yield thread to prevent cumulative CPU issues even in Worker
function yieldThread() {
  return new Promise(resolve => setTimeout(resolve, 0));
}

// ═══════════════════════════════════════
// MAIN ANALYSIS PROCESSOR (API-VERIFIED MODE)
// ═══════════════════════════════════════

async function processAnalysis(msg) {
  const { pair, gateResults, setupEntries, trendResult, lastCandleTime, conditions, trendFlipped, windowMinutes, apiSignal } = msg;
  
  if (!backtestCandles || backtestCandles.length < 130) {
    return { pair, signals: [], reason: 'no_backtest_candles' };
  }

  // Calculate current conditions from backtest candles for similarity comparison
  const currentConditions = calculateMarketConditions(backtestCandles);
  if (!currentConditions) {
    return { pair, signals: [], reason: 'no_conditions' };
  }

  const apiDirection = apiSignal ? apiSignal.direction : null;
  const finalSignals = [];

  for (let i = 0; i < gateResults.length; i++) {
    const gate = gateResults[i];
    const setupEntry = setupEntries[i];
    
    if (!setupEntry) continue;

    const signal = gate.signal;

    // If API direction provided, only process matching direction
    if (apiDirection && signal !== apiDirection) continue;

    const row = {
      setupIds: setupEntry.rowSetupIds,
      smcIds: setupEntry.rowSmcIds,
      liquidityTrapIds: setupEntry.rowLiquidityTrapIds,
      indicatorIds: setupEntry.rowIndicatorIds,
      htfIds: setupEntry.rowHtfIds,
    };

    // Run full backtest scan
    const history = await scanHistoricalSuccess(backtestCandles, setupEntry, row, signal, windowMinutes || 120);

    if (history.totalMatches === 0) continue;

    // Relaxed thresholds for API-verified signals
    // API already provides 99% confidence, so backtest threshold is lower
    let requiredBacktestRate;
    if (history.totalMatches >= 1000) requiredBacktestRate = 60;
    else if (history.totalMatches >= 100) requiredBacktestRate = 65;
    else requiredBacktestRate = 70;

    if (history.successRate < requiredBacktestRate) continue;

    if (trendFlipped && history.successRate < requiredBacktestRate + 5) continue;

    // Similarity check
    let bestSimilarity = 0;
    if (history.successConditions.length > 0) {
      for (const histCond of history.successConditions) {
        const sim = calculateSimilarity(currentConditions, histCond);
        if (sim > bestSimilarity) bestSimilarity = sim;
      }
    }

    const gateScore = (gate.totalGatesPassed / 5) * 100;
    const combinedScore = Math.round(
      history.successRate * 0.4 + bestSimilarity * 0.3 + gateScore * 0.3
    );

    // Lower threshold for API-verified (API already confirmed 99%)
    if (combinedScore < 55) continue;
    if (bestSimilarity < 50) continue;

    // ═══ TIMING: API time verified against backtest good/peak moves ═══
    let displayTime = apiSignal ? apiSignal.time : '00:00';
    
    if (apiSignal && apiSignal.time) {
      const [apiH, apiM] = apiSignal.time.split(':').map(Number);
      const apiMinutes = apiH * 60 + apiM;
      
      // Check if API predicted time matches a good move or peak move in backtest
      const allMoveMinutes = [
        ...(history.explosiveDistribution || []),
        ...(history.goodMoveDistribution || []),
      ];
      
      // Check: does any backtest good/peak move land at the API time (within ±2 min)?
      const apiTimeMatch = allMoveMinutes.some(m => Math.abs(m - history.avgDelayCandles) <= 2);
      
      if (apiTimeMatch) {
        // API time confirmed by backtest — use API time directly
        displayTime = apiSignal.time;
      } else {
        // API time NOT confirmed — search ±20 minutes (candles) from API time for best good/peak move
        const candidateMoves = [];
        
        const expMoves = history.explosiveDistribution || [];
        const gmMoves = history.goodMoveDistribution || [];
        
        // All move delays that fall within API time ±20 min
        for (const m of expMoves) {
          const diffFromAvg = Math.abs(m - history.avgDelayCandles);
          if (diffFromAvg <= 20) candidateMoves.push({ minute: m, weight: 2.0 }); // Peak = higher weight
        }
        for (const m of gmMoves) {
          const diffFromAvg = Math.abs(m - history.avgDelayCandles);
          if (diffFromAvg <= 20) candidateMoves.push({ minute: m, weight: 1.0 }); // Good = normal weight
        }
        
        if (candidateMoves.length > 0) {
          // Weighted average of all matching moves in the ±20 min window
          const totalW = candidateMoves.reduce((s, c) => s + c.weight, 0);
          const weightedAvg = Math.round(candidateMoves.reduce((s, c) => s + c.minute * c.weight, 0) / totalW);
          const offsetFromApi = weightedAvg - history.avgDelayCandles;
          
          // Apply offset to API time (±20 min range)
          const clampedOffset = Math.max(-20, Math.min(20, offsetFromApi));
          const newMinutes = apiMinutes + clampedOffset;
          const newH = Math.floor(newMinutes / 60) % 24;
          const newM = newMinutes % 60;
          displayTime = String(newH).padStart(2, '0') + ':' + String(newM).padStart(2, '0');
        } else {
          // No moves found within ±20 min — still use API time as fallback
          displayTime = apiSignal.time;
        }
      }
    }

    finalSignals.push({
      pair: pair.replace('-OTC', '').replace('STK', ''),
      direction: signal,
      score: combinedScore,
      confidence: combinedScore,
      time: displayTime,
      trend: trendResult.trendName,
      setupNumber: gate.setupNumber,
      setupName: gate.setupName,
      setup: '#' + gate.setupNumber + ': ' + gate.setupName,
      gatesPassed: gate.totalGatesPassed + '/' + gate.totalGates,
      similarity: bestSimilarity,
      historySuccessRate: history.successRate,
      historyMatches: history.totalMatches,
      trendReasons: trendResult.reasons,
      status: 'CONFIRMED',
    });
  }

  // Sort by combined score, take top 1 per pair
  finalSignals.sort((a, b) => b.confidence - a.confidence);
  const best = finalSignals.slice(0, 1);

  return { pair, signals: best };
}
`;
}
