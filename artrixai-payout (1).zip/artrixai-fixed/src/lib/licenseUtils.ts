import { addDays } from 'date-fns';

/**
 * Calculate license expiry date based on package duration
 */
export function calculateExpiryDate(durationDays: number): Date {
  return addDays(new Date(), durationDays);
}

/**
 * Check if a license is expired
 */
export function isLicenseExpired(expiresAt: Date | undefined): boolean {
  if (!expiresAt) return false;
  return new Date() > new Date(expiresAt);
}

/**
 * Get days remaining until license expires
 */
export function getDaysRemaining(expiresAt: Date | undefined): number {
  if (!expiresAt) return 0;
  const now = new Date();
  const expiry = new Date(expiresAt);
  const diffTime = expiry.getTime() - now.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return Math.max(0, diffDays);
}

/**
 * Format expiry date for display
 */
export function formatExpiryDate(date: Date): string {
  return new Date(date).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

/**
 * Check if license is about to expire (within 3 days)
 */
export function isLicenseExpiringSoon(expiresAt: Date | undefined): boolean {
  if (!expiresAt) return false;
  const daysRemaining = getDaysRemaining(expiresAt);
  return daysRemaining > 0 && daysRemaining <= 3;
}
