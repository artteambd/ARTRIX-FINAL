// === 100 MAIN SCENARIO STRATEGIES DATABASE ===
// These strategies have PRIORITY over raw summation.
// If a scenario matches, the bot follows it instead of the raw sum.

import { extendedStrategies, EXTENDED_STRATEGY_DATABASE } from './scenarioStrategiesExtended';
export interface CategoryBreakdown {
  smc: { up: number; down: number };
  htf: { up: number; down: number };
  liquidity: { up: number; down: number };
  indicator: { up: number; down: number };
  retail: { up: number; down: number };
  algoTrap?: { up: number; down: number };
}

export interface StrategyResult {
  signal: 'CALL' | 'PUT';
  logic: string;
  confidence: string;
  strategyName: string;
  strategyNumber: number;
}

// --- STRATEGY #1: THE WHALE VS THE CROWD (ANTI-RETAIL BAIT) ---
function getWhaleSignal(breakdown: CategoryBreakdown): StrategyResult | null {
  const isCleanRoad = (breakdown.htf.up === 0 && breakdown.htf.down === 0);
  const retailBaitUp = (breakdown.retail.up >= 15 && breakdown.retail.down <= 5);
  const retailBaitDown = (breakdown.retail.down >= 15 && breakdown.retail.up <= 5);
  const whaleAlignDown = (breakdown.smc.down >= 1 && breakdown.liquidity.down >= 2);
  const whaleAlignUp = (breakdown.smc.up >= 1 && breakdown.liquidity.up >= 2);

  if (isCleanRoad && retailBaitUp && whaleAlignDown) {
    return {
      signal: "PUT",
      logic: "Whale Strategy: Trapping Retail Crowd (21 UP). Following SMC + Liquidity (DOWN).",
      confidence: "98%",
      strategyName: "Whale vs Crowd",
      strategyNumber: 1
    };
  }

  if (isCleanRoad && retailBaitDown && whaleAlignUp) {
    return {
      signal: "CALL",
      logic: "Whale Strategy: Trapping Retail Crowd (21 DOWN). Following SMC + Liquidity (UP).",
      confidence: "98%",
      strategyName: "Whale vs Crowd",
      strategyNumber: 1
    };
  }

  return null;
}

// --- STRATEGY #2: DOMINATION PARTY ---
function getDominationSignal(breakdown: CategoryBreakdown): StrategyResult | null {
  const mastersSilent = (breakdown.smc.up === 0 && breakdown.smc.down === 0) && 
                        (breakdown.htf.up === 0 && breakdown.htf.down === 0);

  const algoTrap = breakdown.algoTrap || { up: 0, down: 0 };
  const totalUp = (breakdown.liquidity.up + algoTrap.up + breakdown.retail.up);
  const totalDown = (breakdown.liquidity.down + algoTrap.down + breakdown.retail.down);

  if (mastersSilent && totalUp >= 10 && totalDown >= 10) {
    if (totalUp > totalDown) {
      return {
        signal: "CALL",
        logic: `Up Domination: ${totalUp} vs ${totalDown}. Masters Silent. Following the Dominant Party UP.`,
        confidence: "93%",
        strategyName: "Domination Party",
        strategyNumber: 2
      };
    } else if (totalDown > totalUp) {
      return {
        signal: "PUT",
        logic: `Down Domination: ${totalDown} vs ${totalUp}. Masters Silent. Following the Dominant Party DOWN.`,
        confidence: "93%",
        strategyName: "Domination Party",
        strategyNumber: 2
      };
    }
  }
  
  return null;
}

// --- STRATEGY #3: MASTER-CROWD HARMONY ---
function checkHarmonyStrategy(breakdown: CategoryBreakdown): StrategyResult | null {
  const mastersUp = breakdown.smc.up >= 1 && breakdown.smc.down === 0 && breakdown.htf.up >= 1;
  const crowdUp = breakdown.retail.up >= 15 && (breakdown.retail.up > breakdown.retail.down * 3);

  if (mastersUp && crowdUp) {
    return {
      signal: "CALL",
      logic: "Harmony Strategy: SMC & Retail are aligned UP. Ignoring minor Liquidity/Indicator opposition.",
      confidence: "98%",
      strategyName: "Master-Crowd Harmony",
      strategyNumber: 3
    };
  }
  return null;
}

// --- STRATEGY #4: THE EQUILIBRIUM TRAP (ANTI-CROWD) ---
function checkEquilibriumTrap(breakdown: CategoryBreakdown): StrategyResult | null {
  const smcTie = breakdown.smc.up === 1 && breakdown.smc.down === 1;
  const liqTie = breakdown.liquidity.up === 1 && breakdown.liquidity.down === 1;
  const crowdHeavyDown = breakdown.retail.down >= 10 && breakdown.retail.up <= 2;

  if (smcTie && liqTie && crowdHeavyDown) {
    return {
      signal: "CALL",
      logic: "Equilibrium Trap: Masters are tied. Retail crowd is heavily Down. OTC is flushing the crowd UP.",
      confidence: "95%",
      strategyName: "Equilibrium Trap",
      strategyNumber: 4
    };
  }
  return null;
}

// --- STRATEGY #5: HTF ANCHOR OVERRIDE ---
function checkHTFAnchorStrategy(breakdown: CategoryBreakdown): StrategyResult | null {
  const isHTF_UpAnchor = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isRetail_UpDominant = breakdown.retail.up >= 10 && (breakdown.retail.up >= breakdown.retail.down * 3);
  const isSMC_WeakOpposition = breakdown.smc.down > 0 && breakdown.smc.down <= 3;

  if (isHTF_UpAnchor && isRetail_UpDominant && isSMC_WeakOpposition) {
    return {
      signal: "CALL",
      logic: "HTF Anchor Strategy: HTF & Retail are 100% UP. Weak SMC Down is treated as a Bait Trap.",
      confidence: "94%",
      strategyName: "HTF Anchor Override",
      strategyNumber: 5
    };
  }
  return null;
}

// --- STRATEGY #6: THE PURE ANCHOR MAGNET ---
function checkAnchorMagnetStrategy(breakdown: CategoryBreakdown): StrategyResult | null {
  const isHTF_PureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isSMCLiq_Confused = (breakdown.smc.up > 0 && breakdown.smc.down > 0) || 
                            (breakdown.liquidity.up === breakdown.liquidity.down);
  const isRetail_Supporting = breakdown.retail.up > breakdown.retail.down;

  if (isHTF_PureUp && isSMCLiq_Confused && isRetail_Supporting) {
    return {
      signal: "CALL",
      logic: "Anchor Magnet: HTF is Pure UP while SMC/Liquidity are confused. Following the HTF Magnet.",
      confidence: "92%",
      strategyName: "Pure Anchor Magnet",
      strategyNumber: 6
    };
  }
  return null;
}

// --- STRATEGY #7: THE CONSENSUS SURGE (FULL SYNERGY) ---
function checkConsensusSurge(breakdown: CategoryBreakdown): StrategyResult | null {
  const isSMC_PowerAnchor = breakdown.smc.up >= 3 && breakdown.smc.down === 0;
  const isRetail_MassiveUp = breakdown.retail.up >= 25 && (breakdown.retail.up >= breakdown.retail.down * 5);
  const isIndicator_Supporting = breakdown.indicator.up > breakdown.indicator.down;

  if (isSMC_PowerAnchor && isRetail_MassiveUp && isIndicator_Supporting) {
    return {
      signal: "CALL",
      logic: "Consensus Surge: SMC Anchor (3-0) and Massive Retail Force (28-5) are aligned. Absolute market synergy.",
      confidence: "99%",
      strategyName: "Consensus Surge",
      strategyNumber: 7
    };
  }
  return null;
}

// --- STRATEGY #8: THE CROWD WASHOUT (LIQUIDITY VETO) ---
function checkCrowdWashout(breakdown: CategoryBreakdown): StrategyResult | null {
  const isRetail_MassiveUp = breakdown.retail.up >= 20 && breakdown.retail.down <= 5;
  const isSMC_AlsoUp = breakdown.smc.up >= 2 && breakdown.smc.down === 0;
  const isLiquidity_PureDown = breakdown.liquidity.down >= 1 && breakdown.liquidity.up === 0;
  const isIndicator_Down = breakdown.indicator.down > breakdown.indicator.up;

  if (isRetail_MassiveUp && isSMC_AlsoUp && isLiquidity_PureDown && isIndicator_Down) {
    return {
      signal: "PUT",
      logic: "Crowd Washout: Retail and SMC are too heavy UP. Following single pure Liquidity DOWN to wash out the crowd.",
      confidence: "93%",
      strategyName: "Crowd Washout",
      strategyNumber: 8
    };
  }
  return null;
}

// --- STRATEGY #9: THE WEIGHTED DOMINATION ---
function checkWeightedDomination(breakdown: CategoryBreakdown): StrategyResult | null {
  const isSMC_StrongDown = breakdown.smc.down >= 3 && breakdown.smc.up === 0;
  const isRetail_OverwhelmingDown = breakdown.retail.down >= 25 && (breakdown.retail.down >= breakdown.retail.up * 5);
  const isHTF_WeakOpposition = breakdown.htf.up === 1 && breakdown.htf.down === 0;

  if (isSMC_StrongDown && isRetail_OverwhelmingDown && isHTF_WeakOpposition) {
    return {
      signal: "PUT",
      logic: "Weighted Domination: Strong SMC (3-0) and Massive Retail Volume (26-5) crushed the lone HTF Anchor.",
      confidence: "95%",
      strategyName: "Weighted Domination",
      strategyNumber: 9
    };
  }
  return null;
}

// --- STRATEGY #10: THE TRIPLE ANCHOR FORCE ---
function checkTripleAnchorForce(breakdown: CategoryBreakdown): StrategyResult | null {
  const isHTF_PureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isLiq_PureUp = breakdown.liquidity.up >= 2 && breakdown.liquidity.down === 0;
  const isSMC_SupportingUp = breakdown.smc.up > breakdown.smc.down;
  const isRetail_Up = breakdown.retail.up > breakdown.retail.down;

  if (isHTF_PureUp && isLiq_PureUp && isSMC_SupportingUp && isRetail_Up) {
    return {
      signal: "CALL",
      logic: "Triple Anchor Force: HTF & Liquidity are Pure UP. SMC confirms. Ignoring Indicator Down-bait.",
      confidence: "97%",
      strategyName: "Triple Anchor Force",
      strategyNumber: 10
    };
  }
  return null;
}

// --- STRATEGY #11: THE HTF TREND TRAP (REFINED) ---
function checkHTFTrendTrap(breakdown: CategoryBreakdown): StrategyResult | null {
  const isPowerAlignedDown = breakdown.smc.down >= 4 && 
                             breakdown.smc.up === 0 && 
                             breakdown.retail.down >= 20 && 
                             (breakdown.retail.down >= breakdown.retail.up * 5);

  const isPowerAlignedUp = breakdown.smc.up >= 4 && 
                           breakdown.smc.down === 0 && 
                           breakdown.retail.up >= 20 && 
                           (breakdown.retail.up >= breakdown.retail.down * 5);

  const isHTF_BaitUp = breakdown.htf.up >= 1 && breakdown.htf.up <= 2;
  const isHTF_BaitDown = breakdown.htf.down >= 1 && breakdown.htf.down <= 2;

  if (isPowerAlignedDown && isHTF_BaitUp) {
    return {
      signal: "PUT",
      logic: "HTF Trend Trap: Institutional Hammer (SMC 4+) & Massive Retail (20+) are overriding the HTF trend. The trend is acting as a Liquidity Bait.",
      confidence: "99%",
      strategyName: "HTF Trend Trap",
      strategyNumber: 11
    };
  }

  if (isPowerAlignedUp && isHTF_BaitDown) {
    return {
      signal: "CALL",
      logic: "HTF Trend Trap: Institutional Hammer (SMC 4+) & Massive Retail (20+) are overriding the HTF trend. The trend is acting as a Liquidity Bait.",
      confidence: "99%",
      strategyName: "HTF Trend Trap",
      strategyNumber: 11
    };
  }

  return null;
}

// --- STRATEGY #12: THE BALANCED FLOW ---
function checkBalancedFlow(breakdown: CategoryBreakdown): StrategyResult | null {
  const isSMCTie = breakdown.smc.up === breakdown.smc.down;
  const isIndicatorTie = breakdown.indicator.up === breakdown.indicator.down;
  const isHTF_Down = breakdown.htf.down >= 1 && breakdown.htf.up === 0;
  const isLiq_Down = breakdown.liquidity.down > breakdown.liquidity.up;
  const isRetail_MassiveDown = breakdown.retail.down >= 20;

  if (isSMCTie && isIndicatorTie && isHTF_Down && isLiq_Down && isRetail_MassiveDown) {
    return {
      signal: "PUT",
      logic: "Balanced Flow: SMC & Indicators are neutral. Following the HTF + Liquidity + Retail momentum.",
      confidence: "97%",
      strategyName: "Balanced Flow",
      strategyNumber: 12
    };
  }
  return null;
}

// --- STRATEGY #13: THE EXTREMIST TRAP (MASS LIQUIDATION) ---
function checkExtremistTrap(breakdown: CategoryBreakdown): StrategyResult | null {
  const isRetail_ExtremistDown = breakdown.retail.down >= 25 && (breakdown.retail.down >= breakdown.retail.up * 10);
  const isSMC_TrappedDown = breakdown.smc.down >= 1 && breakdown.smc.up === 0;
  const isHTF_PureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isLiq_WithCaptain = breakdown.liquidity.up > breakdown.liquidity.down;

  if (isRetail_ExtremistDown && isSMC_TrappedDown && isHTF_PureUp && isLiq_WithCaptain) {
    return {
      signal: "CALL",
      logic: "Extremist Trap: Retail (29 vs 2) is too heavy. Following lone pure HTF Anchor to liquidate the crowd.",
      confidence: "98%",
      strategyName: "Extremist Trap",
      strategyNumber: 13
    };
  }
  return null;
}

// --- STRATEGY #14: THE MULTI-LAYER LIQUIDATION ---
function checkMultiLayerLiquidation(breakdown: CategoryBreakdown): StrategyResult | null {
  const isRetail_MassiveDown = breakdown.retail.down >= 25 && (breakdown.retail.down >= breakdown.retail.up * 4);
  const isBait_Down = (breakdown.indicator.down >= 4 && breakdown.smc.down <= 1);
  const isHTF_PureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isLiq_WithHTF = breakdown.liquidity.up >= 2 && breakdown.liquidity.up > breakdown.liquidity.down;

  if (isRetail_MassiveDown && isBait_Down && isHTF_PureUp && isLiq_WithHTF) {
    return {
      signal: "CALL",
      logic: "Multi-Layer Liquidation: Crowd, Indicators & weak SMC are trapped Down. Following lone HTF & Liquidity UP.",
      confidence: "98%",
      strategyName: "Multi-Layer Liquidation",
      strategyNumber: 14
    };
  }
  return null;
}

// --- STRATEGY #15: THE SYNERGY OVERPOWER ---
function checkSynergyOverpower(breakdown: CategoryBreakdown): StrategyResult | null {
  const isSMC_PureUp = breakdown.smc.up >= 2 && breakdown.smc.down === 0;
  const isRetail_MassiveUp = breakdown.retail.up >= 20 && (breakdown.retail.up >= breakdown.retail.down * 5);
  const isIndicator_Supporting = breakdown.indicator.up > breakdown.indicator.down;
  const isOpposition_Weak = breakdown.htf.down <= 2 && breakdown.liquidity.down <= 2;

  if (isSMC_PureUp && isRetail_MassiveUp && isIndicator_Supporting && isOpposition_Weak) {
    return {
      signal: "CALL",
      logic: "Synergy Overpower: SMC & Massive Retail (5x) are aligned. Overriding weak HTF & Liquidity opposition.",
      confidence: "95%",
      strategyName: "Synergy Overpower",
      strategyNumber: 15
    };
  }
  return null;
}

// --- STRATEGY #16: THE UNSTOPPABLE ANCHOR SYNERGY ---
function checkUnstoppableAnchor(breakdown: CategoryBreakdown): StrategyResult | null {
  const isHTF_PureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isLiq_PureUp = breakdown.liquidity.up >= 2 && breakdown.liquidity.down === 0;
  const isRetail_StrongUp = breakdown.retail.up >= 15 && (breakdown.retail.up >= breakdown.retail.down * 8);
  const isSMC_DominantUp = breakdown.smc.up > breakdown.smc.down;

  if (isHTF_PureUp && isLiq_PureUp && isRetail_StrongUp && isSMC_DominantUp) {
    return {
      signal: "CALL",
      logic: "Unstoppable Anchor: HTF & Liquidity are 100% Pure UP. Retail Force is massive. Minor indicator noise ignored.",
      confidence: "99%",
      strategyName: "Unstoppable Anchor Synergy",
      strategyNumber: 16
    };
  }
  return null;
}

// --- STRATEGY #17: THE LIQUIDITY VETO ---
function checkLiquidityVeto(breakdown: CategoryBreakdown): StrategyResult | null {
  const isNeutralMarket = (breakdown.htf.up === 0 && breakdown.htf.down === 0) && 
                          (breakdown.indicator.up === breakdown.indicator.down);
  const isLiq_PureUp = breakdown.liquidity.up >= 2 && breakdown.liquidity.down === 0;
  const isOpposition_Down = breakdown.smc.down >= 1 && breakdown.retail.down > breakdown.retail.up;

  if (isNeutralMarket && isLiq_PureUp && isOpposition_Down) {
    return {
      signal: "CALL",
      logic: "Liquidity Veto: Pure 2-0 Liquidity UP overrides the impure SMC and Retail crowd.",
      confidence: "94%",
      strategyName: "Liquidity Veto",
      strategyNumber: 17
    };
  }
  return null;
}

// --- STRATEGY #18: THE MASTER VETO (RETAIL TRAP) ---
function checkMasterVeto(breakdown: CategoryBreakdown): StrategyResult | null {
  const isNeutralMarket = (breakdown.htf.up === 0 && breakdown.htf.down === 0) && 
                          (breakdown.liquidity.up === breakdown.liquidity.down);
  const isRetail_HeavyUp = breakdown.retail.up >= 10 && (breakdown.retail.up >= breakdown.retail.down * 7);
  const isSMC_PureDown = breakdown.smc.down >= 2 && breakdown.smc.up === 0;

  if (isNeutralMarket && isRetail_HeavyUp && isSMC_PureDown) {
    return {
      signal: "PUT",
      logic: "Master Veto: 14 Retail setups trapped UP. Following 2 Pure SMC signals DOWN.",
      confidence: "96%",
      strategyName: "Master Veto",
      strategyNumber: 18
    };
  }
  return null;
}

// --- STRATEGY #19: THE INDICATOR OVERLOAD TRAP ---
function checkIndicatorOverload(breakdown: CategoryBreakdown): StrategyResult | null {
  const isSMC_Neutral = (breakdown.smc.up === breakdown.smc.down) && 
                        (breakdown.htf.up === 0 && breakdown.htf.down === 0);
  const isIndicator_BaitUp = breakdown.indicator.up >= 4 && breakdown.indicator.down <= 1;
  const isRetail_AntiBait = breakdown.retail.down > (breakdown.retail.up * 3);

  if (isSMC_Neutral && isIndicator_BaitUp && isRetail_AntiBait) {
    return {
      signal: "PUT",
      logic: "Indicator Overload Trap: Too many indicators are UP while SMC is tied. Following the retail anti-bait move.",
      confidence: "93%",
      strategyName: "Indicator Overload Trap",
      strategyNumber: 19
    };
  }
  return null;
}

// --- STRATEGY #20: THE OVERCROWDED MAGNET TRAP ---
function checkOvercrowdedTrap(breakdown: CategoryBreakdown): StrategyResult | null {
  const isCrowdedDown = breakdown.smc.down >= 3 && 
                        breakdown.indicator.down >= 6 && 
                        breakdown.retail.down >= 25;
  const isLiquidity_OpposingUp = breakdown.liquidity.up >= 4;
  const isNoHTF = breakdown.htf.up === 0 && breakdown.htf.down === 0;

  if (isCrowdedDown && isLiquidity_OpposingUp && isNoHTF) {
    return {
      signal: "CALL",
      logic: "Overcrowded Trap: SMC, Indicators, and Retail are heavily aligned DOWN. Market reversed to Liquidity UP to hunt the crowd.",
      confidence: "95%",
      strategyName: "Overcrowded Magnet Trap",
      strategyNumber: 20
    };
  }
  return null;
}

// --- STRATEGY #21: THE HTF SUPREMACY ---
function checkHTFSupremacy(breakdown: CategoryBreakdown): StrategyResult | null {
  const isPureMasterUp = (breakdown.smc.up >= 3 && breakdown.smc.down === 0) && 
                         (breakdown.liquidity.up >= 2 && breakdown.liquidity.down === 0);
  const isHTF_Opposing = breakdown.htf.down >= 1 && breakdown.htf.up === 0;
  const isMassiveRetailDown = breakdown.retail.down >= 20 && (breakdown.retail.down > breakdown.retail.up * 2);
  const isWeakIndicatorSupport = (breakdown.indicator.up - breakdown.indicator.down) <= 1;

  if (isPureMasterUp && isHTF_Opposing && isMassiveRetailDown && isWeakIndicatorSupport) {
    return {
      signal: "PUT",
      logic: "HTF Supremacy: Single HTF Down and Massive Retail (22) overpowered Pure SMC Up due to weak indicator support.",
      confidence: "92%",
      strategyName: "HTF Supremacy",
      strategyNumber: 21
    };
  }
  return null;
}

// --- STRATEGY #22: THE LIQUIDITY VACUUM TRAP ---
function checkLiquidityVacuum(breakdown: CategoryBreakdown): StrategyResult | null {
  const isExtremeRetailDown = breakdown.retail.down >= 25 && (breakdown.retail.down >= breakdown.retail.up * 5);
  const isSMC_Liq_TrappingDown = breakdown.smc.down >= 1 && breakdown.liquidity.down >= 1;
  const isHTF_CounteringUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;

  if (isExtremeRetailDown && isSMC_Liq_TrappingDown && isHTF_CounteringUp) {
    return {
      signal: "CALL",
      logic: "Liquidity Vacuum: 25 Retail setups trapped DOWN. Following HTF Up and Indicator support to hunt the crowd.",
      confidence: "96%",
      strategyName: "Liquidity Vacuum Trap",
      strategyNumber: 22
    };
  }
  return null;
}

// --- STRATEGY #23: THE RETAIL LIQUIDITY FLUSH ---
function checkRetailLiquidityFlush(breakdown: CategoryBreakdown): StrategyResult | null {
  const isExtremeRetailDown = breakdown.retail.down >= 20 && (breakdown.retail.down >= breakdown.retail.up * 4);
  const isSMCTied = breakdown.smc.up === breakdown.smc.down;
  const isSupportiveUp = breakdown.liquidity.up >= 1 && breakdown.indicator.up > breakdown.indicator.down;
  const isWeakHTFOpposition = breakdown.htf.down <= 1 && breakdown.htf.up === 0;

  if (isExtremeRetailDown && isSMCTied && isSupportiveUp && isWeakHTFOpposition) {
    return {
      signal: "CALL",
      logic: "Retail Liquidity Flush: 23 Retail sellers trapped. SMC is neutral, allowing Liquidity and Indicators to lead the reversal.",
      confidence: "94%",
      strategyName: "Retail Liquidity Flush",
      strategyNumber: 23
    };
  }
  return null;
}

// --- STRATEGY #24: THE ABSOLUTE TREND CONTINUATION ---
function checkAbsoluteTrendContinuation(breakdown: CategoryBreakdown): StrategyResult | null {
  const isSMCPureUp = breakdown.smc.up >= 3 && breakdown.smc.down === 0;
  const isIndicatorExtremeUp = breakdown.indicator.up >= 8 && breakdown.indicator.down === 0;
  const isRetailMassiveUp = breakdown.retail.up >= 25 && (breakdown.retail.up >= breakdown.retail.down * 8);
  const isHTFSupporting = breakdown.htf.up >= 1 && breakdown.htf.down === 0;

  if (isSMCPureUp && isIndicatorExtremeUp && isRetailMassiveUp && isHTFSupporting) {
    return {
      signal: "CALL",
      logic: "Absolute Trend Continuation: SMC (3-0), Indicators (8-0), and Retail (30-3) are perfectly aligned. Momentum overrides minor liquidity friction.",
      confidence: "99%",
      strategyName: "Absolute Trend Continuation",
      strategyNumber: 24
    };
  }
  return null;
}

// --- STRATEGY #25: THE MOMENTUM OVERPOWER ---
function checkMomentumOverpower(breakdown: CategoryBreakdown): StrategyResult | null {
  const isSMCLeadUp = breakdown.smc.up >= 2 && breakdown.smc.down === 0;
  const isIndicatorStrongUp = breakdown.indicator.up >= 6 && breakdown.indicator.down === 0;
  const isRetailAlignedUp = breakdown.retail.up >= 15 && (breakdown.retail.up >= breakdown.retail.down * 5);
  const isOppositionWeak = (breakdown.htf.down + breakdown.liquidity.down) <= 3;

  if (isSMCLeadUp && isIndicatorStrongUp && isRetailAlignedUp && isOppositionWeak) {
    return {
      signal: "CALL",
      logic: "Momentum Overpower: Strong SMC (2-0) and Indicators (6-0) crushed weak HTF/Liquidity opposition.",
      confidence: "95%",
      strategyName: "Momentum Overpower",
      strategyNumber: 25
    };
  }
  return null;
}

// --- STRATEGY #26: THE SMC SUPERIORITY (UNCHECKED) ---
function checkSMCSuperiority(breakdown: CategoryBreakdown): StrategyResult | null {
  const isSMCPureUp = breakdown.smc.up >= 3 && breakdown.smc.down === 0;
  const isNoHTF = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  const isWeakIndicatorOpp = (breakdown.indicator.down - breakdown.indicator.up) <= 1;
  const isRetailSupporting = breakdown.retail.up >= 15 && breakdown.retail.up > breakdown.retail.down;

  if (isSMCPureUp && isNoHTF && isWeakIndicatorOpp && isRetailSupporting) {
    return {
      signal: "CALL",
      logic: "SMC Superiority: Pure 3-0 SMC dominates when HTF is absent, even if indicators show minor (4-3) opposition.",
      confidence: "93%",
      strategyName: "SMC Superiority",
      strategyNumber: 26
    };
  }
  return null;
}

// --- STRATEGY #27: THE CROWD & MOMENTUM SWEEP ---
function checkCrowdMomentumSweep(breakdown: CategoryBreakdown): StrategyResult | null {
  const isSMCTied = breakdown.smc.up === 1 && breakdown.smc.down === 1;
  const isRetailMassiveUp = breakdown.retail.up >= 20 && (breakdown.retail.up >= breakdown.retail.down * 4);
  const isIndicatorCleanUp = breakdown.indicator.up >= 3 && breakdown.indicator.down <= 1;
  const isWeakHTFOpposition = breakdown.htf.down === 1 && breakdown.htf.up === 0;

  if (isSMCTied && isRetailMassiveUp && isIndicatorCleanUp && isWeakHTFOpposition) {
    return {
      signal: "CALL",
      logic: "Crowd & Momentum Sweep: Massive retail volume (21) and clean indicators (3-1) overrode a single HTF DOWN anchor while SMC was neutral.",
      confidence: "91%",
      strategyName: "Crowd & Momentum Sweep",
      strategyNumber: 27
    };
  }
  return null;
}

// --- STRATEGY #28: THE ANTI-RETAIL MAGNET ---
function checkAntiRetailMagnet(breakdown: CategoryBreakdown): StrategyResult | null {
  const isRetailExtremelyDown = breakdown.retail.down >= 18 && (breakdown.retail.down >= breakdown.retail.up * 8);
  const isSMCSupportUp = breakdown.smc.up >= 1 && breakdown.smc.down === 0;
  const isTechnicalBiasUp = breakdown.liquidity.up > breakdown.liquidity.down && 
                            breakdown.indicator.up > breakdown.indicator.down;
  const isNoHTF = breakdown.htf.up === 0 && breakdown.htf.down === 0;

  if (isRetailExtremelyDown && isSMCSupportUp && isTechnicalBiasUp && isNoHTF) {
    return {
      signal: "CALL",
      logic: "Anti-Retail Magnet: Extreme retail imbalance (20:2) acting as liquidity for a reversal. Small SMC/Ind confirmation supports the UP move.",
      confidence: "97%",
      strategyName: "Anti-Retail Magnet",
      strategyNumber: 28
    };
  }
  return null;
}

// --- STRATEGY #29: THE LIQUIDITY VACUUM REVERSAL ---
function checkLiquidityVacuumReversal(breakdown: CategoryBreakdown): StrategyResult | null {
  const isLiquidityPureDown = breakdown.liquidity.down >= 2 && breakdown.liquidity.up === 0;
  const isRetailHeavilyUp = breakdown.retail.up >= 20 && (breakdown.retail.up >= breakdown.retail.down * 7);
  const isBullishMomentumModerate = (breakdown.indicator.up - breakdown.indicator.down) <= 3;
  const isSMCAloneUp = breakdown.smc.up >= 2 && breakdown.smc.down === 0;

  if (isLiquidityPureDown && isRetailHeavilyUp && isBullishMomentumModerate && isSMCAloneUp) {
    return {
      signal: "PUT",
      logic: "Liquidity Vacuum Reversal: Pure 2-0 Liquidity DOWN hunted the massive 22 retail buyers because bullish momentum was not strong enough (4-1).",
      confidence: "94%",
      strategyName: "Liquidity Vacuum Reversal",
      strategyNumber: 29
    };
  }
  return null;
}

// --- STRATEGY #30: THE OVERCROWDED INSTITUTIONAL TRAP ---
function checkOvercrowdedInstitutionalTrap(breakdown: CategoryBreakdown): StrategyResult | null {
  const isSMCPureDown = breakdown.smc.down >= 3 && breakdown.smc.up === 0;
  const isIndicatorPureDown = breakdown.indicator.down >= 4 && breakdown.indicator.up === 0;
  const isRetailMassiveDown = breakdown.retail.down >= 20 && (breakdown.retail.down >= breakdown.retail.up * 7);
  const isLiquidityNeutral = Math.abs(breakdown.liquidity.up - breakdown.liquidity.down) <= 1;
  const isNoHTF = breakdown.htf.up === 0 && breakdown.htf.down === 0;

  if (isSMCPureDown && isIndicatorPureDown && isRetailMassiveDown && isLiquidityNeutral && isNoHTF) {
    return {
      signal: "CALL",
      logic: "Overcrowded Institutional Trap: 21 Retail, 3 SMC, and 4 Indicators were all DOWN. Market reversed UP to trap the extreme mass consensus.",
      confidence: "98%",
      strategyName: "Overcrowded Institutional Trap",
      strategyNumber: 30
    };
  }
  return null;
}

// --- STRATEGY #31: THE OVERLOADED TREND COMPLETION ---
function checkOverloadedTrendCompletion(breakdown: CategoryBreakdown): StrategyResult | null {
  const isIndicatorPureDown = breakdown.indicator.down >= 4 && breakdown.indicator.up === 0;
  const isSMCDown = breakdown.smc.down >= 2;
  const isRetailMassiveDown = breakdown.retail.down >= 25;
  const isHTF_FakeOutUp = breakdown.htf.up === 1 && breakdown.htf.down === 0;

  if (isIndicatorPureDown && isSMCDown && isRetailMassiveDown && isHTF_FakeOutUp) {
    return {
      signal: "PUT",
      logic: "Overloaded Trend Completion: Pure 4-0 Indicators and SMC (2-1) crushed the lone HTF UP signal. Trend was too heavy to reverse.",
      confidence: "90%",
      strategyName: "Overloaded Trend Completion",
      strategyNumber: 31
    };
  }
  return null;
}

// --- STRATEGY #32: THE RETAIL LIQUIDATION SWEEP ---
function checkRetailLiquidationSweep(breakdown: CategoryBreakdown): StrategyResult | null {
  const isRetailHeavilyUp = breakdown.retail.up >= 15 && (breakdown.retail.up >= breakdown.retail.down * 5);
  const isMastersNeutral = breakdown.smc.up === breakdown.smc.down && 
                           breakdown.liquidity.up === breakdown.liquidity.down;
  const isBearishBias = breakdown.htf.down >= 1 && breakdown.indicator.down > breakdown.indicator.up;

  if (isRetailHeavilyUp && isMastersNeutral && isBearishBias) {
    return {
      signal: "PUT",
      logic: "Retail Liquidation Sweep: 17 Retail buyers trapped. Neutral masters allowed the HTF and Indicator (2-1) to pull the market DOWN for a liquidity hunt.",
      confidence: "95%",
      strategyName: "Retail Liquidation Sweep",
      strategyNumber: 32
    };
  }
  return null;
}

// --- STRATEGY #33: THE TREND AVALANCHE ---
function checkTrendAvalanche(breakdown: CategoryBreakdown): StrategyResult | null {
  const isIndicatorExtremeDown = breakdown.indicator.down >= 4 && breakdown.indicator.up === 0;
  const isLiquidityPureDown = breakdown.liquidity.down >= 1 && breakdown.liquidity.up === 0;
  const isHTF_PureDown = breakdown.htf.down >= 1 && breakdown.htf.up === 0;
  const isRetailOverloadedDown = breakdown.retail.down >= 30;
  const isSMCNotOpposing = breakdown.smc.up <= 1;

  if (isIndicatorExtremeDown && isLiquidityPureDown && isHTF_PureDown && isRetailOverloadedDown && isSMCNotOpposing) {
    return {
      signal: "PUT",
      logic: "Trend Avalanche: Absolute alignment of Ind (4-0), Liq (1-0), and HTF (1-0) crushed the 33 retail traders. Trend continuation is inevitable.",
      confidence: "98%",
      strategyName: "Trend Avalanche",
      strategyNumber: 33
    };
  }
  return null;
}

// --- STRATEGY #34: THE CAPTAIN & MAGNET TRAP ---
function checkCaptainMagnetTrap(breakdown: CategoryBreakdown): StrategyResult | null {
  const isLiquidityPureUp = breakdown.liquidity.up >= 1 && breakdown.liquidity.down === 0;
  const isHTFPureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isStrongBearishPressure = breakdown.indicator.down >= 4 && breakdown.smc.down >= 2;
  const isRetailTrappedDown = breakdown.retail.down >= 20 && breakdown.retail.down > breakdown.retail.up;

  if (isLiquidityPureUp && isHTFPureUp && isStrongBearishPressure && isRetailTrappedDown) {
    return {
      signal: "CALL",
      logic: "Captain & Magnet Trap: Pure HTF (1-0) and Pure Liquidity (1-0) united to reverse the 4-0 Indicator trend and trap 23 retail sellers.",
      confidence: "96%",
      strategyName: "Captain & Magnet Trap",
      strategyNumber: 34
    };
  }
  return null;
}

// --- STRATEGY #35: THE MOMENTUM THRESHOLD RULE ---
function checkMomentumThreshold(breakdown: CategoryBreakdown): StrategyResult | null {
  const isExtremeMomentumDown = breakdown.indicator.down >= 6 && breakdown.indicator.up === 0;
  const isSMCPureDown = breakdown.smc.down >= 3 && breakdown.smc.up === 0;
  const isRetailHeavilyDown = breakdown.retail.down >= 30;
  const oppositionStrength = breakdown.htf.up + breakdown.liquidity.up;

  if (isExtremeMomentumDown && isSMCPureDown && isRetailHeavilyDown && oppositionStrength <= 3) {
    return {
      signal: "PUT",
      logic: "Momentum Threshold: Extreme 6-0 Indicators and 3-0 SMC created an unstoppable trend, crushing the HTF and 2-0 Liquidity opposition.",
      confidence: "97%",
      strategyName: "Momentum Threshold Rule",
      strategyNumber: 35
    };
  }
  return null;
}

// --- STRATEGY #36: THE EXTREME CROWD SACRIFICE ---
function checkExtremeCrowdSacrifice(breakdown: CategoryBreakdown): StrategyResult | null {
  const isExtremeRetailUp = breakdown.retail.up >= 20 && breakdown.retail.down <= 2;
  const isLiquidityCrowdedUp = breakdown.liquidity.up >= 3 && breakdown.liquidity.down === 0;
  const isSMCOpposingDown = breakdown.smc.down >= 2;
  const isIndicatorNotStrongUp = breakdown.indicator.up <= 2;

  if (isExtremeRetailUp && isLiquidityCrowdedUp && isSMCOpposingDown && isIndicatorNotStrongUp) {
    return {
      signal: "PUT",
      logic: "Extreme Crowd Sacrifice: 21 Retail buyers made the 3-0 Liquidity magnet too expensive. Market followed 2-1 SMC Down to liquidate the crowd.",
      confidence: "96%",
      strategyName: "Extreme Crowd Sacrifice",
      strategyNumber: 36
    };
  }
  return null;
}

// --- STRATEGY #37: THE CAPTAIN'S IRON RULE ---
function checkCaptainsIronRule(breakdown: CategoryBreakdown): StrategyResult | null {
  const isHTFPureDown = breakdown.htf.down >= 1 && breakdown.htf.up === 0;
  const isSMCNeutral = breakdown.smc.up === breakdown.smc.down;
  const isLiquidityWeak = Math.abs(breakdown.liquidity.up - breakdown.liquidity.down) <= 1;
  const isIndicatorWeak = Math.abs(breakdown.indicator.up - breakdown.indicator.down) <= 1;
  const isRetailMassiveDown = breakdown.retail.down >= 20;

  if (isHTFPureDown && isSMCNeutral && isLiquidityWeak && isIndicatorWeak && isRetailMassiveDown) {
    return {
      signal: "PUT",
      logic: "Captain's Iron Rule: HTF (1-0) dominated because SMC was tied and other signals were too weak to form a trap. Trend continuation occurred.",
      confidence: "92%",
      strategyName: "Captain's Iron Rule",
      strategyNumber: 37
    };
  }
  return null;
}

// --- STRATEGY #38: THE CAPTAIN'S ENFORCEMENT ---
function checkCaptainsEnforcement(breakdown: CategoryBreakdown): StrategyResult | null {
  const isHTFPureDown = breakdown.htf.down >= 1 && breakdown.htf.up === 0;
  const isSMCLeaningDown = breakdown.smc.down >= 2 && breakdown.smc.up === 1;
  const isIndicatorTied = breakdown.indicator.up === breakdown.indicator.down;
  const isWeakMagnetUp = breakdown.liquidity.up === 1 && breakdown.liquidity.down === 0;
  const isRetailModerateDown = breakdown.retail.down >= 10 && breakdown.retail.down <= 15;

  if (isHTFPureDown && isSMCLeaningDown && isIndicatorTied && isWeakMagnetUp && isRetailModerateDown) {
    return {
      signal: "PUT",
      logic: "Captain's Enforcement: 1-0 HTF and 2-1 SMC enforced the trend. A weak 1-0 Liquidity UP magnet was too small to trap the moderate 13-3 crowd.",
      confidence: "91%",
      strategyName: "Captain's Enforcement",
      strategyNumber: 38
    };
  }
  return null;
}

// --- STRATEGY #39: THE EXTREME OVERLOAD TRAP ---
function checkExtremeOverloadTrap(breakdown: CategoryBreakdown): StrategyResult | null {
  const isSMCPureUp = breakdown.smc.up >= 3 && breakdown.smc.down === 0;
  const isIndicatorExtremeUp = breakdown.indicator.up >= 9;
  const isRetailCrowdedUp = breakdown.retail.up >= 25 && (breakdown.retail.up > breakdown.retail.down * 4);
  const isNoHTF = breakdown.htf.up === 0 && breakdown.htf.down === 0;

  if (isSMCPureUp && isIndicatorExtremeUp && isRetailCrowdedUp && isNoHTF) {
    return {
      signal: "PUT",
      logic: "Extreme Overload Trap: Setup was too perfect (SMC 3-0, Ind 9-1). Without HTF support, the 27 retail buyers became the target for a reversal.",
      confidence: "98%",
      strategyName: "Extreme Overload Trap",
      strategyNumber: 39
    };
  }
  return null;
}

// --- STRATEGY #40: THE ULTRA-MASSIVE PAYOUT TRAP ---
function checkUltraMassivePayoutTrap(breakdown: CategoryBreakdown): StrategyResult | null {
  const isUltraCrowdedDown = breakdown.retail.down >= 30;
  const isHTF_OpposingUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isStrongLiquidityUp = breakdown.liquidity.up >= 4 && (breakdown.liquidity.up > breakdown.liquidity.down);
  const isBearishBaitSet = breakdown.smc.down >= 3 && breakdown.indicator.down >= 6;

  if (isUltraCrowdedDown && isHTF_OpposingUp && isStrongLiquidityUp && isBearishBaitSet) {
    return {
      signal: "CALL",
      logic: "Ultra-Massive Payout Trap: 33 retail sellers and 6-1 indicators were used as bait. HTF (1-0) and Liquidity (4-2) triggered a 100% reversal.",
      confidence: "99%",
      strategyName: "Ultra-Massive Payout Trap",
      strategyNumber: 40
    };
  }
  return null;
}

// --- STRATEGY #41: THE PURE SMC ANCHOR ---
function checkPureSMCAnchor(breakdown: CategoryBreakdown): StrategyResult | null {
  const isSMCPureUp = breakdown.smc.up >= 2 && breakdown.smc.down === 0;
  const isWeakOpposition = breakdown.htf.down <= 1 && breakdown.liquidity.down <= 1;
  const isIndicatorModerateDown = breakdown.indicator.down <= 3;
  const isRetailModerateDown = breakdown.retail.down >= 10 && breakdown.retail.down <= 15;

  if (isSMCPureUp && isWeakOpposition && isIndicatorModerateDown && isRetailModerateDown) {
    return {
      signal: "CALL",
      logic: "Pure SMC Anchor: 2-0 SMC UP outperformed a lone HTF and weak Liquidity/Indicator pressure to follow institutional order flow.",
      confidence: "92%",
      strategyName: "Pure SMC Anchor",
      strategyNumber: 41
    };
  }
  return null;
}

// --- STRATEGY #42: THE CAPTAIN'S AUTHORITY (HTF LEAD) ---
function checkCaptainsAuthority(breakdown: CategoryBreakdown): StrategyResult | null {
  const isMastersTied = (breakdown.smc.up === breakdown.smc.down) && 
                        (breakdown.liquidity.up === breakdown.liquidity.down);
  const isHTFPureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isIndicatorWeak = Math.abs(breakdown.indicator.up - breakdown.indicator.down) <= 1;
  const isRetailUp = breakdown.retail.up >= 10;

  if (isMastersTied && isHTFPureUp && isIndicatorWeak && isRetailUp) {
    return {
      signal: "CALL",
      logic: "Captain's Authority: HTF (1-0) led the market because SMC and Liquidity were tied. Minor indicator opposition was ignored.",
      confidence: "93%",
      strategyName: "Captain's Authority",
      strategyNumber: 42
    };
  }
  return null;
}

// --- STRATEGY #43: THE ABSOLUTE ALIGNMENT ---
function checkAbsoluteAlignment(breakdown: CategoryBreakdown): StrategyResult | null {
  const isSMCPureUp = breakdown.smc.up >= 3 && breakdown.smc.down === 0;
  const isHealthyMomentumUp = breakdown.indicator.up >= 6 && breakdown.indicator.down === 0;
  const isLiquidityUp = breakdown.liquidity.up > breakdown.liquidity.down;
  const isNoHTF = breakdown.htf.up === 0 && breakdown.htf.down === 0;

  if (isSMCPureUp && isHealthyMomentumUp && isLiquidityUp && isNoHTF) {
    return {
      signal: "CALL",
      logic: "Absolute Alignment: Pure 3-0 SMC and Healthy 6-0 Indicators crushed the retail trap logic. Momentum was too strong to reverse.",
      confidence: "98%",
      strategyName: "Absolute Alignment",
      strategyNumber: 43
    };
  }
  return null;
}

// --- STRATEGY #44: THE ULTIMATE LIQUIDATION TRAP ---
function checkUltimateLiquidationTrap(breakdown: CategoryBreakdown): StrategyResult | null {
  const isExtremeRetailUp = breakdown.retail.up >= 25;
  const isHTF_PureDown = breakdown.htf.down >= 2 && breakdown.htf.up === 0;
  const isLiquidityPureDown = breakdown.liquidity.down >= 2 && breakdown.liquidity.up === 0;
  const isBullishBaitPresent = breakdown.indicator.up >= 5 && breakdown.smc.up >= 3;

  if (isExtremeRetailUp && isHTF_PureDown && isLiquidityPureDown && isBullishBaitPresent) {
    return {
      signal: "PUT",
      logic: "Ultimate Liquidation Trap: 2-0 HTF and 2-0 Liquidity united to hunt the massive 29 retail buyers, overriding the 5-1 Indicator momentum.",
      confidence: "98%",
      strategyName: "Ultimate Liquidation Trap",
      strategyNumber: 44
    };
  }
  return null;
}

// --- STRATEGY #45: THE CAPTAIN VS. MAGNET RULE ---
function checkCaptainVsMagnet(breakdown: CategoryBreakdown): StrategyResult | null {
  const isHTFPureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isStrongLiquidityDown = breakdown.liquidity.down >= 2 && breakdown.liquidity.up === 0;
  const isSMCTied = breakdown.smc.up === breakdown.smc.down;
  const isIndicatorSlightUp = breakdown.indicator.up > breakdown.indicator.down;
  const isRetailFollowingMagnet = breakdown.retail.down > breakdown.retail.up;

  if (isHTFPureUp && isStrongLiquidityDown && isSMCTied && isIndicatorSlightUp && isRetailFollowingMagnet) {
    return {
      signal: "CALL",
      logic: "Captain vs Magnet: Pure HTF (1-0) and 3-2 Indicators defeated the 0-2 Liquidity magnet because the crowd (8 sellers) was on the magnet's side.",
      confidence: "93%",
      strategyName: "Captain vs Magnet Rule",
      strategyNumber: 45
    };
  }
  return null;
}

// --- STRATEGY #46: THE INSTITUTIONAL STEAMROLLER ---
function checkInstitutionalSteamroller(breakdown: CategoryBreakdown): StrategyResult | null {
  const isSMCExtremeUp = breakdown.smc.up >= 4 && breakdown.smc.down === 0;
  const isIndicatorPureUp = breakdown.indicator.up >= 4 && breakdown.indicator.down === 0;
  const isHTFWeakOpp = breakdown.htf.down === 1 && breakdown.htf.up === 0;
  const isLiquidityNeutral = Math.abs(breakdown.liquidity.up - breakdown.liquidity.down) <= 1;

  if (isSMCExtremeUp && isIndicatorPureUp && isHTFWeakOpp && isLiquidityNeutral) {
    return {
      signal: "CALL",
      logic: "Institutional Steamroller: 4-0 SMC and 4-0 Indicators created unstoppable force. Lone HTF (1-0) was too weak to cause a reversal.",
      confidence: "97%",
      strategyName: "Institutional Steamroller",
      strategyNumber: 46
    };
  }
  return null;
}

// --- STRATEGY #47: THE CROWD MOMENTUM SURGE ---
function checkCrowdMomentumSurge(breakdown: CategoryBreakdown): StrategyResult | null {
  const isMassiveCrowdUp = breakdown.retail.up >= 30;
  const isStrongIndicatorUp = (breakdown.indicator.up >= 4) && (breakdown.indicator.up >= breakdown.indicator.down * 2);
  const isSMCLeaningUp = breakdown.smc.up >= 2 && breakdown.smc.up > breakdown.smc.down;
  const isNoHTF = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  const isLiquidityNeutral = breakdown.liquidity.up === breakdown.liquidity.down;

  if (isMassiveCrowdUp && isStrongIndicatorUp && isSMCLeaningUp && isNoHTF && isLiquidityNeutral) {
    return {
      signal: "CALL",
      logic: "Crowd Momentum Surge: 30 retail buyers were supported by 4-2 Indicators and 2-1 SMC. Without HTF opposition, the crowd surge carried the trend.",
      confidence: "94%",
      strategyName: "Crowd Momentum Surge",
      strategyNumber: 47
    };
  }
  return null;
}

// --- STRATEGY #48: THE TRIPLE MASTER MAGNET TRAP ---
function checkTripleMasterMagnetTrap(breakdown: CategoryBreakdown): StrategyResult | null {
  const isRetailHeavilyDown = breakdown.retail.down >= 20 && breakdown.retail.up <= 2;
  const isLiquidityPureUp = breakdown.liquidity.up >= 3 && breakdown.liquidity.down === 0;
  const isHTFPureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isMastersNotOpposing = breakdown.smc.down <= 1 && breakdown.indicator.down <= 2;

  if (isRetailHeavilyDown && isLiquidityPureUp && isHTFPureUp && isMastersNotOpposing) {
    return {
      signal: "CALL",
      logic: "Triple Master Magnet: 21 sellers trapped. Pure 3-0 Liquidity and 1-0 HTF acted as an unstoppable pull UP.",
      confidence: "99%",
      strategyName: "Triple Master Magnet Trap",
      strategyNumber: 48
    };
  }
  return null;
}

// --- STRATEGY #49: THE CAPTAIN'S VETO ---
function checkCaptainsVeto(breakdown: CategoryBreakdown): StrategyResult | null {
  const isHTFPureDown = breakdown.htf.down >= 1 && breakdown.htf.up === 0;
  const isIndicatorDown = breakdown.indicator.down > breakdown.indicator.up;
  const isBullishBaitPresent = breakdown.smc.up >= 2 && breakdown.liquidity.up >= 1;
  const isCrowdWithCaptain = breakdown.retail.down >= 20;

  if (isHTFPureDown && isIndicatorDown && isBullishBaitPresent && isCrowdWithCaptain) {
    return {
      signal: "PUT",
      logic: "Captain's Veto: 1-0 HTF and 2-1 Indicators overruled the 2-0 SMC 'Bait'. The market followed the captain despite the massive crowd.",
      confidence: "89%",
      strategyName: "Captain's Veto",
      strategyNumber: 49
    };
  }
  return null;
}

// --- STRATEGY #50: THE MOMENTUM CRUSH (GOLDEN MILESTONE) ---
function checkMomentumCrush(breakdown: CategoryBreakdown): StrategyResult | null {
  const bearishTechPower = breakdown.smc.down + breakdown.indicator.down;
  const bullishMasterPower = breakdown.htf.up + breakdown.liquidity.up;
  const isCrowdHeavyDown = breakdown.retail.down >= 20 && breakdown.retail.down < 30;

  if (bearishTechPower > bullishMasterPower && isCrowdHeavyDown && breakdown.htf.up === 1) {
    return {
      signal: "PUT",
      logic: "Momentum Crush: Bearish Tech Power (4 points) crushed the Bullish Master Power (3 points). The 22-person crowd was not extreme enough to force a reversal.",
      confidence: "91%",
      strategyName: "Momentum Crush",
      strategyNumber: 50
    };
  }
  return null;
}

// === MASTER STRATEGY FILTER ===
// This is the main function that checks ALL 100 strategies in priority order
// Returns the matching strategy result or null if no match found

export function runScenarioFilter(breakdown: CategoryBreakdown): StrategyResult | null {
  // Priority order of original 50 strategies (highest confidence first)
  const originalStrategies = [
    // 99% Confidence
    checkConsensusSurge,           // #7 - 99%
    checkUnstoppableAnchor,        // #16 - 99%
    checkAbsoluteTrendContinuation, // #24 - 99%
    checkHTFTrendTrap,             // #11 - 99%
    checkUltraMassivePayoutTrap,   // #40 - 99%
    checkTripleMasterMagnetTrap,   // #48 - 99%
    
    // 98% Confidence
    getWhaleSignal,                // #1 - 98%
    checkHarmonyStrategy,          // #3 - 98%
    checkExtremistTrap,            // #13 - 98%
    checkMultiLayerLiquidation,    // #14 - 98%
    checkOvercrowdedInstitutionalTrap, // #30 - 98%
    checkTrendAvalanche,           // #33 - 98%
    checkExtremeOverloadTrap,      // #39 - 98%
    checkAbsoluteAlignment,        // #43 - 98%
    checkUltimateLiquidationTrap,  // #44 - 98%
    
    // 97% Confidence
    checkBalancedFlow,             // #12 - 97%
    checkTripleAnchorForce,        // #10 - 97%
    checkAntiRetailMagnet,         // #28 - 97%
    checkMomentumThreshold,        // #35 - 97%
    checkInstitutionalSteamroller, // #46 - 97%
    
    // 96% Confidence
    checkMasterVeto,               // #18 - 96%
    checkLiquidityVacuum,          // #22 - 96%
    checkCaptainMagnetTrap,        // #34 - 96%
    checkExtremeCrowdSacrifice,    // #36 - 96%
    
    // 95% Confidence
    checkWeightedDomination,       // #9 - 95%
    checkSynergyOverpower,         // #15 - 95%
    checkOvercrowdedTrap,          // #20 - 95%
    checkRetailLiquidationSweep,   // #32 - 95%
    checkMomentumOverpower,        // #25 - 95%
    checkEquilibriumTrap,          // #4 - 95%
    
    // 94% Confidence
    checkHTFAnchorStrategy,        // #5 - 94%
    checkLiquidityVeto,            // #17 - 94%
    checkRetailLiquidityFlush,     // #23 - 94%
    checkLiquidityVacuumReversal,  // #29 - 94%
    checkCrowdMomentumSurge,       // #47 - 94%
    
    // 93% Confidence
    getDominationSignal,           // #2 - 93%
    checkCrowdWashout,             // #8 - 93%
    checkIndicatorOverload,        // #19 - 93%
    checkSMCSuperiority,           // #26 - 93%
    checkCaptainsAuthority,        // #42 - 93%
    checkCaptainVsMagnet,          // #45 - 93%
    
    // 92% Confidence
    checkAnchorMagnetStrategy,     // #6 - 92%
    checkHTFSupremacy,             // #21 - 92%
    checkCaptainsIronRule,         // #37 - 92%
    checkPureSMCAnchor,            // #41 - 92%
    
    // 91% Confidence
    checkCrowdMomentumSweep,       // #27 - 91%
    checkCaptainsEnforcement,      // #38 - 91%
    checkMomentumCrush,            // #50 - 91%
    
    // 90% Confidence
    checkOverloadedTrendCompletion, // #31 - 90%
    
    // 89% Confidence
    checkCaptainsVeto              // #49 - 89%
  ];

  // Combine original 50 strategies with extended strategies (#51-100)
  const allStrategies = [...originalStrategies, ...extendedStrategies];
  
  // Run each strategy in order until one matches
  for (const strategy of allStrategies) {
    const result = strategy(breakdown);
    if (result) {
      return result;
    }
  }

  // No scenario matched - return null (standard priority will be used)
  return null;
}

// === COMBINED STRATEGY LIST FOR REFERENCE (1-100) ===
export const STRATEGY_DATABASE = [
  // Original 50 strategies
  { number: 1, name: "Whale vs Crowd", confidence: "98%" },
  { number: 2, name: "Domination Party", confidence: "93%" },
  { number: 3, name: "Master-Crowd Harmony", confidence: "98%" },
  { number: 4, name: "Equilibrium Trap", confidence: "95%" },
  { number: 5, name: "HTF Anchor Override", confidence: "94%" },
  { number: 6, name: "Pure Anchor Magnet", confidence: "92%" },
  { number: 7, name: "Consensus Surge", confidence: "99%" },
  { number: 8, name: "Crowd Washout", confidence: "93%" },
  { number: 9, name: "Weighted Domination", confidence: "95%" },
  { number: 10, name: "Triple Anchor Force", confidence: "97%" },
  { number: 11, name: "HTF Trend Trap", confidence: "99%" },
  { number: 12, name: "Balanced Flow", confidence: "97%" },
  { number: 13, name: "Extremist Trap", confidence: "98%" },
  { number: 14, name: "Multi-Layer Liquidation", confidence: "98%" },
  { number: 15, name: "Synergy Overpower", confidence: "95%" },
  { number: 16, name: "Unstoppable Anchor Synergy", confidence: "99%" },
  { number: 17, name: "Liquidity Veto", confidence: "94%" },
  { number: 18, name: "Master Veto", confidence: "96%" },
  { number: 19, name: "Indicator Overload Trap", confidence: "93%" },
  { number: 20, name: "Overcrowded Magnet Trap", confidence: "95%" },
  { number: 21, name: "HTF Supremacy", confidence: "92%" },
  { number: 22, name: "Liquidity Vacuum Trap", confidence: "96%" },
  { number: 23, name: "Retail Liquidity Flush", confidence: "94%" },
  { number: 24, name: "Absolute Trend Continuation", confidence: "99%" },
  { number: 25, name: "Momentum Overpower", confidence: "95%" },
  { number: 26, name: "SMC Superiority", confidence: "93%" },
  { number: 27, name: "Crowd & Momentum Sweep", confidence: "91%" },
  { number: 28, name: "Anti-Retail Magnet", confidence: "97%" },
  { number: 29, name: "Liquidity Vacuum Reversal", confidence: "94%" },
  { number: 30, name: "Overcrowded Institutional Trap", confidence: "98%" },
  { number: 31, name: "Overloaded Trend Completion", confidence: "90%" },
  { number: 32, name: "Retail Liquidation Sweep", confidence: "95%" },
  { number: 33, name: "Trend Avalanche", confidence: "98%" },
  { number: 34, name: "Captain & Magnet Trap", confidence: "96%" },
  { number: 35, name: "Momentum Threshold Rule", confidence: "97%" },
  { number: 36, name: "Extreme Crowd Sacrifice", confidence: "96%" },
  { number: 37, name: "Captain's Iron Rule", confidence: "92%" },
  { number: 38, name: "Captain's Enforcement", confidence: "91%" },
  { number: 39, name: "Extreme Overload Trap", confidence: "98%" },
  { number: 40, name: "Ultra-Massive Payout Trap", confidence: "99%" },
  { number: 41, name: "Pure SMC Anchor", confidence: "92%" },
  { number: 42, name: "Captain's Authority", confidence: "93%" },
  { number: 43, name: "Absolute Alignment", confidence: "98%" },
  { number: 44, name: "Ultimate Liquidation Trap", confidence: "98%" },
  { number: 45, name: "Captain vs Magnet Rule", confidence: "93%" },
  { number: 46, name: "Institutional Steamroller", confidence: "97%" },
  { number: 47, name: "Crowd Momentum Surge", confidence: "94%" },
  { number: 48, name: "Triple Master Magnet Trap", confidence: "99%" },
  { number: 49, name: "Captain's Veto", confidence: "89%" },
  { number: 50, name: "Momentum Crush", confidence: "91%" },
  // Extended 50 strategies (#51-100)
  ...EXTENDED_STRATEGY_DATABASE
];
