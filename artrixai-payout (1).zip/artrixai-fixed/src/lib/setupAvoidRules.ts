// =============================================================================
// UNIVERSAL OTC ALGORITHMIC SYSTEM: 235 SETUP AVOID RULES DATABASE
// =============================================================================
// Each setup has specific AVOID conditions that filter out weak/trap signals.
// Global filters (like Salami Trend) apply across all setups.
// =============================================================================

export interface AvoidRule {
  id: string;
  setupNumber: number;
  signal: 'CALL' | 'PUT';
  trapReference: string;
  setupName: string;
  avoidConditions: string[];
  triggerLogic: string;
}

// 💡 GLOBAL FILTER: Salami Trend Rule
// Stops all reversal trades if 8-10 tiny candles move in one direction.
export const GLOBAL_SALAMI_TREND_FILTER = {
  description: "Salami Trend Rule - Filter all reversals if 8-10 tiny candles move in one direction",
  candleCount: 10,
  applies: "ALL_REVERSALS"
};

// =============================================================================
// PART 1: SETUPS 1-20
// =============================================================================

export const AVOID_RULES_1_TO_20: AvoidRule[] = [
  {
    id: "SETUP_1",
    setupNumber: 1,
    signal: "CALL",
    trapReference: "Trap 12",
    setupName: "HTF Demand + Hammer",
    avoidConditions: [
      "EMA20 is flat (less than 20° angle) - Hammer needs a trend"
    ],
    triggerLogic: "Candle low < demand level AND close > demand level"
  },
  {
    id: "SETUP_2",
    setupNumber: 2,
    signal: "CALL",
    trapReference: "Trap 2",
    setupName: "HTF Demand + Engulfing",
    avoidConditions: [
      "Engulfing candle is > 3x larger than previous (Exhaustion signal)"
    ],
    triggerLogic: "Close > broken level with bullish engulfing at demand"
  },
  {
    id: "SETUP_3",
    setupNumber: 3,
    signal: "CALL",
    trapReference: "Trap 19",
    setupName: "Morning Star @ HTF",
    avoidConditions: [
      "Middle candle is a huge Doji with long wicks on both sides"
    ],
    triggerLogic: "Morning star pattern with 30s reset entry timing"
  },
  {
    id: "SETUP_4",
    setupNumber: 4,
    signal: "CALL",
    trapReference: "Trap 24",
    setupName: "Sweep Low + Tweezer",
    avoidConditions: [
      "Market already formed 5-6 same color candles (Overextended)"
    ],
    triggerLogic: "Liquidity sweep low within 0.0002 of .000 round number"
  },
  {
    id: "SETUP_5",
    setupNumber: 5,
    signal: "CALL",
    trapReference: "Trap 6",
    setupName: "1M FVG Tap + Engulfing",
    avoidConditions: [
      "Candle body closes fully inside/below the 50% FVG mark"
    ],
    triggerLogic: "Close > FVG midpoint with low touching 50% level"
  },
  {
    id: "SETUP_6",
    setupNumber: 6,
    signal: "CALL",
    trapReference: "Trap 22",
    setupName: "EMA20 + Hammer",
    avoidConditions: [
      "EMAs are not parallel (Choppy market indicator)"
    ],
    triggerLogic: "Hammer at EMA20 with low touching EMA13"
  },
  {
    id: "SETUP_7",
    setupNumber: 7,
    signal: "CALL",
    trapReference: "Trap 14",
    setupName: "EMA50 + Engulfing",
    avoidConditions: [
      "Engulfing is 3x larger than average tiny candles"
    ],
    triggerLogic: "Bullish engulfing at EMA50 level"
  },
  {
    id: "SETUP_8",
    setupNumber: 8,
    signal: "CALL",
    trapReference: "Trap 25",
    setupName: "EMA200 + Engulfing",
    avoidConditions: [],
    triggerLogic: "Bullish engulfing at EMA200 on :00 or :30 minute mark"
  },
  {
    id: "SETUP_9",
    setupNumber: 9,
    signal: "CALL",
    trapReference: "Trap 9",
    setupName: "VWAP + Engulfing",
    avoidConditions: [
      "Volume is lower than previous while body is bigger (Anomaly)"
    ],
    triggerLogic: "Bullish engulfing at VWAP with volume confirmation"
  },
  {
    id: "SETUP_10",
    setupNumber: 10,
    signal: "CALL",
    trapReference: "Trap 11",
    setupName: "BB Lower + Hammer",
    avoidConditions: [
      "BB is expanding rapidly (Mouth Open = Strong Breakout)"
    ],
    triggerLogic: "Hammer fully outside lower BB"
  },
  {
    id: "SETUP_11",
    setupNumber: 11,
    signal: "CALL",
    trapReference: "Trap 10",
    setupName: "RSI <20 + Support",
    avoidConditions: [
      "RSI is 'Flat' (market has zero bounce intent)"
    ],
    triggerLogic: "RSI oversold with EMA9 touching candle body"
  },
  {
    id: "SETUP_12",
    setupNumber: 12,
    signal: "CALL",
    trapReference: "Trap 21",
    setupName: "Stochastic + Bullish",
    avoidConditions: [],
    triggerLogic: "Stochastic K < 20 with 3 Dojis near bottom before breakout"
  },
  {
    id: "SETUP_13",
    setupNumber: 13,
    signal: "CALL",
    trapReference: "Trap 4",
    setupName: "ADX 25-35 + Continue",
    avoidConditions: [
      "Round Number (.000) is within 1-2 pips ahead"
    ],
    triggerLogic: "ADX in trend zone with 3 consecutive bullish candles"
  },
  {
    id: "SETUP_14",
    setupNumber: 14,
    signal: "CALL",
    trapReference: "Trap 27",
    setupName: "OBV Rising + Engulfing",
    avoidConditions: [],
    triggerLogic: "OBV rising with volume spike matching body expansion"
  },
  {
    id: "SETUP_15",
    setupNumber: 15,
    signal: "CALL",
    trapReference: "Trap 5",
    setupName: "MFI Oversold + Hammer",
    avoidConditions: [],
    triggerLogic: "MFI < 20 with hammer near .500 round number"
  },
  {
    id: "SETUP_16",
    setupNumber: 16,
    signal: "CALL",
    trapReference: "Trap 18",
    setupName: "Inside 3 Up @ Demand",
    avoidConditions: [],
    triggerLogic: "Inside three up pattern at demand with RRR sequence"
  },
  {
    id: "SETUP_17",
    setupNumber: 17,
    signal: "CALL",
    trapReference: "Trap 13",
    setupName: "3 Soldiers @ Sweep",
    avoidConditions: [
      "Any candle is too close to a .000 resistance"
    ],
    triggerLogic: "Three white soldiers with proper close structure"
  },
  {
    id: "SETUP_18",
    setupNumber: 18,
    signal: "CALL",
    trapReference: "Trap 1",
    setupName: "Marubozu + Pullback",
    avoidConditions: [
      "Retrace doesn't happen within the 30s reset window"
    ],
    triggerLogic: "Bullish marubozu with bearish pullback to 60% wick level"
  },
  {
    id: "SETUP_19",
    setupNumber: 19,
    signal: "CALL",
    trapReference: "Trap 21",
    setupName: "Rising 3 Methods",
    avoidConditions: [],
    triggerLogic: "Rising three methods with stagnant volume on green candles"
  },
  {
    id: "SETUP_20",
    setupNumber: 20,
    signal: "CALL",
    trapReference: "Trap 17",
    setupName: "PSAR Flip + Bullish",
    avoidConditions: [
      "Gap UP is more than 3-4 pixels (Algo bypass)"
    ],
    triggerLogic: "PSAR flip up with 1-2 pixel gap confirmation"
  }
];

// =============================================================================
// PART 2: SETUPS 21-40
// =============================================================================

export const AVOID_RULES_21_TO_40: AvoidRule[] = [
  {
    id: "SETUP_21",
    setupNumber: 21,
    signal: "CALL",
    trapReference: "Trap 20",
    setupName: "VWAP + EMA20",
    avoidConditions: [
      "Large Gap Up/Down at the EMA touch point"
    ],
    triggerLogic: "VWAP and EMA20 confluence with tight touch"
  },
  {
    id: "SETUP_22",
    setupNumber: 22,
    signal: "CALL",
    trapReference: "Trap 26",
    setupName: "Range Low + Hammer",
    avoidConditions: [
      "Range is too narrow (under 4 pips) - just 'Chop'"
    ],
    triggerLogic: "Hammer at range low with sweep and reclaim"
  },
  {
    id: "SETUP_23",
    setupNumber: 23,
    signal: "CALL",
    trapReference: "Trap 6",
    setupName: "FVG + EMA20",
    avoidConditions: [
      "Candle body closes fully below the FVG 50% zone"
    ],
    triggerLogic: "FVG present with EMA20 touch and 50% rejection"
  },
  {
    id: "SETUP_24",
    setupNumber: 24,
    signal: "CALL",
    trapReference: "Trap 16",
    setupName: "StdDev Expansion",
    avoidConditions: [
      "Expansion spike is 5x the average body size (Exhaustion)"
    ],
    triggerLogic: "Standard deviation expansion with 4 aligned bullish candles"
  },
  {
    id: "SETUP_25",
    setupNumber: 25,
    signal: "CALL",
    trapReference: "Trap 15",
    setupName: "HTF Range Floor",
    avoidConditions: [
      "Range switch sequence is too fast (needs clear G-R alternation)"
    ],
    triggerLogic: "HTF range floor with 5 color switches"
  },
  {
    id: "SETUP_26",
    setupNumber: 26,
    signal: "PUT",
    trapReference: "Trap 12",
    setupName: "Supply OB + Shooting Star",
    avoidConditions: [
      "EMA20 is flat (Market needs at least 20° downward angle)"
    ],
    triggerLogic: "Shooting star at supply with high > resistance and close < resistance"
  },
  {
    id: "SETUP_27",
    setupNumber: 27,
    signal: "PUT",
    trapReference: "Trap 19",
    setupName: "Evening Star @ HTF",
    avoidConditions: [
      "Star (2nd candle) is a large Doji with long wicks"
    ],
    triggerLogic: "Evening star at BB upper with round number confluence"
  },
  {
    id: "SETUP_28",
    setupNumber: 28,
    signal: "PUT",
    trapReference: "Trap 2",
    setupName: "Bearish Engulfing",
    avoidConditions: [
      "Engulfing body is 3x larger than previous (Exhaustion)"
    ],
    triggerLogic: "Bearish engulfing with high > resistance and close < resistance"
  },
  {
    id: "SETUP_29",
    setupNumber: 29,
    signal: "PUT",
    trapReference: "Trap 24",
    setupName: "Sweep High + Tweezer",
    avoidConditions: [
      "Market formed 5-6 same color candles before the tweezer"
    ],
    triggerLogic: "Liquidity sweep high with tweezer top at .000 level"
  },
  {
    id: "SETUP_30",
    setupNumber: 30,
    signal: "PUT",
    trapReference: "Trap 6",
    setupName: "FVG Tap + Engulfing",
    avoidConditions: [
      "Body closes fully above the 50% FVG midline"
    ],
    triggerLogic: "FVG tap with bearish engulfing closing below 50%"
  },
  {
    id: "SETUP_31",
    setupNumber: 31,
    signal: "PUT",
    trapReference: "Trap 1",
    setupName: "EMA20 + Shooting Star",
    avoidConditions: [
      "EMA20 must be trending downward at >= 20°"
    ],
    triggerLogic: "Shooting star at EMA20 with upper wick > 60% of body"
  },
  {
    id: "SETUP_32",
    setupNumber: 32,
    signal: "PUT",
    trapReference: "Trap 14",
    setupName: "EMA50 + Engulfing",
    avoidConditions: [
      "Engulfing body size is > 3x average tiny candles"
    ],
    triggerLogic: "Bearish engulfing at EMA50 with liquidity void below"
  },
  {
    id: "SETUP_33",
    setupNumber: 33,
    signal: "PUT",
    trapReference: "Trap 25",
    setupName: "EMA200 + Engulfing",
    avoidConditions: [],
    triggerLogic: "Bearish engulfing at EMA200 on first candle of 15-min block"
  },
  {
    id: "SETUP_34",
    setupNumber: 34,
    signal: "PUT",
    trapReference: "Trap 9",
    setupName: "VWAP + Engulfing",
    avoidConditions: [
      "Volume is lower than previous while body is bigger (Anomaly)"
    ],
    triggerLogic: "Bearish engulfing at VWAP with volume confirmation"
  },
  {
    id: "SETUP_35",
    setupNumber: 35,
    signal: "PUT",
    trapReference: "Trap 11",
    setupName: "BB Upper + Star",
    avoidConditions: [
      "BB Bands are 'Mouth Open' (Expanding rapidly)"
    ],
    triggerLogic: "Shooting star fully outside upper BB"
  },
  {
    id: "SETUP_36",
    setupNumber: 36,
    signal: "PUT",
    trapReference: "Trap 10",
    setupName: "RSI >80 + Resistance",
    avoidConditions: [
      "RSI is 'Flat' (market has zero intention to reverse)"
    ],
    triggerLogic: "RSI overbought at resistance with EMA9 confirmation"
  },
  {
    id: "SETUP_38",
    setupNumber: 38,
    signal: "PUT",
    trapReference: "Trap 4",
    setupName: "ADX 25-35 + Continue",
    avoidConditions: [
      "Round Number (.000) is immediately ahead"
    ],
    triggerLogic: "ADX in trend zone with 4 consecutive bearish candles"
  },
  {
    id: "SETUP_39",
    setupNumber: 39,
    signal: "PUT",
    trapReference: "Trap 27",
    setupName: "OBV Falling + Engulfing",
    avoidConditions: [
      "Candle is a small Spinning Top (needs higher confirmation)"
    ],
    triggerLogic: "OBV falling with bearish engulfing and volume divergence"
  },
  {
    id: "SETUP_40",
    setupNumber: 40,
    signal: "PUT",
    trapReference: "Trap 5",
    setupName: "MFI Overbought + Star",
    avoidConditions: [
      "Wick pierces the round number significantly (Liquidity Grab)"
    ],
    triggerLogic: "MFI > 80 with shooting star near .500 level"
  }
];

// =============================================================================
// PART 3: SETUPS 41-60
// =============================================================================

export const AVOID_RULES_41_TO_60: AvoidRule[] = [
  {
    id: "SETUP_41",
    setupNumber: 41,
    signal: "PUT",
    trapReference: "Trap 18",
    setupName: "Inside 3 Down @ Supply",
    avoidConditions: [
      "Previous rhythm was already bearish (No trap to spring)"
    ],
    triggerLogic: "Inside three down at supply with GGR sequence"
  },
  {
    id: "SETUP_42",
    setupNumber: 42,
    signal: "PUT",
    trapReference: "Trap 13",
    setupName: "3 Crows After Sweep",
    avoidConditions: [
      "Round Number (.000) is within 1-2 pips ahead"
    ],
    triggerLogic: "Three black crows with proper close structure"
  },
  {
    id: "SETUP_43",
    setupNumber: 43,
    signal: "PUT",
    trapReference: "Trap 1",
    setupName: "Marubozu + Pullback",
    avoidConditions: [
      "Pullback takes longer than 30 seconds to reach the 60% mark"
    ],
    triggerLogic: "Bearish marubozu with bullish pullback to 60% wick level"
  },
  {
    id: "SETUP_44",
    setupNumber: 44,
    signal: "PUT",
    trapReference: "Trap 21",
    setupName: "Falling 3 Methods",
    avoidConditions: [
      "Volume increases on the small green candles (Buying pressure)"
    ],
    triggerLogic: "Falling three methods away from .000 round number"
  },
  {
    id: "SETUP_45",
    setupNumber: 45,
    signal: "PUT",
    trapReference: "Trap 17",
    setupName: "PSAR Flip + Bearish",
    avoidConditions: [
      "Gap DOWN is more than 3-4 pixels (Abnormal volatility)"
    ],
    triggerLogic: "PSAR flip down with 1-2 pixel gap and gap-down open"
  },
  {
    id: "SETUP_46",
    setupNumber: 46,
    signal: "PUT",
    trapReference: "Trap 20",
    setupName: "VWAP + EMA20",
    avoidConditions: [
      "Volume-Price Anomaly (Volume is high but body is small = Absorption)"
    ],
    triggerLogic: "VWAP and EMA20 confluence with bearish close"
  },
  {
    id: "SETUP_47",
    setupNumber: 47,
    signal: "PUT",
    trapReference: "Trap 23",
    setupName: "Liquidity Grab @ High",
    avoidConditions: [
      "Wick pierces the .000 level too deeply without immediate rejection"
    ],
    triggerLogic: "Liquidity grab above session high"
  },
  {
    id: "SETUP_48",
    setupNumber: 48,
    signal: "PUT",
    trapReference: "Trap 6",
    setupName: "FVG + EMA20",
    avoidConditions: [
      "Candle body closes above the 50% Fair Value mark"
    ],
    triggerLogic: "FVG with EMA20 touch, high >= 50% and close < 50%"
  },
  {
    id: "SETUP_49",
    setupNumber: 49,
    signal: "PUT",
    trapReference: "Trap 16",
    setupName: "StdDev Expansion",
    avoidConditions: [
      "Exhaustion Check: 'Godzilla' candle is 5x larger than average"
    ],
    triggerLogic: "StdDev expansion with body >= 2x average"
  },
  {
    id: "SETUP_50",
    setupNumber: 50,
    signal: "PUT",
    trapReference: "Trap 15",
    setupName: "HTF Range High",
    avoidConditions: [
      "Range width is less than 4 pips (Chop zone)"
    ],
    triggerLogic: "HTF range high with 5 color switches"
  },
  {
    id: "SETUP_51",
    setupNumber: 51,
    signal: "CALL",
    trapReference: "Trap 6: Hammer Fail",
    setupName: "HTF Demand + Inverted Hammer",
    avoidConditions: [
      "Upper wick is shorter than the body (Weak rejection)"
    ],
    triggerLogic: "Inverted hammer at demand with next open >= close"
  },
  {
    id: "SETUP_52",
    setupNumber: 52,
    signal: "CALL",
    trapReference: "Trap 6: Symmetrizer",
    setupName: "FVG + Morning Star Combo",
    avoidConditions: [],
    triggerLogic: "Morning star at FVG with high precision 50% midline touch"
  },
  {
    id: "SETUP_53",
    setupNumber: 53,
    signal: "CALL",
    trapReference: "Trap 22",
    setupName: "EMA20 + EMA50 Support",
    avoidConditions: [
      "Large gap at the EMA touch"
    ],
    triggerLogic: "EMA20/50 confluence with parallel EMAs and low touch"
  },
  {
    id: "SETUP_54",
    setupNumber: 54,
    signal: "CALL",
    trapReference: "Trap 11",
    setupName: "VWAP + BB Lower",
    avoidConditions: [
      "Gap between VWAP and BB Lower is too high (>10 pips)"
    ],
    triggerLogic: "VWAP and BB lower confluence without BB expansion"
  },
  {
    id: "SETUP_55",
    setupNumber: 55,
    signal: "CALL",
    trapReference: "Trap 2",
    setupName: "Liquidity Sweep + Marubozu",
    avoidConditions: [
      "Marubozu body size is > 3x average (Potential exhaustion)"
    ],
    triggerLogic: "Bullish marubozu closing above previous fake break low"
  },
  {
    id: "SETUP_56",
    setupNumber: 56,
    signal: "CALL",
    trapReference: "Trap 10",
    setupName: "RSI Divergence + Hammer",
    avoidConditions: [
      "Deep Pierce: Wick goes too far below .000 level"
    ],
    triggerLogic: "RSI bullish divergence with hammer at .000 round number"
  },
  {
    id: "SETUP_57",
    setupNumber: 57,
    signal: "CALL",
    trapReference: "Trap 21",
    setupName: "Stochastic Reset + Engulfing",
    avoidConditions: [
      "All 3 micro-candles are the same color (Must be R-G-R mix)"
    ],
    triggerLogic: "Stochastic < 20 with micro-candle compression before engulfing"
  },
  {
    id: "SETUP_58",
    setupNumber: 58,
    signal: "CALL",
    trapReference: "Trap 14",
    setupName: "ADX Rising + Bullish Break",
    avoidConditions: [
      "Breakout candle is 5x larger than avg tiny candles"
    ],
    triggerLogic: "ADX rising with breakout body >= 2x previous"
  },
  {
    id: "SETUP_59",
    setupNumber: 59,
    signal: "CALL",
    trapReference: "Trap 27",
    setupName: "OBV Breakout + Engulfing",
    avoidConditions: [
      "Bull Trap check: Price closes below resistance level"
    ],
    triggerLogic: "OBV breakout with bullish engulfing closing above resistance"
  },
  {
    id: "SETUP_60",
    setupNumber: 60,
    signal: "CALL",
    trapReference: "Trap 5",
    setupName: "MFI Rising + Demand",
    avoidConditions: [
      "Wick pierces round number significantly (.000 or .500)"
    ],
    triggerLogic: "MFI rising at demand approaching .000 or .500"
  }
];

// =============================================================================
// PART 4: SETUPS 68-80
// =============================================================================

export const AVOID_RULES_68_TO_80: AvoidRule[] = [
  {
    id: "SETUP_68",
    setupNumber: 68,
    signal: "CALL",
    trapReference: "Trap 20: Near-Miss",
    setupName: "Rising Channel + Hammer",
    avoidConditions: [
      "Body closing below support line (Breakout)",
      "Marubozu check (Must have wick)"
    ],
    triggerLogic: "Hammer in rising channel with near-miss to support"
  },
  {
    id: "SETUP_69",
    setupNumber: 69,
    signal: "CALL",
    trapReference: "Trap 4",
    setupName: "PSAR Stair-Step + Bullish",
    avoidConditions: [
      "RSI Overbought check (>70)"
    ],
    triggerLogic: "PSAR below with 3rd bullish candle in sequence"
  },
  {
    id: "SETUP_70",
    setupNumber: 70,
    signal: "CALL",
    trapReference: "Trap 25",
    setupName: "EMA50 Retest + Strong Close",
    avoidConditions: [
      "Deep Pierce Check (> 5 pips below EMA)"
    ],
    triggerLogic: "EMA50 retest on :00 or :30 minute mark"
  },
  {
    id: "SETUP_71",
    setupNumber: 71,
    signal: "CALL",
    trapReference: "Trap 12",
    setupName: "Asia/OTC Low Sweep",
    avoidConditions: [
      "Doji Stall Check (Must be a rejection candle)"
    ],
    triggerLogic: "Session low sweep with close back inside range"
  },
  {
    id: "SETUP_72",
    setupNumber: 72,
    signal: "CALL",
    trapReference: "Trap 1",
    setupName: "FVG Partial Fill + Continue",
    avoidConditions: [
      "Momentum Check (Next Open must be strong)"
    ],
    triggerLogic: "Partial FVG fill with wick fill attempt detected"
  },
  {
    id: "SETUP_73",
    setupNumber: 73,
    signal: "CALL",
    trapReference: "Trap 5",
    setupName: "VWAP + EMA200 Stack",
    avoidConditions: [
      "Gap Check (Indicators must be stacked tight)"
    ],
    triggerLogic: "VWAP and EMA200 within 0.0002 with round number confluence"
  },
  {
    id: "SETUP_74",
    setupNumber: 74,
    signal: "CALL",
    trapReference: "Trap 9",
    setupName: "OBV Higher Low + Engulfing",
    avoidConditions: [
      "Body Size Ratio (Engulfing must be > Previous)"
    ],
    triggerLogic: "OBV higher low with bullish engulfing body > previous"
  },
  {
    id: "SETUP_75",
    setupNumber: 75,
    signal: "CALL",
    trapReference: "Trap 4",
    setupName: "BB Walk (Lower to Mid)",
    avoidConditions: [
      "Mid-Band Rejection Check"
    ],
    triggerLogic: "Walking BB upward with 3 bullish candle confirmation"
  },
  {
    id: "SETUP_76_78",
    setupNumber: 76,
    signal: "PUT",
    trapReference: "Trap Mix",
    setupName: "Supply/FVG/EMA Rejections",
    avoidConditions: [
      "Wick-to-Body Ratio Check (Must look like a pinbar)"
    ],
    triggerLogic: "Key level rejection with shooting star or bearish rejection pattern"
  },
  {
    id: "SETUP_79",
    setupNumber: 79,
    signal: "PUT",
    trapReference: "Trap 11",
    setupName: "VWAP + BB Upper",
    avoidConditions: [],
    triggerLogic: "Fully outside upper BB with VWAP touch"
  },
  {
    id: "SETUP_80",
    setupNumber: 80,
    signal: "PUT",
    trapReference: "Trap 23",
    setupName: "Liquidity Sweep High",
    avoidConditions: [
      "Fake-out Reclaim Check (Close must be below resistance)"
    ],
    triggerLogic: "High > resistance with close < resistance and .000 pierce"
  }
];

// =============================================================================
// PART 5: SETUPS 81-90
// =============================================================================

export const AVOID_RULES_81_TO_90: AvoidRule[] = [
  {
    id: "SETUP_81",
    setupNumber: 81,
    signal: "PUT",
    trapReference: "Trap 10",
    setupName: "RSI Divergence + Star",
    avoidConditions: [
      "Parabolic Move Check (Too vertical = unsafe)"
    ],
    triggerLogic: "RSI bearish divergence with shooting star"
  },
  {
    id: "SETUP_82",
    setupNumber: 82,
    signal: "PUT",
    trapReference: "Trap 21",
    setupName: "Stochastic 80 + Doji",
    avoidConditions: [
      "Salami Trend Filter (Stop if 5-6 small green candles)"
    ],
    triggerLogic: "Stochastic > 80 with cluster of Dojis"
  },
  {
    id: "SETUP_83",
    setupNumber: 83,
    signal: "PUT",
    trapReference: "Trap 14",
    setupName: "ADX Rising Breakout",
    avoidConditions: [
      "Support Proximity Check"
    ],
    triggerLogic: "ADX rising with bearish breakout away from support"
  },
  {
    id: "SETUP_84_85",
    setupNumber: 84,
    signal: "PUT",
    trapReference: "Trap 27/25",
    setupName: "OBV/MFI Falling",
    avoidConditions: [
      "Liquidity Check (Volume must be > 1)"
    ],
    triggerLogic: "OBV breakdown or MFI falling with time reset or engulfing"
  },
  {
    id: "SETUP_86",
    setupNumber: 86,
    signal: "PUT",
    trapReference: "Trap 26",
    setupName: "Inside Bar Grab + Down",
    avoidConditions: [],
    triggerLogic: "Inside bar with fake breakout up and close below low"
  },
  {
    id: "SETUP_87",
    setupNumber: 87,
    signal: "PUT",
    trapReference: "Trap 16",
    setupName: "3 Pushes Up + Star",
    avoidConditions: [],
    triggerLogic: "3 pushes up with shooting star at BB upper, body > 2x avg"
  },
  {
    id: "SETUP_88",
    setupNumber: 88,
    signal: "PUT",
    trapReference: "Trap 8",
    setupName: "EMA200 + Fib 78.6",
    avoidConditions: [
      "Direct Break Check (Must have rejection wick)"
    ],
    triggerLogic: "EMA200 at Fib 78.6% with rejection wick"
  },
  {
    id: "SETUP_89",
    setupNumber: 89,
    signal: "PUT",
    trapReference: "Trap 17",
    setupName: "VWAP Loss + Bearish",
    avoidConditions: [],
    triggerLogic: "VWAP crossover down with gap-down next open confirmation"
  },
  {
    id: "SETUP_90",
    setupNumber: 90,
    signal: "PUT",
    trapReference: "Trap 21",
    setupName: "StdDev Compression",
    avoidConditions: [
      "Range Duration Check (> 5 mins = Breakout Risk)"
    ],
    triggerLogic: "StdDev low with bearish breakout within 5 min range"
  }
];

// =============================================================================
// PART 6: SETUPS 91-100
// =============================================================================

export const AVOID_RULES_91_TO_100: AvoidRule[] = [
  {
    id: "SETUP_91",
    setupNumber: 91,
    signal: "PUT",
    trapReference: "Trap 19",
    setupName: "Range High Snap-Back",
    avoidConditions: [
      "Resistance Reclaim Check"
    ],
    triggerLogic: "Evening star at range high with close < range high"
  },
  {
    id: "SETUP_92",
    setupNumber: 92,
    signal: "PUT",
    trapReference: "Trap 7",
    setupName: "Bearish Engulfing After Doji",
    avoidConditions: [
      "Size Ratio Check (Engulfing must be >= 2x Doji Range)"
    ],
    triggerLogic: "Doji followed by bearish engulfing >= 2x doji range"
  },
  {
    id: "SETUP_93",
    setupNumber: 93,
    signal: "PUT",
    trapReference: "Trap 20",
    setupName: "Falling Channel Near-Miss",
    avoidConditions: [
      "Channel Breakout Check"
    ],
    triggerLogic: "Shooting star in falling channel with near-miss to resistance"
  },
  {
    id: "SETUP_94",
    setupNumber: 94,
    signal: "PUT",
    trapReference: "Trap 4",
    setupName: "PSAR Momentum Cycle",
    avoidConditions: [
      "Oversold Check (RSI < 30)"
    ],
    triggerLogic: "PSAR above with 3rd bearish candle, RSI >= 30"
  },
  {
    id: "SETUP_95_97",
    setupNumber: 95,
    signal: "PUT",
    trapReference: "Trap 1/13",
    setupName: "EMA Retest / Wick Fill",
    avoidConditions: [
      "Gap Up Check (Must not have large gap up)"
    ],
    triggerLogic: "EMA50 retest or partial FVG fill without gap up"
  },
  {
    id: "SETUP_98_99",
    setupNumber: 98,
    signal: "PUT",
    trapReference: "Trap 5/9",
    setupName: "Institutional Ceiling",
    avoidConditions: [
      "Exhaustion Volume Check (> 5x Avg)"
    ],
    triggerLogic: "VWAP + EMA200 or OBV lower high with volume anomaly"
  },
  {
    id: "SETUP_100",
    setupNumber: 100,
    signal: "PUT",
    trapReference: "Trap 15",
    setupName: "BB Walk Fatigue",
    avoidConditions: [
      "Flat Box Market Check"
    ],
    triggerLogic: "Walking BB downward with 5+ color switches"
  }
];

// =============================================================================
// PART 7: SETUPS 101-150
// =============================================================================

export const AVOID_RULES_101_TO_150: AvoidRule[] = [
  {
    id: "SETUP_101",
    setupNumber: 101,
    signal: "CALL",
    trapReference: "Trap 12",
    setupName: "HTF Demand + Long Rej Wick",
    avoidConditions: [
      "Candle must be Green (Bullish Close) inside zone"
    ],
    triggerLogic: "Bullish at demand with lower wick > body size"
  },
  {
    id: "SETUP_102",
    setupNumber: 102,
    signal: "CALL",
    trapReference: "Trap 7",
    setupName: "Demand OB + Doji → Engulfing",
    avoidConditions: [
      "Momentum Check (Engulfing must be strong, not weak)"
    ],
    triggerLogic: "Doji at demand OB followed by bullish engulfing > doji range"
  },
  {
    id: "SETUP_103",
    setupNumber: 103,
    signal: "CALL",
    trapReference: "Trap 6",
    setupName: "FVG + Tweezer Bottom",
    avoidConditions: [
      "Fill Risk (Must reject 50% line, not close below)"
    ],
    triggerLogic: "Tweezer bottom at FVG with precision 50% touch"
  },
  {
    id: "SETUP_104",
    setupNumber: 104,
    signal: "CALL",
    trapReference: "Trap 21",
    setupName: "EMA20 Trend + Inside Bar Up",
    avoidConditions: [
      "Mother Bar Size (Must not be tiny/micro)"
    ],
    triggerLogic: "Inside bar riding EMA20 with break of mother high"
  },
  {
    id: "SETUP_105",
    setupNumber: 105,
    signal: "CALL",
    trapReference: "Trap 9",
    setupName: "VWAP Rising + Hammer",
    avoidConditions: [
      "Angle Check (VWAP must act as support, not magnet)"
    ],
    triggerLogic: "Hammer touching VWAP with VWAP angle > 30°"
  },
  {
    id: "SETUP_107",
    setupNumber: 107,
    signal: "CALL",
    trapReference: "Trap 23",
    setupName: "EMA200 + Sweep + Hammer",
    avoidConditions: [
      "Godzilla Candle Check (Sweep candle shouldn't be massive)"
    ],
    triggerLogic: "Hammer at EMA200 with low sweep through .000"
  },
  {
    id: "SETUP_108",
    setupNumber: 108,
    signal: "CALL",
    trapReference: "Trap 14",
    setupName: "BB Squeeze + Bullish Expansion",
    avoidConditions: [
      "Dead Market Check (Volume must increase on expansion)"
    ],
    triggerLogic: "BB squeeze with bullish expansion body >= 3x squeeze avg"
  },
  {
    id: "SETUP_109",
    setupNumber: 109,
    signal: "CALL",
    trapReference: "Trap 10",
    setupName: "RSI Mid-Zone Rejection",
    avoidConditions: [
      "Hover Check (Must be a sharp Hook, not flat)"
    ],
    triggerLogic: "RSI hook up from 50 zone"
  },
  {
    id: "SETUP_110",
    setupNumber: 110,
    signal: "CALL",
    trapReference: "Trap 27",
    setupName: "OBV Flat → Sudden Spike",
    avoidConditions: [
      "Manipulation Check (Price must match volume)"
    ],
    triggerLogic: "OBV sideways then spike with bullish candle"
  },
  {
    id: "SETUP_115",
    setupNumber: 115,
    signal: "CALL",
    trapReference: "Trap 26",
    setupName: "Range Low Fakeout + Marubozu",
    avoidConditions: [
      "Reclaim Strength (Must close deep inside range)"
    ],
    triggerLogic: "Fakeout below range low with bullish marubozu reclaim"
  },
  {
    id: "SETUP_121",
    setupNumber: 121,
    signal: "CALL",
    trapReference: "Trap 12",
    setupName: "Prev Day Low Sweep + Hammer",
    avoidConditions: [
      "Close Position (Must close ABOVE PDL)"
    ],
    triggerLogic: "Hammer sweeping below PDL with close above"
  },
  {
    id: "SETUP_125",
    setupNumber: 125,
    signal: "CALL",
    trapReference: "Trap 8",
    setupName: "EMA50 + FVG Overlap",
    avoidConditions: [
      "Gap Tolerance (Must be a tight stack < 2 pips)"
    ],
    triggerLogic: "EMA50 within 0.0002 of FVG midline"
  },
  {
    id: "SETUP_135",
    setupNumber: 135,
    signal: "CALL",
    trapReference: "Trap 19",
    setupName: "StdDev Spike + Bullish",
    avoidConditions: [
      "Resistance Block (Ensure no immediate resistance above)"
    ],
    triggerLogic: "StdDev spike at BB lower with round number low"
  }
];

// =============================================================================
// PART 8: SETUPS 151-166
// =============================================================================

export const AVOID_RULES_151_TO_166: AvoidRule[] = [
  {
    id: "SETUP_151",
    setupNumber: 151,
    signal: "PUT",
    trapReference: "Trap 1",
    setupName: "HTF Supply + Long Upper Wick",
    avoidConditions: [
      "Color Check (Must close Red/Bearish)"
    ],
    triggerLogic: "Bearish at supply with upper wick > 60% of total"
  },
  {
    id: "SETUP_152",
    setupNumber: 152,
    signal: "PUT",
    trapReference: "Trap 7",
    setupName: "Supply OB + Doji → Engulfing",
    avoidConditions: [
      "Breakout Check (Must break Doji Low)"
    ],
    triggerLogic: "Doji at supply OB followed by bearish engulfing below doji low"
  },
  {
    id: "SETUP_153",
    setupNumber: 153,
    signal: "PUT",
    trapReference: "Trap 6",
    setupName: "FVG + Tweezer Top",
    avoidConditions: [
      "Midline Rejection (Must not close above 50% line)"
    ],
    triggerLogic: "Tweezer top at FVG with precision 50% touch"
  },
  {
    id: "SETUP_154",
    setupNumber: 154,
    signal: "PUT",
    trapReference: "Trap 21",
    setupName: "EMA20 Trend + Inside Bar Down",
    avoidConditions: [
      "Trend Gap (EMA must be close to price)"
    ],
    triggerLogic: "Inside bar below EMA20 with break of mother low"
  },
  {
    id: "SETUP_155",
    setupNumber: 155,
    signal: "PUT",
    trapReference: "Trap 9",
    setupName: "VWAP Falling + Shooting Star",
    avoidConditions: [
      "Angle Check (Must be steep down -30°)",
      "Body must close BELOW VWAP"
    ],
    triggerLogic: "Shooting star touching VWAP with angle < -30°"
  },
  {
    id: "SETUP_157",
    setupNumber: 157,
    signal: "PUT",
    trapReference: "Trap 23",
    setupName: "EMA200 + Sweep + Star",
    avoidConditions: [
      "Breakout Check (Star must NOT close above EMA200)"
    ],
    triggerLogic: "Shooting star at EMA200 with high sweep through .000"
  },
  {
    id: "SETUP_158",
    setupNumber: 158,
    signal: "PUT",
    trapReference: "Trap 14",
    setupName: "BB Squeeze + Bearish Expansion",
    avoidConditions: [
      "Obstacle Check (Avoid if Round Number .000 is below)"
    ],
    triggerLogic: "BB squeeze with bearish expansion body >= 3x squeeze avg"
  },
  {
    id: "SETUP_159",
    setupNumber: 159,
    signal: "PUT",
    trapReference: "Trap 10",
    setupName: "RSI Mid-Zone Rejection",
    avoidConditions: [
      "Flat Hook Check (Must be sharp downward hook)"
    ],
    triggerLogic: "RSI hook down from 50 zone"
  },
  {
    id: "SETUP_160",
    setupNumber: 160,
    signal: "PUT",
    trapReference: "Trap 27",
    setupName: "OBV Flat → Sudden Drop",
    avoidConditions: [
      "Fake Drop (Price must drop with volume)"
    ],
    triggerLogic: "OBV sideways then drop with bearish candle"
  },
  {
    id: "SETUP_164",
    setupNumber: 164,
    signal: "PUT",
    trapReference: "Trap 13",
    setupName: "FVG Edge Tap + Strong Close",
    avoidConditions: [
      "Coverage Check (Engulfing must cover the FVG gap)"
    ],
    triggerLogic: "FVG edge tap with bearish engulfing closing below"
  },
  {
    id: "SETUP_165",
    setupNumber: 165,
    signal: "PUT",
    trapReference: "Trap 26",
    setupName: "Range High Fakeout + Marubozu",
    avoidConditions: [
      "Fast Reclaim (Must happen immediately)"
    ],
    triggerLogic: "Fakeout above range high with bearish marubozu reclaim"
  }
];

// =============================================================================
// PART 9: SETUPS 166-184
// =============================================================================

export const AVOID_RULES_166_TO_184: AvoidRule[] = [
  {
    id: "SETUP_166",
    setupNumber: 166,
    signal: "PUT",
    trapReference: "Trap 15",
    setupName: "Engulfing After 2 Small Greens",
    avoidConditions: [
      "Small candles must NOT be Dojis (Must have real body)"
    ],
    triggerLogic: "2 small green candles followed by bearish candle"
  },
  {
    id: "SETUP_167",
    setupNumber: 167,
    signal: "PUT",
    trapReference: "Trap 21",
    setupName: "3 Inside Bars + Break Down",
    avoidConditions: [
      "Mother bar must be significant (> 3 pips)"
    ],
    triggerLogic: "3 inside bars with break below mother bar low"
  },
  {
    id: "SETUP_168",
    setupNumber: 168,
    signal: "PUT",
    trapReference: "Trap 2",
    setupName: "Falling Wedge Fake Breakout",
    avoidConditions: [
      "Volume must increase on the Fakeout (Trap confirmation)"
    ],
    triggerLogic: "Falling wedge fakeout with bearish engulfing reclaim"
  },
  {
    id: "SETUP_169",
    setupNumber: 169,
    signal: "PUT",
    trapReference: "Trap 17",
    setupName: "EMA20 Loss + Gap",
    avoidConditions: [
      "Gap must not be excessive (> 4 pixels/pips)"
    ],
    triggerLogic: "EMA20 crossover down with controlled gap size"
  },
  {
    id: "SETUP_171",
    setupNumber: 171,
    signal: "PUT",
    trapReference: "Trap 12",
    setupName: "PDH Sweep + Star",
    avoidConditions: [
      "Must close BELOW Previous Day High"
    ],
    triggerLogic: "Shooting star sweeping above PDH with close below"
  },
  {
    id: "SETUP_173",
    setupNumber: 173,
    signal: "PUT",
    trapReference: "Trap 11",
    setupName: "BB Upper Walk → Mid",
    avoidConditions: [
      "Volume must be High on the crossing candle"
    ],
    triggerLogic: "BB upper walk with close below mid and high volume"
  },
  {
    id: "SETUP_176",
    setupNumber: 176,
    signal: "PUT",
    trapReference: "Trap 10",
    setupName: "RSI Bearish Divergence",
    avoidConditions: [
      "RSI > 90 is Super Trend - Wait for price break confirmation"
    ],
    triggerLogic: "RSI > 90 divergence with close < previous low"
  },
  {
    id: "SETUP_177",
    setupNumber: 177,
    signal: "PUT",
    trapReference: "Trap 14",
    setupName: "ADX Rising + Marubozu",
    avoidConditions: [
      "Exhaustion Check (Candle must not be > 3x Average)",
      "Must be a true Marubozu (No lower wick)"
    ],
    triggerLogic: "ADX rising with bearish marubozu (low = close)"
  },
  {
    id: "SETUP_184",
    setupNumber: 184,
    signal: "PUT",
    trapReference: "Trap 21",
    setupName: "EMA20/50 Compression Break",
    avoidConditions: [
      "Breakout candle must have a strong body (Not Doji/Spinning Top)"
    ],
    triggerLogic: "EMA20/50 squeeze with bearish break below both"
  }
];


// =============================================================================
// PART 10: SETUPS 185-215
// =============================================================================

export const AVOID_RULES_185_TO_215: AvoidRule[] = [
  {
    id: "SETUP_191",
    setupNumber: 191,
    signal: "PUT",
    trapReference: "Trap 25",
    setupName: "HTF Trend Pullback + Star",
    avoidConditions: [
      "Time Window Exactness - Must be exactly at minute start (:00) for algo reset"
    ],
    triggerLogic: "HTF pullback to supply with shooting star at :00 second"
  },
  {
    id: "SETUP_193",
    setupNumber: 193,
    signal: "PUT",
    trapReference: "Trap 22",
    setupName: "EMA50 Retest + Continue",
    avoidConditions: [
      "Momentum Break Check - If retest candle is Giant (3x avg), don't trade"
    ],
    triggerLogic: "2nd EMA50 touch with controlled candle size"
  },
  {
    id: "SETUP_194",
    setupNumber: 194,
    signal: "PUT",
    trapReference: "Trap 2",
    setupName: "FVG + Sweep Combo",
    avoidConditions: [
      "Reclaim Failure - Price must NOT stay above the sweep level"
    ],
    triggerLogic: "Liquidity sweep high at FVG with close below resistance"
  },
  {
    id: "SETUP_195",
    setupNumber: 195,
    signal: "PUT",
    trapReference: "Trap 14",
    setupName: "VWAP Falling + Marubozu",
    avoidConditions: [
      "Volume confirmation - Falling VWAP needs Volume to confirm downward pressure"
    ],
    triggerLogic: "VWAP falling with bearish marubozu and high volume"
  },
  {
    id: "SETUP_196",
    setupNumber: 196,
    signal: "PUT",
    trapReference: "Trap 9",
    setupName: "OBV Flat → Sudden Drop",
    avoidConditions: [
      "Price Action Confirm - Don't trust OBV if candle is bullish"
    ],
    triggerLogic: "OBV sideways then drop with doji, candle must be bearish"
  },
  {
    id: "SETUP_197",
    setupNumber: 197,
    signal: "PUT",
    trapReference: "Trap 4",
    setupName: "ADX Stable + Continue",
    avoidConditions: [
      "Support Block - Don't sell if hitting a round number support"
    ],
    triggerLogic: "ADX at 30 with even count consecutive bearish, avoid .000"
  },
  {
    id: "SETUP_198",
    setupNumber: 198,
    signal: "PUT",
    trapReference: "Trap 21",
    setupName: "BB Expansion + Supply",
    avoidConditions: [
      "Parabolic Exhaustion - If price moved too fast (>5 candles vertical), wait"
    ],
    triggerLogic: "BB expanding at supply zone, no parabolic move"
  },
  {
    id: "SETUP_200",
    setupNumber: 200,
    signal: "PUT",
    trapReference: "Trap 16",
    setupName: "HTF Range + Vol Spike",
    avoidConditions: [
      "Volume Anomaly Check - If Volume > 5x average, it's exhaustion/climax, not entry"
    ],
    triggerLogic: "Range high with volume spike < 5x average"
  },
  {
    id: "SETUP_201",
    setupNumber: 201,
    signal: "CALL",
    trapReference: "Trap 12",
    setupName: "Liquidity Sweep + Demand",
    avoidConditions: [
      "Reclaim Speed - Hammer close must be back inside range/session low"
    ],
    triggerLogic: "Demand zone hammer with close > session low"
  },
  {
    id: "SETUP_203",
    setupNumber: 203,
    signal: "CALL",
    trapReference: "Trap 1",
    setupName: "EMA200 Rejection + Hammer",
    avoidConditions: [
      "Invalid Rejection - If candle closes BELOW EMA200, it's breakout not rejection"
    ],
    triggerLogic: "EMA200 touch with hammer closing above EMA200"
  },
  {
    id: "SETUP_205",
    setupNumber: 205,
    signal: "CALL",
    trapReference: "Trap 6",
    setupName: "FVG Tap + Strong Bullish Close",
    avoidConditions: [
      "Weak Rejection - Candle must not be a Doji, body signifies intent"
    ],
    triggerLogic: "FVG tap with bullish close, body > micro threshold"
  },
  {
    id: "SETUP_207",
    setupNumber: 207,
    signal: "CALL",
    trapReference: "Trap 2",
    setupName: "HTF Order Block + Engulfing",
    avoidConditions: [
      "Wick Rejection Check - Ensure the OB was actually touched by a wick first"
    ],
    triggerLogic: "Demand OB with bullish engulfing, low <= OB edge"
  },
  {
    id: "SETUP_208",
    setupNumber: 208,
    signal: "PUT",
    trapReference: "Trap 2",
    setupName: "HTF Order Block + Engulfing (Supply)",
    avoidConditions: [
      "Wick Rejection Check - Ensure the OB was touched by wick first"
    ],
    triggerLogic: "Supply OB with bearish engulfing, high >= OB edge"
  },
  {
    id: "SETUP_209",
    setupNumber: 209,
    signal: "CALL",
    trapReference: "Trap 26",
    setupName: "Range Low Fakeout + Marubozu",
    avoidConditions: [
      "False Move Trap - If Marubozu is tiny (inside prev candle range), ignore"
    ],
    triggerLogic: "Range low fakeout with bullish marubozu > 50% prev body"
  },
  {
    id: "SETUP_210",
    setupNumber: 210,
    signal: "PUT",
    trapReference: "Trap 26",
    setupName: "Range High Fakeout + Marubozu",
    avoidConditions: [
      "False Move Trap - If Marubozu is tiny (inside prev candle range), ignore"
    ],
    triggerLogic: "Range high fakeout with bearish marubozu > 50% prev body"
  },
  {
    id: "SETUP_211",
    setupNumber: 211,
    signal: "CALL",
    trapReference: "Trap 7",
    setupName: "Doji at Support + Green Conf",
    avoidConditions: [
      "Breakout Strength - Must break Doji High by at least 1 pip"
    ],
    triggerLogic: "Doji at support with green close > doji high + 0.0001"
  },
  {
    id: "SETUP_212",
    setupNumber: 212,
    signal: "PUT",
    trapReference: "Trap 7",
    setupName: "Doji at Resistance + Red Conf",
    avoidConditions: [
      "Breakout Strength - Must break Doji Low by at least 1 pip"
    ],
    triggerLogic: "Doji at resistance with red close < doji low - 0.0001"
  },
  {
    id: "SETUP_213",
    setupNumber: 213,
    signal: "CALL",
    trapReference: "Trap 6",
    setupName: "Hammer at Support",
    avoidConditions: [
      "Wick Ratio - Lower wick must be strictly larger than the body"
    ],
    triggerLogic: "Hammer at support with lower wick > body size"
  },
  {
    id: "SETUP_214",
    setupNumber: 214,
    signal: "PUT",
    trapReference: "Trap 12",
    setupName: "Hanging Man at Resistance",
    avoidConditions: [
      "Confirmation Required - Hanging man is weak alone, next candle MUST be red"
    ],
    triggerLogic: "Hanging man at resistance, wait for red confirmation"
  },
  {
    id: "SETUP_215",
    setupNumber: 215,
    signal: "CALL",
    trapReference: "Trap 6",
    setupName: "Inverted Hammer at Support",
    avoidConditions: [
      "Body Color - Inverted Hammer at Support works best if Green/Bullish"
    ],
    triggerLogic: "Inverted hammer at support with bullish close"
  }
];

// =============================================================================
// PART 11: SETUPS 216-235
// =============================================================================

export const AVOID_RULES_216_TO_235: AvoidRule[] = [
  {
    id: "SETUP_216",
    setupNumber: 216,
    signal: "PUT",
    trapReference: "Trap 1",
    setupName: "Shooting Star at Resistance",
    avoidConditions: [
      "Wick Precision - Wick must be at least 60% of the total candle length"
    ],
    triggerLogic: "Shooting star at resistance with upper wick > 60% of total range"
  },
  {
    id: "SETUP_217",
    setupNumber: 217,
    signal: "CALL",
    trapReference: "Trap 15",
    setupName: "Spinning Top Confirmation",
    avoidConditions: [
      "Range Break Check - Price must break the Wick High/Low, not just the Body"
    ],
    triggerLogic: "Spinning top with close breaking wick high (CALL) or low (PUT)"
  },
  {
    id: "SETUP_218",
    setupNumber: 218,
    signal: "CALL",
    trapReference: "Trap 14",
    setupName: "Green Marubozu Trend",
    avoidConditions: [
      "Round Number Block - If .000 is immediately ahead (within 2 pips), DO NOT CALL",
      "Must be pure Marubozu (Zero Wicks)"
    ],
    triggerLogic: "Bullish marubozu with zero wicks, no .000 ahead"
  },
  {
    id: "SETUP_220",
    setupNumber: 220,
    signal: "CALL",
    trapReference: "Trap 2",
    setupName: "Bullish Engulfing",
    avoidConditions: [
      "Exhaustion (Giant Candle) - Engulfing candle must NOT be > 3x larger than previous"
    ],
    triggerLogic: "Bullish engulfing at support with close > support level"
  },
  {
    id: "SETUP_222",
    setupNumber: 222,
    signal: "CALL",
    trapReference: "Trap 24",
    setupName: "Tweezer Bottom",
    avoidConditions: [
      "Downtrend Exhaustion - Works best after at least 3 red candles"
    ],
    triggerLogic: "Tweezer bottom after 3+ bearish candles at .000/.500"
  },
  {
    id: "SETUP_223",
    setupNumber: 223,
    signal: "PUT",
    trapReference: "Trap 24",
    setupName: "Tweezer Top",
    avoidConditions: [
      "Uptrend Exhaustion - Works best after at least 3 green candles"
    ],
    triggerLogic: "Tweezer top after 3+ bullish candles at .000/.500"
  },
  {
    id: "SETUP_224",
    setupNumber: 224,
    signal: "CALL",
    trapReference: "Trap 17",
    setupName: "Harami",
    avoidConditions: [
      "Volatility Gap - Gap must not be too large (> 3 pips), indicates instability"
    ],
    triggerLogic: "Harami pattern with micro gap, no excessive gap"
  },
  {
    id: "SETUP_225",
    setupNumber: 225,
    signal: "CALL",
    trapReference: "Trap 21",
    setupName: "Harami Cross",
    avoidConditions: [
      "Inside Bar Position - The cross (Doji) must be in upper/lower 3rd of Mother bar"
    ],
    triggerLogic: "Harami cross with doji in extreme position of mother bar"
  },
  {
    id: "SETUP_226",
    setupNumber: 226,
    signal: "CALL",
    trapReference: "Trap 13",
    setupName: "Piercing Line",
    avoidConditions: [
      "Midline Check - Green candle MUST close above 50% of the previous Red candle"
    ],
    triggerLogic: "Piercing line with close > previous candle midpoint"
  },
  {
    id: "SETUP_227",
    setupNumber: 227,
    signal: "PUT",
    trapReference: "Trap 13",
    setupName: "Dark Cloud Cover",
    avoidConditions: [
      "Midline Check - Red candle MUST close below 50% of the previous Green candle"
    ],
    triggerLogic: "Dark cloud cover with close < previous candle midpoint"
  },
  {
    id: "SETUP_228",
    setupNumber: 228,
    signal: "CALL",
    trapReference: "Trap 19",
    setupName: "Morning Star",
    avoidConditions: [
      "Star Separation - The star should ideally gap down from the first candle"
    ],
    triggerLogic: "Morning star with star gap down, low < BB Lower"
  },
  {
    id: "SETUP_229",
    setupNumber: 229,
    signal: "PUT",
    trapReference: "Trap 19",
    setupName: "Evening Star",
    avoidConditions: [
      "Star Separation - The star should ideally gap up from the first candle"
    ],
    triggerLogic: "Evening star with star gap up, high > BB Upper"
  },
  {
    id: "SETUP_230",
    setupNumber: 230,
    signal: "CALL",
    trapReference: "Trap 4",
    setupName: "Three White Soldiers",
    avoidConditions: [
      "Momentum Loss - 3rd candle should NOT be significantly smaller than 1st & 2nd (80% min)",
      "RSI Overbought Extremes - RSI must be <= 90"
    ],
    triggerLogic: "Three white soldiers with 3rd candle >= 80% of avg prev two, RSI <= 90"
  },
  {
    id: "SETUP_232",
    setupNumber: 232,
    signal: "CALL",
    trapReference: "Trap 18",
    setupName: "Inside Three Up",
    avoidConditions: [
      "Trend Context - Ensure we are not hitting a major resistance EMA (200)",
      "Sequence Check - Must not be RGRG pattern"
    ],
    triggerLogic: "Inside three up with close < EMA200, no RGRG sequence"
  },
  {
    id: "SETUP_233",
    setupNumber: 233,
    signal: "PUT",
    trapReference: "Trap 18",
    setupName: "Inside Three Down",
    avoidConditions: [
      "Trend Context - Ensure we are not hitting a major support EMA (200)",
      "Sequence Check - Must not be GRGR pattern"
    ],
    triggerLogic: "Inside three down with close > EMA200, no GRGR sequence"
  },
  {
    id: "SETUP_234",
    setupNumber: 234,
    signal: "CALL",
    trapReference: "Trap 21",
    setupName: "Rising Three Methods",
    avoidConditions: [
      "Shape of Resting Candles - The 3 small candles must be Dojis or Spinning Tops (not big bodies)"
    ],
    triggerLogic: "Rising three methods with middle candles as dojis/spinning tops"
  },
  {
    id: "SETUP_235",
    setupNumber: 235,
    signal: "PUT",
    trapReference: "Trap 21",
    setupName: "Falling Three Methods",
    avoidConditions: [
      "Shape of Resting Candles - The 3 small candles must be Dojis or Spinning Tops (not big bodies)"
    ],
    triggerLogic: "Falling three methods with middle candles as dojis/spinning tops"
  }
];

// =============================================================================
// SMC 18 SETUP AVOID RULES DATABASE
// =============================================================================
// Smart Money Concepts (SMC) specific avoid rules for 18 core setups
// Organized in 3 batches + MTF (Multi-Timeframe) setups
// =============================================================================

export interface SMCAvoidRule {
  id: string;
  smcNumber: number;
  batch: 1 | 2 | 3 | 'MTF';
  setupName: string;
  strategy: string;
  avoidConditions: string[];
  triggerLogic: string;
}

// =============================================================================
// SMC BATCH 1: Basic Setups (1-6)
// =============================================================================

export const SMC_AVOID_RULES_BATCH_1: SMCAvoidRule[] = [
  {
    id: "SMC_1",
    smcNumber: 1,
    batch: 1,
    setupName: "FVG (Fair Value Gap)",
    strategy: "Magnet Strategy",
    avoidConditions: [
      "Tiny gaps less than 2 pips are just noise - must be > 2 pips",
      "Price already filled > 50% immediately - gap is mitigated",
      "Bullish FVG: If close < (c1.high + fvg_size * 0.5) ignore",
      "Bearish FVG: If close > (c3.high + fvg_size * 0.5) ignore"
    ],
    triggerLogic: "Bullish: c3.low > c1.high | Bearish: c3.high < c1.low - Magnet fill to 50%"
  },
  {
    id: "SMC_2",
    smcNumber: 2,
    batch: 1,
    setupName: "iFVG (Inverted FVG)",
    strategy: "Momentum Strategy (Polarity Flip)",
    avoidConditions: [
      "Breakout candle must be strong (Marubozu/Big Body)",
      "Weak break with Doji/Spinning Top means fakeout",
      "Body must be > 60% of total candle range: abs(open - close) > (high - low) * 0.6"
    ],
    triggerLogic: "Bullish FVG broken -> Resistance (PUT) | Bearish FVG broken -> Support (CALL) - Polarity Flip Retest"
  },
  {
    id: "SMC_3",
    smcNumber: 3,
    batch: 1,
    setupName: "BPR (Balanced Price Range)",
    strategy: "Velocity Strategy (Vacuum Slingshot)",
    avoidConditions: [
      "Too narrow BPR (< 1 pip) is risky chop zone",
      "Overlap zone must be significant for valid momentum trade"
    ],
    triggerLogic: "Overlap between bullish and bearish FVG zones - Vacuum Slingshot momentum entry"
  },
  {
    id: "SMC_4",
    smcNumber: 4,
    batch: 1,
    setupName: "Volume Imbalance",
    strategy: "Body Gap Strategy (Body Data Fill)",
    avoidConditions: [
      "Gap must be visible but not insane: > 1 pip but < 10 pips",
      "Avoid news spikes with gaps > 10 pips",
      "Wick Fill Check: If wicks already covered the gap, imbalance is mitigated",
      "CALL: If current low <= prev close - gap filled",
      "PUT: If current high >= prev close - gap filled"
    ],
    triggerLogic: "Gap between current open and previous close - Body Data Fill entry"
  },
  {
    id: "SMC_5",
    smcNumber: 5,
    batch: 1,
    setupName: "Turtle Soup",
    strategy: "Liquidity Sweep Reversal (Stop Hunt)",
    avoidConditions: [
      "Sweep must happen fast - if price stays below old_low for > 30s it's a breakout",
      "Bullish: Rejection strength must be > 80% of sweep distance",
      "Bearish: Upper wick rejection must be > 80% of pierce distance",
      "Weak rejection = continuation not reversal"
    ],
    triggerLogic: "Sweep old high/low with strong rejection close back inside range - Liquidity Grab"
  },
  {
    id: "SMC_6",
    smcNumber: 6,
    batch: 1,
    setupName: "EQH/EQL (Equal Highs/Lows)",
    strategy: "Inducement (Money Pool)",
    avoidConditions: [
      "Market Structure: Only valid if price is approaching aggressively",
      "Low volume approach = No inducement - current vol must be > avg vol",
      "Equal levels must be within threshold (2 pips) to be valid targets"
    ],
    triggerLogic: "Multiple highs/lows within 2 pip threshold = liquidity pool target"
  }
];

// =============================================================================
// SMC BATCH 2: Advanced Setups (7-10)
// =============================================================================

export const SMC_AVOID_RULES_BATCH_2: SMCAvoidRule[] = [
  {
    id: "SMC_7",
    smcNumber: 7,
    batch: 2,
    setupName: "IDM (Inducement Trap)",
    strategy: "Retail Trap Reversal",
    avoidConditions: [
      "Momentum Shift Check: If sweep candle is a massive Red Marubozu, don't buy",
      "Sweep candle must close bullish (close > open) for valid CALL",
      "Bearish body even after sweep = continuation down, not reversal"
    ],
    triggerLogic: "Low < inducement_low AND close > inducement_low - Retailers Trapped"
  },
  {
    id: "SMC_8",
    smcNumber: 8,
    batch: 2,
    setupName: "The Unicorn (Breaker + FVG)",
    strategy: "Double Magnet Trap",
    avoidConditions: [
      "Zone Alignment: Overlap must be at least 50% of the FVG size",
      "Weak confluence if overlap_size < (fvg_size * 0.5)",
      "Both zones must be active and untested for high probability"
    ],
    triggerLogic: "Breaker zone overlaps with FVG zone - Double Magnet Trap entry"
  },
  {
    id: "SMC_9",
    smcNumber: 9,
    batch: 2,
    setupName: "Fresh Order Block (Memory)",
    strategy: "Institutional Memory (1st Touch Only)",
    avoidConditions: [
      "Liquidity Pool Trap: If touched more than once, it's now liquidity not support",
      "touch_count > 0 = AVOID - multiple touches invalidate the OB",
      "Deep Penetration: If price closes beyond 50% of OB, it's failing",
      "CALL OB: Avoid if current_price < ob_mid",
      "PUT OB: Avoid if current_price > ob_mid"
    ],
    triggerLogic: "First touch of fresh order block only - Institutional Memory"
  },
  {
    id: "SMC_10",
    smcNumber: 10,
    batch: 2,
    setupName: "Breaker Block (BB)",
    strategy: "Stop Hunt Flip Confirmation",
    avoidConditions: [
      "Time Lag: Break must happen within 5-15 candles of the sweep",
      "If break takes > 15 candles, the correlation is lost",
      "Old OB must have liquidity swept before flip is valid"
    ],
    triggerLogic: "Old PUT OB broken with liquidity swept - Breaker Flip to CALL"
  }
];

// =============================================================================
// SMC BATCH 3: Block Setups (11-13)
// =============================================================================

export const SMC_AVOID_RULES_BATCH_3: SMCAvoidRule[] = [
  {
    id: "SMC_11",
    smcNumber: 11,
    batch: 3,
    setupName: "Mitigation Block (MB)",
    strategy: "Failure Swing",
    avoidConditions: [
      "Volatility Check: Displacement candle needs high volume to confirm valid BOS",
      "If candle volume < avg_vol = Fake breakdown",
      "Structure must show clear failure swing (high < last_swing_high, close < last_swing_low)"
    ],
    triggerLogic: "High < last_swing_high AND close < last_swing_low with volume confirmation"
  },
  {
    id: "SMC_12",
    smcNumber: 12,
    batch: 3,
    setupName: "Propulsion Block (PB)",
    strategy: "Continuation Entry",
    avoidConditions: [
      "Candle Color: Propulsion must be a Strong Green candle for Bullish OB",
      "If close < open (bearish candle at bullish OB) = Invalid",
      "Body must be significant: abs(open - close) > 2 pips"
    ],
    triggerLogic: "Price touches active OB zone with strong momentum candle - Mean Threshold entry"
  },
  {
    id: "SMC_13",
    smcNumber: 13,
    batch: 3,
    setupName: "Rejection Block (RB)",
    strategy: "Wick Zone Entry",
    avoidConditions: [
      "Body Existence: Dojis are not Rejection Blocks - must have a body",
      "Body size must be > 0.5 pips minimum",
      "Upper wick must be > 2x body size for valid bearish rejection"
    ],
    triggerLogic: "Upper wick > 2x body = PUT entry at high - (wick * 0.25) zone"
  }
];

// =============================================================================
// SMC MTF (Multi-Timeframe) Setups (14-18)
// =============================================================================

export const SMC_AVOID_RULES_MTF: SMCAvoidRule[] = [
  {
    id: "SMC_14",
    smcNumber: 14,
    batch: 'MTF',
    setupName: "HTF SMT to LTF CHoCH",
    strategy: "Smart Money Technique Divergence",
    avoidConditions: [
      "Correlation Coefficient: Ensure pairs are actually correlated (> 0.80)",
      "Divergence must be clear between correlated pairs",
      "LTF CHoCH must confirm HTF SMT divergence"
    ],
    triggerLogic: "HTF divergence between correlated pairs + LTF structure shift"
  },
  {
    id: "SMC_15",
    smcNumber: 15,
    batch: 'MTF',
    setupName: "HTF Propulsion Combo",
    strategy: "Propulsion Combo V2",
    avoidConditions: [
      "Exhaustion: If HTF OB has been tested > 3 times, LTF propulsion will fail",
      "htf_ob_zone tests >= 3 = AVOID",
      "HTF zone must be fresh for valid LTF continuation"
    ],
    triggerLogic: "Fresh HTF OB with LTF propulsion confirmation - Continuation entry"
  },
  {
    id: "SMC_16",
    smcNumber: 16,
    batch: 'MTF',
    setupName: "Wick Sniper",
    strategy: "Wick Sniper V2",
    avoidConditions: [
      "Close Proximity: LTF Rejection must happen in top 25% of HTF wick",
      "If reaction from bottom of wick = weak signal",
      "Current close must be > htf_wick mid_point for valid entry"
    ],
    triggerLogic: "LTF rejection in upper 25% of HTF wick zone - Sniper entry"
  },
  {
    id: "SMC_17",
    smcNumber: 17,
    batch: 'MTF',
    setupName: "Unicorn Combo",
    strategy: "Unicorn Combo V2 (Triple Confluence)",
    avoidConditions: [
      "Timing: Unicorns work best during Killzones (London/NY Open)",
      "Avoid during Asia session (low volume)",
      "Must have HTF FVG + LTF Breaker + LTF FVG confluence"
    ],
    triggerLogic: "HTF FVG aligned with LTF Breaker and LTF FVG - High Probability entry"
  },
  {
    id: "SMC_18",
    smcNumber: 18,
    batch: 'MTF',
    setupName: "Mitigation Combo",
    strategy: "Mitigation Combo V2 (Structure Shift)",
    avoidConditions: [
      "RSI Confluence: Ensure RSI is not oversold when selling Mitigation Block",
      "Need room to drop - RSI must have space for continuation",
      "HTF failure high must align with LTF structure low break"
    ],
    triggerLogic: "HTF failure high + LTF structure low break - Structure Shift entry"
  }
];

// =============================================================================
// COMBINED SMC AVOID RULES (ALL 18)
// =============================================================================

export const ALL_SMC_AVOID_RULES: SMCAvoidRule[] = [
  ...SMC_AVOID_RULES_BATCH_1,
  ...SMC_AVOID_RULES_BATCH_2,
  ...SMC_AVOID_RULES_BATCH_3,
  ...SMC_AVOID_RULES_MTF
];

// =============================================================================
// SMC HELPERS
// =============================================================================

export function getSMCAvoidRulesForSetup(smcNumber: number): SMCAvoidRule | undefined {
  return ALL_SMC_AVOID_RULES.find(rule => rule.smcNumber === smcNumber);
}

export function getSMCAvoidConditions(smcNumber: number): string[] {
  const rule = getSMCAvoidRulesForSetup(smcNumber);
  return rule?.avoidConditions || [];
}

export function getSMCAvoidRulesByName(setupName: string): SMCAvoidRule | undefined {
  return ALL_SMC_AVOID_RULES.find(rule => 
    rule.setupName.toLowerCase().includes(setupName.toLowerCase())
  );
}

export function getSMCRulesByBatch(batch: 1 | 2 | 3 | 'MTF'): SMCAvoidRule[] {
  return ALL_SMC_AVOID_RULES.filter(rule => rule.batch === batch);
}

// =============================================================================
// LIQUIDITY 36 SETUP AVOID RULES DATABASE
// =============================================================================
// OTC Liquidity Trap System - 36 specific setups with avoid conditions
// =============================================================================

export interface LiquidityAvoidRule {
  id: string;
  liquidityNumber: number;
  signal: 'CALL' | 'PUT' | 'CONTINUATION' | 'REVERSAL' | 'TARGET';
  setupName: string;
  avoidConditions: string[];
  triggerLogic: string;
  category: 'Round_Number' | 'Wick_Fill' | 'Gap' | 'EMA' | 'Volume' | 'Sweep' | 'Time' | 'Pattern' | 'Grandmaster';
}

// =============================================================================
// LIQUIDITY TRAPS PART 1: SETUPS 1-7
// =============================================================================

export const LIQUIDITY_RULES_1_TO_7: LiquidityAvoidRule[] = [
  {
    id: "LIQ_1",
    liquidityNumber: 1,
    signal: "CONTINUATION",
    setupName: "Round Number Vacuum (.000)",
    category: "Round_Number",
    avoidConditions: [
      "Market is Ranging (ADX < 20) - price might stall and not hit the magnet",
      "Wick already touched .000 level - the magnet is dead"
    ],
    triggerLogic: "Price within 3 pips of nearest .000 with ADX > 20 and level untouched"
  },
  {
    id: "LIQ_2",
    liquidityNumber: 2,
    signal: "REVERSAL",
    setupName: "Half-Number Concrete Wall (.500)",
    category: "Round_Number",
    avoidConditions: [
      "Current candle is a Marubozu (No Wicks) - implies strong momentum that might smash the wall"
    ],
    triggerLogic: "Price closed within 1 pip of .500 with visible upper OR lower wick (> 0.5 pip)"
  },
  {
    id: "LIQ_3",
    liquidityNumber: 3,
    signal: "CONTINUATION",
    setupName: "Wick-Fill Bait (Long Wick)",
    category: "Wick_Fill",
    avoidConditions: [
      "EMA50 is sitting inside the wick zone - price might struggle to fill"
    ],
    triggerLogic: "Wick is > 60% of total candle size with no EMA50 obstacle in fill path"
  },
  {
    id: "LIQ_4",
    liquidityNumber: 4,
    signal: "REVERSAL",
    setupName: "Failed Wick Fill (Double Trap)",
    category: "Wick_Fill",
    avoidConditions: [
      "Rejection candle has lower volume than previous - weakness not confirmed"
    ],
    triggerLogic: "Previous wick > 3 pips, current fill attempt < 50% with higher volume on rejection"
  },
  {
    id: "LIQ_5",
    liquidityNumber: 5,
    signal: "REVERSAL",
    setupName: "Gap-Fill Slingshot",
    category: "Gap",
    avoidConditions: [
      "Runaway Gap (> 5 pips) - indicates news/trend strength, NOT a trap"
    ],
    triggerLogic: "Gap exists (> 2 pips but < 5 pips) for fade trade"
  },
  {
    id: "LIQ_6",
    liquidityNumber: 6,
    signal: "CONTINUATION",
    setupName: "Unfinished Business (1-Pip Tease)",
    category: "Round_Number",
    avoidConditions: [
      "NEXT candle opens with a gap away from support - algo might have reset"
    ],
    triggerLogic: "Price turned exactly 1 pip before major support level"
  },
  {
    id: "LIQ_7",
    liquidityNumber: 7,
    signal: "REVERSAL",
    setupName: "EMA 20 Rubber Band",
    category: "EMA",
    avoidConditions: [
      "Current candle is a tiny Doji (body < 0.5 pip) - trend pausing, not reversing"
    ],
    triggerLogic: "Price overextended > 15 pips from EMA20 with real body candle (> 0.5 pip)"
  }
];

// =============================================================================
// LIQUIDITY TRAPS PART 2: SETUPS 8-14
// =============================================================================

export const LIQUIDITY_RULES_8_TO_14: LiquidityAvoidRule[] = [
  {
    id: "LIQ_8",
    liquidityNumber: 8,
    signal: "CONTINUATION",
    setupName: "V-Shape Origin Hunt",
    category: "Pattern",
    avoidConditions: [
      "Round Number (.000) exists between current price and Origin - price might react there first"
    ],
    triggerLogic: "Price approaching V-shape origin (< 5 pips away) with no roadblock"
  },
  {
    id: "LIQ_9",
    liquidityNumber: 9,
    signal: "REVERSAL",
    setupName: "Turtle Soup (Standard Sweep)",
    category: "Sweep",
    avoidConditions: [
      "Sweep candle closes in same direction as break (momentum) - not a rejection"
    ],
    triggerLogic: "Sweep 0-2 pips above resistance with close inside AND red candle (close < open)"
  },
  {
    id: "LIQ_10",
    liquidityNumber: 10,
    signal: "REVERSAL",
    setupName: "The Hollow Bridge (Volume Trap)",
    category: "Volume",
    avoidConditions: [
      "Breakout distance > 5 pips - might be real breakout despite low volume (Liquidity Vacuum)"
    ],
    triggerLogic: "Big body (> avg) but low volume (< prev) with breakout < 3 pips"
  },
  {
    id: "LIQ_11",
    liquidityNumber: 11,
    signal: "REVERSAL",
    setupName: "Double Top Inducement (EQH)",
    category: "Sweep",
    avoidConditions: [
      "Upper wick < 20% of total range - no visible rejection"
    ],
    triggerLogic: "Price broke previous high but closed back below with visible upper wick (> 20%)"
  },
  {
    id: "LIQ_13",
    liquidityNumber: 13,
    signal: "REVERSAL",
    setupName: "Inside Bar Pixel Break",
    category: "Pattern",
    avoidConditions: [
      "Candle closes above mother bar high - valid breakout, not a trap"
    ],
    triggerLogic: "Micro break (0-0.2 pips above mother high) with close back inside mother bar"
  },
  {
    id: "LIQ_14",
    liquidityNumber: 14,
    signal: "REVERSAL",
    setupName: "News Candle Fade",
    category: "Volume",
    avoidConditions: [
      "Body is 10x larger than average - extreme news/trend, do NOT fade"
    ],
    triggerLogic: "Massive candle (5x average but < 10x) for reversal trade"
  }
];

// =============================================================================
// LIQUIDITY TRAPS PART 3: SETUPS 15-21
// =============================================================================

export const LIQUIDITY_RULES_15_TO_21: LiquidityAvoidRule[] = [
  {
    id: "LIQ_15",
    liquidityNumber: 15,
    signal: "REVERSAL",
    setupName: "Trendline Phantom Touch",
    category: "Pattern",
    avoidConditions: [
      "Rejection candle is a Doji (body < 0.2 pip) - need real body to confirm buyers stepped in"
    ],
    triggerLogic: "3rd touch of trendline with fakeout (low below TL, close above TL) and real body"
  },
  {
    id: "LIQ_16",
    liquidityNumber: 16,
    signal: "REVERSAL",
    setupName: "Session Sweep (Asian Kill Zone)",
    category: "Sweep",
    avoidConditions: [
      "Volume is lower than average - not a real liquidity sweep event"
    ],
    triggerLogic: "Sweep Asian High with close below and high volume (> avg)"
  },
  {
    id: "LIQ_18",
    liquidityNumber: 18,
    signal: "CONTINUATION",
    setupName: "FVG 50% Sniper",
    category: "Gap",
    avoidConditions: [
      "Smaller timeframe Order Block exists inside FVG - price might react to OB instead of 50%"
    ],
    triggerLogic: "Price touched exact 50% of FVG (< 1 pip diff) with no internal OB"
  },
  {
    id: "LIQ_20",
    liquidityNumber: 20,
    signal: "CONTINUATION",
    setupName: "Breaker Block (The Flip)",
    category: "Pattern",
    avoidConditions: [
      "Huge upper wick on reclaim candle (wick > 30% of body) - sellers still active pushing down"
    ],
    triggerLogic: "Price closed back above broken support with small upper wick (< 30% of body)"
  },
  {
    id: "LIQ_21",
    liquidityNumber: 21,
    signal: "CONTINUATION",
    setupName: "Volume Imbalance (Gapless Gap)",
    category: "Gap",
    avoidConditions: [
      "Candle color moving AWAY from gap - don't chase wrong direction momentum"
    ],
    triggerLogic: "Gap up detected with bearish candle filling the gap"
  }
];

// =============================================================================
// LIQUIDITY TRAPS PART 4: SETUPS 22-28
// =============================================================================

export const LIQUIDITY_RULES_22_TO_28: LiquidityAvoidRule[] = [
  {
    id: "LIQ_22",
    liquidityNumber: 22,
    signal: "TARGET",
    setupName: "Opening Price Magnet",
    category: "Time",
    avoidConditions: [
      "Volume is normal (>= 50% of avg) - magnet effect weakened"
    ],
    triggerLogic: "Very low volume (< 50% avg) with price > 5 pips from day open - target open price"
  },
  {
    id: "LIQ_25",
    liquidityNumber: 25,
    signal: "REVERSAL",
    setupName: "The :00 Hard Reset",
    category: "Time",
    avoidConditions: [
      "Current candle is a Doji (body < 0.1 pip) - no momentum to reverse"
    ],
    triggerLogic: "Exact start of hour (minute=0, second<=2) with real body candle (> 0.1 pip)"
  },
  {
    id: "LIQ_27",
    liquidityNumber: 27,
    signal: "REVERSAL",
    setupName: "Godzilla Exhaustion",
    category: "Volume",
    avoidConditions: [
      "Giant candle BROKE a major Support/Resistance - it's Momentum, NOT Exhaustion"
    ],
    triggerLogic: "Body is 3x larger than average with no major level broken"
  },
  {
    id: "LIQ_28",
    liquidityNumber: 28,
    signal: "REVERSAL",
    setupName: "3-Push Staircase",
    category: "Pattern",
    avoidConditions: [
      "3rd push has HIGHER volume than 2nd push - trend is accelerating, not ending"
    ],
    triggerLogic: "3rd push detected with stalling (close < prev close) and lower volume"
  }
];

// =============================================================================
// LIQUIDITY TRAPS PART 5: SETUPS 29-36
// =============================================================================

export const LIQUIDITY_RULES_29_TO_36: LiquidityAvoidRule[] = [
  {
    id: "LIQ_29",
    liquidityNumber: 29,
    signal: "CONTINUATION",
    setupName: "Last Second Wick (The Hook)",
    category: "Time",
    avoidConditions: [
      "5S chart does not show a rejection structure - hook not validated"
    ],
    triggerLogic: "Candle color flipped in last 2 seconds (58s->60s) with 5s rejection valid"
  },
  {
    id: "LIQ_32",
    liquidityNumber: 32,
    signal: "CONTINUATION",
    setupName: "The Correction Candle",
    category: "Pattern",
    avoidConditions: [
      "7th candle is small (< avg body) - trend is healthy, don't fade yet"
    ],
    triggerLogic: "6+ consecutive green candles with 7th being large (climax for reversal)"
  },
  {
    id: "LIQ_34",
    liquidityNumber: 34,
    signal: "PUT",
    setupName: "Resistance Liquidity Sweep",
    category: "Grandmaster",
    avoidConditions: [
      "Break distance > 5 pips - not a sweep, it's a failed breakout",
      "RSI not overbought (< 65) - exhaustion not confirmed"
    ],
    triggerLogic: "High broke swing high but close below with break < 5 pips and RSI > 65"
  },
  {
    id: "LIQ_35",
    liquidityNumber: 35,
    signal: "CALL",
    setupName: "Resistance Valid Breakout",
    category: "Grandmaster",
    avoidConditions: [
      "Volume lower than average - fake breakout, needs high volume",
      "Upper wick > 30% of body - rejection invalidates breakout"
    ],
    triggerLogic: "Close above swing high with high volume (> avg) and small upper wick (< 30% body)"
  },
  {
    id: "LIQ_36_A",
    liquidityNumber: 36,
    signal: "CALL",
    setupName: "Support Liquidity Sweep",
    category: "Grandmaster",
    avoidConditions: [
      "Break distance > 5 pips - not a sweep, it's a failed breakdown",
      "RSI not oversold (> 35) - exhaustion not confirmed"
    ],
    triggerLogic: "Low broke swing low but close above with break < 5 pips and RSI < 35"
  },
  {
    id: "LIQ_36_B",
    liquidityNumber: 36,
    signal: "PUT",
    setupName: "Support Valid Breakout",
    category: "Grandmaster",
    avoidConditions: [
      "Volume lower than average - fake breakout, needs high volume",
      "Lower wick > 30% of body - rejection invalidates breakout"
    ],
    triggerLogic: "Close below swing low with high volume (> avg) and small lower wick (< 30% body)"
  }
];

// =============================================================================
// COMBINED LIQUIDITY AVOID RULES (ALL 1-36)
// =============================================================================

export const ALL_LIQUIDITY_AVOID_RULES: LiquidityAvoidRule[] = [
  ...LIQUIDITY_RULES_1_TO_7,
  ...LIQUIDITY_RULES_8_TO_14,
  ...LIQUIDITY_RULES_15_TO_21,
  ...LIQUIDITY_RULES_22_TO_28,
  ...LIQUIDITY_RULES_29_TO_36
];

// =============================================================================
// LIQUIDITY HELPER FUNCTIONS
// =============================================================================

export function getLiquidityAvoidRulesForSetup(liquidityNumber: number): LiquidityAvoidRule | undefined {
  return ALL_LIQUIDITY_AVOID_RULES.find(rule => rule.liquidityNumber === liquidityNumber);
}

export function getLiquidityAvoidConditions(liquidityNumber: number): string[] {
  const rule = getLiquidityAvoidRulesForSetup(liquidityNumber);
  return rule?.avoidConditions || [];
}

export function getLiquidityRulesByName(setupName: string): LiquidityAvoidRule | undefined {
  return ALL_LIQUIDITY_AVOID_RULES.find(rule => 
    rule.setupName.toLowerCase().includes(setupName.toLowerCase())
  );
}

export function getLiquidityRulesByCategory(category: LiquidityAvoidRule['category']): LiquidityAvoidRule[] {
  return ALL_LIQUIDITY_AVOID_RULES.filter(rule => rule.category === category);
}

export function getTotalLiquidityAvoidRulesCount(): number {
  return ALL_LIQUIDITY_AVOID_RULES.length;
}

// =============================================================================
// INDICATOR AVOID RULES: 36 INDICATOR-SPECIFIC SETUPS
// =============================================================================
// Technical indicator signals with specific avoid conditions to filter weak entries.
// =============================================================================

export interface IndicatorAvoidRule {
  id: string;
  indicatorNumber: number;
  signal: 'CALL' | 'PUT' | 'CONTINUATION';
  setupName: string;
  indicator: 'RSI' | 'Stochastic' | 'CCI' | 'EMA' | 'BB' | 'PSAR' | 'MACD' | 'Williams' | 'ADX' | 'MFI' | 'Keltner' | 'Donchian' | 'ATR' | 'AO' | 'Ichimoku' | 'Vortex';
  avoidConditions: string[];
  triggerLogic: string;
}

// =============================================================================
// INDICATOR RULES PART 1: SETUPS 1-10 (RSI, Stochastic, CCI, EMA, Golden/Death Cross)
// =============================================================================

export const INDICATOR_RULES_1_TO_10: IndicatorAvoidRule[] = [
  {
    id: "IND_1",
    indicatorNumber: 1,
    signal: "CALL",
    setupName: "RSI Oversold Reversal",
    indicator: "RSI",
    avoidConditions: [
      "ADX > 30 - strong downtrend, trend too strong for reversal",
      "Candle is not bullish - need confirmation candle"
    ],
    triggerLogic: "RSI < 30 with bullish candle and ADX < 30"
  },
  {
    id: "IND_2",
    indicatorNumber: 2,
    signal: "PUT",
    setupName: "RSI Overbought Reversal",
    indicator: "RSI",
    avoidConditions: [
      "ADX > 30 - strong uptrend, price will likely glide RSI not reverse",
      "Candle is not bearish - need confirmation candle"
    ],
    triggerLogic: "RSI > 70 with bearish candle and ADX < 30"
  },
  {
    id: "IND_3",
    indicatorNumber: 3,
    signal: "CALL",
    setupName: "Stochastic Cross Up (Oversold)",
    indicator: "Stochastic",
    avoidConditions: [
      "Last 5 candles are all red - Salami Trend, ignore the cross",
      "Stoch K and D not both < 20 - not truly oversold"
    ],
    triggerLogic: "Stoch K < 20, D < 20, K crosses above D, not all 5 candles bearish"
  },
  {
    id: "IND_4",
    indicatorNumber: 4,
    signal: "PUT",
    setupName: "Stochastic Cross Down (Overbought)",
    indicator: "Stochastic",
    avoidConditions: [
      "Last 5 candles are all green - Salami Trend, ignore the cross",
      "Stoch K and D not both > 80 - not truly overbought"
    ],
    triggerLogic: "Stoch K > 80, D > 80, K crosses below D, not all 5 candles bullish"
  },
  {
    id: "IND_5",
    indicatorNumber: 5,
    signal: "CALL",
    setupName: "CCI -200 Rejection (Extreme Oversold)",
    indicator: "CCI",
    avoidConditions: [
      "CCI still falling (current < previous) - Falling Knife, wait for uptick",
      "Candle is not bullish - need confirmation"
    ],
    triggerLogic: "CCI < -200, CCI ticking up (current > previous), bullish candle"
  },
  {
    id: "IND_6",
    indicatorNumber: 6,
    signal: "PUT",
    setupName: "CCI +200 Rejection (Extreme Overbought)",
    indicator: "CCI",
    avoidConditions: [
      "CCI still rising (current > previous) - Rocket Launch, wait for downtick",
      "Candle is not bearish - need confirmation"
    ],
    triggerLogic: "CCI > 200, CCI ticking down (current < previous), bearish candle"
  },
  {
    id: "IND_7",
    indicatorNumber: 7,
    signal: "CALL",
    setupName: "EMA 20 Crossover (Trend Start)",
    indicator: "EMA",
    avoidConditions: [
      "EMA20 angle < 15° - flat EMA means ranging market, fake breakout likely"
    ],
    triggerLogic: "Previous close < EMA20 AND current close > EMA20 with EMA angle > 15°"
  },
  {
    id: "IND_8",
    indicatorNumber: 8,
    signal: "PUT",
    setupName: "EMA 20 Crossunder (Trend Start)",
    indicator: "EMA",
    avoidConditions: [
      "EMA20 angle > -15° - flat EMA means ranging market, fake breakdown likely"
    ],
    triggerLogic: "Previous close > EMA20 AND current close < EMA20 with EMA angle < -15°"
  },
  {
    id: "IND_9",
    indicatorNumber: 9,
    signal: "CALL",
    setupName: "Golden Cross (EMA 50 crosses EMA 200)",
    indicator: "EMA",
    avoidConditions: [
      "Price > 5 pips from cross point - overextended, late entry"
    ],
    triggerLogic: "EMA50 > EMA200 AND EMA50_Prev <= EMA200_Prev with price near cross point (< 5 pips)"
  },
  {
    id: "IND_10",
    indicatorNumber: 10,
    signal: "PUT",
    setupName: "Death Cross (EMA 50 crosses EMA 200)",
    indicator: "EMA",
    avoidConditions: [
      "Price > 5 pips from cross point - overextended, late entry"
    ],
    triggerLogic: "EMA50 < EMA200 AND EMA50_Prev >= EMA200_Prev with price near cross point (< 5 pips)"
  }
];

// =============================================================================
// INDICATOR RULES PART 2: SETUPS 11-20 (BB, PSAR, MACD, Williams, ADX)
// =============================================================================

export const INDICATOR_RULES_11_TO_20: IndicatorAvoidRule[] = [
  {
    id: "IND_11",
    indicatorNumber: 11,
    signal: "CALL",
    setupName: "Bollinger Band Squeeze Breakout (Up)",
    indicator: "BB",
    avoidConditions: [
      "Volume < 1.5x average - weak breakout, needs volume confirmation",
      "BB Bandwidth not in squeeze (> 0.0005) - not a true squeeze breakout"
    ],
    triggerLogic: "BB Bandwidth < 0.0005 (squeeze), close > BB Upper, volume > 1.5x avg"
  },
  {
    id: "IND_12",
    indicatorNumber: 12,
    signal: "PUT",
    setupName: "Bollinger Band Squeeze Breakout (Down)",
    indicator: "BB",
    avoidConditions: [
      "Volume < 1.5x average - weak breakout, needs volume confirmation",
      "BB Bandwidth not in squeeze (> 0.0005) - not a true squeeze breakout"
    ],
    triggerLogic: "BB Bandwidth < 0.0005 (squeeze), close < BB Lower, volume > 1.5x avg"
  },
  {
    id: "IND_13",
    indicatorNumber: 13,
    signal: "CALL",
    setupName: "Parabolic SAR Flip (Bear to Bull)",
    indicator: "PSAR",
    avoidConditions: [
      "Gap between current open and previous close > 2 pips - massive gap invalidates flip"
    ],
    triggerLogic: "PSAR_Prev > prev high AND PSAR < current low with small gap (< 2 pips)"
  },
  {
    id: "IND_14",
    indicatorNumber: 14,
    signal: "PUT",
    setupName: "Parabolic SAR Flip (Bull to Bear)",
    indicator: "PSAR",
    avoidConditions: [
      "Gap between current open and previous close > 2 pips - massive gap invalidates flip"
    ],
    triggerLogic: "PSAR_Prev < prev low AND PSAR > current high with small gap (< 2 pips)"
  },
  {
    id: "IND_15",
    indicatorNumber: 15,
    signal: "CALL",
    setupName: "MACD Zero Line Cross (Up)",
    indicator: "MACD",
    avoidConditions: [
      "Histogram not growing (current <= previous) - weak momentum, histogram must be increasing"
    ],
    triggerLogic: "MACD > 0 AND MACD_Prev <= 0 with histogram growing (current > previous)"
  },
  {
    id: "IND_16",
    indicatorNumber: 16,
    signal: "PUT",
    setupName: "MACD Zero Line Cross (Down)",
    indicator: "MACD",
    avoidConditions: [
      "Histogram not growing red (current >= previous) - weak momentum, histogram must be decreasing"
    ],
    triggerLogic: "MACD < 0 AND MACD_Prev >= 0 with histogram growing red (current < previous)"
  },
  {
    id: "IND_17",
    indicatorNumber: 17,
    signal: "CALL",
    setupName: "Williams %R Oversold (-80)",
    indicator: "Williams",
    avoidConditions: [
      "Williams %R locked at -100 for 3+ candles - momentum crash, not reversal",
      "Candle is not bullish - need confirmation"
    ],
    triggerLogic: "Williams %R < -80, bullish candle, not locked at -100 for 3 candles"
  },
  {
    id: "IND_18",
    indicatorNumber: 18,
    signal: "PUT",
    setupName: "Williams %R Overbought (-20)",
    indicator: "Williams",
    avoidConditions: [
      "Williams %R locked at 0 for 3+ candles - momentum pump, not reversal",
      "Candle is not bearish - need confirmation"
    ],
    triggerLogic: "Williams %R > -20, bearish candle, not locked at 0 for 3 candles"
  },
  {
    id: "IND_19",
    indicatorNumber: 19,
    signal: "CALL",
    setupName: "ADX Trend Pullback (Buy)",
    indicator: "ADX",
    avoidConditions: [
      "Close below EMA20 - support broken, pullback failed",
      "ADX < 25 - trend not strong enough",
      "DI+ not > DI- - not in uptrend"
    ],
    triggerLogic: "ADX > 25, DI+ > DI-, low touches EMA20, close > EMA20"
  },
  {
    id: "IND_20",
    indicatorNumber: 20,
    signal: "PUT",
    setupName: "ADX Trend Pullback (Sell)",
    indicator: "ADX",
    avoidConditions: [
      "Close above EMA20 - resistance broken, pullback failed",
      "ADX < 25 - trend not strong enough",
      "DI- not > DI+ - not in downtrend"
    ],
    triggerLogic: "ADX > 25, DI- > DI+, high touches EMA20, close < EMA20"
  }
];

// =============================================================================
// INDICATOR RULES PART 3: SETUPS 21-30 (BB Rejection, MFI, Keltner, Donchian, ATR)
// =============================================================================

export const INDICATOR_RULES_21_TO_30: IndicatorAvoidRule[] = [
  {
    id: "IND_21",
    indicatorNumber: 21,
    signal: "CALL",
    setupName: "Bollinger Band Rejection (Lower)",
    indicator: "BB",
    avoidConditions: [
      "Bands are expanding aggressively - do not trade reversal during expansion",
      "Candle is not hammer or bullish - need rejection confirmation"
    ],
    triggerLogic: "Low <= BB Lower, close > BB Lower, bands not expanding, hammer or bullish candle"
  },
  {
    id: "IND_22",
    indicatorNumber: 22,
    signal: "PUT",
    setupName: "Bollinger Band Rejection (Upper)",
    indicator: "BB",
    avoidConditions: [
      "Bands are expanding aggressively - do not trade reversal during expansion",
      "Candle is not shooting star or bearish - need rejection confirmation"
    ],
    triggerLogic: "High >= BB Upper, close < BB Upper, bands not expanding, shooting star or bearish candle"
  },
  {
    id: "IND_23",
    indicatorNumber: 23,
    signal: "CALL",
    setupName: "MFI Divergence (Bullish)",
    indicator: "MFI",
    avoidConditions: [
      "Volume not dropping (current >= previous) - need declining volume to confirm lack of sellers",
      "MFI not making higher low while price makes lower low - no divergence"
    ],
    triggerLogic: "MFI < 20, price lower low, MFI higher low vs 5 candles ago, volume dropping"
  },
  {
    id: "IND_24",
    indicatorNumber: 24,
    signal: "PUT",
    setupName: "MFI Divergence (Bearish)",
    indicator: "MFI",
    avoidConditions: [
      "Volume not dropping (current >= previous) - need declining volume to confirm lack of buyers",
      "MFI not making lower high while price makes higher high - no divergence"
    ],
    triggerLogic: "MFI > 80, price higher high, MFI lower high vs 5 candles ago, volume dropping"
  },
  {
    id: "IND_25",
    indicatorNumber: 25,
    signal: "CALL",
    setupName: "Keltner Channel Breakout (Up)",
    indicator: "Keltner",
    avoidConditions: [
      "RSI > 80 - breakout is late, overbought condition"
    ],
    triggerLogic: "Close > Keltner Upper with RSI < 80"
  },
  {
    id: "IND_26",
    indicatorNumber: 26,
    signal: "PUT",
    setupName: "Keltner Channel Breakdown",
    indicator: "Keltner",
    avoidConditions: [
      "RSI < 20 - breakdown is late, oversold condition"
    ],
    triggerLogic: "Close < Keltner Lower with RSI > 20"
  },
  {
    id: "IND_27",
    indicatorNumber: 27,
    signal: "CALL",
    setupName: "Donchian Channel Rejection (Lower)",
    indicator: "Donchian",
    avoidConditions: [
      "No lower wick present - must leave rejection wick at bottom rail"
    ],
    triggerLogic: "Low == Donchian Lower with lower wick > 0"
  },
  {
    id: "IND_28",
    indicatorNumber: 28,
    signal: "PUT",
    setupName: "Donchian Channel Rejection (Upper)",
    indicator: "Donchian",
    avoidConditions: [
      "No upper wick present - must leave rejection wick at upper rail"
    ],
    triggerLogic: "High == Donchian Upper with upper wick > 0"
  },
  {
    id: "IND_29",
    indicatorNumber: 29,
    signal: "CALL",
    setupName: "ATR Volatility Explosion (Call)",
    indicator: "ATR",
    avoidConditions: [
      "Near resistance level - volatility spike into resistance is risky",
      "Candle is not bullish - need direction confirmation"
    ],
    triggerLogic: "ATR > 1.5x ATR_Avg, bullish candle, not near resistance"
  },
  {
    id: "IND_30",
    indicatorNumber: 30,
    signal: "PUT",
    setupName: "ATR Volatility Explosion (Put)",
    indicator: "ATR",
    avoidConditions: [
      "Near support level - volatility spike into support is risky",
      "Candle is not bearish - need direction confirmation"
    ],
    triggerLogic: "ATR > 1.5x ATR_Avg, bearish candle, not near support"
  }
];

// =============================================================================
// INDICATOR RULES PART 4: SETUPS 31-36 (AO, Ichimoku, Vortex)
// =============================================================================

export const INDICATOR_RULES_31_TO_36: IndicatorAvoidRule[] = [
  {
    id: "IND_31",
    indicatorNumber: 31,
    signal: "CALL",
    setupName: "Awesome Oscillator Saucer (Buy)",
    indicator: "AO",
    avoidConditions: [
      "AO bars are tiny (< 0.0001) - flat market, no real momentum",
      "Pattern not above zero line - saucer must be in bullish territory"
    ],
    triggerLogic: "Red bar followed by 2 green bars, all > 0, bars significant size (> 0.0001)"
  },
  {
    id: "IND_32",
    indicatorNumber: 32,
    signal: "PUT",
    setupName: "Awesome Oscillator Saucer (Sell)",
    indicator: "AO",
    avoidConditions: [
      "AO bars are tiny (< 0.0001) - flat market, no real momentum",
      "Pattern not below zero line - saucer must be in bearish territory"
    ],
    triggerLogic: "Green bar followed by 2 red bars, all < 0, bars significant size (> 0.0001)"
  },
  {
    id: "IND_33",
    indicatorNumber: 33,
    signal: "CALL",
    setupName: "Ichimoku Cloud Breakout (Bullish)",
    indicator: "Ichimoku",
    avoidConditions: [
      "Chikou Span not above price - lagging span must confirm by being above current price"
    ],
    triggerLogic: "Close > Cloud Top with Chikou Span > price"
  },
  {
    id: "IND_34",
    indicatorNumber: 34,
    signal: "PUT",
    setupName: "Ichimoku Cloud Breakout (Bearish)",
    indicator: "Ichimoku",
    avoidConditions: [
      "Chikou Span not below price - lagging span must confirm by being below current price"
    ],
    triggerLogic: "Close < Cloud Bottom with Chikou Span < price"
  },
  {
    id: "IND_35",
    indicatorNumber: 35,
    signal: "CALL",
    setupName: "Vortex Indicator Cross (Bullish)",
    indicator: "Vortex",
    avoidConditions: [
      "ADX < 20 - trend strength too weak for valid vortex cross"
    ],
    triggerLogic: "VI+ > VI- AND VI+_Prev <= VI-_Prev with ADX > 20"
  },
  {
    id: "IND_36",
    indicatorNumber: 36,
    signal: "PUT",
    setupName: "Vortex Indicator Cross (Bearish)",
    indicator: "Vortex",
    avoidConditions: [
      "ADX < 20 - trend strength too weak for valid vortex cross"
    ],
    triggerLogic: "VI- > VI+ AND VI-_Prev <= VI+_Prev with ADX > 20"
  }
];

// =============================================================================
// COMBINED INDICATOR AVOID RULES (ALL 1-36)
// =============================================================================

export const ALL_INDICATOR_AVOID_RULES: IndicatorAvoidRule[] = [
  ...INDICATOR_RULES_1_TO_10,
  ...INDICATOR_RULES_11_TO_20,
  ...INDICATOR_RULES_21_TO_30,
  ...INDICATOR_RULES_31_TO_36
];

// =============================================================================
// INDICATOR HELPER FUNCTIONS
// =============================================================================

export function getIndicatorAvoidRulesForSetup(indicatorNumber: number): IndicatorAvoidRule | undefined {
  return ALL_INDICATOR_AVOID_RULES.find(rule => rule.indicatorNumber === indicatorNumber);
}

export function getIndicatorAvoidConditions(indicatorNumber: number): string[] {
  const rule = getIndicatorAvoidRulesForSetup(indicatorNumber);
  return rule?.avoidConditions || [];
}

export function getIndicatorRulesByName(setupName: string): IndicatorAvoidRule | undefined {
  return ALL_INDICATOR_AVOID_RULES.find(rule => 
    rule.setupName.toLowerCase().includes(setupName.toLowerCase())
  );
}

export function getIndicatorRulesByType(indicator: IndicatorAvoidRule['indicator']): IndicatorAvoidRule[] {
  return ALL_INDICATOR_AVOID_RULES.filter(rule => rule.indicator === indicator);
}

export function getTotalIndicatorAvoidRulesCount(): number {
  return ALL_INDICATOR_AVOID_RULES.length;
}

// =============================================================================
// HTF (HIGHER TIMEFRAME) AVOID RULES: 20 MASTER HTF STRATEGIES
// =============================================================================
// Higher timeframe analysis with specific avoid conditions for each strategy.
// Uses 5M and 15M timeframe data for institutional-level analysis.
// =============================================================================

export interface HTFAvoidRule {
  id: string;
  htfNumber: number;
  signal: 'CALL' | 'PUT' | 'REVERSAL' | 'CONTINUATION';
  setupName: string;
  category: 'Wick' | 'FVG' | 'RoundNumber' | 'OrderBlock' | 'Liquidity' | 'Time' | 'Pattern' | 'RSI' | 'Volume' | 'BB' | 'ATR' | 'EMA' | 'Structure';
  timeframe: '5M' | '15M' | 'Both';
  avoidConditions: string[];
  triggerLogic: string;
}

// =============================================================================
// HTF RULES PART 1: STRATEGIES 1-10
// =============================================================================

export const HTF_RULES_1_TO_10: HTFAvoidRule[] = [
  {
    id: "HTF_1",
    htfNumber: 1,
    signal: "CONTINUATION",
    setupName: "Wick-Fill Magnet (Institutional Liquidity)",
    category: "Wick",
    timeframe: "Both",
    avoidConditions: [
      "1M candle is strong counter-momentum Marubozu (size > HTF body) - counter-trend rejection active",
      "Wick < 60% of body size - not a significant institutional wick"
    ],
    triggerLogic: "5M/15M wick > 60% of body, no 1M counter-momentum Marubozu, target wick fill"
  },
  {
    id: "HTF_2",
    htfNumber: 2,
    signal: "CONTINUATION",
    setupName: "FVG 50% Symmetrizer (The Void Logic)",
    category: "FVG",
    timeframe: "15M",
    avoidConditions: [
      "Heading UP to midpoint but RSI > 70 - overbought, don't buy into resistance",
      "Heading DOWN to midpoint but RSI < 30 - oversold, don't sell into support",
      "15M body < 2x average body - not a large enough expansion for FVG"
    ],
    triggerLogic: "15M Marubozu > 2x avg body, price > 2 pips from midpoint, RSI allows direction"
  },
  {
    id: "HTF_3",
    htfNumber: 3,
    signal: "CONTINUATION",
    setupName: "Round Number Magnet (Gravity Pillar)",
    category: "RoundNumber",
    timeframe: "Both",
    avoidConditions: [
      "EMA 200 sits between price and target magnet (.000/.500) - obstacle blocking path",
      "Distance > 3 pips from round number - too far for magnet effect"
    ],
    triggerLogic: "Within 3 pips of .000 or .500, no EMA200 obstacle between price and target"
  },
  {
    id: "HTF_4",
    htfNumber: 4,
    signal: "REVERSAL",
    setupName: "OB Mean Threshold (Order Block Target)",
    category: "OrderBlock",
    timeframe: "15M",
    avoidConditions: [
      "OB has been touched before (touch count > 0) - only trade 1st touch, multiple touches = weak zone"
    ],
    triggerLogic: "Price at 15M OB mean threshold (± 1 pip), fresh OB (0 prior touches)"
  },
  {
    id: "HTF_5",
    htfNumber: 5,
    signal: "CONTINUATION",
    setupName: "Liquidity Sweep (S/R Break-and-Reclaim)",
    category: "Liquidity",
    timeframe: "15M",
    avoidConditions: [
      "Close remains OUTSIDE the level (not reclaiming) - this is a real breakout, not a sweep",
      "Break distance < 3 pips - insufficient sweep for confirmation"
    ],
    triggerLogic: "Sweep > 3 pips beyond 15M S/R level with close back inside (reclaim)"
  },
  {
    id: "HTF_6",
    htfNumber: 6,
    signal: "CONTINUATION",
    setupName: "Near-Miss Breakout (First Bounce Trap)",
    category: "Liquidity",
    timeframe: "15M",
    avoidConditions: [
      "Volume > 2x average - high volume will likely smash the level instead of bouncing",
      "Distance not in 1-2 pip range - outside near-miss zone"
    ],
    triggerLogic: "Price 1-2 pips from 15M S/R level with normal volume (< 2x avg)"
  },
  {
    id: "HTF_7",
    htfNumber: 7,
    signal: "REVERSAL",
    setupName: "Time-Window Reset (Temporal Reversal)",
    category: "Time",
    timeframe: "Both",
    avoidConditions: [
      "1M candle has no wicks (solid Marubozu) - momentum may continue, no rejection structure",
      "Not at :00, :15, :30, or :45 minute mark within 5 seconds - no algo reset window"
    ],
    triggerLogic: "Minute at 0/15/30/45 within 5 seconds, 1M candle shows rejection wick"
  },
  {
    id: "HTF_8",
    htfNumber: 8,
    signal: "CONTINUATION",
    setupName: "V-Shape Mirroring (15M Symmetry)",
    category: "Pattern",
    timeframe: "15M",
    avoidConditions: [
      "Recovery candles are tiny (< avg body) - weak momentum, symmetry won't complete",
      "No pinbar on 1M chart - missing reversal confirmation"
    ],
    triggerLogic: "Within symmetry time of 15M drop, 1M pinbar present, recovery candles >= avg body"
  },
  {
    id: "HTF_9",
    htfNumber: 9,
    signal: "CONTINUATION",
    setupName: "Color Switching Fatigue (Burnout Pillar)",
    category: "Pattern",
    timeframe: "15M",
    avoidConditions: [
      "ADX > 30 - strong trend, not fatigue/chop, color switching is trend continuation",
      "Less than 4 color switches in last 5 candles - not enough fatigue"
    ],
    triggerLogic: "4+ color switches in last 5 15M candles (R-G-R-G-R), ADX < 30"
  },
  {
    id: "HTF_10",
    htfNumber: 10,
    signal: "REVERSAL",
    setupName: "HTF RSI Lock (Momentum Anchor)",
    category: "RSI",
    timeframe: "15M",
    avoidConditions: [
      "For PUT: price not below 1M EMA9 - need confirmation cross before shorting",
      "For CALL: price not above 1M EMA9 - need confirmation cross before buying",
      "15M RSI not at extreme (not >= 90 for PUT, not <= 10 for CALL) - no momentum lock"
    ],
    triggerLogic: "15M RSI >= 90 with price < EMA9 (PUT) OR 15M RSI <= 10 with price > EMA9 (CALL)"
  }
];

// =============================================================================
// HTF RULES PART 2: STRATEGIES 11-20
// =============================================================================

export const HTF_RULES_11_TO_20: HTFAvoidRule[] = [
  {
    id: "HTF_11",
    htfNumber: 11,
    signal: "REVERSAL",
    setupName: "Vol-Price Divergence (The Hollow Move)",
    category: "Volume",
    timeframe: "15M",
    avoidConditions: [
      "Volume drop < 10% (current > prev * 0.9) - volume drop not significant enough",
      "Current body <= previous body - no expansion to create divergence"
    ],
    triggerLogic: "15M current body > prev body with volume < 90% of previous (hollow expansion)"
  },
  {
    id: "HTF_12",
    htfNumber: 12,
    signal: "REVERSAL",
    setupName: "BB Outer Walk Exit (Mean Reversion Extreme)",
    category: "BB",
    timeframe: "15M",
    avoidConditions: [
      "ATR > 2x average ATR - parabolic move, do not fade extreme volatility",
      "15M candle not fully detached from Bollinger Band - not a true walk"
    ],
    triggerLogic: "15M low > BB Upper (PUT) or high < BB Lower (CALL) with ATR < 2x avg"
  },
  {
    id: "HTF_13",
    htfNumber: 13,
    signal: "CONTINUATION",
    setupName: "Godzilla Vacuum (ATR Expansion)",
    category: "ATR",
    timeframe: "15M",
    avoidConditions: [
      "Major S/R level was broken by Godzilla candle - this is breakout momentum, not vacuum",
      "Candle has wicks - true Godzilla is a Marubozu with zero wicks",
      "Body < 3x average body - not large enough for Godzilla classification"
    ],
    triggerLogic: "15M body >= 3x avg with zero wicks (Marubozu), no major level broken"
  },
  {
    id: "HTF_14",
    htfNumber: 14,
    signal: "CONTINUATION",
    setupName: "Doji Compression Spring (Volatility Squeeze)",
    category: "Pattern",
    timeframe: "15M",
    avoidConditions: [
      "Pre-squeeze direction is CALL but price < EMA200 - counter-trend to major trend",
      "Pre-squeeze direction is PUT but price > EMA200 - counter-trend to major trend",
      "Less than 3 consecutive Dojis - compression not established"
    ],
    triggerLogic: "3+ consecutive 15M Dojis (body < 10% of range), follow pre-squeeze direction aligned with EMA200"
  },
  {
    id: "HTF_15",
    htfNumber: 15,
    signal: "CONTINUATION",
    setupName: "Fractal Symmetry Break (Structural Failure)",
    category: "Structure",
    timeframe: "15M",
    avoidConditions: [
      "Bullish break but upper wick > body size - rejection wick invalidates breakout",
      "Bearish break but lower wick > body size - rejection wick invalidates breakout"
    ],
    triggerLogic: "15M pattern broken with break candle showing strong close (wick < body)"
  },
  {
    id: "HTF_16",
    htfNumber: 16,
    signal: "REVERSAL",
    setupName: "Session Range Sweep (Macro Liquidity Hunt)",
    category: "Liquidity",
    timeframe: "Both",
    avoidConditions: [
      "Within first 5 minutes of London Open (8:00) or NY Open (13:00) - high volatility period, avoid",
      "Sweep < 3 pips beyond session high/low - not a significant sweep",
      "Close remains outside session range - real breakout, not sweep"
    ],
    triggerLogic: "Sweep > 3 pips beyond session high/low with close back inside, not during session open"
  },
  {
    id: "HTF_17",
    htfNumber: 17,
    signal: "CONTINUATION",
    setupName: "HTF Inside Bar Trap (The Mother Bar Squeeze)",
    category: "Pattern",
    timeframe: "15M",
    avoidConditions: [
      "Breakout volume < average volume - low volume breakout is a fakeout",
      "Current 15M candle not an inside bar (high >= prev high OR low <= prev low)"
    ],
    triggerLogic: "15M inside bar present, 1M breaks mother bar high/low with volume > avg"
  },
  {
    id: "HTF_18",
    htfNumber: 18,
    signal: "REVERSAL",
    setupName: "EMA Mean Reversion (The 20-Pip Debt Rule)",
    category: "EMA",
    timeframe: "15M",
    avoidConditions: [
      "News event active - volatility can extend debt to 40+ pips, avoid",
      "Distance from 15M EMA50 < 20 pips - not enough debt accumulated"
    ],
    triggerLogic: "Price >= 20 pips from 15M EMA50, no news event active"
  },
  {
    id: "HTF_19",
    htfNumber: 19,
    signal: "REVERSAL",
    setupName: "Three-Push Exhaustion (Staircase Fatigue)",
    category: "Pattern",
    timeframe: "15M",
    avoidConditions: [
      "3rd push didn't touch round number (> 1 pip away) - might push 4th time to complete magnet",
      "Wave count < 3 - exhaustion requires 3 complete waves"
    ],
    triggerLogic: "3+ waves detected on 15M, 3rd push touched round number (within 1 pip)"
  },
  {
    id: "HTF_20",
    htfNumber: 20,
    signal: "REVERSAL",
    setupName: "Algorithmic Book Reset (Hourly Turn Pivot)",
    category: "Time",
    timeframe: "Both",
    avoidConditions: [
      "Price > 2 pips from 15M S/R level - not at a key level, reset logic is weak",
      "Not at :00 minute mark - no hourly algo reset window"
    ],
    triggerLogic: "At :00 minute mark with price within 2 pips of 15M S/R level"
  }
];

// =============================================================================
// COMBINED HTF AVOID RULES (ALL 1-20)
// =============================================================================

export const ALL_HTF_AVOID_RULES: HTFAvoidRule[] = [
  ...HTF_RULES_1_TO_10,
  ...HTF_RULES_11_TO_20
];

// =============================================================================
// HTF HELPER FUNCTIONS
// =============================================================================

export function getHTFAvoidRulesForSetup(htfNumber: number): HTFAvoidRule | undefined {
  return ALL_HTF_AVOID_RULES.find(rule => rule.htfNumber === htfNumber);
}

export function getHTFAvoidConditions(htfNumber: number): string[] {
  const rule = getHTFAvoidRulesForSetup(htfNumber);
  return rule?.avoidConditions || [];
}

export function getHTFRulesByName(setupName: string): HTFAvoidRule | undefined {
  return ALL_HTF_AVOID_RULES.find(rule => 
    rule.setupName.toLowerCase().includes(setupName.toLowerCase())
  );
}

export function getHTFRulesByCategory(category: HTFAvoidRule['category']): HTFAvoidRule[] {
  return ALL_HTF_AVOID_RULES.filter(rule => rule.category === category);
}

export function getHTFRulesByTimeframe(timeframe: HTFAvoidRule['timeframe']): HTFAvoidRule[] {
  return ALL_HTF_AVOID_RULES.filter(rule => rule.timeframe === timeframe || rule.timeframe === 'Both');
}

export function getTotalHTFAvoidRulesCount(): number {
  return ALL_HTF_AVOID_RULES.length;
}

// =============================================================================
// PRICE ACTION 27 STRATEGY SPECIFIC AVOID RULES
// =============================================================================
// Universal Global Trap Scanner - 27 strategies for price action pattern recognition
// Each strategy has specific AVOID conditions to filter out false signals
// =============================================================================

export interface PriceActionAvoidRule {
  id: string;
  strategyNumber: number;
  signal: 'CALL' | 'PUT' | 'REVERSAL' | 'CONTINUATION' | 'BOTH';
  setupName: string;
  category: 'Wick' | 'S/R' | 'Gap' | 'Cycle' | 'Round' | 'FVG' | 'Doji' | 'Liquidity' | 'Pattern' | 'RSI' | 'Level' | 'Volume' | 'EMA' | 'Time' | 'Range';
  avoidConditions: string[];
  triggerLogic: string;
}

// =============================================================================
// PRICE ACTION RULES 1-10 (Universal Trap Scanner Module 1)
// =============================================================================

export const PRICE_ACTION_RULES_1_TO_10: PriceActionAvoidRule[] = [
  {
    id: "PA_1",
    strategyNumber: 1,
    signal: "BOTH",
    setupName: "Universal Wick-Fill (Liquidity Neutralization)",
    category: "Wick",
    avoidConditions: [
      "RSI4 < 10 or RSI4 > 90 - extreme RSI means reversal likely, not fill",
      "Body > 3x average body - news candle, too volatile for wick-fill trade",
      "Wick < 60% of body - not significant enough to trigger fill logic"
    ],
    triggerLogic: "Wick > 60% of body, RSI4 between 10-90, body < 3x avg body"
  },
  {
    id: "PA_2",
    strategyNumber: 2,
    signal: "REVERSAL",
    setupName: "Universal S/R Siphon (Clean Break Trap)",
    category: "S/R",
    avoidConditions: [
      "Breakout body > 3x average body - real momentum breakout, not a trap",
      "Volume >= average volume - confirmed breakout with volume",
      "Range > body * 1.05 - not a clean Marubozu break"
    ],
    triggerLogic: "Clean break (close past level), Marubozu style (range <= body * 1.05), low volume"
  },
  {
    id: "PA_3",
    strategyNumber: 3,
    signal: "BOTH",
    setupName: "Universal Jump Gap (Algorithm Continuity)",
    category: "Gap",
    avoidConditions: [
      "Gap >= 5 pips - runaway gap indicating trend continuation, do not fade",
      "Gap < 0.5 pip - gap too small to trigger algo gap logic",
      "Not hitting S/R level - gap needs S/R context for trap signal"
    ],
    triggerLogic: "Gap between 0.5-5 pips with price hitting resistance (PUT) or support (CALL)"
  },
  {
    id: "PA_4",
    strategyNumber: 4,
    signal: "BOTH",
    setupName: "Universal 3-5 Color Cycle (Momentum Drain)",
    category: "Cycle",
    avoidConditions: [
      "ADX > 40 - trend too strong to predict cycle end at count 3",
      "RSI not between 25-75 for cycle 3 - need confirmation of range-bound market",
      "Cycle 5 requires RSI > 80 or < 20 - needs extreme RSI for 6th candle reversal"
    ],
    triggerLogic: "Cycle 3: Follow color if ADX < 40 and RSI 25-75. Cycle 5: Reverse on 6th if RSI extreme"
  },
  {
    id: "PA_5",
    strategyNumber: 5,
    signal: "BOTH",
    setupName: "Universal Round Number Magnet (.000 / .500)",
    category: "Round",
    avoidConditions: [
      "Body < 0.5 pip - choppy market with tiny candles, magnet won't pull price",
      "Distance > 3 pips from .000/.500 - not close enough for magnet effect",
      "Not at BB extremes - magnet touch without BB context lacks reversal confirmation"
    ],
    triggerLogic: "Within 3 pips of .000/.500, body > 0.5 pip. BB extreme = reverse, otherwise accelerate"
  },
  {
    id: "PA_6",
    strategyNumber: 6,
    signal: "BOTH",
    setupName: "Universal FVG Symmetrizer (Institutional Gap)",
    category: "FVG",
    avoidConditions: [
      "Body < 2.5x average body - candle not large enough for FVG classification",
      "Price already crossed the 50% midpoint - immediate invalidation of FVG target"
    ],
    triggerLogic: "Giant candle (body > 2.5x avg), return target = (high + low) / 2 midpoint"
  },
  {
    id: "PA_7",
    strategyNumber: 7,
    signal: "CONTINUATION",
    setupName: "Universal Binary Doji Reset",
    category: "Doji",
    avoidConditions: [
      "ADX <= 25 - need strong trend for Doji to signal continuation",
      "Previous candle body >= 3x average body - Godzilla predecessor means Doji is exhaustion, not continuation",
      "Body > 10% of range - not a valid Doji (needs tiny body)"
    ],
    triggerLogic: "Doji (body <= 10% range), ADX > 25, previous candle body < 3x avg"
  },
  {
    id: "PA_8",
    strategyNumber: 8,
    signal: "BOTH",
    setupName: "Universal Liquidity Sweep (Double Top/Bottom)",
    category: "Liquidity",
    avoidConditions: [
      "Close is exactly on the level (< 1 pip gap) - breakout buildup, not sweep completion",
      "Sweep > 3 pips beyond level - too deep for sweep, likely real breakout",
      "Sweep candle color doesn't confirm - need red close for PUT sweep, green for CALL"
    ],
    triggerLogic: "Sweep high > level + 3 pips, close < level = PUT. Sweep low < level - 3 pips, close > level = CALL"
  },
  {
    id: "PA_9",
    strategyNumber: 9,
    signal: "REVERSAL",
    setupName: "Universal M-W Exhaustion",
    category: "Pattern",
    avoidConditions: [
      "Leg 2 range >= 3x Leg 1 range - massive leg indicates trend change, not exhaustion reversal",
      "Not a valid M/W formation - requires clear double top/bottom structure"
    ],
    triggerLogic: "M/W formation with Leg 2 > Leg 1 but < 3x Leg 1 range"
  },
  {
    id: "PA_10",
    strategyNumber: 10,
    signal: "BOTH",
    setupName: "Universal RSI Algorithm Lock",
    category: "RSI",
    avoidConditions: [
      "Body <= 30% of range - spinning top/Doji at EMA9 cross, wait for clarity",
      "RSI not at extreme (10-90) - no algo lock active",
      "Price not crossing EMA9 - no unlock trigger"
    ],
    triggerLogic: "RSI > 90 or < 10 (locked). EMA9 cross with body > 30% range = unlock reversal"
  }
];

// =============================================================================
// PRICE ACTION RULES 11-20 (Universal Trap Scanner Module 2)
// =============================================================================

export const PRICE_ACTION_RULES_11_TO_20: PriceActionAvoidRule[] = [
  {
    id: "PA_11",
    strategyNumber: 11,
    signal: "REVERSAL",
    setupName: "Universal Z-Level (Flip Level Pivot)",
    category: "Level",
    avoidConditions: [
      "Level touched > 5 times recently - dead zone, level has lost significance",
      "Distance > 2 pips from Z-level - not close enough for reaction"
    ],
    triggerLogic: "Within 2 pips of recent flip level, touch count < 5"
  },
  {
    id: "PA_12",
    strategyNumber: 12,
    signal: "CONTINUATION",
    setupName: "Universal Institutional Stop Hunt (4th Touch Rule)",
    category: "Level",
    avoidConditions: [
      "Steep approach angle with 3+ same color candles - wait for pullback before breakout trade",
      "Touch count != 4 - 4th touch is the institutional stop hunt trigger"
    ],
    triggerLogic: "4th touch of level detected, expect stop hunt breakout"
  },
  {
    id: "PA_13",
    strategyNumber: 13,
    signal: "CALL",
    setupName: "Universal Invalidated Rejection (The 99% Bridge)",
    category: "Wick",
    avoidConditions: [
      "Current candle upper wick >= body - inverted hammer (weak filler), bridge likely fails",
      "Previous candle upper wick <= 60% of body - not a valid rejection wick setup",
      "Current close not inside previous wick zone - bridge not forming"
    ],
    triggerLogic: "Prev candle has 60%+ rejection wick, current bullish closes inside wick with upper wick < body"
  },
  {
    id: "PA_14",
    strategyNumber: 14,
    signal: "CONTINUATION",
    setupName: "Universal Vacuum Effect (ATR Expansion)",
    category: "Volume",
    avoidConditions: [
      "Round number (.000) immediately ahead - vacuum stalls at major level",
      "Body <= 3x 10-candle average body - not enough expansion for vacuum effect"
    ],
    triggerLogic: "Body > 3x avg(10 candles), no round number ahead = continuation signal"
  },
  {
    id: "PA_15",
    strategyNumber: 15,
    signal: "CONTINUATION",
    setupName: "Universal Color Switching Fatigue (Zig-Zag End)",
    category: "Pattern",
    avoidConditions: [
      "ADX <= 30 - choppy ADX means random market, fatigue pattern unreliable",
      "Color switches < 4 in last 5 candles - not enough alternation for fatigue signal",
      "Not at EMA or S/R level - needs confluence for color repeat expectation"
    ],
    triggerLogic: "4+ color switches in 5 candles, ADX > 30, at EMA or S/R = expect color repeat"
  },
  {
    id: "PA_16",
    strategyNumber: 16,
    signal: "REVERSAL",
    setupName: "Universal Exhaustion Escalator (Godzilla Candle)",
    category: "Volume",
    avoidConditions: [
      "Major level was broken by Godzilla candle - breakout momentum, not exhaustion",
      "Previous 4 candles not roughly equal size (> 20% variance) - no escalator pattern",
      "Current body < 2x average of previous 4 - not a true Godzilla expansion"
    ],
    triggerLogic: "4 equal-sized candles followed by 2x expansion (Godzilla), no major level broken"
  },
  {
    id: "PA_17",
    strategyNumber: 17,
    signal: "CONTINUATION",
    setupName: "Universal Micro-Gap Magnet",
    category: "Gap",
    avoidConditions: [
      "Gap >= previous body size - slingshot gap, not a micro-gap",
      "Gap < 1 pip or > 3 pips - outside micro-gap range (1-3 pips)",
      "Gap direction conflicts with previous candle color - no bridge alignment"
    ],
    triggerLogic: "Micro-gap (1-3 pips), gap < prev body, gap direction matches prev candle color"
  },
  {
    id: "PA_18",
    strategyNumber: 18,
    signal: "CONTINUATION",
    setupName: "Universal Fractal Symmetry Break",
    category: "Pattern",
    avoidConditions: [
      "Break candle has zero volume - ignore the break, no conviction",
      "No symmetry pattern detected (e.g., RR-G, RR-G) in last 7 candles"
    ],
    triggerLogic: "Symmetry pattern in candles[-7:-1], 7th candle breaks pattern, volume > 0"
  },
  {
    id: "PA_19",
    strategyNumber: 19,
    signal: "REVERSAL",
    setupName: "Universal Volatility Spike Snap-Back",
    category: "Time",
    avoidConditions: [
      "News event at :00/:30 mark - snap-back fails during major news volatility",
      "Not at round number (> 2 pips from .000) - needs round number confluence",
      "Not outside Bollinger Bands - no volatility spike detected",
      "Not at :00 or :30 minute mark - no temporal snap-back window"
    ],
    triggerLogic: "At :00/:30 minute, outside BB, within 2 pips of .000, no news = 3M snap-back reversal"
  },
  {
    id: "PA_20",
    strategyNumber: 20,
    signal: "CONTINUATION",
    setupName: "Universal Near-Miss Breakout",
    category: "Level",
    avoidConditions: [
      "Wick already touched level - not a 'miss', invalidates near-miss logic",
      "Distance from level < 1 pip or > 2 pips - outside near-miss range (1-2 pips)"
    ],
    triggerLogic: "Price within 1-2 pips of level without touching = expect delayed breakout"
  }
];

// =============================================================================
// PRICE ACTION RULES 21-27 (Universal Trap Scanner Module 3)
// =============================================================================

export const PRICE_ACTION_RULES_21_TO_27: PriceActionAvoidRule[] = [
  {
    id: "PA_21",
    strategyNumber: 21,
    signal: "CONTINUATION",
    setupName: "Universal Doji Compression Spring",
    category: "Doji",
    avoidConditions: [
      "Less than 3 consecutive Dojis (body <= 15% of range) - compression not established",
      "Gap opening on next candle - spring release invalidated by gap"
    ],
    triggerLogic: "3 consecutive Dojis, follow pre-compression candle direction (green = CALL, red = PUT)"
  },
  {
    id: "PA_22",
    strategyNumber: 22,
    signal: "BOTH",
    setupName: "Universal Ribbon Kiss Continuation",
    category: "EMA",
    avoidConditions: [
      "EMA5 crosses EMA13 - not a kiss, it's a breakdown signal",
      "EMAs not parallel (EMA5 > EMA13 > EMA21 or vice versa) - no ribbon alignment",
      "Distance between EMA5 and EMA13 < 1 pip - too close, potential crossover"
    ],
    triggerLogic: "Parallel EMAs, price touches EMA13 and closes on trend side = ribbon kiss continuation"
  },
  {
    id: "PA_23",
    strategyNumber: 23,
    signal: "REVERSAL",
    setupName: "Universal Round Number Liquidity Flush",
    category: "Round",
    avoidConditions: [
      "Body > 25% of range - solid body close, not a rejection wick (needs wick > 75% of range)",
      "Distance past round level < 5 pips or > 8 pips - outside flush zone (5-8 pips)"
    ],
    triggerLogic: "5-8 pips past round level with rejection wick > 75% of range = liquidity flush reversal"
  },
  {
    id: "PA_24",
    strategyNumber: 24,
    signal: "BOTH",
    setupName: "Universal Second-Leg Exhaustion (M/W Trap)",
    category: "Pattern",
    avoidConditions: [
      "RSI not divergent - W pattern needs RSI higher low (RSI > leg1_RSI + 5), M needs lower high",
      "No valid M or W pattern structure detected in recent candles",
      "Second leg didn't exceed first leg level - no liquidity grab"
    ],
    triggerLogic: "W: low < leg1_level with RSI divergence = CALL. M: high > leg1_level with RSI divergence = PUT"
  },
  {
    id: "PA_25",
    strategyNumber: 25,
    signal: "REVERSAL",
    setupName: "Universal Time-Window Reset",
    category: "Time",
    avoidConditions: [
      "1M candle is Marubozu (body >= 80% of range) - high momentum overrides time reset",
      "Not at :00 or :30 minute mark - no algo reset window",
      "Not at 15M S/R level - time reset needs level confluence for valid signal"
    ],
    triggerLogic: "At :00/:30 minute, at 15M S/R level, 1M candle body < 80% range = algo time reset reversal"
  },
  {
    id: "PA_26",
    strategyNumber: 26,
    signal: "REVERSAL",
    setupName: "Universal Micro-Range Expansion",
    category: "Range",
    avoidConditions: [
      "Breakout distance >= 2 pips - real breakout, not a fakeout",
      "Range of last 8 candles > 3 pips - not a tight micro-range box"
    ],
    triggerLogic: "Tight 8-candle range (< 3 pips), breakout < 2 pips = micro-range fakeout reversal"
  },
  {
    id: "PA_27",
    strategyNumber: 27,
    signal: "BOTH",
    setupName: "Universal Volume-Price Divergence (Hollow Move)",
    category: "Volume",
    avoidConditions: [
      "Volume increased compared to previous candle - real move with volume confirmation, not hollow",
      "Body <= 2x 10-candle average body - not enough expansion for hollow move detection"
    ],
    triggerLogic: "Body > 2x avg(10), volume dropped = hollow move (green = PUT, red = CALL)"
  }
];

// =============================================================================
// COMBINED PRICE ACTION AVOID RULES (ALL 1-27)
// =============================================================================

export const ALL_PRICE_ACTION_AVOID_RULES: PriceActionAvoidRule[] = [
  ...PRICE_ACTION_RULES_1_TO_10,
  ...PRICE_ACTION_RULES_11_TO_20,
  ...PRICE_ACTION_RULES_21_TO_27
];

// =============================================================================
// PRICE ACTION HELPER FUNCTIONS
// =============================================================================

export function getPriceActionAvoidRulesForSetup(strategyNumber: number): PriceActionAvoidRule | undefined {
  return ALL_PRICE_ACTION_AVOID_RULES.find(rule => rule.strategyNumber === strategyNumber);
}

export function getPriceActionAvoidConditions(strategyNumber: number): string[] {
  const rule = getPriceActionAvoidRulesForSetup(strategyNumber);
  return rule?.avoidConditions || [];
}

export function getPriceActionRulesByName(setupName: string): PriceActionAvoidRule | undefined {
  return ALL_PRICE_ACTION_AVOID_RULES.find(rule => 
    rule.setupName.toLowerCase().includes(setupName.toLowerCase())
  );
}

export function getPriceActionRulesByCategory(category: PriceActionAvoidRule['category']): PriceActionAvoidRule[] {
  return ALL_PRICE_ACTION_AVOID_RULES.filter(rule => rule.category === category);
}

export function getTotalPriceActionAvoidRulesCount(): number {
  return ALL_PRICE_ACTION_AVOID_RULES.length;
}

// =============================================================================
// COMBINED AVOID RULES (ALL 1-235)
// =============================================================================

export const ALL_AVOID_RULES: AvoidRule[] = [
  ...AVOID_RULES_1_TO_20,
  ...AVOID_RULES_21_TO_40,
  ...AVOID_RULES_41_TO_60,
  ...AVOID_RULES_68_TO_80,
  ...AVOID_RULES_81_TO_90,
  ...AVOID_RULES_91_TO_100,
  ...AVOID_RULES_101_TO_150,
  ...AVOID_RULES_151_TO_166,
  ...AVOID_RULES_166_TO_184,
  ...AVOID_RULES_185_TO_215,
  ...AVOID_RULES_216_TO_235
];

// =============================================================================
// HELPER: Get Avoid Rules for a specific setup
// =============================================================================

export function getAvoidRulesForSetup(setupNumber: number): AvoidRule | undefined {
  return ALL_AVOID_RULES.find(rule => rule.setupNumber === setupNumber);
}

// =============================================================================
// HELPER: Get all Avoid conditions for a setup number
// =============================================================================

export function getAvoidConditions(setupNumber: number): string[] {
  const rule = getAvoidRulesForSetup(setupNumber);
  return rule?.avoidConditions || [];
}

// =============================================================================
// HELPER: Check if setup has avoid rules defined
// =============================================================================

export function hasAvoidRules(setupNumber: number): boolean {
  const rule = getAvoidRulesForSetup(setupNumber);
  return rule !== undefined && rule.avoidConditions.length > 0;
}

// =============================================================================
// HELPER: Get setup by name (for matching when numbers don't align)
// =============================================================================

export function getAvoidRulesByName(setupName: string): AvoidRule | undefined {
  return ALL_AVOID_RULES.find(rule => 
    rule.setupName.toLowerCase().includes(setupName.toLowerCase())
  );
}

// =============================================================================
// HELPER: Get total count of avoid rules
// =============================================================================

export function getTotalAvoidRulesCount(): number {
  return ALL_AVOID_RULES.length;
}

export function getTotalSMCAvoidRulesCount(): number {
  return ALL_SMC_AVOID_RULES.length;
}
