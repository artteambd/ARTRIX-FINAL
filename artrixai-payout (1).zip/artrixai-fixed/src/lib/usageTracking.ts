export type UsageKind = 'signal' | 'analysis';

export const USAGE_UPDATED_EVENT = 'artrix:usage-updated';

type UsageStore = {
  date: string; // YYYY-MM-DD
  signal: number;
  analysis: number;
};

const STORAGE_KEY = 'artrix_usage_today_v1';

function todayKey(d = new Date()): string {
  // ISO date in local time (avoid UTC shifting)
  const local = new Date(d);
  local.setHours(0, 0, 0, 0);
  const y = local.getFullYear();
  const m = String(local.getMonth() + 1).padStart(2, '0');
  const day = String(local.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function safeReadStore(): UsageStore {
  const today = todayKey();

  if (typeof window === 'undefined') {
    return { date: today, signal: 0, analysis: 0 };
  }

  const raw = window.localStorage.getItem(STORAGE_KEY);
  if (!raw) return { date: today, signal: 0, analysis: 0 };

  try {
    const parsed = JSON.parse(raw) as Partial<UsageStore>;

    if (parsed.date !== today) {
      return { date: today, signal: 0, analysis: 0 };
    }

    return {
      date: today,
      signal: Math.max(0, Number(parsed.signal ?? 0) || 0),
      analysis: Math.max(0, Number(parsed.analysis ?? 0) || 0),
    };
  } catch {
    return { date: today, signal: 0, analysis: 0 };
  }
}

function safeWriteStore(store: UsageStore) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
  window.dispatchEvent(new Event(USAGE_UPDATED_EVENT));
}

export function getTodayUsage(): { signal: number; analysis: number } {
  const s = safeReadStore();
  return { signal: s.signal, analysis: s.analysis };
}

export function incrementTodayUsage(kind: UsageKind, amount = 1): { signal: number; analysis: number } {
  const current = safeReadStore();
  const delta = Number(amount) || 0;

  const next: UsageStore = {
    ...current,
    [kind]: Math.max(0, (current[kind] ?? 0) + delta),
  } as UsageStore;

  safeWriteStore(next);
  return { signal: next.signal, analysis: next.analysis };
}
