import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft,
  Receipt,
  Crown,
  Zap,
  Star,
  Diamond,
  Rocket,
  Sparkles,
  MessageCircle,
  ExternalLink,
  X,
  Calendar,
  Clock,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Package } from '@/types';
import { calculateExpiryDate, formatExpiryDate } from '@/lib/licenseUtils';

const packages: Package[] = [
  {
    id: 'nano',
    name: 'Nano',
    tier: 'nano',
    credits: 25,
    price: 5,
    pricePerAnalysis: 0.2,
    color: 'cyan',
    icon: 'zap',
    durationDays: 15,
    durationLabel: 'Valid for 15 Days',
  },
  {
    id: 'starter',
    name: 'Starter',
    tier: 'starter',
    credits: 100,
    price: 10,
    pricePerAnalysis: 0.1,
    color: 'pink',
    icon: 'star',
    durationDays: 30,
    durationLabel: 'Valid for 1 Month',
  },
  {
    id: 'popular',
    name: 'Most Popular',
    tier: 'popular',
    credits: 150,
    price: 25,
    pricePerAnalysis: 0.167,
    color: 'orange',
    icon: 'crown',
    popular: true,
    durationDays: 45,
    durationLabel: 'Valid for 1.5 Months',
  },
  {
    id: 'expert',
    name: 'Expert',
    tier: 'expert',
    credits: 300,
    price: 50,
    pricePerAnalysis: 0.167,
    color: 'emerald',
    icon: 'diamond',
    durationDays: 60,
    durationLabel: 'Valid for 2 Months',
  },
  {
    id: 'investor',
    name: 'Investor',
    tier: 'investor',
    credits: 500,
    price: 100,
    pricePerAnalysis: 0.2,
    color: 'rose',
    icon: 'sparkles',
    durationDays: 90,
    durationLabel: 'Valid for 3 Months',
  },
];

const getPackageIcon = (icon: string, className: string) => {
  switch (icon) {
    case 'zap':
      return <Zap className={className} />;
    case 'star':
      return <Star className={className} />;
    case 'crown':
      return <Crown className={className} />;
    case 'diamond':
      return <Diamond className={className} />;
    case 'sparkles':
      return <Rocket className={className} />;
    default:
      return <Zap className={className} />;
  }
};

const getPackageColors = (color: string) => {
  switch (color) {
    case 'cyan':
      return { bg: 'bg-cyan-500/20', text: 'text-cyan-400', border: 'border-cyan-500/30' };
    case 'pink':
      return { bg: 'bg-pink-500/20', text: 'text-pink-400', border: 'border-pink-500/30' };
    case 'orange':
      return { bg: 'bg-orange-500/20', text: 'text-orange-400', border: 'border-orange-500/30' };
    case 'emerald':
      return { bg: 'bg-emerald-500/20', text: 'text-emerald-400', border: 'border-emerald-500/30' };
    case 'rose':
      return { bg: 'bg-rose-500/20', text: 'text-rose-400', border: 'border-rose-500/30' };
    default:
      return { bg: 'bg-primary/20', text: 'text-primary', border: 'border-primary/30' };
  }
};

export default function Credits() {
  const navigate = useNavigate();
  const [selectedPackage, setSelectedPackage] = useState<Package | null>(null);

  const handleSelectPackage = (pkg: Package) => {
    setSelectedPackage(pkg);
  };

  const handleContactTelegram = () => {
    window.open('https://t.me/Ariyan_trader10', '_blank');
  };

  return (
    <div className="min-h-screen pb-8">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between px-4 py-4"
      >
        <div className="flex items-center gap-3">
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => navigate('/dashboard')}
            className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </motion.button>
          <div>
            <h1 className="text-xl font-bold text-primary">VIP Credits</h1>
            <p className="text-xs text-muted-foreground">Premium packages</p>
          </div>
        </div>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => navigate('/transactions')}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-secondary/50 border border-border/50"
        >
          <Receipt className="w-4 h-4 text-foreground" />
          <span className="text-sm font-medium">My Transactions</span>
        </motion.button>
      </motion.header>

      {/* Badge */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        className="flex justify-center mt-4"
      >
        <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-put/20 border border-put/30">
          <Crown className="w-4 h-4 text-put" />
          <span className="text-sm font-semibold text-put">VIP MEMBERSHIP</span>
        </div>
      </motion.div>

      {/* Title */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="text-center mt-6 mb-8"
      >
        <h2 className="text-2xl font-bold text-foreground">Choose Your Package</h2>
        <p className="text-muted-foreground mt-2">Unlock premium AI chart analysis</p>
      </motion.div>

      {/* Packages Grid */}
      <div className="px-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {packages.map((pkg, index) => {
          const colors = getPackageColors(pkg.color);
          return (
            <motion.div
              key={pkg.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 * index }}
              className={`relative glass-card glow-border p-6 ${
                pkg.popular ? 'border-orange-500/50' : ''
              }`}
            >
              {pkg.popular && (
                <div className="absolute -top-2 -right-2 px-2 py-1 bg-put text-put-foreground text-xs font-bold rounded-md">
                  HOT
                </div>
              )}

              <div className="flex flex-col items-center text-center">
                <div className={`w-14 h-14 rounded-xl ${colors.bg} flex items-center justify-center mb-4`}>
                  {getPackageIcon(pkg.icon, `w-7 h-7 ${colors.text}`)}
                </div>

                <h3 className="text-lg font-bold text-foreground">{pkg.name}</h3>

                <div className="flex items-center gap-1 mt-2">
                  <Sparkles className="w-4 h-4 text-primary" />
                  <span className="text-xl font-bold text-foreground">{pkg.credits}</span>
                  <span className="text-muted-foreground">Credits</span>
                </div>

                <p className="text-sm text-muted-foreground mt-1">
                  <span className="font-semibold text-foreground">{pkg.durationLabel}</span>
                </p>

                <p className="text-2xl font-bold text-primary mt-2">${pkg.price}</p>
                <p className="text-xs text-muted-foreground">
                  ${pkg.pricePerAnalysis.toFixed(3)} per analysis
                </p>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleSelectPackage(pkg)}
                  className="w-full mt-4 py-3 rounded-xl font-semibold bg-primary text-primary-foreground btn-glow"
                >
                  Select Package
                </motion.button>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Package Dialog */}
      <AnimatePresence>
        {selectedPackage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4 z-50"
            onClick={() => setSelectedPackage(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-card glow-border p-6 w-full max-w-sm relative"
            >
              <button
                onClick={() => setSelectedPackage(null)}
                className="absolute top-4 right-4 text-muted-foreground hover:text-foreground"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex flex-col items-center text-center">
                {/* Telegram Icon */}
                <div className="w-16 h-16 rounded-2xl bg-blue-500 flex items-center justify-center mb-4">
                  <MessageCircle className="w-8 h-8 text-white" />
                </div>

                {/* Package Badge */}
                <div
                  className={`flex items-center gap-2 px-3 py-1 rounded-full mb-4 ${
                    getPackageColors(selectedPackage.color).bg
                  }`}
                >
                  {getPackageIcon(
                    selectedPackage.icon,
                    `w-4 h-4 ${getPackageColors(selectedPackage.color).text}`
                  )}
                  <span className={`text-sm font-semibold ${getPackageColors(selectedPackage.color).text}`}>
                    {selectedPackage.name}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-foreground">
                  Upgrade to {selectedPackage.credits} Credits
                </h3>
                <p className="text-2xl font-bold text-primary mt-2">${selectedPackage.price}</p>

                {/* License Validity Info */}
                <div className="w-full mt-4 p-3 rounded-xl bg-secondary/50 border border-border/50">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="w-4 h-4 text-primary" />
                    <span className="text-sm font-semibold text-foreground">License Validity</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Duration:</span>
                    <span className="font-medium text-foreground">{selectedPackage.durationLabel}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm mt-1">
                    <span className="text-muted-foreground">Valid until:</span>
                    <span className="font-medium text-call">
                      {formatExpiryDate(calculateExpiryDate(selectedPackage.durationDays))}
                    </span>
                  </div>
                </div>

                {/* Warning about expiry */}
                <div className="flex items-start gap-2 mt-3 p-2 rounded-lg bg-put/10 border border-put/20">
                  <Calendar className="w-4 h-4 text-put mt-0.5 flex-shrink-0" />
                  <p className="text-xs text-put">
                    Credits expire when license ends. Use before expiry.
                  </p>
                </div>

                <p className="text-sm text-muted-foreground mt-4 mb-4">
                  To upgrade your package, please contact our admin on Telegram. Only verified payments
                  through admin are accepted.
                </p>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleContactTelegram}
                  className="w-full py-3 rounded-xl font-semibold bg-blue-500 text-white flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>Contact on Telegram</span>
                  <ExternalLink className="w-4 h-4" />
                </motion.button>

                <p className="text-sm text-muted-foreground mt-4">@Ariyan_trader10</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8 }}
        className="text-center text-xs text-muted-foreground mt-8"
      >
        Powered by <span className="text-primary font-semibold">ART TRADER TEAM</span>
      </motion.p>
    </div>
  );
}
