import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Zap, Check, ChevronDown, Send, Pencil, Clock, Rocket, Diamond, X, Search } from 'lucide-react';
import { Header } from '@/components/Header';
import { useAuth } from '@/contexts/AuthContext';
import { incrementTodayUsage } from '@/lib/usageTracking';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { FutureSignalLoadingAnimation } from '@/components/FutureSignalLoadingAnimation';

// QUOTEX Available OTC pairs - 56 pairs
const OTC_PAIRS = [
  'AUDCAD-OTC', 'AUDJPY-OTC', 'AUDNZD-OTC', 'AUDUSD-OTC',
  'BRLUSD-OTC', 'CADCHF-OTC', 'CADJPY-OTC', 'CHFJPY-OTC',
  'EURAUD-OTC', 'EURCAD-OTC', 'EURCHF-OTC', 'EURGBP-OTC', 'EURJPY-OTC',
  'EURNZD-OTC', 'EURSGD-OTC', 'EURUSD-OTC', 'GBPAUD-OTC', 'GBPCAD-OTC',
  'GBPCHF-OTC', 'GBPJPY-OTC', 'GBPUSD-OTC', 'NZDUSD-OTC', 'USDARS-OTC',
  'USDBDT-OTC', 'USDCAD-OTC', 'USDCHF-OTC', 'USDEGP-OTC', 'USDGBP-OTC',
  'USDIDR-OTC', 'USDINR-OTC', 'USDJPY-OTC', 'USDMXN-OTC', 'USDNGN-OTC',
  'USDPKR-OTC', 'USDTRY-OTC', 'USDZAR-OTC', 'USDPHP-OTC',
  'BTCUSD-OTC', 'BCHUSD-OTC', 'ARBUSD-OTC', 'ZECUSD-OTC', 'ATOUSD-OTC', 'AXSUSD-OTC',
  'XAUUSD-OTC', 'XAGUSD-OTC', 'USCrude-OTC', 'UKBrent-OTC', 'FLOUSD-OTC',
  'AXP-OTC', 'PFE-OTC', 'INTL-OTC', 'JNJ-OTC', 'MCD-OTC', 'FB-OTC', 'BA-OTC', 'MSFT-OTC'
];

const REAL_PAIRS = [
  'EUR/USD', 'GBP/USD', 'USD/JPY', 'AUD/USD', 'USD/CAD',
  'NZD/USD', 'EUR/GBP', 'EUR/JPY', 'EUR/AUD', 'GBP/JPY',
  'AUD/CAD', 'AUD/CHF', 'AUD/JPY', 'AUD/NZD', 'CAD/CHF',
  'CAD/JPY', 'CHF/JPY', 'EUR/CAD', 'EUR/CHF', 'EUR/NZD',
  'GBP/AUD', 'GBP/CAD', 'GBP/CHF', 'GBP/NZD', 'NZD/CAD', 'NZD/JPY'
];

const getPairDisplayName = (pair: string) => pair.replace('-OTC', '');

interface FutureSignal {
  pair: string;
  time: string;
  direction: 'CALL' | 'PUT';
  confidence: number;
  reasoning?: string;
  market_overview?: string;
  backtest_winrate?: number;
  explosive_potential?: string;
  statistical_edge?: number;
  price_action_grade?: string;
  dimensions_confirmed?: number;
  key_findings?: string[];
  risk_factors?: string[];
  martingale?: string;
}

// Copper/Rose-gold color palette
const COLORS = {
  copper: '#c9956c',
  copperLight: '#e8b896',
  copperDark: '#8b5a3c',
  copperGlow: 'rgba(201, 149, 108, 0.4)',
  darkBg: '#1a1614',
  cardBg: '#1e1a18',
  inputBg: '#151210',
  borderCopper: '#7a5a45',
  textMuted: '#8a8078',
  textLight: '#d4c4b8',
};

export default function FutureSignal() {
  const navigate = useNavigate();
  const { user, isLoading, useCredit } = useAuth();
  
  const [pairMode, setPairMode] = useState<'otc' | 'real'>('otc');
  const [selectedPairs, setSelectedPairs] = useState<string[]>([...OTC_PAIRS]);
  const [startTime, setStartTime] = useState('16:10');
  const [endTime, setEndTime] = useState('17:30');
  const [countDays, setCountDays] = useState(7);
  const [filterEnabled, setFilterEnabled] = useState(0);
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [showAnimation, setShowAnimation] = useState(false);
  const [signals, setSignals] = useState<FutureSignal[]>([]);
  const [copied, setCopied] = useState(false);
  const [isPairSelectorOpen, setIsPairSelectorOpen] = useState(false);
  const [pairSearchQuery, setPairSearchQuery] = useState('');
  const pairSelectorRef = useRef<HTMLDivElement>(null);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [analysisComplete, setAnalysisComplete] = useState(false);
  const [analysisStatus, setAnalysisStatus] = useState('');
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const elapsedRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (pairSelectorRef.current && !pairSelectorRef.current.contains(e.target as Node)) {
        setIsPairSelectorOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (!isLoading && !user) navigate('/');
  }, [user, isLoading, navigate]);

  const togglePair = (pair: string) => {
    setSelectedPairs(prev => 
      prev.includes(pair) ? prev.filter(p => p !== pair) : [...prev, pair]
    );
  };

  const selectAllPairs = () => {
    setSelectedPairs([...(pairMode === 'otc' ? OTC_PAIRS : REAL_PAIRS)]);
  };

  const deselectAllPairs = () => setSelectedPairs([]);

  const filteredPairsList = (pairMode === 'otc' ? OTC_PAIRS : REAL_PAIRS).filter(p =>
    getPairDisplayName(p).toLowerCase().includes(pairSearchQuery.toLowerCase())
  );

  const pollIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const stopPolling = () => {
    if (pollIntervalRef.current) { clearInterval(pollIntervalRef.current); pollIntervalRef.current = null; }
    if (elapsedRef.current) { clearInterval(elapsedRef.current); elapsedRef.current = null; }
  };

  const handleGenerate = async () => {
    if (!user || user.credits <= 0) {
      toast.error('No credits remaining');
      navigate('/credits');
      return;
    }
    if (selectedPairs.length === 0) {
      toast.error('Please select at least 1 pair');
      return;
    }

    const creditUsed = useCredit();
    if (!creditUsed) {
      toast.error('Failed to use credit');
      return;
    }

    incrementTodayUsage('signal');
    setShowAnimation(true);
    setIsGenerating(true);
    setSignals([]);
    setAnalysisProgress(0);
    setAnalysisComplete(false);
    setAnalysisStatus('🧬 Initializing QUANTUM-NEXUS V14...');
    setElapsedSeconds(0);
    stopPolling();
    // Only elapsed timer - NO fake progress
    elapsedRef.current = setInterval(() => {
      setElapsedSeconds(s => s + 1);
    }, 1000);

    try {
      const allSignals: FutureSignal[] = [];
      
      // ═══ BATCH PAIRS IN GROUPS OF 2 ═══
      const batches: string[][] = [];
      for (let i = 0; i < selectedPairs.length; i += 2) {
        batches.push(selectedPairs.slice(i, i + 2));
      }

      const totalBatches = batches.length;
      console.log(`[Future] Starting ${totalBatches} batches (${selectedPairs.length} pairs, 2 per batch)`);

      for (let batchIdx = 0; batchIdx < totalBatches; batchIdx++) {
        const batch = batches[batchIdx];
        const pairNames = batch.map(p => p.replace('-OTC', '')).join(' + ');
        
        setAnalysisStatus(`🧠 Analyzing ${pairNames}... (${batchIdx + 1}/${totalBatches})`);

        try {
          // ═══ FIRE EDGE FUNCTION & POLL REAL PROGRESS FROM DB ═══
          // Start the edge function call (runs synchronously server-side)
          const edgeFunctionPromise = supabase.functions.invoke('future-signal', {
            body: { action: 'start', pairs: batch, startTime, endTime }
          });

          // Poll processing_jobs table for REAL progress updates
          // Wait a moment for the job to be created in DB
          await new Promise(r => setTimeout(r, 1500));
          
          // Find the latest processing job
          const { data: latestJob } = await supabase
            .from('processing_jobs')
            .select('id')
            .eq('status', 'processing')
            .order('created_at', { ascending: false })
            .limit(1)
            .single();

          const jobId = latestJob?.id;
          
          if (jobId) {
            console.log(`[Future] Polling real progress for job ${jobId}`);
            // Poll DB for real progress every 3 seconds
            pollIntervalRef.current = setInterval(async () => {
              try {
                const { data: jobData } = await supabase
                  .from('processing_jobs')
                  .select('progress, status')
                  .eq('id', jobId)
                  .single();
                
                if (jobData) {
                  // Map per-batch progress to overall progress
                  const batchBaseProgress = (batchIdx / totalBatches) * 100;
                  const batchWeight = 100 / totalBatches;
                  const overallProgress = batchBaseProgress + (jobData.progress / 100) * batchWeight;
                  setAnalysisProgress(Math.min(95, Math.round(overallProgress)));
                  
                  // Update status text based on real DB progress
                  if (jobData.progress <= 20) {
                    setAnalysisStatus(`📡 Fetching candle data for ${pairNames}... (${batchIdx + 1}/${totalBatches})`);
                  } else if (jobData.progress <= 35) {
                    setAnalysisStatus(`🔬 Calculating technical indicators for ${pairNames}...`);
                  } else if (jobData.progress <= 40) {
                    setAnalysisStatus(`🧠 Building 50-step analysis prompt for ${pairNames}...`);
                  } else if (jobData.progress <= 88) {
                    setAnalysisStatus(`🔮 AI deep analysis in progress for ${pairNames}... (${jobData.progress}%)`);
                  } else if (jobData.progress <= 92) {
                    setAnalysisStatus(`📦 Parsing AI response for ${pairNames}...`);
                  } else {
                    setAnalysisStatus(`✅ Finalizing signals for ${pairNames}...`);
                  }
                  
                  if (jobData.status === 'completed' || jobData.status === 'failed') {
                    if (pollIntervalRef.current) {
                      clearInterval(pollIntervalRef.current);
                      pollIntervalRef.current = null;
                    }
                  }
                }
              } catch {}
            }, 3000);
          }

          // Get the jobId from the edge function response (returns immediately now)
          const { data: resultData, error: callError } = await edgeFunctionPromise;
          
          if (callError) {
            console.error(`Batch ${batchIdx + 1} error:`, callError);
            if (pollIntervalRef.current) {
              clearInterval(pollIntervalRef.current);
              pollIntervalRef.current = null;
            }
            continue;
          }

          // Get jobId from response or from DB
          const responseJobId = resultData?.jobId || jobId;
          
          if (!responseJobId) {
            console.error(`Batch ${batchIdx + 1}: No jobId returned`);
            continue;
          }

          // Stop the progress-only polling interval
          if (pollIntervalRef.current) {
            clearInterval(pollIntervalRef.current);
            pollIntervalRef.current = null;
          }

          // Poll until job completes (it runs in background now)
          console.log(`[Future] Waiting for background job ${responseJobId} to complete...`);
          let finalResult: any = null;
          const maxPollTime = 5 * 60 * 1000; // 5 minutes max
          const pollStart = Date.now();
          
          while (Date.now() - pollStart < maxPollTime) {
            await new Promise(r => setTimeout(r, 3000));
            
            const { data: jobData } = await supabase
              .from('processing_jobs')
              .select('progress, status, result, error')
              .eq('id', responseJobId)
              .single();
            
            if (!jobData) continue;
            
            // Update progress UI
            const batchBaseProgress = (batchIdx / totalBatches) * 100;
            const batchWeight = 100 / totalBatches;
            const overallProgress = batchBaseProgress + (jobData.progress / 100) * batchWeight;
            setAnalysisProgress(Math.min(95, Math.round(overallProgress)));
            
            if (jobData.progress <= 20) {
              setAnalysisStatus(`📡 Fetching candle data for ${pairNames}... (${batchIdx + 1}/${totalBatches})`);
            } else if (jobData.progress <= 35) {
              setAnalysisStatus(`🔬 Calculating technical indicators for ${pairNames}...`);
            } else if (jobData.progress <= 40) {
              setAnalysisStatus(`🧠 Building 50-step analysis prompt for ${pairNames}...`);
            } else if (jobData.progress <= 88) {
              setAnalysisStatus(`🔮 AI deep analysis in progress for ${pairNames}... (${jobData.progress}%)`);
            } else if (jobData.progress <= 92) {
              setAnalysisStatus(`📦 Parsing AI response for ${pairNames}...`);
            } else {
              setAnalysisStatus(`✅ Finalizing signals for ${pairNames}...`);
            }
            
            if (jobData.status === 'completed') {
              finalResult = jobData.result;
              break;
            }
            if (jobData.status === 'failed') {
              console.error(`Batch ${batchIdx + 1} job failed:`, jobData.error);
              break;
            }
          }

          // Update progress based on batch completion
          const batchProgress = Math.round(((batchIdx + 1) / totalBatches) * 95);
          setAnalysisProgress(Math.min(95, batchProgress));

          // Extract signals from result
          const result = finalResult;
          if (result?.success && result?.signals?.length > 0) {
            for (const sig of result.signals) {
              allSignals.push({
                pair: sig.pair,
                time: sig.entry_time,
                direction: sig.direction,
                confidence: sig.confidence,
                reasoning: sig.reasoning,
                market_overview: sig.market_overview,
                backtest_winrate: sig.backtest_winrate,
                explosive_potential: sig.explosive_potential,
                statistical_edge: sig.statistical_edge,
                price_action_grade: sig.price_action_grade,
                dimensions_confirmed: sig.dimensions_confirmed,
                key_findings: sig.key_findings,
                risk_factors: sig.risk_factors,
                martingale: sig.martingale || 'MG1',
              });
            }
            console.log(`[Future] Batch ${batchIdx + 1}: ${result.signals.length} signals from ${pairNames}`);
          } else {
            console.log(`[Future] Batch ${batchIdx + 1}: No signals from ${pairNames}`, finalResult);
          }
        } catch (batchErr) {
          console.error(`Batch ${batchIdx + 1} failed:`, batchErr);
          if (pollIntervalRef.current) {
            clearInterval(pollIntervalRef.current);
            pollIntervalRef.current = null;
          }
        }
      }

      // Sort signals by time
      allSignals.sort((a, b) => {
        const [ah, am] = a.time.split(':').map(Number);
        const [bh, bm] = b.time.split(':').map(Number);
        return (ah * 60 + am) - (bh * 60 + bm);
      });

      setAnalysisProgress(100);
      setAnalysisComplete(true);
      setSignals(allSignals);
      setAnalysisStatus(`🏆 ${allSignals.length} signals confirmed from ${selectedPairs.length} pairs`);

      if (allSignals.length > 0) {
        toast.success(`🏆 ${allSignals.length} signals confirmed by QUANTUM-NEXUS V14`);
      } else {
        toast.error('No signals generated — AI could not find tradeable setups for these pairs');
      }

      setTimeout(() => {
        setShowAnimation(false);
        setIsGenerating(false);
        stopPolling();
      }, 1500);

    } catch (err) {
      console.error('Error generating future signals:', err);
      toast.error('Failed to generate signals');
      setShowAnimation(false);
      setIsGenerating(false);
      stopPolling();
    }
  };

  const formatPairDisplay = (pair: string) => {
    const name = pair.replace('-OTC', '');
    if (name.length === 6 && /^[A-Z]+$/.test(name)) {
      return `${name.slice(0, 3)}/${name.slice(3)}-OTC`;
    }
    return `${name}-OTC`;
  };

  const handleCopy = () => {
    if (signals.length === 0) return;
    const lines = [
      `⚡️✨━━━━━━━━━━━━━━━━━━✨⚡️`,
      `  📊 💀 ARTIRIX  𝗕𝗥𝗨𝗧𝗔𝗟 𝗙𝗨𝗧𝗨𝗥𝗘 𝗦𝗜𝗚𝗡𝗔𝗟𝗦 💀 🌐`,
      `⚡️✨━━━━━━━━━━━━━━━━━━✨⚡️`,
      ``, `🕒 𝙏𝙄𝙈𝙀 𝙕𝙊𝙉𝙀: (𝙐𝙏𝘾 +06:00) 🇧🇩`,
      `🎯 𝙏𝙄𝙈𝙀𝙁𝙍𝘼𝙈𝙀: 1 𝙈𝙞𝙣𝙪𝙩𝙚`,
      `🔁 𝙈𝘼𝙍𝙏𝙄𝙉𝙂𝘼𝙇𝙀: 1 𝙎𝙩𝙚𝙥 (𝙞𝙛 𝙣𝙚𝙚𝙙𝙚𝙙)`,
      ``, `╔═══════▣🔥▣═══════╗`,
      `💹 𝗧𝗢𝗗𝗔𝗬'𝗦 𝗦𝗜𝗚𝗡𝗔𝗟 𝗟𝗜𝗡𝗘-𝗨𝗣 `,
      `╚═══════▣🔥▣═══════╝`, ``,
      ...signals.map(s => `❒ ${formatPairDisplay(s.pair)} ☞ ${s.time} ⊱ ${s.direction}`),
      ``, `⚡️✨━━━━━━━━━━━━━━━━━━✨⚡️`,
      `👑 𝙋𝙊𝙒𝙀𝙍𝙀𝘿 𝘽𝙔: ARTRIX 𝗕𝗥𝗨𝗧𝗔𝗟 𝗙𝗨𝗧𝗨𝗥𝗘`,
    ];
    navigator.clipboard.writeText(lines.join('\n'));
    setCopied(true);
    toast.success('Signals copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  if (!user) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen pb-24 w-full relative overflow-hidden"
      style={{ background: COLORS.darkBg }}
    >
      {/* Corner Diagonal Accents */}
      <div className="absolute top-0 left-0 w-32 h-32 md:w-48 md:h-48 pointer-events-none"
        style={{ background: `linear-gradient(135deg, ${COLORS.copperDark} 0%, transparent 60%)`, opacity: 0.6 }} />
      <div className="absolute top-0 right-0 w-32 h-32 md:w-48 md:h-48 pointer-events-none"
        style={{ background: `linear-gradient(225deg, ${COLORS.copperDark} 0%, transparent 60%)`, opacity: 0.6 }} />
      <div className="absolute bottom-0 left-0 w-32 h-32 md:w-48 md:h-48 pointer-events-none"
        style={{ background: `linear-gradient(45deg, ${COLORS.copperDark} 0%, transparent 60%)`, opacity: 0.6 }} />
      <div className="absolute bottom-0 right-0 w-32 h-32 md:w-48 md:h-48 pointer-events-none"
        style={{ background: `linear-gradient(315deg, ${COLORS.copperDark} 0%, transparent 60%)`, opacity: 0.6 }} />
      
      {/* Diagonal line accents */}
      <div className="absolute top-0 left-0 w-24 h-1 md:w-40 md:h-1 pointer-events-none origin-top-left rotate-45 translate-x-4 translate-y-8"
        style={{ background: `linear-gradient(90deg, ${COLORS.copper}, transparent)` }} />
      <div className="absolute top-0 right-0 w-24 h-1 md:w-40 md:h-1 pointer-events-none origin-top-right -rotate-45 -translate-x-4 translate-y-8"
        style={{ background: `linear-gradient(270deg, ${COLORS.copper}, transparent)` }} />
      <div className="absolute bottom-0 left-0 w-24 h-1 md:w-40 md:h-1 pointer-events-none origin-bottom-left -rotate-45 translate-x-4 -translate-y-8"
        style={{ background: `linear-gradient(90deg, ${COLORS.copper}, transparent)` }} />
      <div className="absolute bottom-0 right-0 w-24 h-1 md:w-40 md:h-1 pointer-events-none origin-bottom-right rotate-45 -translate-x-4 -translate-y-8"
        style={{ background: `linear-gradient(270deg, ${COLORS.copper}, transparent)` }} />

      <div className="relative z-10">
        <Header />

        <div className="max-w-xl mx-auto px-3 md:px-4 pt-4">
          {showAnimation ? (
            <FutureSignalLoadingAnimation 
              progress={analysisProgress} 
              isComplete={analysisComplete}
              statusText={analysisStatus}
              elapsedSeconds={elapsedSeconds}
              totalPairs={selectedPairs.length}
            />
          ) : (
            <>
              {/* Main Container */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                className="rounded-xl overflow-hidden relative"
                style={{
                  background: COLORS.cardBg,
                  border: `1px solid ${COLORS.borderCopper}`,
                  boxShadow: `0 0 40px ${COLORS.copperGlow}, inset 0 1px 0 rgba(255,255,255,0.03)`
                }}
              >
                <div className="absolute inset-0 pointer-events-none rounded-xl"
                  style={{ border: `1px solid ${COLORS.borderCopper}`, boxShadow: `inset 0 0 30px rgba(201, 149, 108, 0.1)` }} />

                {/* Header */}
                <div className="text-center py-5 md:py-6 px-4 relative">
                  <h1 className="text-xl md:text-3xl font-extrabold tracking-wider font-mono"
                    style={{ 
                      background: `linear-gradient(180deg, ${COLORS.copperLight} 0%, ${COLORS.copper} 50%, ${COLORS.copperDark} 100%)`,
                      WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
                      textShadow: `0 0 40px ${COLORS.copperGlow}`,
                    }}>
                    AI SIGNAL GENERATOR
                  </h1>
                  <p className="font-medium mt-1 tracking-[0.15em] md:tracking-[0.2em] text-xs md:text-sm font-mono"
                    style={{ color: COLORS.textMuted }}>
                    QUANTUM-NEXUS V14 • 50-STEP ULTRA-DEEP
                  </p>
                </div>

                {/* Branding Badges */}
                <div className="flex flex-wrap justify-center gap-2 md:gap-3 px-3 md:px-4 pb-2 md:pb-3">
                  <div className="px-3 md:px-4 py-1.5 md:py-2 rounded-full text-xs md:text-sm flex items-center gap-1.5 md:gap-2"
                    style={{ background: 'transparent', border: `1px solid ${COLORS.borderCopper}` }}>
                    <Rocket className="w-3 h-3 md:w-4 md:h-4" style={{ color: COLORS.copper }} />
                    <Diamond className="w-3 h-3 md:w-4 md:h-4" style={{ color: '#60a5fa' }} />
                    <span className="font-mono tracking-wide" style={{ color: COLORS.textLight }}>MADE BY TRAD WITH JAKARIA</span>
                  </div>
                  <div className="px-3 md:px-4 py-1.5 md:py-2 rounded-full text-xs md:text-sm flex items-center gap-1.5 md:gap-2"
                    style={{ background: 'transparent', border: `1px solid ${COLORS.borderCopper}` }}>
                    <Send className="w-3 h-3 md:w-4 md:h-4" style={{ color: COLORS.textLight }} />
                    <span className="font-mono tracking-wide" style={{ color: COLORS.textLight }}>@Tredwithjakaria</span>
                  </div>
                </div>

                <div className="flex flex-wrap justify-center gap-2 md:gap-3 px-3 md:px-4 pb-3 md:pb-4">
                  <div className="px-3 md:px-4 py-1.5 md:py-2 rounded-full text-xs md:text-sm flex items-center gap-1.5 md:gap-2"
                    style={{ background: 'transparent', border: `1px solid ${COLORS.borderCopper}` }}>
                    <Pencil className="w-3 h-3 md:w-4 md:h-4" style={{ color: COLORS.copper }} />
                    <span className="font-mono" style={{ color: COLORS.textLight }}>VERSION: v3.0</span>
                  </div>
                  <div className="px-3 md:px-4 py-1.5 md:py-2 rounded-full text-xs md:text-sm flex items-center gap-1.5 md:gap-2"
                    style={{ background: 'transparent', border: `1px solid ${COLORS.borderCopper}` }}>
                    <Zap className="w-3 h-3 md:w-4 md:h-4" style={{ color: COLORS.copper }} />
                    <span className="font-mono" style={{ color: COLORS.textLight }}>FAITH WITH POWER</span>
                  </div>
                  <div className="px-3 md:px-4 py-1.5 md:py-2 rounded-full text-xs md:text-sm flex items-center gap-1.5 md:gap-2"
                    style={{ background: 'transparent', border: `1px solid ${COLORS.borderCopper}` }}>
                    <Check className="w-3 h-3 md:w-4 md:h-4" style={{ color: COLORS.textLight }} />
                    <span className="font-mono" style={{ color: COLORS.textLight }}>QUALITY WITH QUANTITY</span>
                  </div>
                </div>

                {/* Form Controls */}
                <div className="px-3 md:px-5 py-4 md:py-5 space-y-3 md:space-y-4">
                  {/* Pair Selector */}
                  <div className="space-y-1" ref={pairSelectorRef}>
                    <label className="text-[10px] md:text-xs uppercase tracking-wider font-mono flex items-center justify-between"
                      style={{ color: COLORS.textMuted }}>
                      <span>SELECT PAIRS ({selectedPairs.length}/{pairMode === 'otc' ? OTC_PAIRS.length : REAL_PAIRS.length})</span>
                      <div className="flex gap-2">
                        <button onClick={selectAllPairs} className="text-[10px] font-mono px-1.5 py-0.5 rounded" style={{ color: COLORS.copper, border: `1px solid ${COLORS.borderCopper}` }}>ALL</button>
                        <button onClick={deselectAllPairs} className="text-[10px] font-mono px-1.5 py-0.5 rounded" style={{ color: COLORS.textMuted, border: `1px solid ${COLORS.borderCopper}` }}>NONE</button>
                      </div>
                    </label>
                    <button
                      onClick={() => setIsPairSelectorOpen(!isPairSelectorOpen)}
                      className="w-full p-2.5 md:p-3 rounded-lg text-left flex items-center justify-between font-mono text-sm md:text-base"
                      style={{ background: COLORS.inputBg, border: `1px solid ${COLORS.borderCopper}`, color: COLORS.textLight }}>
                      <span className="truncate">
                        {selectedPairs.length === 0 ? 'Select pairs...' 
                          : selectedPairs.length === (pairMode === 'otc' ? OTC_PAIRS.length : REAL_PAIRS.length)
                            ? `ALL ${selectedPairs.length} PAIRS`
                            : selectedPairs.slice(0, 3).map(getPairDisplayName).join(', ') + (selectedPairs.length > 3 ? ` +${selectedPairs.length - 3}` : '')}
                      </span>
                      <ChevronDown className={`w-4 h-4 transition-transform flex-shrink-0 ${isPairSelectorOpen ? 'rotate-180' : ''}`} style={{ color: COLORS.textMuted }} />
                    </button>
                    <AnimatePresence>
                      {isPairSelectorOpen && (
                        <motion.div initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }}
                          className="absolute left-3 right-3 md:left-5 md:right-5 mt-1 rounded-lg overflow-hidden z-50"
                          style={{ background: COLORS.cardBg, border: `1px solid ${COLORS.borderCopper}`, boxShadow: `0 8px 32px rgba(0,0,0,0.6)` }}>
                          <div className="p-2 border-b" style={{ borderColor: COLORS.borderCopper }}>
                            <div className="relative">
                              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5" style={{ color: COLORS.textMuted }} />
                              <input type="text" placeholder="Search pairs..." value={pairSearchQuery}
                                onChange={(e) => setPairSearchQuery(e.target.value)}
                                className="w-full pl-8 pr-3 py-2 rounded font-mono text-xs"
                                style={{ background: COLORS.inputBg, border: `1px solid ${COLORS.borderCopper}`, color: COLORS.textLight }}
                                autoFocus />
                            </div>
                          </div>
                          <div className="max-h-48 overflow-y-auto p-2 grid grid-cols-3 gap-1">
                            {filteredPairsList.map(pair => {
                              const isSelected = selectedPairs.includes(pair);
                              return (
                                <button key={pair} onClick={() => togglePair(pair)}
                                  className="px-2 py-1.5 rounded text-[11px] font-mono text-center transition-all"
                                  style={{
                                    background: isSelected ? 'rgba(201, 149, 108, 0.2)' : 'transparent',
                                    border: `1px solid ${isSelected ? COLORS.copper : COLORS.borderCopper}`,
                                    color: isSelected ? COLORS.copper : COLORS.textMuted,
                                  }}>
                                  {getPairDisplayName(pair)}
                                </button>
                              );
                            })}
                          </div>
                          <div className="p-2 border-t flex justify-between items-center" style={{ borderColor: COLORS.borderCopper }}>
                            <span className="text-[10px] font-mono" style={{ color: COLORS.textMuted }}>{selectedPairs.length} selected</span>
                            <button onClick={() => setIsPairSelectorOpen(false)}
                              className="text-[10px] font-mono px-3 py-1 rounded"
                              style={{ background: COLORS.copper, color: '#0a0a0a' }}>DONE</button>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* Time Row */}
                  <div className="grid grid-cols-2 gap-2 md:gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] md:text-xs uppercase tracking-wider font-mono" style={{ color: COLORS.textMuted }}>START</label>
                      <div className="relative">
                        <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)}
                          className="w-full p-2.5 md:p-3 rounded-lg font-mono text-sm md:text-base pr-8"
                          style={{ background: COLORS.inputBg, border: `1px solid ${COLORS.borderCopper}`, color: COLORS.textLight }} />
                        <Clock className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: COLORS.textMuted }} />
                      </div>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] md:text-xs uppercase tracking-wider font-mono" style={{ color: COLORS.textMuted }}>END</label>
                      <div className="relative">
                        <input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)}
                          className="w-full p-2.5 md:p-3 rounded-lg font-mono text-sm md:text-base pr-8"
                          style={{ background: COLORS.inputBg, border: `1px solid ${COLORS.borderCopper}`, color: COLORS.textLight }} />
                        <Clock className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: COLORS.textMuted }} />
                      </div>
                    </div>
                  </div>

                  {/* Info Row */}
                  <div className="grid grid-cols-3 gap-2 md:gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] md:text-xs uppercase tracking-wider font-mono" style={{ color: COLORS.textMuted }}>COUNT DAYS</label>
                      <input type="number" value={countDays} onChange={(e) => setCountDays(parseInt(e.target.value) || 7)}
                        min={1} max={30} className="w-full p-2.5 md:p-3 rounded-lg font-mono text-sm md:text-base"
                        style={{ background: COLORS.inputBg, border: `1px solid ${COLORS.borderCopper}`, color: COLORS.textLight }} />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] md:text-xs uppercase tracking-wider font-mono" style={{ color: COLORS.textMuted }}>FILTER (0=ON)</label>
                      <input type="number" value={filterEnabled} onChange={(e) => setFilterEnabled(parseInt(e.target.value) || 0)}
                        min={0} max={1} className="w-full p-2.5 md:p-3 rounded-lg font-mono text-sm md:text-base"
                        style={{ background: COLORS.inputBg, border: `1px solid ${COLORS.borderCopper}`, color: COLORS.textLight }} />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] md:text-xs uppercase tracking-wider font-mono" style={{ color: COLORS.textMuted }}>ENGINE</label>
                      <div className="w-full p-2.5 md:p-3 rounded-lg font-mono text-sm md:text-base flex items-center justify-center"
                        style={{ background: COLORS.inputBg, border: `1px solid ${COLORS.borderCopper}`, color: COLORS.copper }}>
                        V14 AI
                      </div>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="grid grid-cols-2 gap-3 md:gap-4 px-3 md:px-5 pb-4 md:pb-5">
                  <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                    onClick={handleGenerate} disabled={isGenerating}
                    className="py-3 md:py-4 rounded-xl font-bold text-sm md:text-base uppercase tracking-wider transition-all disabled:opacity-50 font-mono relative overflow-hidden"
                    style={{
                      background: `linear-gradient(180deg, ${COLORS.copperLight} 0%, ${COLORS.copper} 50%, ${COLORS.copperDark} 100%)`,
                      color: '#0a0a0a', boxShadow: `0 4px 20px ${COLORS.copperGlow}`, border: `1px solid ${COLORS.copperLight}`,
                    }}>
                    <span className="relative z-10">GENERATE</span>
                    <div className="absolute inset-0 opacity-30"
                      style={{ background: 'linear-gradient(110deg, transparent 30%, rgba(255,255,255,0.4) 50%, transparent 70%)' }} />
                  </motion.button>
                  <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                    onClick={handleCopy} disabled={signals.length === 0}
                    className="py-3 md:py-4 rounded-xl font-bold text-sm md:text-base uppercase tracking-wider transition-all disabled:opacity-50 font-mono relative overflow-hidden"
                    style={{
                      background: 'linear-gradient(180deg, #5a5a5a 0%, #3a3a3a 50%, #2a2a2a 100%)',
                      color: COLORS.textLight, boxShadow: '0 4px 20px rgba(0,0,0,0.4)', border: '1px solid #4a4a4a',
                    }}>
                    <span className="relative z-10">{copied ? 'COPIED!' : 'COPY'}</span>
                    <div className="absolute inset-0 opacity-20"
                      style={{ background: 'linear-gradient(110deg, transparent 30%, rgba(255,255,255,0.3) 50%, transparent 70%)' }} />
                  </motion.button>
                </div>

                {/* Results Section */}
                <div className="px-3 md:px-5 pb-4 md:pb-5">
                  <div className="rounded-xl overflow-hidden"
                    style={{ background: 'linear-gradient(180deg, #0d0d0d 0%, #111111 100%)', border: `1px solid ${COLORS.borderCopper}`, boxShadow: `0 0 30px rgba(201, 149, 108, 0.15)` }}>
                    {signals.length === 0 ? (
                      <div className="text-center py-8 md:py-10 font-mono" style={{ color: COLORS.textMuted }}>
                        <span className="text-lg">🧬</span>
                        <p className="mt-2 text-xs">Press GENERATE for QUANTUM-NEXUS V14 analysis</p>
                      </div>
                    ) : (
                      <div className="p-3 md:p-4 space-y-0.5 font-mono text-xs md:text-sm">
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center font-bold" style={{ color: COLORS.copper }}>
                          ⚡️✨━━━━━━━━━━━━━━━━━━✨⚡️
                        </motion.div>
                        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1 }}
                          className="text-center font-extrabold text-sm md:text-base py-1" style={{ color: '#ffffff' }}>
                          📊 💀 ARTIRIX <span style={{ color: COLORS.copper }}>𝗕𝗥𝗨𝗧𝗔𝗟 𝗙𝗨𝗧𝗨𝗥𝗘 𝗦𝗜𝗚𝗡𝗔𝗟𝗦</span> 💀 🌐
                        </motion.div>
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center font-bold" style={{ color: COLORS.copper }}>
                          ⚡️✨━━━━━━━━━━━━━━━━━━✨⚡️
                        </motion.div>
                        <div className="py-2 space-y-0.5">
                          <div style={{ color: '#e0e0e0' }} className="font-bold">🕒 𝙏𝙄𝙈𝙀 𝙕𝙊𝙉𝙀: <span style={{ color: COLORS.copperLight }}>(𝙐𝙏𝘾 +06:00)</span> 🇧🇩</div>
                          <div style={{ color: '#e0e0e0' }} className="font-bold">🎯 𝙏𝙄𝙈𝙀𝙁𝙍𝘼𝙈𝙀: <span style={{ color: COLORS.copperLight }}>1 𝙈𝙞𝙣𝙪𝙩𝙚</span></div>
                          <div style={{ color: '#e0e0e0' }} className="font-bold">🔁 𝙈𝘼𝙍𝙏𝙄𝙉𝙂𝘼𝙇𝙀: <span style={{ color: COLORS.copperLight }}>1 𝙎𝙩𝙚𝙥 (𝙞𝙛 𝙣𝙚𝙚𝙙𝙚𝙙)</span></div>
                        </div>
                        <div className="py-1">
                          <div className="text-center font-bold" style={{ color: COLORS.copper }}>╔═══════▣🔥▣═══════╗</div>
                          <div className="text-center font-extrabold py-0.5" style={{ color: '#ffffff' }}>💹 𝗧𝗢𝗗𝗔𝗬'𝗦 𝗦𝗜𝗚𝗡𝗔𝗟 𝗟𝗜𝗡𝗘-𝗨𝗣</div>
                          <div className="text-center font-bold" style={{ color: COLORS.copper }}>╚═══════▣🔥▣═══════╝</div>
                        </div>
                        <div className="py-1 space-y-1 max-h-[250px] md:max-h-[300px] overflow-y-auto">
                          {signals.map((signal, index) => (
                            <motion.div key={index} initial={{ opacity: 0, x: -15 }} animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: 0.3 + index * 0.06 }}
                              className="font-bold text-xs md:text-sm flex items-center gap-1"
                              style={{ color: signal.direction === 'CALL' ? '#4ade80' : '#f87171' }}>
                              <span style={{ color: '#9ca3af' }}>❒</span>
                              <span className="font-extrabold" style={{ color: '#e0e0e0' }}>{formatPairDisplay(signal.pair)}</span>
                              <span style={{ color: '#9ca3af' }}>☞</span>
                              <span style={{ color: COLORS.copperLight }} className="font-extrabold">{signal.time}</span>
                              <span style={{ color: '#9ca3af' }}>⊱</span>
                              <span className="font-extrabold"
                                style={{ color: signal.direction === 'CALL' ? '#4ade80' : '#f87171',
                                  textShadow: signal.direction === 'CALL' ? '0 0 8px rgba(74, 222, 128, 0.5)' : '0 0 8px rgba(248, 113, 113, 0.5)' }}>
                                {signal.direction}
                              </span>
                              {signal.confidence && (
                                <span className="text-[9px] ml-auto" style={{ color: COLORS.textMuted }}>{signal.confidence}%</span>
                              )}
                            </motion.div>
                          ))}
                        </div>
                        <div className="pt-2">
                          <div className="text-center font-bold" style={{ color: COLORS.copper }}>⚡️✨━━━━━━━━━━━━━━━━━━✨⚡️</div>
                          <div className="text-center font-extrabold py-1" style={{ color: '#ffffff' }}>
                            👑 𝙋𝙊𝙒𝙀𝙍𝙀𝘿 𝘽𝙔: ARTRIX <span style={{ color: COLORS.copper }}>𝗕𝗥𝗨𝗧𝗔𝗟 𝗙𝗨𝗧𝗨𝗥𝗘</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>

              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="text-center mt-4">
                <button onClick={() => navigate('/live-signal')}
                  className="text-xs md:text-sm transition-colors font-mono flex items-center justify-center gap-2 mx-auto"
                  style={{ color: COLORS.copper }}>
                  <span>←</span><span>Back to Live Signal</span>
                </button>
              </motion.div>
            </>
          )}
        </div>
      </div>
    </motion.div>
  );
}
