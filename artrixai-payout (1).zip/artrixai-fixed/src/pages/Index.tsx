import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Header } from '@/components/Header';
import { BottomNav } from '@/components/BottomNav';
import { ModeSwitch } from '@/components/ModeSwitch';
import { UploadCard } from '@/components/UploadCard';
import { AnalyzeButton } from '@/components/AnalyzeButton';
import { AnalysisResult } from '@/components/AnalysisResult';
import { TradeHistory } from '@/components/TradeHistory';
import { SignalLoadingAnimation } from '@/components/SignalLoadingAnimation';
import { LicenseStatus } from '@/components/LicenseStatus';
import { WarningBanner } from '@/components/WarningBanner';
import { useAuth } from '@/contexts/AuthContext';
import { TradingMode, AnalysisResult as AnalysisResultType } from '@/types';
import { useVoiceAnnouncement } from '@/hooks/useVoiceAnnouncement';
import { analyzeChartImage } from '@/lib/chartAnalysis';
import { incrementTodayUsage } from '@/lib/usageTracking';
import { isLicenseExpired } from '@/lib/licenseUtils';
import { toast } from 'sonner';
import { Bot, BotOff } from 'lucide-react';

export default function Index() {
  const navigate = useNavigate();
  const { user, isLoading, useCredit } = useAuth();
  const [mode, setMode] = useState<TradingMode>('binary');
  const [activeTab, setActiveTab] = useState<'gallery' | 'camera' | 'history'>('camera');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isAnalysisComplete, setIsAnalysisComplete] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResultType | null>(null);
  const [tradeHistory, setTradeHistory] = useState<AnalysisResultType[]>([]);
  const analysisStarted = useRef(false);
  const { announce: announceSignal } = useVoiceAnnouncement();
  const [chartAiMode, setChartAiMode] = useState(() => {
    try { return localStorage.getItem('artrix_chart_ai_mode') !== 'off'; } catch { return true; }
  });

  useEffect(() => {
    const savedHistory = localStorage.getItem('chartx_history');
    if (savedHistory) {
      setTradeHistory(JSON.parse(savedHistory));
    }
  }, []);

  useEffect(() => {
    if (!isLoading && !user) {
      navigate('/');
    }
  }, [user, isLoading, navigate]);

  const handleImageSelect = (imageUrl: string) => {
    setSelectedImage(imageUrl);
    setAnalysisResult(null);
  };

  const handleClearImage = () => {
    setSelectedImage(null);
    setAnalysisResult(null);
  };

  const handleAnalyze = async () => {
    if (!selectedImage) {
      toast.error('Please upload a chart image first');
      return;
    }

    if (!user || user.credits <= 0) {
      toast.error('No credits remaining. Please purchase more credits.');
      navigate('/credits');
      return;
    }

    if (isLicenseExpired(user.expiresAt)) {
      toast.error('Your license has expired. Please renew to continue.');
      navigate('/credits');
      return;
    }

    const creditUsed = useCredit();
    if (!creditUsed) {
      toast.error('Failed to use credit. License may have expired.');
      return;
    }

    incrementTodayUsage('analysis');
    setIsAnalyzing(true);
    setAnalysisResult(null);
    analysisStarted.current = false;

    // Start the actual analysis immediately (runs in parallel with loading animation)
    startAnalysis();
  };

  const startAnalysis = async () => {
    if (!selectedImage || !user || analysisStarted.current) return;
    analysisStarted.current = true;

    // Frontend timeout: if analysis doesn't complete within 180s, abort gracefully
    const analysisTimeout = setTimeout(() => {
      if (analysisStarted.current) {
        console.error('Analysis timed out after 180s');
        toast.error('Analysis timed out. The server took too long to respond. Please try again.');
        setIsAnalyzing(false);
        analysisStarted.current = false;
      }
    }, 180000);

    try {
      const result = await analyzeChartImage(selectedImage, mode, user.licenseKey, undefined, !chartAiMode);
      clearTimeout(analysisTimeout);
      
      if (!analysisStarted.current) return; // Already timed out
      
      result.imageUrl = selectedImage;
      
      setAnalysisResult(result);

      // Voice announcement for chart analysis result
      if (result.signal !== 'NO SIGNAL') {
        announceSignal({
          pair: result.pair || result.market || 'Unknown',
          direction: result.signal,
          confidence: result.confidence,
          payout: null,
        });
      }

      const newHistory = [result, ...tradeHistory].slice(0, 50);
      setTradeHistory(newHistory);
      localStorage.setItem('chartx_history', JSON.stringify(newHistory));

      setIsAnalyzing(false);
      setIsAnalysisComplete(true);
      
      setTimeout(() => {
        setIsAnalysisComplete(false);
      }, 3000);

      toast.success('Analysis complete!');
    } catch (error) {
      clearTimeout(analysisTimeout);
      console.error('Analysis failed:', error);
      toast.error('Analysis failed. Please try again.');
      setIsAnalyzing(false);
      analysisStarted.current = false;
    }
  };

  const handleUploadTrigger = () => {
    const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;
    if (fileInput) {
      fileInput.click();
    }
  };

  if (!user) return null;

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen pb-24 w-full"
    >
      {/* Background Effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-accent/5 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10">
        <Header />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <WarningBanner />
          <LicenseStatus />
          <ModeSwitch />

          <AnimatePresence mode="wait">
            {activeTab === 'history' ? (
              <TradeHistory key="history" history={tradeHistory} />
            ) : (
              <motion.div
                key="main"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-4 sm:space-y-6"
              >
                  {isAnalyzing ? (
                    <SignalLoadingAnimation isRealAnalysis={true} fastMode={!chartAiMode} />
                  ) : (
                    <>
                    <UploadCard
                      onImageSelect={handleImageSelect}
                      selectedImage={selectedImage}
                      onClear={handleClearImage}
                    />

                    {/* Analyze Button + AI Toggle Row */}
                    <div className="flex items-center gap-2">
                      <div className="flex-1">
                        <AnalyzeButton
                          isLoading={isAnalyzing}
                          disabled={!selectedImage}
                          onClick={handleAnalyze}
                          isComplete={isAnalysisComplete}
                        />
                      </div>

                      {/* AI Mode Toggle — live signal style */}
                      <motion.button
                        whileTap={{ scale: 0.9 }}
                        onClick={() => {
                          const next = !chartAiMode;
                          setChartAiMode(next);
                          try { localStorage.setItem('artrix_chart_ai_mode', next ? 'on' : 'off'); } catch {}
                          toast.info(next ? '🤖 AI Mode ON — Full AI chart analysis' : '⚡ Fast Mode — Code analysis + pair detection');
                        }}
                        className={`flex-shrink-0 w-14 h-14 rounded-xl flex flex-col items-center justify-center gap-0.5 border-2 transition-all relative overflow-hidden ${
                          chartAiMode
                            ? 'bg-blue-500/15 border-blue-500/60 text-blue-400 shadow-[0_0_16px_hsl(217,91%,60%,0.3)]'
                            : 'bg-emerald-500/15 border-emerald-500/60 text-emerald-400 shadow-[0_0_16px_hsl(152,69%,52%,0.25)]'
                        }`}
                        title={chartAiMode ? 'AI Mode ON — click for Fast Code Mode' : 'Fast Code Mode — click for AI Mode'}
                      >
                        {chartAiMode && (
                          <span className="absolute inset-0 rounded-xl border-2 border-blue-400/40 animate-ping pointer-events-none" />
                        )}
                        <span className={`absolute top-1.5 right-1.5 w-2 h-2 rounded-full ${chartAiMode ? 'bg-blue-400 animate-pulse' : 'bg-emerald-400'}`} />
                        {chartAiMode ? <Bot className="w-5 h-5" /> : <BotOff className="w-5 h-5" />}
                        <span className="text-[8px] font-bold leading-none tracking-wide">{chartAiMode ? 'AI ON' : 'AI OFF'}</span>
                      </motion.button>
                    </div>

                    {analysisResult && (
                      <AnalysisResult 
                        result={analysisResult} 
                        onNewAnalysis={() => {
                          setSelectedImage(null);
                          setAnalysisResult(null);
                        }}
                      />
                    )}
                  </>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <BottomNav
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onUpload={handleUploadTrigger}
      />
    </motion.div>
  );
}
