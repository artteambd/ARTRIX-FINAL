import { motion } from 'framer-motion';
import { TrendingUp, Sparkles, BarChart3, Activity, Globe, ChevronRight, Shield, Zap, Award, Users, ArrowRight, LogIn, UserPlus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
export default function Landing() {
  const navigate = useNavigate();
  const containerVariants = {
    hidden: {
      opacity: 0
    },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };
  const itemVariants = {
    hidden: {
      opacity: 0,
      y: 20
    },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring" as const,
        stiffness: 100,
        damping: 15
      }
    }
  };
  const features = [{
    icon: BarChart3,
    title: 'AI Chart Analysis',
    description: 'Advanced pattern recognition powered by AI',
    color: 'text-primary'
  }, {
    icon: Activity,
    title: 'Real-time Signals',
    description: 'Instant trading signals with high accuracy',
    color: 'text-call'
  }, {
    icon: Globe,
    title: 'OTC Markets',
    description: 'Support for OTC and regular markets',
    color: 'text-warning'
  }, {
    icon: Shield,
    title: 'Secure Platform',
    description: 'Enterprise-grade security for your data',
    color: 'text-primary'
  }, {
    icon: Zap,
    title: 'Fast Analysis',
    description: 'Get results in under 15 seconds',
    color: 'text-call'
  }, {
    icon: Award,
    title: '85%+ Accuracy',
    description: 'Proven track record of successful signals',
    color: 'text-warning'
  }];
  const stats = [{
    value: '10K+',
    label: 'Active Users'
  }, {
    value: '85%+',
    label: 'Accuracy Rate'
  }, {
    value: '24/7',
    label: 'Available'
  }, {
    value: '<15s',
    label: 'Analysis Time'
  }];
  return <div className="min-h-screen bg-background overflow-x-hidden">
      {/* Navigation */}
      <motion.nav initial={{
      y: -20,
      opacity: 0
    }} animate={{
      y: 0,
      opacity: 1
    }} className="fixed top-0 left-0 right-0 z-50 px-4 sm:px-6 lg:px-8 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-gradient">ARTRIX</span>
          </div>
          
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => navigate('/auth?mode=login')} className="text-muted-foreground hover:text-foreground">
              <LogIn className="w-4 h-4 mr-2" />
              Sign In
            </Button>
            <Button size="sm" onClick={() => navigate('/auth?mode=signup')} className="bg-primary hover:bg-primary/90">
              <UserPlus className="w-4 h-4 mr-2" />
              Sign Up
            </Button>
          </div>
        </div>
      </motion.nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        {/* Background Effects */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div initial={{
          opacity: 0,
          scale: 0.5
        }} animate={{
          opacity: 1,
          scale: 1
        }} transition={{
          duration: 2
        }} className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/10 rounded-full blur-3xl" />
          <motion.div animate={{
          y: [0, -30, 0],
          opacity: [0.3, 0.5, 0.3]
        }} transition={{
          duration: 6,
          repeat: Infinity
        }} className="absolute top-20 right-20 w-40 h-40 bg-call/20 rounded-full blur-2xl" />
          <motion.div animate={{
          y: [0, 40, 0],
          opacity: [0.2, 0.4, 0.2]
        }} transition={{
          duration: 8,
          repeat: Infinity
        }} className="absolute bottom-40 left-10 w-48 h-48 bg-put/15 rounded-full blur-2xl" />
          <div className="absolute inset-0 bg-[linear-gradient(rgba(56,189,248,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(56,189,248,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />
        </div>

        <motion.div variants={containerVariants} initial="hidden" animate="visible" className="max-w-5xl mx-auto text-center relative z-10">
          {/* Badge */}
          <motion.div variants={itemVariants} className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/30 bg-primary/10 backdrop-blur-sm mb-8">
            <motion.div animate={{
            rotate: 360
          }} transition={{
            duration: 8,
            repeat: Infinity,
            ease: "linear"
          }}>
              <Sparkles className="w-4 h-4 text-primary" />
            </motion.div>
            <span className="text-sm font-medium text-primary">AI-Powered Trading Signals</span>
          </motion.div>

          {/* Title */}
          <motion.h1 variants={itemVariants} className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-6">
            <span className="text-foreground">Trade Smarter with</span>
            <br />
            <span className="text-gradient">AI Signal Analysis</span>
          </motion.h1>

          {/* Description */}
          <motion.p variants={itemVariants} className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10">
            Get high-accuracy trading signals for Binary and Forex markets. Our AI analyzes charts in seconds and provides actionable insights.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div variants={itemVariants} className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
            <Button size="lg" onClick={() => navigate('/auth?mode=signup')} className="w-full sm:w-auto px-8 py-6 text-lg bg-primary hover:bg-primary/90 btn-glow">
              <UserPlus className="w-5 h-5 mr-2" />
              Get Started Free
              <ChevronRight className="w-5 h-5 ml-2" />
            </Button>
            <Button variant="outline" size="lg" onClick={() => navigate('/auth?mode=login')} className="w-full sm:w-auto px-8 py-6 text-lg border-border/50 hover:bg-secondary/50">
              <LogIn className="w-5 h-5 mr-2" />
              Sign In
            </Button>
          </motion.div>

          {/* Stats */}
          <motion.div variants={itemVariants} className="grid grid-cols-2 sm:grid-cols-4 gap-6 max-w-3xl mx-auto">
            {stats.map((stat, index) => <motion.div key={stat.label} initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: 0.5 + index * 0.1
          }} whileHover={{
            scale: 1.05
          }} className="p-4 rounded-2xl bg-secondary/30 border border-border/30 backdrop-blur-sm">
                <p className="text-2xl sm:text-3xl font-bold text-primary mb-1">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </motion.div>)}
          </motion.div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 relative">
        <div className="max-w-6xl mx-auto">
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              <span className="text-foreground">Why Choose </span>
              <span className="text-gradient">ARTRIX</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our platform combines cutting-edge AI technology with user-friendly design to deliver the most accurate trading signals.
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => <motion.div key={feature.title} initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            delay: index * 0.1
          }} whileHover={{
            y: -5,
            scale: 1.02
          }} className="p-6 rounded-2xl bg-secondary/20 border border-border/30 backdrop-blur-sm group cursor-pointer">
                <div className={`w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <feature.icon className={`w-6 h-6 ${feature.color}`} />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm">{feature.description}</p>
              </motion.div>)}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-secondary/10">
        <div className="max-w-5xl mx-auto">
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              <span className="text-foreground">How It </span>
              <span className="text-gradient">Works</span>
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[{
            step: '01',
            title: 'Upload Chart',
            description: 'Take a screenshot of your trading chart and upload it to our platform.'
          }, {
            step: '02',
            title: 'AI Analysis',
            description: 'Our AI analyzes patterns, trends, and indicators in seconds.'
          }, {
            step: '03',
            title: 'Get Signal',
            description: 'Receive a clear CALL or PUT signal with confidence percentage.'
          }].map((item, index) => <motion.div key={item.step} initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            delay: index * 0.15
          }} className="relative">
                <div className="text-6xl font-bold text-primary/10 mb-4">{item.step}</div>
                <h3 className="text-xl font-semibold text-foreground mb-2">{item.title}</h3>
                <p className="text-muted-foreground">{item.description}</p>
                {index < 2 && <ArrowRight className="hidden md:block absolute top-8 -right-4 w-8 h-8 text-primary/30" />}
              </motion.div>)}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} whileInView={{
        opacity: 1,
        y: 0
      }} viewport={{
        once: true
      }} className="max-w-4xl mx-auto text-center">
          <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-primary/20 to-primary/5 border border-primary/30 backdrop-blur-sm relative overflow-hidden">
            <motion.div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent" animate={{
            x: ['-100%', '100%']
          }} transition={{
            duration: 3,
            repeat: Infinity,
            ease: "linear"
          }} />
            
            <div className="relative z-10">
              <Users className="w-12 h-12 text-primary mx-auto mb-6" />
              <h2 className="text-2xl sm:text-3xl font-bold text-foreground mb-4">
                Start Trading Smarter Today
              </h2>
              <p className="text-muted-foreground mb-8 max-w-lg mx-auto">
                Join thousands of traders who use ARTRIX for accurate trading signals. Sign up now and get 5 free credits!
              </p>
              <Button size="lg" onClick={() => navigate('/auth?mode=signup')} className="px-10 py-6 text-lg bg-primary hover:bg-primary/90 btn-glow">
                <UserPlus className="w-5 h-5 mr-2" />
                Create Free Account
              </Button>
            </div>
          </div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-border/30">
        <div className="max-w-6xl mx-auto flex flex-col items-center justify-center gap-4 text-center">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-primary" />
            <span className="font-semibold text-foreground">ARTRIX</span>
          </div>
          <p className="text-sm text-muted-foreground">© 2025  ARTRIX. Powered by ART TEAM<span className="text-primary">ART TEAM</span>
          </p>
        </div>
      </footer>
    </div>;
}