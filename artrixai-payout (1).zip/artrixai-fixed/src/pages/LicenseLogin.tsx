import { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Key, Eye, EyeOff, Zap, Loader2, Sparkles, Shield, Lock, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export default function LicenseLogin() {
  const navigate = useNavigate();
  const { loginWithLicense } = useAuth();
  const [licenseKey, setLicenseKey] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!licenseKey.trim()) {
      toast.error('Please enter your license key');
      return;
    }

    setIsLoading(true);
    const result = await loginWithLicense(licenseKey.trim().toUpperCase());
    setIsLoading(false);

    if (result.success) {
      toast.success('Welcome to ARTRIX AI VIP!');
      navigate('/dashboard');
    } else {
      toast.error(result.error);
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  const features = [
    { icon: Shield, text: 'Secure License' },
    { icon: Zap, text: 'Instant Access' },
    { icon: CheckCircle, text: 'Premium Features' },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen flex flex-col p-4 relative overflow-hidden"
    >
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div 
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.5 }}
          className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-primary/10 rounded-full blur-3xl"
        />
        <motion.div 
          animate={{ 
            y: [0, -30, 0],
            x: [0, 20, 0],
            opacity: [0.2, 0.4, 0.2]
          }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-40 right-10 w-40 h-40 bg-call/20 rounded-full blur-2xl"
        />
        <motion.div 
          animate={{ 
            y: [0, 40, 0],
            x: [0, -30, 0],
            opacity: [0.15, 0.3, 0.15]
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-40 left-10 w-48 h-48 bg-put/15 rounded-full blur-2xl"
        />
        
        {/* Floating particles */}
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 100 }}
            animate={{ 
              opacity: [0, 0.5, 0],
              y: [-20, -200],
              x: Math.sin(i) * 50
            }}
            transition={{ 
              duration: 4 + i,
              repeat: Infinity,
              delay: i * 0.8,
              ease: "easeOut"
            }}
            className="absolute bottom-20 w-2 h-2 bg-primary/50 rounded-full"
            style={{ left: `${15 + i * 15}%` }}
          />
        ))}
      </div>

      {/* Back Button */}
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        whileHover={{ scale: 1.05, x: -4 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => navigate('/')}
        className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors w-fit z-10"
      >
        <ArrowLeft className="w-4 h-4" />
        <span className="text-sm">Back</span>
      </motion.button>

      {/* Content */}
      <div className="flex-1 flex items-center justify-center">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="w-full max-w-md relative z-10"
        >
          {/* Icon */}
          <motion.div
            variants={itemVariants}
            className="flex justify-center mb-8"
          >
            <motion.div 
              className="relative"
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: 'spring', stiffness: 200, delay: 0.3 }}
            >
              <motion.div 
                className="w-24 h-24 rounded-2xl bg-gradient-to-br from-primary/30 to-primary/10 border border-primary/30 flex items-center justify-center"
                animate={{ 
                  boxShadow: [
                    '0 0 30px hsl(199 89% 48% / 0.3)',
                    '0 0 60px hsl(199 89% 48% / 0.5)',
                    '0 0 30px hsl(199 89% 48% / 0.3)'
                  ]
                }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              >
                <motion.div
                  animate={{ rotate: [0, 10, -10, 0] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                >
                  <Key className="w-12 h-12 text-primary" />
                </motion.div>
              </motion.div>
              
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.6, type: "spring" }}
                className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-warning flex items-center justify-center"
              >
                <Lock className="w-4 h-4 text-warning-foreground" />
              </motion.div>
            </motion.div>
          </motion.div>

          {/* Title */}
          <motion.h1 
            variants={itemVariants}
            className="text-3xl font-bold text-foreground text-center mb-2"
          >
            Enter License Key
          </motion.h1>
          
          <motion.div 
            variants={itemVariants}
            className="flex items-center justify-center gap-2 mb-8"
          >
            <Sparkles className="w-4 h-4 text-primary" />
            <p className="text-muted-foreground text-center">
              Access your VIP trading dashboard
            </p>
          </motion.div>

          {/* Features Row */}
          <motion.div 
            variants={itemVariants}
            className="flex items-center justify-center gap-4 mb-8"
          >
            {features.map((feature, index) => (
              <motion.div
                key={feature.text}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.5 + index * 0.1 }}
                className="flex items-center gap-1.5 text-xs text-muted-foreground"
              >
                <feature.icon className="w-3.5 h-3.5 text-primary" />
                <span>{feature.text}</span>
              </motion.div>
            ))}
          </motion.div>

          {/* Form */}
          <motion.form 
            variants={itemVariants}
            onSubmit={handleSubmit} 
            className="space-y-4"
          >
            <div>
              <label className="text-sm text-muted-foreground mb-2 block">
                License Key
              </label>
              <motion.div 
                className="relative"
                whileFocus={{ scale: 1.01 }}
              >
                <input
                  type={showKey ? 'text' : 'password'}
                  value={licenseKey}
                  onChange={(e) => setLicenseKey(e.target.value.toUpperCase())}
                  placeholder="XXXX-XXXX-XXXX-XXXX"
                  className="w-full px-4 py-4 bg-secondary/50 border border-border/50 rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 focus:ring-2 focus:ring-primary/20 transition-all font-mono tracking-wider text-center"
                />
                <button
                  type="button"
                  onClick={() => setShowKey(!showKey)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showKey ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </motion.div>
            </div>

            <motion.button
              whileHover={{ scale: 1.02, y: -2 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              disabled={isLoading}
              className="w-full py-4 rounded-xl font-semibold bg-primary text-primary-foreground btn-glow flex items-center justify-center gap-2 disabled:opacity-50 transition-all duration-300"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Verifying...</span>
                </>
              ) : (
                <>
                  <Zap className="w-5 h-5" />
                  <span>Activate License</span>
                </>
              )}
            </motion.button>
          </motion.form>

          {/* License Help */}
          <motion.div
            variants={itemVariants}
            className="mt-8 p-4 rounded-xl bg-secondary/30 border border-border/30"
          >
            <p className="text-center text-sm text-muted-foreground">
              Enter your license key to access premium features
            </p>
          </motion.div>

          {/* Footer */}
          <motion.div
            variants={itemVariants}
            className="mt-8 text-center"
          >
            <p className="text-xs text-muted-foreground">
              Powered by <span className="text-primary font-medium">ART TEAM</span>
            </p>
          </motion.div>
        </motion.div>
      </div>
    </motion.div>
  );
}
