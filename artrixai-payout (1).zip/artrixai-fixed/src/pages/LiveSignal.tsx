import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { TrendingUp, TrendingDown, Clock, ChevronDown, Activity, Zap, Timer, Target, AlertCircle, BarChart3, Lightbulb, Send, Layers, Bot, BotOff } from 'lucide-react';
import { Header } from '@/components/Header';
import { useAuth } from '@/contexts/AuthContext';
import { incrementTodayUsage } from '@/lib/usageTracking';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { SignalLoadingAnimation } from '@/components/SignalLoadingAnimation';
import { OTCChart } from '@/components/OTCChart';
import { TelegramSignalPanel } from '@/components/TelegramSignalPanel';
import { SignalImageOverlay } from '@/components/SignalImageOverlay';
import { SignalConflictPanel } from '@/components/SignalConflictPanel';
import { TelegramChart, TelegramChartHandle } from '@/components/TelegramChart';
import { useVoiceAnnouncement } from '@/hooks/useVoiceAnnouncement';

const MARKETS = [
  // Quotex OTC Currencies
  { id: 'AUDCAD-OTC', name: 'AUD/CAD OTC', category: 'Quotex OTC Pair' },
  { id: 'AUDJPY-OTC', name: 'AUD/JPY OTC', category: 'Quotex OTC Pair' },
  { id: 'AUDNZD-OTC', name: 'AUD/NZD OTC', category: 'Quotex OTC Pair' },
  { id: 'AUDUSD-OTC', name: 'AUD/USD OTC', category: 'Quotex OTC Pair' },
  { id: 'BRLUSD-OTC', name: 'BRL/USD OTC', category: 'Quotex OTC Pair' },
  { id: 'CADCHF-OTC', name: 'CAD/CHF OTC', category: 'Quotex OTC Pair' },
  { id: 'CADJPY-OTC', name: 'CAD/JPY OTC', category: 'Quotex OTC Pair' },
  { id: 'CHFJPY-OTC', name: 'CHF/JPY OTC', category: 'Quotex OTC Pair' },
  { id: 'EURAUD-OTC', name: 'EUR/AUD OTC', category: 'Quotex OTC Pair' },
  { id: 'EURCAD-OTC', name: 'EUR/CAD OTC', category: 'Quotex OTC Pair' },
  { id: 'EURCHF-OTC', name: 'EUR/CHF OTC', category: 'Quotex OTC Pair' },
  { id: 'EURGBP-OTC', name: 'EUR/GBP OTC', category: 'Quotex OTC Pair' },
  { id: 'EURJPY-OTC', name: 'EUR/JPY OTC', category: 'Quotex OTC Pair' },
  { id: 'EURNZD-OTC', name: 'EUR/NZD OTC', category: 'Quotex OTC Pair' },
  { id: 'EURSGD-OTC', name: 'EUR/SGD OTC', category: 'Quotex OTC Pair' },
  { id: 'EURUSD-OTC', name: 'EUR/USD OTC', category: 'Quotex OTC Pair' },
  { id: 'GBPAUD-OTC', name: 'GBP/AUD OTC', category: 'Quotex OTC Pair' },
  { id: 'GBPCAD-OTC', name: 'GBP/CAD OTC', category: 'Quotex OTC Pair' },
  { id: 'GBPCHF-OTC', name: 'GBP/CHF OTC', category: 'Quotex OTC Pair' },
  { id: 'GBPJPY-OTC', name: 'GBP/JPY OTC', category: 'Quotex OTC Pair' },
  { id: 'GBPUSD-OTC', name: 'GBP/USD OTC', category: 'Quotex OTC Pair' },
  { id: 'NZDUSD-OTC', name: 'NZD/USD OTC', category: 'Quotex OTC Pair' },
  { id: 'USDARS-OTC', name: 'USD/ARS OTC', category: 'Quotex OTC Pair' },
  { id: 'USDBDT-OTC', name: 'USD/BDT OTC', category: 'Quotex OTC Pair' },
  { id: 'USDCAD-OTC', name: 'USD/CAD OTC', category: 'Quotex OTC Pair' },
  { id: 'USDCHF-OTC', name: 'USD/CHF OTC', category: 'Quotex OTC Pair' },
  { id: 'USDEGP-OTC', name: 'USD/EGP OTC', category: 'Quotex OTC Pair' },
  { id: 'USDGBP-OTC', name: 'USD/GBP OTC', category: 'Quotex OTC Pair' },
  { id: 'USDIDR-OTC', name: 'USD/IDR OTC', category: 'Quotex OTC Pair' },
  { id: 'USDINR-OTC', name: 'USD/INR OTC', category: 'Quotex OTC Pair' },
  { id: 'USDJPY-OTC', name: 'USD/JPY OTC', category: 'Quotex OTC Pair' },
  { id: 'USDMXN-OTC', name: 'USD/MXN OTC', category: 'Quotex OTC Pair' },
  { id: 'USDNGN-OTC', name: 'USD/NGN OTC', category: 'Quotex OTC Pair' },
  { id: 'USDPKR-OTC', name: 'USD/PKR OTC', category: 'Quotex OTC Pair' },
  { id: 'USDTRY-OTC', name: 'USD/TRY OTC', category: 'Quotex OTC Pair' },
  { id: 'USDZAR-OTC', name: 'USD/ZAR OTC', category: 'Quotex OTC Pair' },
  { id: 'USDPHP-OTC', name: 'USD/PHP OTC', category: 'Quotex OTC Pair' },
  // Quotex OTC Crypto
  { id: 'BTCUSD-OTC', name: 'BTC/USD OTC', category: 'Quotex OTC Crypto' },
  { id: 'BCHUSD-OTC', name: 'BCH/USD OTC', category: 'Quotex OTC Crypto' },
  { id: 'ARBUSD-OTC', name: 'ARB/USD OTC', category: 'Quotex OTC Crypto' },
  { id: 'ZECUSD-OTC', name: 'ZEC/USD OTC', category: 'Quotex OTC Crypto' },
  { id: 'ATOUSD-OTC', name: 'ATO/USD OTC', category: 'Quotex OTC Crypto' },
  { id: 'AXSUSD-OTC', name: 'AXS/USD OTC', category: 'Quotex OTC Crypto' },
  // Quotex OTC Commodities
  { id: 'XAUUSD-OTC', name: 'XAU/USD OTC (Gold)', category: 'Quotex OTC Commodities' },
  { id: 'XAGUSD-OTC', name: 'XAG/USD OTC (Silver)', category: 'Quotex OTC Commodities' },
  { id: 'USCrude-OTC', name: 'US Crude OTC', category: 'Quotex OTC Commodities' },
  { id: 'UKBrent-OTC', name: 'UK Brent OTC', category: 'Quotex OTC Commodities' },
  { id: 'FLOUSD-OTC', name: 'FLO/USD OTC', category: 'Quotex OTC Commodities' },
  // Quotex Stocks Pairs
  { id: 'AXP-OTC', name: 'American Express OTC', category: 'Quotex Stocks Pairs' },
  { id: 'PFE-OTC', name: 'Pfizer OTC', category: 'Quotex Stocks Pairs' },
  { id: 'INTL-OTC', name: 'Intel OTC', category: 'Quotex Stocks Pairs' },
  { id: 'JNJ-OTC', name: 'Johnson & Johnson OTC', category: 'Quotex Stocks Pairs' },
  { id: 'MCD-OTC', name: 'McDonald\'s OTC', category: 'Quotex Stocks Pairs' },
  { id: 'FB-OTC', name: 'Meta OTC', category: 'Quotex Stocks Pairs' },
  { id: 'BA-OTC', name: 'Boeing OTC', category: 'Quotex Stocks Pairs' },
  { id: 'MSFT-OTC', name: 'Microsoft OTC', category: 'Quotex Stocks Pairs' },
];

interface MarketAnalysis {
  direction: 'CALL' | 'PUT';
  confidence: number;
  rawConfidence?: number;
  currentPrice: number;
  trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  support: number;
  resistance: number;
  rsi: number;
  rsi7?: number;
  stochastic?: { k: number; d: number };
  bollingerPosition?: string;
  macdSignal: string;
  ema20: number;
  ema50: number;
}

interface CategoryBreakdown {
  name: string;
  callCount: number;
  putCount: number;
  callScore: number;
  putScore: number;
  hasConflict: boolean;
  conflictingSetups: string[];
}

interface BlockedStrategy {
  name: string;
  category: string;
  reason: string;
  signal: 'CALL' | 'PUT';
}

interface BlockedCounts {
  callBlocked: number;
  putBlocked: number;
}

interface ConflictAnalysis {
  hasInternalConflict: boolean;
  conflictPenalty: number;
  hiddenTrapWarning: boolean;
  highRisk: boolean;
  conflictDetails: CategoryBreakdown[];
  opposingSetups: string[];
  blockedStrategies?: BlockedStrategy[];
  blockedCounts?: BlockedCounts;
}

interface Signal {
  id: string;
  market: string;
  direction: 'CALL' | 'PUT';
  confidence: number;
  entryPrice: number;
  timestamp: Date;
  expiry: string;
  status: 'active' | 'won' | 'lost' | 'expired';
  trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  rsi: number;
  support: number;
  resistance: number;
  payout?: number | null;
  reasoning?: string;
  selfCorrection?: {
    insights: string | null;
    isActive: boolean;
  };
  backtest?: {
    call: { winRate: number; wins: number; losses: number; totalTests: number };
    put: { winRate: number; wins: number; losses: number; totalTests: number };
    recommendation: string;
    warning: string | null;
  } | null;
  conflictAnalysis?: ConflictAnalysis | null;
}

interface SignalHistoryItem extends Signal {}

export default function LiveSignal() {
  const navigate = useNavigate();
  const { user, isLoading, useCredit } = useAuth();
  const [selectedMarket, setSelectedMarket] = useState<string | null>(null);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [marketPayout, setMarketPayout] = useState<number | null>(null);
  const [currentSignal, setCurrentSignal] = useState<Signal | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [signalHistory, setSignalHistory] = useState<SignalHistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [countdown, setCountdown] = useState<number>(0);
  const [selfCorrectionStats, setSelfCorrectionStats] = useState<{ total: number; wins: number; losses: number; winRate: string } | null>(null);
  const [isCheckingResult, setIsCheckingResult] = useState(false);
  const [showTelegramPanel, setShowTelegramPanel] = useState(false);
  const [aiMode, setAiMode] = useState(() => {
    try { return localStorage.getItem('artrix_ai_mode') !== 'off'; } catch { return true; }
  });
  const [lastResultDebug, setLastResultDebug] = useState<{
    result: string;
    openPrice: number;
    closePrice: number;
    candleTime: string;
    direction: string;
    market: string;
    priceDiff: number;
    logic: string;
  } | null>(null);
  const [signalSentToTelegram, setSignalSentToTelegram] = useState(false);
  const [pendingAutoResult, setPendingAutoResult] = useState<{ result: 'WIN' | 'LOSS' | 'MTG'; signal: Signal } | null>(null);
  const [chartResultData, setChartResultData] = useState<{
    resultType: 'WIN' | 'LOSS' | 'MTG';
    pair: string;
    time: string;
    wins: number;
    losses: number;
    winRate: number;
  } | null>(null);
  const [chartCaptureFunc, setChartCaptureFunc] = useState<(() => string | null) | null>(null);
  // Auto-mode signal data — used to update TelegramChart dashboard for auto signals
  const [autoSignalData, setAutoSignalData] = useState<{
    direction: 'CALL' | 'PUT';
    timestamp: Date;
    pair: string;
  } | null>(null);
  
  // Ref for the hidden TelegramChart (high-res desktop-style chart for Telegram)
  const telegramChartRef = useRef<TelegramChartHandle>(null);
  const { announce: announceSignal } = useVoiceAnnouncement();

  // IMPORTANT: countdown interval closes over values; keep this as a ref so result-check can
  // still auto-send even if the user clicks "Send Signal" after the interval starts.
  const signalSentToTelegramRef = useRef(false);
  useEffect(() => {
    signalSentToTelegramRef.current = signalSentToTelegram;
  }, [signalSentToTelegram]);

  // Load signal history
  useEffect(() => {
    const saved = localStorage.getItem('artrix_signal_history');
    if (saved) {
      setSignalHistory(JSON.parse(saved));
    }
  }, []);

  // Live payout fetch — polls the candle API whenever a market is selected
  useEffect(() => {
    if (!selectedMarket) {
      setMarketPayout(null);
      return;
    }
    const STOCK_OTC_MAP: Record<string, string> = {
      'AXP-OTC': 'AXP_otc', 'PFE-OTC': 'PFE_otc', 'INTL-OTC': 'INTL_otc',
      'JNJ-OTC': 'JNJ_otc', 'MCD-OTC': 'MCD_otc', 'FB-OTC': 'FB_otc',
      'BA-OTC': 'BA_otc', 'MSFT-OTC': 'MSFT_otc',
      'USCrude-OTC': 'USCrude_otc', 'UKBrent-OTC': 'UKBrent_otc', 'FLOUSD-OTC': 'FLOUSD_otc',
    };
    const apiPair = STOCK_OTC_MAP[selectedMarket] || selectedMarket.replace('-OTC', '_otc');
    const url = `https://quotexcandles.bdtraderpro.xyz/proversion/quotexcandles/Qx.php?pair=${encodeURIComponent(apiPair)}&timeframe=M1&count=5`;

    const fetchPayout = async () => {
      try {
        const res = await fetch(url);
        const raw = await res.text();
        const trimmed = raw.trim();
        const start = trimmed.indexOf('[');
        const jsonStr = start !== -1 ? trimmed.slice(start) : trimmed;
        const candles = JSON.parse(jsonStr);
        if (Array.isArray(candles)) {
          const found = candles.find((c: any) => {
            const p = parseFloat(c.payout ?? c.Payout ?? '');
            return Number.isFinite(p) && p > 0;
          });
          if (found) {
            const p = parseFloat(found.payout ?? found.Payout);
            if (Number.isFinite(p)) setMarketPayout(p);
          }
        }
      } catch { /* silently fail — payout stays as last known */ }
    };

    setMarketPayout(null); // reset on market change
    fetchPayout();
    const interval = setInterval(fetchPayout, 60000);
    return () => clearInterval(interval);
  }, [selectedMarket]);

  // Redirect if not logged in
  useEffect(() => {
    if (!isLoading && !user) {
      navigate('/');
    }
  }, [user, isLoading, navigate]);

  // Countdown timer for signal
  const [expiryTime, setExpiryTime] = useState<Date | null>(null);
  

  // Get last trade result from localStorage for MTG detection
  const getLastTradeResult = (market: string): { result: 'WIN' | 'LOSS'; direction: 'CALL' | 'PUT'; candleTime: string } | null => {
    const stored = localStorage.getItem(`artrix_last_trade_${market}`);
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch {
        return null;
      }
    }
    return null;
  };

  // Save last trade result to localStorage for MTG detection
  const saveLastTradeResult = (market: string, result: 'WIN' | 'LOSS', direction: 'CALL' | 'PUT', candleTime: string) => {
    localStorage.setItem(`artrix_last_trade_${market}`, JSON.stringify({ result, direction, candleTime }));
  };

  // Automatic result checking when signal expires
  // DUAL-API SYSTEM: Uses running candle proxy for instant WIN detection + backend API for full MTG verification
  // STRONGLY CODED: Result is determined ONCE and FROZEN — cannot change or leak after determination
  const resultFinalizedRef = useRef(false);
  
  const checkSignalResult = async (signal: Signal, isEarlyCheck = false) => {
    // STRONGLY CODED: If result already finalized, NEVER run again
    if (resultFinalizedRef.current) {
      console.log('[RESULT] Already finalized — skipping duplicate check');
      return;
    }
    if (isCheckingResult) return;
    setIsCheckingResult(true);
    
    try {
      console.log(`[RESULT] ${isEarlyCheck ? 'EARLY' : 'FULL'} check for ${signal.market} ${signal.direction}...`);
      
      // Get last trade for this market to detect MTG
      const lastTrade = getLastTradeResult(signal.market);
      
      // DUAL-API: Try backend with automatic retry on failure
      const invokeCheck = async (checkMtgWindow: boolean, retryCount = 0): Promise<any> => {
        try {
          const { data, error } = await supabase.functions.invoke('live-signal', {
            body: {
              action: 'check-result',
              market: signal.market,
              direction: signal.direction,
              entryPrice: signal.entryPrice,
              entryTime: signal.timestamp.toISOString(),
              expiryTime: new Date(new Date(signal.timestamp).getTime() + (isEarlyCheck ? 65000 : 120000)).toISOString(),
              lastTrade: lastTrade || null,
              checkMtgWindow,
            }
          });
          
          if (error) {
            if (retryCount < 3) {
              console.log(`[RESULT] Retry ${retryCount + 1}/3 after error...`);
              await new Promise(r => setTimeout(r, 3000));
              return invokeCheck(checkMtgWindow, retryCount + 1);
            }
            return { data: null, error };
          }
          return { data, error: null };
        } catch (err) {
          if (retryCount < 3) {
            console.log(`[RESULT] Retry ${retryCount + 1}/3 after exception...`);
            await new Promise(r => setTimeout(r, 3000));
            return invokeCheck(checkMtgWindow, retryCount + 1);
          }
          return { data: null, error: err };
        }
      };

      const { data, error } = await invokeCheck(!isEarlyCheck);

      if (error || !data?.success || !data?.result) {
        if (isEarlyCheck) {
          // Early check failed — normal, candle may not be ready. Let full check handle it.
          console.log('[RESULT] Early check: data not ready yet');
          setIsCheckingResult(false);
          return;
        }
        // Full check failed after all retries
        console.log('[RESULT] Full check failed after retries:', error || data?.error);
        const expiredSignal: SignalHistoryItem = { ...signal, status: 'expired' };
        const newHistory = [expiredSignal, ...signalHistory].slice(0, 50);
        setSignalHistory(newHistory);
        localStorage.setItem('artrix_signal_history', JSON.stringify(newHistory));
        toast.warning('Could not verify result — candle data not available');
        resultFinalizedRef.current = true;
        setIsCheckingResult(false);
        setCurrentSignal(null);
        setExpiryTime(null);
        return;
      }

      const raw = String(data.result).toLowerCase();
      
      // EARLY CHECK: If WIN detected, fire immediately! If LOSS, wait for full MTG check
      if (isEarlyCheck) {
        if (raw === 'win') {
          console.log('[RESULT] 🎯 EARLY WIN DETECTED! Firing immediately.');
          resultFinalizedRef.current = true;
          processResultData(data, signal, lastTrade);
          return;
        } else {
          // LOSS on early check → don't finalize yet, wait for MTG window
          console.log('[RESULT] Early check shows LOSS, waiting for MTG window...');
          setIsCheckingResult(false);
          return;
        }
      }

      // FULL CHECK: Process final result (includes MTG detection)
      // STRONGLY CODED: Mark as finalized BEFORE processing to prevent any race condition
      resultFinalizedRef.current = true;
      processResultData(data, signal, lastTrade);
      
    } catch (err) {
      console.error('[RESULT] Error checking signal result:', err);
      if (!isEarlyCheck) {
        resultFinalizedRef.current = true;
        const expiredSignal: SignalHistoryItem = { ...signal, status: 'expired' };
        const newHistory = [expiredSignal, ...signalHistory].slice(0, 50);
        setSignalHistory(newHistory);
        localStorage.setItem('artrix_signal_history', JSON.stringify(newHistory));
      }
      setIsCheckingResult(false);
      if (!isEarlyCheck) {
        setCurrentSignal(null);
        setExpiryTime(null);
      }
    }
  };

  // Process result data from backend (shared by early and full checks)
  const processResultData = (data: any, signal: Signal, lastTrade: any) => {
    const isMtgFromBackend = data.isMTG === true;
    const raw = String(data.result).toLowerCase();
    const resultType: 'WIN' | 'LOSS' | 'MTG' = isMtgFromBackend ? 'MTG' : (raw === 'mtg' ? 'MTG' : raw === 'win' ? 'WIN' : 'LOSS');
    const isWin = resultType === 'WIN' || resultType === 'MTG';
    const resultSignal: SignalHistoryItem = {
      ...signal,
      status: isWin ? 'won' : 'lost',
    };
    
    const newHistory = [resultSignal, ...signalHistory].slice(0, 50);
    setSignalHistory(newHistory);
    localStorage.setItem('artrix_signal_history', JSON.stringify(newHistory));
    
    // Store debug info
    const openPrice = data.entryPrice || 0;
    const closePrice = data.currentPrice || 0;
    const priceDiff = closePrice - openPrice;
    const winLogicCall = closePrice > openPrice;
    const winLogicPut = closePrice < openPrice;
    const logic = `${signal.direction} | Close(${closePrice}) ${priceDiff > 0 ? '>' : priceDiff < 0 ? '<' : '='} Open(${openPrice}) | ${signal.direction === 'CALL' ? (winLogicCall ? 'WIN' : 'LOSS') : (winLogicPut ? 'WIN' : 'LOSS')}`;
    
    setLastResultDebug({
      result: data.result,
      openPrice,
      closePrice,
      candleTime: data.candleTime || '',
      direction: signal.direction,
      market: signal.market,
      priceDiff,
      logic,
    });
    
    // Update self-correction stats
    if (data.selfCorrectionInsights || data.stats) {
      const stats = data.stats || {
        total: 1,
        wins: isWin ? 1 : 0,
        losses: isWin ? 0 : 1,
        winRate: isWin ? '100.0' : '0.0'
      };
      setSelfCorrectionStats(stats);
    }
    
    // Save trade result for MTG detection on next signal
    const candleTimeForMtg = data.candleTime || new Date(Math.floor(new Date(signal.timestamp).getTime() / 60000) * 60000).toISOString();
    const baseResultForSave: 'WIN' | 'LOSS' = (resultType === 'WIN' || resultType === 'MTG') ? 'WIN' : 'LOSS';
    saveLastTradeResult(signal.market, baseResultForSave, signal.direction, candleTimeForMtg);
    
    // Show result toast
    if (isWin) {
      toast.success(`✅ ${resultType === 'MTG' ? 'MTG WIN' : 'WIN'}! ${signal.market} ${signal.direction} - Self-correction learning...`);
    } else {
      toast.error(`❌ LOSS! ${signal.market} ${signal.direction} - Self-correction learning...`);
    }

    // Set pending result for automatic Telegram sending
    if (signalSentToTelegramRef.current) {
      setPendingAutoResult({
        result: resultType,
        signal: signal
      });
    }
    
    setIsCheckingResult(false);
    setCurrentSignal(null);
    setExpiryTime(null);
  };

  // Auto-send result to Telegram when self-correction determines WIN/LOSS
  useEffect(() => {
    if (!pendingAutoResult) return;

    const sendAutoResult = async () => {
      const botToken = localStorage.getItem('telegram_bot_token');
      const chatId = localStorage.getItem('telegram_chat_id');
      const avatarUrl = localStorage.getItem('user_avatar_url');
      
      if (!botToken || !chatId) {
        console.log('Telegram not configured, skipping auto-send');
        setPendingAutoResult(null);
        return;
      }

      // Get current stats from localStorage
       const savedWins = parseInt(localStorage.getItem('telegram_wins') || '0');
       const savedLosses = parseInt(localStorage.getItem('telegram_losses') || '0');
       const savedMtg = parseInt(localStorage.getItem('telegram_mtg') || '0');
      const savedRecords = JSON.parse(localStorage.getItem('telegram_trade_records') || '[]');

      const { result, signal } = pendingAutoResult;
       const isMtg = result === 'MTG';
       const isWin = result === 'WIN' || isMtg;
       const newWins = isWin ? savedWins + 1 : savedWins;
       const newLosses = isWin ? savedLosses : savedLosses + 1;
       const newMtg = isMtg ? savedMtg + 1 : savedMtg;
      const winRate = Math.round((newWins / (newWins + newLosses)) * 100);

      const formatTime = (date: Date) => {
        return date.toLocaleTimeString('en-US', { 
          hour: '2-digit', 
          minute: '2-digit',
          hour12: false 
        });
      };

      const time = formatTime(new Date(signal.timestamp));
      const pair = signal.market.replace('/', '-').replace('-OTC', '-OTC');

       // Generate message based on result
       let message = '';
       if (isMtg) {
         const directionText = signal.direction === 'CALL' ? '🟢 𝗖𝗔𝗟𝗟' : '🔴 𝗣𝗨𝗧';
         message = `<b>𒆜•——‼️ 𝚁 | 𝙴 | 𝚂 | 𝚄 | 𝙻 | 𝚃 ‼️——•𒆜  

╭━━━━━━━━━・━━━━━━━━━╮ 
🚀𝙰𝚂𝚂𝙴𝚃            ☞ ${pair}
⏰𝚃𝙸𝙼𝙴               ☞ ${time}
🎯𝙳𝙸𝚁𝙴𝙲𝚃𝙸𝙾𝙽 ☞ ${directionText}  
╰━━━━━━━━━・━━━━━━━━━╯ 
✅✅✅ 𝗠𝗧𝗚 𝗪𝗜𝗡 ✅✅✅
╭━━━━━━━━━・━━━━━━━━━╮ 
🏆 𝚆𝚒𝚗: ${newWins}    |  𝙻𝚘𝚜𝚜: ${newLosses} • ${winRate}%
╰━━━━━━━━━・━━━━━━━━━╯  

𒆜•——‼️ A | R | T | R | I | X ‼️——•𒆜</b>`;
       } else if (isWin) {
        message = `<b>𒆜•——‼️ 𝚁 | 𝙴 | 𝚂 | 𝚄 | 𝙻 | 𝚃 ‼️——•𒆜  

╭━━━━━━━━𖥠━━━━━━━━╮ 
📊 ${pair}    | 🕓 ${time}
╰━━━━━━━━𖥠━━━━━━━━╯ 
✅✅✅ 𝗦𝗨𝗥𝗘𝗦𝗛𝗢𝗧 ✅✅✅
╭━━━━━━━━𖥠━━━━━━━━╮ 
🚀 𝚆𝚒𝚗:${newWins} ┃✖️𝙻𝚘𝚜𝚜:${newLosses} ◈ ${winRate}%
╰━━━━━━━━𖥠━━━━━━━━╯  

🌐𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖: @Tredwithjakaria 
𒆜•——‼️ A | R | T | R | I | X ‼️——•𒆜</b>`;
      } else {
        message = `<b>𒆜•——‼️ 𝚁 | 𝙴 | 𝚂 | 𝚄 | 𝙻 | 𝚃 ‼️——•𒆜

╭━━━━━━━ ・ ━━━━━━━╮ 
🐲 ${pair}  ┃ 🕓 ${time}
╰━━━━━━━ ・ ━━━━━━━╯
❎❎❎ 𝗟𝗢𝗦𝗦 𝗧𝗥𝗔𝗗𝗘 ❎❎❎
╭━━━━━━━━𖥠━━━━━━━━╮ 
🚀 𝚆𝚒𝚗:${newWins} ┃✖️𝙻𝚘𝚜𝚜:${newLosses} ◈ ${winRate}%
╰━━━━━━━━𖥠━━━━━━━━╯  

𒆜•——‼️ A | R | T | R | I | X ‼️——•𒆜</b>`;
      }

      try {
        console.log(`Auto-sending ${result} result to Telegram...`);
        
        // Set chart result data for capturing with result overlay
        setChartResultData({
          resultType: result,
          pair: pair,
          time: time,
          wins: newWins,
          losses: newLosses,
          winRate: winRate
        });
        
        // Wait a brief moment for the chart to update with result data
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Capture chart with result overlay
        const chartImage = telegramChartRef.current?.capture() || null;
        
        const { data, error } = await supabase.functions.invoke('telegram-signal', {
          body: {
            botToken,
            chatId,
            message,
            photoUrl: avatarUrl,
            chartImage: chartImage, // Send chart with result overlay
            direction: signal.direction,
            resultData: {
              market: signal.market,
              time,
              result,
              wins: newWins,
              losses: newLosses,
              winRate
            }
          }
        });

        if (error) throw error;

        if (data?.success) {
          // Update localStorage with new stats
          localStorage.setItem('telegram_wins', newWins.toString());
          localStorage.setItem('telegram_losses', newLosses.toString());
          if (isMtg) localStorage.setItem('telegram_mtg', newMtg.toString());
          
          // Add to trade records
          const newRecord = {
            time,
            pair: signal.market.replace('/', '-'),
            direction: signal.direction,
            result: isMtg ? 'mtg' : isWin ? 'win' : 'loss'
          };
          const newRecords = [...savedRecords, newRecord];
          localStorage.setItem('telegram_trade_records', JSON.stringify(newRecords));

          toast.success(`📤 ${result} result auto-sent to Telegram!`);
        }
      } catch (err) {
        console.error('Auto-send Telegram error:', err);
        toast.error('Failed to auto-send result to Telegram');
      } finally {
        setPendingAutoResult(null);
        setChartResultData(null); // Clear result data after sending
      }
    };

    sendAutoResult();
  }, [pendingAutoResult]);

  // Countdown with EARLY WIN detection at 65s + FULL MTG check at 120s
  const earlyCheckDoneRef = useRef(false);
  useEffect(() => {
    if (!expiryTime || !currentSignal) {
      earlyCheckDoneRef.current = false;
      return;
    }
    
    const entryMs = new Date(currentSignal.timestamp).getTime();
    const earlyCheckMs = entryMs + 65000; // 65s after entry = candle closed + 5s buffer
    
    const updateCountdown = () => {
      // STRONGLY CODED: If result already finalized, stop all checks
      if (resultFinalizedRef.current) return;
      
      const now = Date.now();
      const remaining = Math.ceil((expiryTime.getTime() - now) / 1000);
      
      // EARLY WIN CHECK: At 65s after entry, check if direct WIN
      if (!earlyCheckDoneRef.current && now >= earlyCheckMs && !isCheckingResult && !resultFinalizedRef.current) {
        earlyCheckDoneRef.current = true;
        checkSignalResult(currentSignal, true);
      }
      
      if (remaining > 0) {
        setCountdown(remaining);
      } else if (remaining <= 0 && !isCheckingResult && !resultFinalizedRef.current) {
        setCountdown(0);
        // FULL CHECK: 120s expired, check with MTG window
        checkSignalResult(currentSignal, false);
      }
    };
    
    updateCountdown();
    const timer = setInterval(updateCountdown, 1000);
    return () => clearInterval(timer);
  }, [expiryTime, currentSignal, signalHistory, isCheckingResult]);

  const generateSignal = async () => {
    if (!selectedMarket) {
      toast.error('Please select a market first');
      return;
    }

    if (!user || user.credits <= 0) {
      toast.error('No credits remaining');
      navigate('/credits');
      return;
    }

    const creditUsed = useCredit();
    if (!creditUsed) {
      toast.error('Failed to use credit');
      return;
    }

    incrementTodayUsage('signal');
    setIsGenerating(true);
    // Clear previous signal data to prevent leakage
    setCurrentSignal(null);
    setLastResultDebug(null);
    setSelfCorrectionStats(null);
    setChartResultData(null);
    setAutoSignalData(null);
    setSignalSentToTelegram(false);
    setPendingAutoResult(null);
    // STRONGLY CODED: Reset finalized flag for new signal
    resultFinalizedRef.current = false;
    earlyCheckDoneRef.current = false;

    try {
      const signalGenerationStartedAt = Date.now();

      // ── FAST MODE (AI OFF): code-based + tiny AI direction call in ~60s ──
      if (!aiMode) {
        const { data: fsData, error: fsError } = await supabase.functions.invoke('live-signal', {
          body: { market: selectedMarket, action: 'fast-signal' },
        });
        if (fsError || !fsData?.success || !fsData?.analysis) {
          toast.error(fsData?.error || 'Fast analysis failed — please try again');
          setIsGenerating(false);
          return;
        }
        const fa = fsData.analysis;
        const fastDir: 'CALL' | 'PUT' = (fa.direction === 'CALL' || fa.direction === 'PUT') ? fa.direction : 'CALL';
        const fastConf = Number(fa.confidence ?? 60);

        // Target the 2nd candle (entry = next minute + 1 minute)
        const now2 = new Date();
        const entryTime2 = new Date(now2);
        entryTime2.setSeconds(0); entryTime2.setMilliseconds(0);
        entryTime2.setMinutes(entryTime2.getMinutes() + 2); // 2nd candle
        const verifyAt2 = new Date(entryTime2.getTime() + 120000);

        const newSignalFast: Signal = {
          id: Date.now().toString(),
          market: selectedMarket,
          direction: fastDir,
          confidence: fastConf,
          entryPrice: fa.currentPrice || 0,
          timestamp: entryTime2,
          expiry: '1 min',
          status: 'active',
          trend: fa.trend === 'BULLISH' ? 'BULLISH' : fa.trend === 'BEARISH' ? 'BEARISH' : 'NEUTRAL',
          rsi: fa.rsi || 50,
          support: fa.support || 0,
          resistance: fa.resistance || 0,
          payout: fsData.payout || null,
          reasoning: fsData.geminiAnalysis?.reasoning || `[FAST CODE] ${fastDir} ${fastConf}%`,
          selfCorrection: null,
          backtest: null,
          conflictAnalysis: fsData.scoring?.conflictAnalysis || null,
        };
        setCurrentSignal(newSignalFast);
        announceSignal({ pair: selectedMarket, direction: fastDir, confidence: fastConf, payout: fsData.payout || null });
        resultFinalizedRef.current = false;
        earlyCheckDoneRef.current = false;
        setExpiryTime(verifyAt2);
        setCountdown(Math.ceil((verifyAt2.getTime() - Date.now()) / 1000));
        const elapsed60 = Date.now() - signalGenerationStartedAt;
        console.log(`[FAST] Signal ready in ${elapsed60}ms: ${fastDir} ${fastConf}%`);
        toast.success(`⚡ Fast Signal! ${fastDir} ${fastConf}% — targeting 2nd candle`);
        setIsGenerating(false);
        return;
      }

      // ── AI MODE (normal): full 3-minute dual-stage analysis ──

      // STEP 1: Run AI analysis (Quantum Trader V7) + Live Signal Pillar in parallel
      const [aiResult, lsResult] = await Promise.allSettled([
        // AI Dual-Stage Analysis via analyze-signal
        supabase.functions.invoke('analyze-signal', {
          body: { pair: selectedMarket }
        }),
        // Live Signal Pillar-based strategy analysis
        supabase.functions.invoke('live-signal', {
          body: { market: selectedMarket }
        }),
      ]);

      // Extract AI data — analyze-signal returns { direction, confidence, reasoning, ... } directly (no 'success' wrapper)
      const rawAiValue = aiResult.status === 'fulfilled' ? aiResult.value : null;
      const aiData = rawAiValue?.data && !rawAiValue?.error ? rawAiValue.data : null;
      const lsData = lsResult.status === 'fulfilled' ? lsResult.value.data : null;
      const lsError = lsResult.status === 'fulfilled' ? lsResult.value.error : lsResult.reason;

      console.log('AI analysis response:', aiData);
      console.log('AI analysis raw:', rawAiValue);
      console.log('Live signal response:', { data: lsData, error: lsError });

      const aiInvokeError = aiResult.status === 'fulfilled' ? rawAiValue?.error : aiResult.reason;
      const aiEngineDirectionRaw = typeof aiData?.aiDirection === 'string' ? aiData.aiDirection.toUpperCase() : null;
      const aiDirection = aiEngineDirectionRaw === 'CALL'
        ? 'UP'
        : aiEngineDirectionRaw === 'PUT'
          ? 'DOWN'
          : aiEngineDirectionRaw;
      const aiConfidence = Number(aiData?.aiConfidence ?? 0);

      // ── PILLAR FALLBACK DETECTION ──────────────────────────────────────────────────
      // PILLAR_FALLBACK = AI was tried but all Gemini keys exhausted mid-request
      // PILLAR_ONLY     = AI key pool was empty at request start (keys never attempted)
      // Both are valid signal sources — the backend resolved a final direction via pillar.
      const PILLAR_STATUSES = ['PILLAR_FALLBACK', 'PILLAR_ONLY', 'CANDLE_FALLBACK'] as const;
      const aiUsedPillarFallback = PILLAR_STATUSES.includes(aiData?.matchStatus as any);

      const aiWasFiltered = aiData?.filtered === true || aiData?.matchStatus === 'LOW_CONFIDENCE' || aiData?.direction === 'NO_SIGNAL';
      const aiHasValidDirection = (aiDirection === 'UP' || aiDirection === 'DOWN') && aiConfidence > 0 && !aiWasFiltered && !aiUsedPillarFallback;

      // Extract backend's FINAL resolved direction from analyze-signal.
      // aiData.direction is the backend's single authoritative output — it holds a valid
      // direction for ALL scenarios: AI success (DUAL_CONFIRMED/AI_AUTHORITY), pillar fallback
      // (PILLAR_FALLBACK/PILLAR_ONLY), or any other matchStatus the backend resolves.
      // aiData.aiDirection is only the raw AI engine output and is NULL during pillar modes.
      const backendRawDir = typeof aiData?.direction === 'string' ? aiData.direction.toUpperCase() : null;
      const backendResolvedDir: 'CALL' | 'PUT' | null =
        backendRawDir === 'UP' || backendRawDir === 'CALL' ? 'CALL' :
        backendRawDir === 'DOWN' || backendRawDir === 'PUT' ? 'PUT' : null;
      const backendResolvedConf = Number(aiData?.confidence ?? 0);
      // ROOT CAUSE FIX: Previously gated on aiUsedPillarFallback (requiring matchStatus to be
      // exactly PILLAR_FALLBACK or PILLAR_ONLY). This caused silent failure when matchStatus was
      // anything else (e.g., NO_MATCH, or unexpected value) even though aiData.direction had a
      // valid resolved direction. Now: use aiData.direction whenever it's valid, regardless of
      // matchStatus — the only requirements are that aiData exists, direction is CALL/PUT,
      // confidence > 0, and signal was not explicitly filtered.
      const hasBackendPillarResult = !!aiData && !!backendResolvedDir && backendResolvedConf > 0 && !aiWasFiltered && !aiHasValidDirection;

      if (lsError || !lsData?.success || !lsData?.analysis) {
        if (aiHasValidDirection) {
          // AI returned a valid direction — proceed with AI-only result
          console.log('Using AI-only result (live-signal failed)');
        } else if (hasBackendPillarResult) {
          // BUG FIX: analyze-signal has a valid PILLAR_FALLBACK/PILLAR_ONLY direction.
          // Previously this branch was missing, causing a wrong error toast even though
          // the backend had already resolved a direction. Continue — it will be used below.
          console.log(\`Using analyze-signal \${aiData?.matchStatus} result (live-signal failed, backend pillar direction: \${backendResolvedDir} @ \${backendResolvedConf}%)\`);
        } else {
          // Neither AI nor backend pillar resolved a direction on first attempt.
          // ROOT CAUSE FIX: Retry live-signal once independently before giving up.
          // The parallel first call ran alongside a 3-minute AI window and often hits
          // a cold-start or transient timeout. A direct solo retry succeeds almost always.
          console.log('[LIVE] Both AI and live-signal failed \u2014 retrying live-signal solo...');
          let retryLsData: any = null;
          try {
            const retryResult = await supabase.functions.invoke('live-signal', {
              body: { market: selectedMarket }
            });
            if (!retryResult.error && retryResult.data?.success && retryResult.data?.analysis) {
              retryLsData = retryResult.data;
              console.log('[LIVE] Retry live-signal succeeded:', retryLsData.analysis?.direction);
            } else {
              console.log('[LIVE] Retry live-signal also failed:', retryResult.error);
            }
          } catch (retryErr) {
            console.log('[LIVE] Retry live-signal threw:', retryErr);
          }

          if (retryLsData) {
            const retryAnalysis: MarketAnalysis = retryLsData.analysis || {} as MarketAnalysis;
            const retryPillarDir = (retryAnalysis.direction === 'CALL' || retryAnalysis.direction === 'PUT') ? retryAnalysis.direction : null;
            const retryPillarConf = Number(retryAnalysis.confidence || 0);
            if (retryPillarDir) {
              const entryNow = new Date();
              entryNow.setSeconds(0, 0);
              entryNow.setMinutes(entryNow.getMinutes() + 1);
              const verifyAtRetry = new Date(entryNow.getTime() + 120000);
              const newSignalRetry: Signal = {
                id: Date.now().toString(),
                market: selectedMarket,
                direction: retryPillarDir,
                confidence: Math.max(55, retryPillarConf),
                entryPrice: retryAnalysis.currentPrice || 0,
                timestamp: entryNow,
                expiry: '1 min',
                status: 'active',
                trend: retryAnalysis.trend || 'NEUTRAL',
                rsi: retryAnalysis.rsi || 50,
                support: retryAnalysis.support || 0,
                resistance: retryAnalysis.resistance || 0,
                payout: retryLsData.payout || null,
                reasoning: `[RETRY PILLAR \u2014 AI unavailable, live-signal retry succeeded | Pillar(${retryPillarDir} ${retryPillarConf}%)]`,
                selfCorrection: retryLsData.selfCorrection || null,
                backtest: retryLsData.backtest || null,
                conflictAnalysis: retryLsData.scoring?.conflictAnalysis ? {
                  ...retryLsData.scoring.conflictAnalysis,
                  blockedStrategies: retryLsData.scoring.blockedStrategies || [],
                  blockedCounts: retryLsData.scoring.blockedCounts || undefined,
                } : null,
              };
              setCurrentSignal(newSignalRetry);
              announceSignal({ pair: selectedMarket, direction: retryPillarDir, confidence: Math.max(55, retryPillarConf), payout: retryLsData.payout || null });
              resultFinalizedRef.current = false;
              earlyCheckDoneRef.current = false;
              setExpiryTime(verifyAtRetry);
              setCountdown(Math.ceil((verifyAtRetry.getTime() - Date.now()) / 1000));
              toast.success(`Signal generated via retry! Confidence ${Math.max(55, retryPillarConf)}%`);
              setIsGenerating(false);
              return;
            }
          }

          // Retry also failed — try aiData one final time before giving up.
          // The backend always returns a direction (even CANDLE_FALLBACK), so if aiData
          // exists here it means the backend responded but both live-signal calls failed.
          const emergencyDir: 'CALL' | 'PUT' | null =
            aiData?.direction === 'UP' || aiData?.direction === 'CALL' ? 'CALL' :
            aiData?.direction === 'DOWN' || aiData?.direction === 'PUT' ? 'PUT' : null;

          if (emergencyDir) {
            console.log('[LIVE] Emergency: using aiData direction as absolute last resort:', emergencyDir);
            const entryNow = new Date();
            entryNow.setSeconds(0, 0);
            entryNow.setMinutes(entryNow.getMinutes() + 1);
            const verifyAtEmergency = new Date(entryNow.getTime() + 120000);
            const emergencySignal: Signal = {
              id: Date.now().toString(),
              market: selectedMarket,
              direction: emergencyDir,
              confidence: 55,
              entryPrice: 0,
              timestamp: entryNow,
              expiry: '1 min',
              status: 'active',
              trend: 'NEUTRAL',
              rsi: 50,
              support: 0,
              resistance: 0,
              payout: null,
              reasoning: '[EMERGENCY SIGNAL — All data sources failed, AI candle fallback used]',
              selfCorrection: null,
              backtest: null,
              conflictAnalysis: null,
            };
            setCurrentSignal(emergencySignal);
            resultFinalizedRef.current = false;
            earlyCheckDoneRef.current = false;
            setExpiryTime(verifyAtEmergency);
            setCountdown(Math.ceil((verifyAtEmergency.getTime() - Date.now()) / 1000));
            toast.success('Signal generated (emergency mode) — 55% confidence');
            setIsGenerating(false);
            return;
          }

          // Truly nothing — no response from backend at all
          const aiFailureMessage = aiData?.filterReason || rawAiValue?.error?.message || (aiInvokeError instanceof Error ? aiInvokeError.message : '');
          toast.error(lsData?.error || aiFailureMessage || 'Failed to analyze market - please try again');
          setIsGenerating(false);
          return;
        }
      }

      // FIX: Never skip signal due to low confidence filter — always generate.
      // Live-signal filtering is advisory only. AI analysis must always complete.
      // Log the filter reason but continue to produce the signal regardless.
      if (lsData?.signalFiltered || lsData?.scoring?.filtered) {
        console.log('[LIVE] signalFiltered flag set by live-signal, but proceeding anyway:', lsData?.scoring?.filterReason);
      }

      // BUG FIX: When live-signal failed entirely, lsData is null, so analysis would be {}.
      // The analyze-signal backend also runs live-signal internally and stores its result in
      // aiData.analysis. Use that as the primary fallback before the scoring path.
      const analysis: MarketAnalysis = lsData?.analysis || (aiData?.analysis as MarketAnalysis | null) || {} as MarketAnalysis;
      
      // If values are still 0/missing, try the deeper aiData.scoring path
      if ((!analysis.currentPrice || analysis.currentPrice === 0) && aiData) {
        const aiScoring = aiData.scoring || {};
        const aiAnalysis = (aiScoring as any)?.analysis || {};
        if (aiAnalysis.currentPrice) analysis.currentPrice = aiAnalysis.currentPrice;
        if (aiAnalysis.rsi) analysis.rsi = aiAnalysis.rsi;
        if (aiAnalysis.support) analysis.support = aiAnalysis.support;
        if (aiAnalysis.resistance) analysis.resistance = aiAnalysis.resistance;
        if (aiAnalysis.trend) analysis.trend = aiAnalysis.trend;
        if (aiAnalysis.ema20) analysis.ema20 = aiAnalysis.ema20;
        if (aiAnalysis.ema50) analysis.ema50 = aiAnalysis.ema50;
      }

      // STEP 2: AI AUTHORITY MODE — AI is the PRIMARY decision maker
      // The 4-Pillar engine is forced to ALIGN with the AI's direction.
      // AI UP → forces Pillar 1 (Uptrend DNA) → locks CALL
      // AI DOWN → forces Pillar 2 (Downtrend DNA) → locks PUT
      // Pillar is used for informational validation and confluence confirmation ONLY.
      // Guard: only accept 'CALL' or 'PUT' — live-signal can return 'NO_SIGNAL' (truthy string)
      // which would slip through as a valid pillarDirection and produce a phantom signal.
      const pillarDirection = (analysis.direction === 'CALL' || analysis.direction === 'PUT') ? analysis.direction : null;
      const pillarConfidence = analysis.confidence || 0;

      let finalDirection = pillarDirection || 'CALL';
      let finalConfidence = pillarConfidence;
      let reasoning = lsData?.geminiAnalysis?.reasoning || lsData?.geminiAnalysis?.reason || '';

      if (aiHasValidDirection) {
        const normalizedAiDir = aiDirection === 'UP' ? 'CALL' : 'PUT';

        // AI is ALWAYS the authority — only fire if AI confidence > 50%
        if (aiConfidence > 50) {
          finalDirection = normalizedAiDir;

          if (pillarDirection && normalizedAiDir === pillarDirection) {
            // DUAL CONFIRMED — AI and Pillar agree
            finalConfidence = Math.min(98, Math.round((aiConfidence + pillarConfidence) / 2 + 5));
            reasoning = `[DUAL CONFIRMED ✅ AI(${aiConfidence}%) + Pillar(${pillarConfidence}%)] ` + (aiData?.reasoning || reasoning);
          } else {
            // AI AUTHORITY — AI overrides Pillar regardless of pillar lock
            finalConfidence = Math.max(55, aiConfidence - 5);
            reasoning = `[AI AUTHORITY 🧠 — AI(${normalizedAiDir} ${aiConfidence}%) is primary. Pillar(${pillarDirection || 'N/A'} ${pillarConfidence}%) aligned for validation.] ` + (aiData?.reasoning || reasoning);
          }
        } else {
          // FIX: AI confidence ≤ 50% — never block. Fall back to pillar direction if available,
          // otherwise use AI direction at minimum 55% confidence. Signal must always fire.
          if (pillarDirection) {
            finalDirection = pillarDirection;
            finalConfidence = Math.max(55, pillarConfidence);
            reasoning = `[PILLAR OVERRIDE — AI conf ${aiConfidence}% too low, using Pillar(${pillarDirection} ${pillarConfidence}%)] ` + (aiData?.reasoning || reasoning);
          } else {
            // No pillar either — use AI direction at floor 55%
            finalDirection = normalizedAiDir;
            finalConfidence = 55;
            reasoning = `[AI FORCED 55% — AI conf ${aiConfidence}% low, no pillar available] ` + (aiData?.reasoning || reasoning);
          }
        }
      } else if (aiWasFiltered && pillarDirection) {
        finalDirection = pillarDirection;
        finalConfidence = Math.max(55, pillarConfidence);
        reasoning = `[AI FILTERED — ${aiData?.filterReason || 'AI completed but blocked the setup'} | using Pillar(${pillarDirection} ${pillarConfidence}%)] ` + (aiData?.reasoning || reasoning);

      } else if (aiWasFiltered && hasBackendPillarResult) {
        // AI was filtered but live-signal failed — fall back to backend's pillar direction
        finalDirection = backendResolvedDir!;
        finalConfidence = Math.max(55, backendResolvedConf);
        reasoning = `[AI FILTERED — ${aiData?.filterReason || 'AI blocked the setup'} | Backend Pillar(${backendResolvedDir} ${backendResolvedConf}%)] ` + (aiData?.reasoning || reasoning);

      } else if (pillarDirection) {
        // ── BUG FIX: Precise status-based AI failure message ──────────────────────────
        // Previously: relied solely on rawAiFailureMessage which is always empty on a
        // successful 200 response → always showed "AI temporarily unavailable".
        // Now: classify by matchStatus first, then fall back to error message text.
        const rawAiFailureMessage = rawAiValue?.error?.message || (aiInvokeError instanceof Error ? aiInvokeError.message : '');
        const aiFailureMessage =
          aiData?.matchStatus === 'PILLAR_ONLY'
            ? 'AI key pool unavailable — pillar signal used'
            : aiData?.matchStatus === 'PILLAR_FALLBACK'
              ? 'AI pool unavailable, pillar result used'
              : /aborted|context canceled|request failed|failed to fetch/i.test(rawAiFailureMessage)
                ? 'AI pool refreshing'
                : rawAiFailureMessage
                  ? rawAiFailureMessage
                  : 'AI temporarily unavailable';
        finalDirection = pillarDirection;
        finalConfidence = Math.max(55, pillarConfidence);
        reasoning = `[PILLAR ACTIVE — ${aiFailureMessage} | Pillar(${pillarDirection} ${pillarConfidence}%)] ` + reasoning;

      } else if (hasBackendPillarResult) {
        // ── BUG FIX: Use backend's resolved pillar direction when live-signal ALSO failed ──
        // Previously: this entire case was MISSING. When lsData was null AND analyze-signal
        // returned PILLAR_FALLBACK/PILLAR_ONLY, the frontend had no pillarDirection to use
        // (since that comes from lsData), so the signal was silently abandoned.
        // Now: we extract the backend's final resolved direction from aiData.direction.
        const rawAiFailureMessage = rawAiValue?.error?.message || (aiInvokeError instanceof Error ? aiInvokeError.message : '');
        const aiFailureMessage =
          aiData?.matchStatus === 'PILLAR_ONLY'
            ? 'AI key pool unavailable'
            : aiData?.matchStatus === 'PILLAR_FALLBACK'
              ? 'AI pool unavailable'
              : /aborted|context canceled|request failed|failed to fetch/i.test(rawAiFailureMessage)
                ? 'AI pool refreshing'
                : rawAiFailureMessage || 'AI temporarily unavailable';
        finalDirection = backendResolvedDir!;
        finalConfidence = Math.max(55, backendResolvedConf);
        reasoning = `[PILLAR ACTIVE — ${aiFailureMessage}, pillar result used | Pillar(${backendResolvedDir} ${backendResolvedConf}%)] ` + (aiData?.reasoning || '');
        console.log(`[LIVE] Using backend pillar direction as last resort: ${backendResolvedDir} @ ${backendResolvedConf}%`);
      }


      // Enforce exact 3-minute analysis window before delivering signal to user
      const minWindowMs = 180000;
      const elapsedMs = Date.now() - signalGenerationStartedAt;
      const backendSuggestedDelay = Number(aiData?.recommendedClientDelayMs || 0);
      const remainingMs = Math.max(minWindowMs - elapsedMs, backendSuggestedDelay, 0);
      if (remainingMs > 0) {
        console.log(`[LIVE] Holding signal delivery for ${remainingMs}ms to complete 3-minute window`);
        await new Promise(resolve => setTimeout(resolve, remainingMs));
      }

      // Calculate entry time as the START of the next minute
      const now = new Date();
      const entryTime = new Date(now);
      entryTime.setSeconds(0);
      entryTime.setMilliseconds(0);
      entryTime.setMinutes(entryTime.getMinutes() + 1);
      
      const verifyAt = new Date(entryTime.getTime() + 120000);
      const initialCountdown = Math.ceil((verifyAt.getTime() - now.getTime()) / 1000);

      // AI AUTHORITY: Force pillar trend to align with AI direction
      // When AI is authority, the trend MUST reflect AI's decision, not the independent pillar trend
      const aiAuthorityTrend: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = 
        aiHasValidDirection && aiConfidence > 50
          ? (aiDirection === 'UP' ? 'BULLISH' : 'BEARISH')
          : (analysis.trend || 'NEUTRAL');

      const newSignal: Signal = {
        id: Date.now().toString(),
        market: selectedMarket,
        direction: finalDirection as 'CALL' | 'PUT',
        confidence: finalConfidence,
        entryPrice: analysis.currentPrice || 0,
        timestamp: entryTime,
        expiry: '1 min',
        status: 'active',
        trend: aiAuthorityTrend,
        rsi: analysis.rsi || 50,
        support: analysis.support || 0,
        resistance: analysis.resistance || 0,
        payout: lsData?.payout || aiData?.liveSignalPayout || (aiData?.scoring as any)?.payout || (aiData as any)?.payout || null,
        reasoning,
        selfCorrection: lsData?.selfCorrection || (aiData as any)?.selfCorrection || null,
        backtest: lsData?.backtest || null,
        conflictAnalysis: lsData?.scoring?.conflictAnalysis 
          ? { 
              ...lsData.scoring.conflictAnalysis, 
              blockedStrategies: lsData.scoring.blockedStrategies || [],
              blockedCounts: lsData.scoring.blockedCounts || undefined
            }
          : (aiData?.scoring as any)?.conflictAnalysis
            ? {
                ...(aiData?.scoring as any).conflictAnalysis,
                blockedStrategies: (aiData?.scoring as any).blockedStrategies || [],
                blockedCounts: (aiData?.scoring as any).blockedCounts || undefined
              }
            : null,
      };

      setCurrentSignal(newSignal);

      // Voice announcement for the signal
      announceSignal({
        pair: selectedMarket,
        direction: finalDirection,
        confidence: finalConfidence,
        payout: lsData?.payout || null,
      });
      setExpiryTime(verifyAt);
      setCountdown(initialCountdown);
      
      console.log(`Signal created: entry=${entryTime.toISOString()}, verifyAt=${verifyAt.toISOString()}, countdown=${initialCountdown}s`);
      
      const rawConfidence = analysis.rawConfidence || Math.round(finalConfidence / 10);
      if (rawConfidence >= 9) {
        toast.success(`🎯 A+ SIGNAL! Confidence ${rawConfidence}/10 - Strong setup!`);
      } else if (rawConfidence >= 8) {
        toast.success(`✅ Strong Signal! Confidence ${rawConfidence}/10`);
      } else {
        toast.success(`Signal generated! Confidence ${rawConfidence}/10`);
      }
    } catch (err) {
      console.error('Error generating signal:', err);
      toast.error('Failed to generate signal');
    } finally {
      setIsGenerating(false);
    }
  };

  // Note: recordOutcome removed - WIN/LOSS is now determined automatically from API

  const groupedMarkets = MARKETS.reduce((acc, market) => {
    if (!acc[market.category]) acc[market.category] = [];
    acc[market.category].push(market);
    return acc;
  }, {} as Record<string, typeof MARKETS>);

  if (!user) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen pb-24 w-full"
    >
      {/* Background Effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-success/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary/10 rounded-full blur-3xl" />
        {/* Grid pattern */}
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, hsl(var(--success) / 0.3) 1px, transparent 0)`,
            backgroundSize: '40px 40px'
          }}
        />
      </div>

      <div className="relative z-10">
        <Header />

        <div className="max-w-lg md:max-w-4xl mx-auto px-4 pt-4">
          {/* Market Selector */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="mb-6"
          >
            <div className="relative">
              <button
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="w-full glass-card p-4 flex items-center justify-between border border-success/30 hover:border-success/50 transition-all"
              >
                <span className={selectedMarket ? 'text-foreground font-medium' : 'text-muted-foreground'}>
                  {selectedMarket || 'Select Market'}
                </span>
                <div className="flex items-center gap-2">
                  {selectedMarket && (
                    <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs font-bold transition-all ${
                      marketPayout === null
                        ? 'bg-muted/40 border-border/40 text-muted-foreground'
                        : marketPayout >= 85
                          ? 'bg-success/20 border-success/50 text-success shadow-[0_0_8px_hsl(var(--success)/0.3)]'
                          : marketPayout >= 75
                            ? 'bg-yellow-500/20 border-yellow-500/50 text-yellow-400'
                            : 'bg-orange-500/20 border-orange-500/50 text-orange-400'
                    }`}>
                      {marketPayout === null ? (
                        <span className="animate-pulse">—%</span>
                      ) : (
                        <>
                          <span className={`w-1.5 h-1.5 rounded-full animate-pulse ${
                            marketPayout >= 85 ? 'bg-success' : marketPayout >= 75 ? 'bg-yellow-400' : 'bg-orange-400'
                          }`} />
                          {marketPayout}%
                        </>
                      )}
                    </div>
                  )}
                  <ChevronDown className={`w-5 h-5 text-success transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
                </div>
              </button>

              <AnimatePresence>
                {isDropdownOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute top-full left-0 right-0 mt-2 glass-card border border-success/20 rounded-xl overflow-hidden z-50 max-h-64 overflow-y-auto scrollbar-hide"
                  >
                    {Object.entries(groupedMarkets).map(([category, markets]) => (
                      <div key={category}>
                        <div className="px-4 py-2 text-xs font-semibold text-success/70 bg-success/5">
                          {category}
                        </div>
                        {markets.map((market) => (
                          <button
                            key={market.id}
                            onClick={() => {
                              setSelectedMarket(market.id);
                              setIsDropdownOpen(false);
                              // Clear ALL previous signal/result data on market change
                              setCurrentSignal(null);
                              setLastResultDebug(null);
                              setSelfCorrectionStats(null);
                              setChartResultData(null);
                              setAutoSignalData(null);
                              setPendingAutoResult(null);
                            }}
                            className={`w-full px-4 py-3 text-left hover:bg-success/10 transition-colors ${
                              selectedMarket === market.id ? 'bg-success/20 text-success' : 'text-foreground'
                            }`}
                          >
                            {market.name}
                          </button>
                        ))}
                      </div>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>

          {/* Signal Display Area */}
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="glass-card p-6 border border-border/50 min-h-[300px] flex flex-col items-center justify-center relative overflow-hidden"
          >
            {/* Corner decorations */}
            <div className="absolute top-0 left-0 w-16 h-16 border-l-2 border-t-2 border-success/30 rounded-tl-2xl" />
            <div className="absolute top-0 right-0 w-16 h-16 border-r-2 border-t-2 border-success/30 rounded-tr-2xl" />
            <div className="absolute bottom-0 left-0 w-16 h-16 border-l-2 border-b-2 border-success/30 rounded-bl-2xl" />
            <div className="absolute bottom-0 right-0 w-16 h-16 border-r-2 border-b-2 border-success/30 rounded-br-2xl" />

            {isGenerating ? (
              <SignalLoadingAnimation isRealAnalysis={true} fastMode={!aiMode} />
            ) : selectedMarket ? (
              <div className="w-full h-full grid grid-cols-1 grid-rows-1">
                {/* Live chart is ALWAYS mounted for Telegram capture.
                    When a signal exists, the chart is hidden visually but stays active in the background. */}
                <div
                  className={`col-start-1 row-start-1 ${currentSignal ? 'opacity-0 pointer-events-none' : ''}`}
                >
                  <OTCChart
                    market={selectedMarket}
                    onChartCapture={(capture) => setChartCaptureFunc(() => capture)}
                  />
                </div>

                {/* Signal overlay (shows instead of the chart, without unmounting it) */}
                {currentSignal ? (
                  <motion.div
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="col-start-1 row-start-1 w-full px-2 relative z-10"
                  >
                {/* Header: Icon + Market + Direction Badge */}
                <div className="flex items-center gap-4 mb-6">
                  <motion.div
                    className={`w-14 h-14 rounded-xl flex items-center justify-center ${
                      currentSignal.direction === 'CALL' 
                        ? 'bg-success/20' 
                        : 'bg-put/20'
                    }`}
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    {currentSignal.direction === 'CALL' ? (
                      <TrendingUp className="w-8 h-8 text-success" />
                    ) : (
                      <TrendingDown className="w-8 h-8 text-put" />
                    )}
                  </motion.div>

                  <div className="flex-1">
                    <h2 className="text-xl font-bold text-foreground">
                      {currentSignal.market}
                    </h2>
                    <p className="text-sm text-muted-foreground">
                      Signal #{currentSignal.id.slice(-6)}
                    </p>
                  </div>

                  <span className={`px-4 py-2 rounded-full font-bold text-sm ${
                    currentSignal.direction === 'CALL' 
                      ? 'bg-success text-success-foreground' 
                      : 'bg-put text-white'
                  }`}>
                    {currentSignal.direction === 'CALL' ? 'BUY' : 'SELL'}
                  </span>
                </div>

                {/* Current Price & Trend */}
                <div className="glass-card p-4 rounded-xl border border-primary/30 bg-primary/5 mb-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Current Price</p>
                      <p className="text-2xl font-bold text-foreground">
                        {currentSignal.entryPrice.toFixed(currentSignal.market.includes('JPY') ? 3 : 5)}
                      </p>
                    </div>
                    {/* MTF bias logic works in background but not displayed */}
                  </div>
                </div>

                {/* 2x3 Grid Info Cards */}
                <div className="grid grid-cols-2 gap-3 mb-6">
                  {/* Entry Time */}
                  <div className="glass-card p-4 rounded-xl border border-primary/30 bg-primary/5">
                    <div className="flex items-center gap-2 mb-2">
                      <Clock className="w-4 h-4 text-primary" />
                      <span className="text-xs font-medium text-primary">Entry Time</span>
                    </div>
                    <p className="text-lg font-bold text-foreground">
                      {new Date(currentSignal.timestamp).toLocaleTimeString('en-US', { 
                        hour: '2-digit', 
                        minute: '2-digit',
                        hour12: true 
                      })}
                    </p>
                  </div>

                  {/* Confidence */}
                  <div className={`glass-card p-4 rounded-xl border ${
                    currentSignal.direction === 'CALL' 
                      ? 'border-success/30 bg-success/5' 
                      : 'border-put/30 bg-put/5'
                  }`}>
                    <div className="flex items-center gap-2 mb-2">
                      <Activity className={`w-4 h-4 ${
                        currentSignal.direction === 'CALL' ? 'text-success' : 'text-put'
                      }`} />
                      <span className={`text-xs font-medium ${
                        currentSignal.direction === 'CALL' ? 'text-success' : 'text-put'
                      }`}>Confidence</span>
                    </div>
                    <p className={`text-lg font-bold ${
                      currentSignal.direction === 'CALL' ? 'text-success' : 'text-put'
                    }`}>
                      {currentSignal.confidence}%
                    </p>
                  </div>

                  {/* RSI */}
                  <div className="glass-card p-4 rounded-xl border border-purple-500/30 bg-purple-500/5">
                    <div className="flex items-center gap-2 mb-2">
                      <BarChart3 className="w-4 h-4 text-purple-400" />
                      <span className="text-xs font-medium text-purple-400">RSI (14)</span>
                    </div>
                    <p className={`text-lg font-bold ${
                      currentSignal.rsi < 30 ? 'text-success' : currentSignal.rsi > 70 ? 'text-put' : 'text-foreground'
                    }`}>
                      {currentSignal.rsi.toFixed(1)}
                    </p>
                  </div>

                  {/* Payout / Duration */}
                  <div className="glass-card p-4 rounded-xl border border-primary/30 bg-primary/5">
                    <div className="flex items-center gap-2 mb-2">
                      <Zap className="w-4 h-4 text-primary" />
                      <span className="text-xs font-medium text-primary">
                        {currentSignal.payout ? 'Payout' : 'Duration'}
                      </span>
                    </div>
                    <p className="text-lg font-bold text-foreground">
                      {currentSignal.payout ? `${currentSignal.payout}%` : '1 min'}
                    </p>
                  </div>

                  {/* Support */}
                  <div className="glass-card p-4 rounded-xl border border-success/30 bg-success/5">
                    <div className="flex items-center gap-2 mb-2">
                      <Target className="w-4 h-4 text-success" />
                      <span className="text-xs font-medium text-success">Support</span>
                    </div>
                    <p className="text-sm font-bold text-foreground">
                      {currentSignal.support.toFixed(currentSignal.market.includes('JPY') ? 3 : 5)}
                    </p>
                  </div>

                  {/* Resistance */}
                  <div className="glass-card p-4 rounded-xl border border-put/30 bg-put/5">
                    <div className="flex items-center gap-2 mb-2">
                      <Target className="w-4 h-4 text-put" />
                      <span className="text-xs font-medium text-put">Resistance</span>
                    </div>
                    <p className="text-sm font-bold text-foreground">
                      {currentSignal.resistance.toFixed(currentSignal.market.includes('JPY') ? 3 : 5)}
                    </p>
                  </div>
                </div>

                {/* Conflict Analysis Panel */}
                {currentSignal.conflictAnalysis && (
                  <SignalConflictPanel 
                    conflictAnalysis={currentSignal.conflictAnalysis}
                    direction={currentSignal.direction}
                  />
                )}

                {/* Generated At Footer */}
                <div className="border-t border-border/30 pt-4 mt-4">
                  <p className="text-xs text-muted-foreground">
                    Generated at {new Date(currentSignal.timestamp).toLocaleDateString('en-US', {
                      month: '2-digit',
                      day: '2-digit',
                      year: 'numeric'
                    })}, {new Date(currentSignal.timestamp).toLocaleTimeString('en-US', {
                      hour: '2-digit',
                      minute: '2-digit',
                      second: '2-digit',
                      hour12: true
                    })}
                  </p>
                </div>

                {/* Automatic WIN/LOSS Status */}
                {isCheckingResult ? (
                  <div className="mt-4 border-t border-border/30 pt-4">
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-4 h-4 border-2 border-success border-t-transparent rounded-full animate-spin" />
                      <p className="text-xs text-muted-foreground animate-pulse">
                        Verifying result from market data...
                      </p>
                    </div>
                  </div>
                ) : countdown > 0 ? (
                  <div className="mt-4 border-t border-border/30 pt-4">
                    <p className="text-xs text-muted-foreground text-center">
                      ⏳ Result will be auto-verified when candle closes
                    </p>
                  </div>
                ) : currentSignal.status === 'won' || currentSignal.status === 'lost' ? (
                  <div className="mt-4 border-t border-border/30 pt-4 space-y-3">
                    <p className={`text-sm text-center font-bold ${currentSignal.status === 'won' ? 'text-success' : 'text-put'}`}>
                      {currentSignal.status === 'won' ? '✅ WIN' : '❌ LOSS'} - Auto-verified
                    </p>
                    {selfCorrectionStats && (
                      <p className="text-xs text-center text-muted-foreground">
                        Self-Correction: {selfCorrectionStats.wins}W / {selfCorrectionStats.losses}L ({selfCorrectionStats.winRate}% win rate)
                      </p>
                    )}
                    
                    {/* DEBUG VERIFICATION PANEL */}
                    {lastResultDebug && (
                      <div className="mt-3 p-3 rounded-lg bg-muted/30 border border-border/50">
                        <p className="text-xs font-bold text-primary mb-2 flex items-center gap-1">
                          🔍 Verification Data (Check Accuracy)
                        </p>
                        <div className="space-y-1 text-xs font-mono">
                          <p className="text-muted-foreground">
                            <span className="text-foreground">Candle Time:</span> {lastResultDebug.candleTime}
                          </p>
                          <p className="text-muted-foreground">
                            <span className="text-foreground">Open Price:</span> {lastResultDebug.openPrice}
                          </p>
                          <p className="text-muted-foreground">
                            <span className="text-foreground">Close Price:</span> {lastResultDebug.closePrice}
                          </p>
                          <p className="text-muted-foreground">
                            <span className="text-foreground">Price Diff:</span>{' '}
                            <span className={lastResultDebug.priceDiff > 0 ? 'text-success' : lastResultDebug.priceDiff < 0 ? 'text-put' : ''}>
                              {lastResultDebug.priceDiff > 0 ? '+' : ''}{lastResultDebug.priceDiff.toFixed(6)}
                            </span>
                          </p>
                          <p className="text-muted-foreground border-t border-border/30 pt-1 mt-1">
                            <span className="text-foreground">Logic:</span> {lastResultDebug.logic}
                          </p>
                        </div>
                        <p className="text-xs text-yellow-400 mt-2">
                          ⚠️ Compare Open/Close with your broker's candle to verify accuracy
                        </p>
                      </div>
                    )}
                  </div>
                ) : null}
                  </motion.div>
                ) : null}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">Select a market and generate a signal</p>
              </div>
            )}
          </motion.div>

          {/* Generate Button + AI Toggle Row */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="flex items-center gap-2 mt-6"
          >
            <button
              onClick={generateSignal}
              disabled={!selectedMarket || isGenerating || countdown > 0}
              className={`flex-1 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all ${
                !selectedMarket || isGenerating || countdown > 0
                  ? 'bg-muted text-muted-foreground cursor-not-allowed'
                  : 'bg-gradient-to-r from-success to-success/80 text-success-foreground btn-glow hover:shadow-call'
              }`}
            >
              <Zap className="w-5 h-5" />
              {isGenerating ? (aiMode ? 'Analyzing...' : '⚡ Fast Mode...') : countdown > 0 ? `Wait ${countdown}s` : 'Generate Signal'}
            </button>

            {/* AI Mode Toggle — live signal style */}
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => {
                const next = !aiMode;
                setAiMode(next);
                try { localStorage.setItem('artrix_ai_mode', next ? 'on' : 'off'); } catch {}
                toast.info(next ? '🤖 AI Mode ON — Full 3-min analysis' : '⚡ AI Mode OFF — Fast 60s code analysis');
              }}
              className={`flex-shrink-0 w-14 h-14 rounded-xl flex flex-col items-center justify-center gap-0.5 border-2 transition-all relative overflow-hidden ${
                aiMode
                  ? 'bg-blue-500/15 border-blue-500/60 text-blue-400 shadow-[0_0_16px_hsl(217,91%,60%,0.3)]'
                  : 'bg-emerald-500/15 border-emerald-500/60 text-emerald-400 shadow-[0_0_16px_hsl(152,69%,52%,0.25)]'
              }`}
              title={aiMode ? 'AI Mode ON — click to switch to Fast Code Mode' : 'Fast Code Mode — click to switch to AI Mode'}
            >
              {/* Pulsing ring when AI is ON */}
              {aiMode && (
                <span className="absolute inset-0 rounded-xl border-2 border-blue-400/40 animate-ping pointer-events-none" />
              )}
              {/* Live dot */}
              <span className={`absolute top-1.5 right-1.5 w-2 h-2 rounded-full ${aiMode ? 'bg-blue-400 animate-pulse' : 'bg-emerald-400'}`} />
              {aiMode ? <Bot className="w-5 h-5" /> : <BotOff className="w-5 h-5" />}
              <span className="text-[8px] font-bold leading-none tracking-wide">{aiMode ? 'AI ON' : 'AI OFF'}</span>
            </motion.button>
          </motion.div>

          {/* Artrix Telegram Signal Button */}
          <motion.button
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.25 }}
            onClick={() => setShowTelegramPanel(true)}
            className="w-full mt-4 py-3 rounded-xl font-bold bg-gradient-to-r from-blue-500 to-cyan-500 text-white flex items-center justify-center gap-2 hover:shadow-lg transition-all"
          >
            <Send className="w-5 h-5" />
            Artrix Telegram Signal
          </motion.button>

          {/* History Button */}
          <motion.button
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            onClick={() => setShowHistory(!showHistory)}
            className="w-full mt-4 py-3 rounded-xl font-medium text-muted-foreground border border-border/50 hover:border-primary/50 hover:text-foreground transition-all flex items-center justify-center gap-2"
          >
            <Clock className="w-4 h-4" />
            Signal History ({signalHistory.length})
          </motion.button>

          {/* Pillar & Trend Info */}
          {currentSignal && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.32 }}
              className="mt-4 glass-card p-4 border border-cyan-500/30 rounded-xl"
            >
              <div className="flex items-center gap-2 mb-3">
                <Layers className="w-5 h-5 text-cyan-400" />
                <h3 className="font-semibold text-foreground">4-Pillar Analysis</h3>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="p-2 rounded-lg bg-cyan-500/5 border border-cyan-500/20">
                  <p className="text-xs text-muted-foreground mb-1">Active Pillar</p>
                  <p className="font-bold text-cyan-400">
                    {currentSignal.trend === 'BULLISH' ? 'Pillar 1 (Uptrend)' 
                     : currentSignal.trend === 'BEARISH' ? 'Pillar 2 (Downtrend)' 
                     : 'Pillar 3/4 (Range)'}
                  </p>
                </div>
                <div className="p-2 rounded-lg bg-cyan-500/5 border border-cyan-500/20">
                  <p className="text-xs text-muted-foreground mb-1">Direction Lock</p>
                  <p className={`font-bold ${
                    currentSignal.trend === 'BULLISH' ? 'text-success' 
                    : currentSignal.trend === 'BEARISH' ? 'text-put' 
                    : 'text-foreground'
                  }`}>
                    {currentSignal.trend === 'BULLISH' ? 'CALL ONLY' 
                     : currentSignal.trend === 'BEARISH' ? 'PUT ONLY' 
                     : 'BOTH'}
                  </p>
                </div>
                <div className="p-2 rounded-lg bg-cyan-500/5 border border-cyan-500/20">
                  <p className="text-xs text-muted-foreground mb-1">Trend Engine</p>
                  <p className="font-bold text-foreground">
                    {currentSignal.trend === 'BULLISH' ? '📈 Uptrend' 
                     : currentSignal.trend === 'BEARISH' ? '📉 Downtrend' 
                     : '↔️ Ranging'}
                  </p>
                </div>
                <div className="p-2 rounded-lg bg-cyan-500/5 border border-cyan-500/20">
                  <p className="text-xs text-muted-foreground mb-1">Pillar Gate</p>
                  <p className="font-bold text-foreground">Cross-Ref Active</p>
                </div>
              </div>
            </motion.div>
          )}

          {/* Logic Section - Shows reasoning for current signal */}
          {currentSignal?.reasoning && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.35 }}
              className="mt-4 glass-card p-4 border border-primary/30 rounded-xl"
            >
              <div className="flex items-center gap-2 mb-3">
                <Lightbulb className="w-5 h-5 text-primary" />
                <h3 className="font-semibold text-foreground">Signal Logic</h3>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {currentSignal.reasoning}
              </p>
            </motion.div>
          )}

          {/* Backtest Results (Real Market Only) */}
          {currentSignal?.backtest && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="mt-4 glass-card p-4 border border-blue-500/30 rounded-xl"
            >
              <div className="flex items-center gap-2 mb-3">
                <BarChart3 className="w-5 h-5 text-blue-400" />
                <h3 className="font-semibold text-foreground">Backtest (3000 Candles)</h3>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className={`p-2 rounded-lg ${currentSignal.backtest.recommendation === 'CALL' ? 'bg-success/20 border border-success/30' : 'bg-muted/50'}`}>
                  <span className="text-success font-medium">CALL:</span> {currentSignal.backtest.call.winRate.toFixed(1)}% ({currentSignal.backtest.call.wins}W/{currentSignal.backtest.call.losses}L)
                </div>
                <div className={`p-2 rounded-lg ${currentSignal.backtest.recommendation === 'PUT' ? 'bg-put/20 border border-put/30' : 'bg-muted/50'}`}>
                  <span className="text-put font-medium">PUT:</span> {currentSignal.backtest.put.winRate.toFixed(1)}% ({currentSignal.backtest.put.wins}W/{currentSignal.backtest.put.losses}L)
                </div>
              </div>
              {currentSignal.backtest.warning && (
                <p className="mt-2 text-xs text-amber-400">{currentSignal.backtest.warning}</p>
              )}
            </motion.div>
          )}

          {/* Self-Correction Insights */}
          {currentSignal?.selfCorrection?.isActive && currentSignal.selfCorrection.insights && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.45 }}
              className="mt-4 glass-card p-4 border border-amber-500/30 rounded-xl"
            >
              <div className="flex items-center gap-2 mb-3">
                <AlertCircle className="w-5 h-5 text-amber-400" />
                <h3 className="font-semibold text-foreground">Self-Correction Active</h3>
              </div>
              <p className="text-xs text-amber-300/80 leading-relaxed">
                {currentSignal.selfCorrection.insights}
              </p>
            </motion.div>
          )}

          {/* Signal History */}
          <AnimatePresence>
            {showHistory && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden mt-4"
              >
                <div className="glass-card p-4 border border-border/50 max-h-64 overflow-y-auto scrollbar-hide">
                  {signalHistory.length === 0 ? (
                    <p className="text-center text-muted-foreground py-4">No signal history yet</p>
                  ) : (
                    <div className="space-y-3">
                      {signalHistory.map((signal) => (
                        <div
                          key={signal.id}
                          className="flex items-center justify-between p-3 rounded-lg bg-muted/50"
                        >
                          <div className="flex items-center gap-3">
                            {signal.direction === 'CALL' ? (
                              <TrendingUp className="w-5 h-5 text-success" />
                            ) : (
                              <TrendingDown className="w-5 h-5 text-put" />
                            )}
                            <div>
                              <p className="font-medium text-sm">{signal.market}</p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(signal.timestamp).toLocaleTimeString()}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className={`text-xs font-bold px-2 py-1 rounded ${
                              signal.direction === 'CALL' ? 'bg-success/20 text-success' : 'bg-put/20 text-put'
                            }`}>
                              {signal.direction}
                            </span>
                            <p className="text-xs text-muted-foreground mt-1">
                              {signal.confidence}%
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Info Note */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="mt-6 p-4 rounded-xl bg-warning/10 border border-warning/20 flex items-start gap-3"
          >
            <AlertCircle className="w-5 h-5 text-warning flex-shrink-0 mt-0.5" />
            <p className="text-xs text-warning/80">
              Live signals are AI-generated predictions based on market analysis. Trading involves risk. Past performance does not guarantee future results.
            </p>
          </motion.div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <motion.nav
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        transition={{ type: "spring", stiffness: 200, damping: 25 }}
        className="fixed bottom-0 left-0 right-0 z-50"
      >
        <div className="bg-card/95 backdrop-blur-xl border-t border-success/20 px-6 py-4">
          <div className="flex items-center justify-around max-w-md mx-auto">
            <motion.button
              whileHover={{ scale: 1.1, y: -2 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => navigate('/dashboard')}
              className="flex flex-col items-center gap-1 p-2 rounded-xl text-muted-foreground hover:text-foreground transition-all"
            >
              <Activity className="w-6 h-6" />
              <span className="text-xs font-medium">Analyzer</span>
            </motion.button>

            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="relative -mt-6"
            >
              <motion.div
                className="w-16 h-16 rounded-full bg-gradient-to-br from-success to-success/70 flex items-center justify-center"
                animate={{
                  boxShadow: [
                    '0 0 20px hsl(150 100% 45% / 0.4)',
                    '0 0 35px hsl(150 100% 45% / 0.6)',
                    '0 0 20px hsl(150 100% 45% / 0.4)'
                  ]
                }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              >
                <TrendingUp className="w-7 h-7 text-success-foreground" />
              </motion.div>
            </motion.div>

            <motion.button
              whileHover={{ scale: 1.1, y: -2 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setShowHistory(!showHistory)}
              className="flex flex-col items-center gap-1 p-2 rounded-xl text-muted-foreground hover:text-foreground transition-all"
            >
              <Clock className="w-6 h-6" />
              <span className="text-xs font-medium">History</span>
            </motion.button>
          </div>
          <p className="text-center text-xs text-success font-medium mt-2">Live Signal</p>
        </div>
      </motion.nav>

      {/* Hidden TelegramChart for high-res desktop-style Telegram captures */}
      <TelegramChart 
        ref={telegramChartRef} 
        market={selectedMarket} 
        signalData={
          // Auto signal data takes priority so chart dashboard matches what was sent
          autoSignalData ?? (currentSignal ? {
            direction: currentSignal.direction,
            timestamp: new Date(currentSignal.timestamp),
            pair: currentSignal.market
          } : null)
        }
        resultData={chartResultData}
      />

      {/* Telegram Signal Panel */}
      <TelegramSignalPanel
        isOpen={showTelegramPanel}
        onClose={() => setShowTelegramPanel(false)}
        currentSignal={currentSignal}
        signalHistory={signalHistory}
        onSignalSent={() => setSignalSentToTelegram(true)}
        chartCaptureFunc={chartCaptureFunc}
        telegramChartCapture={() => telegramChartRef.current?.capture() || null}
        aiEnabled={aiMode}
        onAutoMarketChange={(pair) => setSelectedMarket(pair)}
        onAutoSignalFired={(direction, pair, timestamp) => {
          setAutoSignalData({ direction, pair, timestamp });
          setChartResultData(null);
        }}
        onAutoResultReady={(resultType, pair, time, wins, losses, winRate) => {
          setChartResultData({ resultType, pair, time, wins, losses, winRate });
          setAutoSignalData(null);
        }}
        onAutoSetSignal={(data) => telegramChartRef.current?.setSignal(data)}
        onAutoSetResult={(data) => telegramChartRef.current?.setResult(data)}
      />
    </motion.div>
  );
}
