import { useState, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Download, RotateCcw, TrendingUp, TrendingDown, Minus, DollarSign, Target, ShieldAlert, Percent } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

interface Trade {
  id: number;
  result: 'W' | 'L' | 'D';
  amount: number;
  pl: number;
  balance: number;
  note: string;
}

export default function MoneyManagement() {
  const navigate = useNavigate();

  // Setup state
  const [initialCapital, setInitialCapital] = useState(1000);
  const [baseAmount, setBaseAmount] = useState(10);
  const [payout, setPayout] = useState(85);
  const [profitTarget, setProfitTarget] = useState(10);
  const [stopLoss, setStopLoss] = useState(20);
  const [setupDone, setSetupDone] = useState(false);

  // Session state
  const [balance, setBalance] = useState(0);
  const [nextTrade, setNextTrade] = useState(0);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [consecutiveLosses, setConsecutiveLosses] = useState(0);
  const [lossAccumulated, setLossAccumulated] = useState(0);
  const [showAlert, setShowAlert] = useState<'target' | 'stoploss' | null>(null);

  const stats = useMemo(() => {
    const wins = trades.filter(t => t.result === 'W').length;
    const losses = trades.filter(t => t.result === 'L').length;
    const draws = trades.filter(t => t.result === 'D').length;
    const netPL = balance - initialCapital;
    const netPLPercent = initialCapital > 0 ? (netPL / initialCapital) * 100 : 0;
    const targetAmount = initialCapital * (profitTarget / 100);
    const targetProgress = targetAmount > 0 ? Math.min(100, Math.max(0, (netPL / targetAmount) * 100)) : 0;
    return { wins, losses, draws, netPL, netPLPercent, targetProgress };
  }, [trades, balance, initialCapital, profitTarget]);

  const chartData = useMemo(() => {
    const data = [{ trade: 0, balance: initialCapital }];
    trades.forEach(t => data.push({ trade: t.id, balance: t.balance }));
    return data;
  }, [trades, initialCapital]);

  const startSession = () => {
    if (initialCapital <= 0 || baseAmount <= 0 || payout <= 0) return;
    setBalance(initialCapital);
    setNextTrade(baseAmount);
    setTrades([]);
    setConsecutiveLosses(0);
    setLossAccumulated(0);
    setSetupDone(true);
    setShowAlert(null);
  };

  const calculateMartingaleAmount = useCallback((totalLost: number) => {
    // Recovery: need to recover all losses + profit margin
    const payoutRate = payout / 100;
    if (payoutRate <= 0) return baseAmount;
    const needed = (totalLost + baseAmount) / payoutRate;
    return Math.ceil(needed * 100) / 100;
  }, [payout, baseAmount]);

  const handleResult = useCallback((result: 'W' | 'L' | 'D') => {
    if (showAlert) return;

    const tradeAmount = nextTrade;
    let pl = 0;
    let newBalance = balance;
    let note = '';
    let newConsecutive = consecutiveLosses;
    let newLossAccum = lossAccumulated;
    let newNextTrade = baseAmount;

    if (result === 'W') {
      pl = +(tradeAmount * (payout / 100)).toFixed(2);
      newBalance = +(balance + pl).toFixed(2);
      note = newConsecutive > 0 ? 'Win (Recovery!)' : 'Win (Reset to base)';
      newConsecutive = 0;
      newLossAccum = 0;
      newNextTrade = baseAmount;
    } else if (result === 'L') {
      pl = -tradeAmount;
      newBalance = +(balance + pl).toFixed(2);
      newConsecutive = consecutiveLosses + 1;
      newLossAccum = +(lossAccumulated + tradeAmount).toFixed(2);
      newNextTrade = calculateMartingaleAmount(newLossAccum);
      note = `Loss (Step ${newConsecutive})`;
    } else {
      pl = 0;
      newBalance = balance;
      newNextTrade = tradeAmount;
      note = 'Draw (Same trade)';
    }

    // Cap next trade to remaining balance
    if (newNextTrade > newBalance) {
      newNextTrade = newBalance;
    }

    const newTrade: Trade = {
      id: trades.length + 1,
      result,
      amount: tradeAmount,
      pl,
      balance: newBalance,
      note,
    };

    const newTrades = [newTrade, ...trades];

    setBalance(newBalance);
    setNextTrade(newNextTrade);
    setTrades(newTrades);
    setConsecutiveLosses(newConsecutive);
    setLossAccumulated(newLossAccum);

    // Check alerts
    const netPL = newBalance - initialCapital;
    const targetAmt = initialCapital * (profitTarget / 100);
    const stopLossAmt = initialCapital * (stopLoss / 100);

    if (netPL >= targetAmt) {
      setShowAlert('target');
    } else if (netPL <= -stopLossAmt) {
      setShowAlert('stoploss');
    }
  }, [balance, nextTrade, trades, consecutiveLosses, lossAccumulated, payout, baseAmount, initialCapital, profitTarget, stopLoss, calculateMartingaleAmount, showAlert]);

  const endSession = () => {
    setSetupDone(false);
    setTrades([]);
    setBalance(0);
    setNextTrade(0);
    setConsecutiveLosses(0);
    setLossAccumulated(0);
    setShowAlert(null);
  };

  const downloadCSV = () => {
    const headers = '#,Result,Trade Amount,P/L,Balance,Note';
    // Reverse to show oldest first in CSV
    const rows = [...trades].reverse().map(t =>
      `${t.id},${t.result},$${t.amount.toFixed(2)},$${t.pl.toFixed(2)},$${t.balance.toFixed(2)},"${t.note}"`
    );
    const csv = [headers, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mm-session-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Setup screen
  if (!setupDone) {
    return (
      <div className="min-h-screen bg-background overflow-x-hidden">
        <div className="fixed inset-0 pointer-events-none overflow-hidden">
          <motion.div animate={{ scale: [1, 1.2, 1], opacity: [0.08, 0.15, 0.08] }} transition={{ duration: 8, repeat: Infinity }} className="absolute top-1/4 -right-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl" />
          <motion.div animate={{ scale: [1.2, 1, 1.2], opacity: [0.1, 0.2, 0.1] }} transition={{ duration: 6, repeat: Infinity }} className="absolute bottom-1/4 -left-1/4 w-80 h-80 bg-accent/20 rounded-full blur-3xl" />
        </div>

        <motion.header initial={{ y: -20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="sticky top-0 z-50 bg-background/80 backdrop-blur-xl border-b border-primary/20">
          <div className="flex items-center justify-between px-4 py-4">
            <motion.button whileTap={{ scale: 0.9 }} onClick={() => navigate(-1)} className="w-10 h-10 rounded-xl bg-card/50 border border-primary/20 flex items-center justify-center text-foreground">
              <ArrowLeft className="w-5 h-5" />
            </motion.button>
            <h1 className="text-lg font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Money Management</h1>
            <div className="w-10" />
          </div>
        </motion.header>

        <main className="relative z-10 px-4 py-6 pb-32 space-y-5 max-w-lg mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center space-y-1">
            <h2 className="text-2xl font-bold text-foreground">Session Setup</h2>
            <p className="text-sm text-muted-foreground">Configure your trading parameters</p>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="rounded-2xl bg-card/60 backdrop-blur-sm border border-primary/30 p-5 space-y-4">
            {[
              { label: 'Initial Capital ($)', icon: DollarSign, value: initialCapital, setter: setInitialCapital },
              { label: 'Base Trade ($)', icon: TrendingUp, value: baseAmount, setter: setBaseAmount },
              { label: 'Payout (%)', icon: Percent, value: payout, setter: setPayout },
              { label: 'Profit Target (%)', icon: Target, value: profitTarget, setter: setProfitTarget },
              { label: 'Stop Loss (%)', icon: ShieldAlert, value: stopLoss, setter: setStopLoss },
            ].map(({ label, icon: Icon, value, setter }) => (
              <div key={label} className="space-y-1.5">
                <label className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Icon className="w-4 h-4 text-primary" />
                  {label}
                </label>
                <input
                  type="number"
                  value={value}
                  onChange={e => setter(+e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-background/60 border border-primary/20 text-foreground text-lg font-semibold focus:outline-none focus:border-primary/50 transition-colors"
                />
              </div>
            ))}
          </motion.div>

          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={startSession}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-primary to-accent text-primary-foreground font-bold text-lg btn-glow"
          >
            Start Session
          </motion.button>
        </main>
      </div>
    );
  }

  // Main dashboard
  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <motion.div animate={{ scale: [1, 1.2, 1], opacity: [0.08, 0.15, 0.08] }} transition={{ duration: 8, repeat: Infinity }} className="absolute top-1/4 -right-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl" />
        <motion.div animate={{ scale: [1.2, 1, 1.2], opacity: [0.1, 0.2, 0.1] }} transition={{ duration: 6, repeat: Infinity }} className="absolute bottom-1/4 -left-1/4 w-80 h-80 bg-accent/20 rounded-full blur-3xl" />
      </div>

      <motion.header initial={{ y: -20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="sticky top-0 z-50 bg-background/80 backdrop-blur-xl border-b border-primary/20">
        <div className="flex items-center justify-between px-4 py-4">
          <motion.button whileTap={{ scale: 0.9 }} onClick={() => navigate(-1)} className="w-10 h-10 rounded-xl bg-card/50 border border-primary/20 flex items-center justify-center text-foreground">
            <ArrowLeft className="w-5 h-5" />
          </motion.button>
          <h1 className="text-lg font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Money Management</h1>
          <div className="w-10" />
        </div>
      </motion.header>

      {/* Alert overlays */}
      <AnimatePresence>
        {showAlert && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-background/80 backdrop-blur-sm flex items-center justify-center px-6"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className={`rounded-2xl p-8 text-center space-y-4 border max-w-sm w-full ${
                showAlert === 'target'
                  ? 'bg-card/90 border-success/50'
                  : 'bg-card/90 border-destructive/50'
              }`}
            >
              <div className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center ${
                showAlert === 'target' ? 'bg-success/20' : 'bg-destructive/20'
              }`}>
                {showAlert === 'target' ? (
                  <Target className="w-8 h-8 text-success" />
                ) : (
                  <ShieldAlert className="w-8 h-8 text-destructive" />
                )}
              </div>
              <h3 className={`text-xl font-bold ${showAlert === 'target' ? 'text-success' : 'text-destructive'}`}>
                {showAlert === 'target' ? '🎉 Target Reached!' : '⚠️ Stop Loss Hit!'}
              </h3>
              <p className="text-muted-foreground text-sm">
                {showAlert === 'target'
                  ? `You've reached your ${profitTarget}% daily profit target!`
                  : `You've hit your ${stopLoss}% stop loss limit.`}
              </p>
              <p className="text-foreground font-semibold">
                Net P/L: <span className={stats.netPL >= 0 ? 'text-success' : 'text-destructive'}>
                  ${stats.netPL.toFixed(2)} ({stats.netPLPercent.toFixed(2)}%)
                </span>
              </p>
              <div className="flex gap-3">
                <button onClick={() => setShowAlert(null)} className="flex-1 py-3 rounded-xl bg-card border border-primary/20 text-foreground font-medium">
                  Continue
                </button>
                <button onClick={endSession} className="flex-1 py-3 rounded-xl bg-primary text-primary-foreground font-medium">
                  End Session
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="relative z-10 px-4 py-5 pb-32 space-y-4 max-w-lg mx-auto">
        {/* Balance + Next Trade Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl bg-card/60 backdrop-blur-sm border border-primary/30 p-5"
        >
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider">Current Balance</p>
              <p className="text-3xl font-bold text-foreground mt-1">${balance.toFixed(2)}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground uppercase tracking-wider">Next Trade</p>
              <p className="text-3xl font-bold text-primary mt-1">${nextTrade.toFixed(2)}</p>
              <p className="text-xs text-muted-foreground">{balance > 0 ? ((nextTrade / balance) * 100).toFixed(1) : '0'}% of balance</p>
            </div>
          </div>
        </motion.div>

        {/* Win / Loss / Draw Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="grid grid-cols-3 gap-3"
        >
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => handleResult('W')}
            className="py-4 rounded-xl bg-success/20 border border-success/40 text-success font-bold text-lg flex items-center justify-center gap-2"
          >
            <TrendingUp className="w-5 h-5" />
            Win
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => handleResult('L')}
            className="py-4 rounded-xl bg-destructive/20 border border-destructive/40 text-destructive font-bold text-lg flex items-center justify-center gap-2"
          >
            <TrendingDown className="w-5 h-5" />
            Loss
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => handleResult('D')}
            className="py-4 rounded-xl bg-warning/20 border border-warning/40 text-warning font-bold text-lg flex items-center justify-center gap-2"
          >
            <Minus className="w-5 h-5" />
            Draw
          </motion.button>
        </motion.div>

        {/* Stats Row */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="rounded-2xl bg-card/60 backdrop-blur-sm border border-primary/30 p-4 space-y-3"
        >
          {/* Profit target progress */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>Daily Profit Target ({profitTarget}%)</span>
              <span>{stats.targetProgress.toFixed(0)}%</span>
            </div>
            <div className="w-full h-2 rounded-full bg-background/60 overflow-hidden">
              <motion.div
                className="h-full rounded-full bg-gradient-to-r from-primary to-success"
                initial={{ width: 0 }}
                animate={{ width: `${stats.targetProgress}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>

          {/* W/L/D + Net P/L */}
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center p-3 rounded-xl bg-background/40">
              <p className="text-xs text-muted-foreground">W / L / D</p>
              <p className="text-lg font-bold text-foreground mt-0.5">
                <span className="text-success">{stats.wins}</span>
                <span className="text-muted-foreground"> / </span>
                <span className="text-destructive">{stats.losses}</span>
                <span className="text-muted-foreground"> / </span>
                <span className="text-warning">{stats.draws}</span>
              </p>
            </div>
            <div className="text-center p-3 rounded-xl bg-background/40">
              <p className="text-xs text-muted-foreground">Start Capital</p>
              <p className="text-lg font-bold text-foreground mt-0.5">${initialCapital.toFixed(2)}</p>
            </div>
            <div className="text-center p-3 rounded-xl bg-background/40 border border-primary/20">
              <p className="text-xs text-muted-foreground">Net P/L</p>
              <p className={`text-lg font-bold mt-0.5 ${stats.netPL >= 0 ? 'text-success' : 'text-destructive'}`}>
                ${stats.netPL.toFixed(2)} ({stats.netPLPercent.toFixed(2)}%)
              </p>
            </div>
          </div>
        </motion.div>

        {/* Balance Chart */}
        {trades.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="rounded-2xl bg-card/60 backdrop-blur-sm border border-primary/30 p-4"
          >
            <p className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Balance Growth</p>
            <div className="h-40">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(250 15% 20% / 0.5)" />
                  <XAxis dataKey="trade" tick={{ fill: 'hsl(250 10% 60%)', fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: 'hsl(250 10% 60%)', fontSize: 10 }} axisLine={false} tickLine={false} domain={['dataMin - 50', 'dataMax + 50']} />
                  <Tooltip
                    contentStyle={{
                      background: 'hsl(250 25% 10%)',
                      border: '1px solid hsl(185 100% 50% / 0.3)',
                      borderRadius: '12px',
                      color: 'hsl(220 20% 95%)',
                      fontSize: '12px',
                    }}
                    formatter={(value: number) => [`$${value.toFixed(2)}`, 'Balance']}
                    labelFormatter={(label) => `Trade #${label}`}
                  />
                  <Line
                    type="monotone"
                    dataKey="balance"
                    stroke="hsl(185 100% 50%)"
                    strokeWidth={2}
                    dot={{ fill: 'hsl(185 100% 50%)', r: 3, strokeWidth: 0 }}
                    activeDot={{ r: 5, fill: 'hsl(185 100% 50%)', strokeWidth: 0 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
        )}

        {/* Trade History Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="rounded-2xl bg-card/60 backdrop-blur-sm border border-primary/30 overflow-hidden"
        >
          <div className="px-4 py-3 border-b border-primary/20">
            <p className="text-sm font-semibold text-foreground">Trade History</p>
          </div>

          {/* Header */}
          <div className="grid grid-cols-6 gap-1 px-4 py-2 text-xs text-muted-foreground border-b border-primary/10">
            <span className="text-center">#</span>
            <span className="text-center">Result</span>
            <span className="text-center">Trade</span>
            <span className="text-center">P/L</span>
            <span className="text-center">Balance</span>
            <span className="text-center">Note</span>
          </div>

          <div className="max-h-64 overflow-y-auto scrollbar-hide">
            {trades.length === 0 ? (
              <div className="py-8 text-center text-muted-foreground text-sm">
                No trades yet. Click Win, Loss, or Draw to start.
              </div>
            ) : (
              trades.map((trade, i) => (
                <motion.div
                  key={trade.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.02 }}
                  className="grid grid-cols-6 gap-1 px-4 py-2.5 text-xs border-b border-primary/5 items-center"
                >
                  <span className="text-center text-muted-foreground">{trade.id}</span>
                  <span className="text-center">
                    <span className={`inline-flex items-center justify-center w-7 h-7 rounded-full text-xs font-bold border ${
                      trade.result === 'W'
                        ? 'bg-success/20 text-success border-success/40'
                        : trade.result === 'L'
                        ? 'bg-destructive/20 text-destructive border-destructive/40'
                        : 'bg-warning/20 text-warning border-warning/40'
                    }`}>
                      {trade.result}
                    </span>
                  </span>
                  <span className="text-center text-foreground font-medium">${trade.amount.toFixed(2)}</span>
                  <span className={`text-center font-medium ${trade.pl >= 0 ? 'text-success' : 'text-destructive'}`}>
                    ${trade.pl.toFixed(2)}
                  </span>
                  <span className="text-center text-foreground">${trade.balance.toFixed(2)}</span>
                  <span className="text-center text-muted-foreground truncate text-[10px]">{trade.note}</span>
                </motion.div>
              ))
            )}

            {/* Initial Capital row */}
            {trades.length > 0 && (
              <div className="grid grid-cols-6 gap-1 px-4 py-2.5 text-xs border-b border-primary/5 items-center bg-background/30">
                <span className="text-center text-muted-foreground">0</span>
                <span className="text-center text-muted-foreground">START</span>
                <span className="text-center text-muted-foreground">-</span>
                <span className="text-center text-muted-foreground">-</span>
                <span className="text-center text-foreground">${initialCapital.toFixed(2)}</span>
                <span className="text-center text-muted-foreground text-[10px]">Initial</span>
              </div>
            )}
          </div>
        </motion.div>

        {/* Bottom Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="grid grid-cols-2 gap-3"
        >
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={downloadCSV}
            disabled={trades.length === 0}
            className="py-3 rounded-xl bg-card/60 border border-primary/30 text-foreground font-medium text-sm flex items-center justify-center gap-2 disabled:opacity-40"
          >
            <Download className="w-4 h-4" />
            Download CSV
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={endSession}
            className="py-3 rounded-xl bg-destructive/20 border border-destructive/30 text-destructive font-medium text-sm flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            End Session
          </motion.button>
        </motion.div>
      </main>
    </div>
  );
}
