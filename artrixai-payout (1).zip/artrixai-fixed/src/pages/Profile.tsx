import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, User, Mail, Key, Calendar, CreditCard, Shield, LogOut, Sparkles, ChevronRight, Crown, AlertTriangle, Bell, Copy, Check, ExternalLink, Camera } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { format } from 'date-fns';
import { getUserWarnings, markWarningRead } from '@/lib/backendApi';
import CreditExhaustedBanner from '@/components/CreditExhaustedBanner';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

interface Warning {
  _id?: string;
  message: string;
  type: 'info' | 'warning' | 'critical';
  isRead: boolean;
  createdAt: string;
}

export default function Profile() {
  const navigate = useNavigate();
  const { user, logout, activateLicenseKey } = useAuth();
  const [warnings, setWarnings] = useState<Warning[]>([]);
  const [copied, setCopied] = useState(false);
  const [licenseInput, setLicenseInput] = useState('');
  const [isActivating, setIsActivating] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load avatar from localStorage
  useEffect(() => {
    const savedAvatar = localStorage.getItem('user_avatar_url');
    if (savedAvatar) {
      setAvatarUrl(savedAvatar);
    }
  }, []);
  useEffect(() => {
    if (user?.licenseKey) {
      loadWarnings();
    }
  }, [user?.licenseKey]);

  const loadWarnings = async () => {
    if (!user?.licenseKey) return;
    const fetchedWarnings = await getUserWarnings(user.licenseKey);
    setWarnings(fetchedWarnings as Warning[]);
  };

  const handleDismissWarning = async (warning: Warning) => {
    if (user?.licenseKey && warning._id) {
      await markWarningRead(user.licenseKey, warning._id);
      setWarnings(prev => prev.map(w => 
        w._id === warning._id ? { ...w, isRead: true } : w
      ));
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleCopyLicense = () => {
    if (user?.licenseKey) {
      navigator.clipboard.writeText(user.licenseKey);
      setCopied(true);
      toast.success('License key copied!');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleActivateLicense = async () => {
    if (!licenseInput.trim()) {
      toast.error('Please enter a license key');
      return;
    }

    setIsActivating(true);
    try {
      if (activateLicenseKey) {
        const result = await activateLicenseKey(licenseInput.trim().toUpperCase());
        if (result.success) {
          toast.success('License activated! Your account has been upgraded.');
          setLicenseInput('');
        } else {
          toast.error(result.error || 'Failed to activate license');
        }
      }
    } catch (error) {
      toast.error('Failed to activate license');
    } finally {
      setIsActivating(false);
    }
  };

  const handleAvatarUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !user) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast.error('Please select an image file');
      return;
    }

    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      toast.error('Image must be less than 2MB');
      return;
    }

    setIsUploadingAvatar(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}-${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(fileName, file, { upsert: true });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(fileName);

      setAvatarUrl(publicUrl);
      localStorage.setItem('user_avatar_url', publicUrl);
      toast.success('Avatar updated successfully!');
    } catch (error) {
      console.error('Avatar upload error:', error);
      toast.error('Failed to upload avatar');
    } finally {
      setIsUploadingAvatar(false);
    }
  };

  if (!user) {
    navigate('/');
    return null;
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08,
        delayChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 16 },
    visible: { opacity: 1, y: 0 }
  };

  const hasNoCredits = user.credits <= 0;
  const isVip = user.membership && user.membership !== 'free' && user.membership !== 'nano';

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen pb-8 relative overflow-hidden w-full"
    >
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.5 }}
          className="absolute top-20 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-gradient-to-br from-primary/10 to-accent/5 rounded-full blur-3xl"
        />
        <motion.div 
          animate={{ 
            y: [0, -30, 0],
            opacity: [0.2, 0.4, 0.2]
          }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-40 right-10 w-40 h-40 bg-call/10 rounded-full blur-3xl"
        />
      </div>

      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 z-20 backdrop-blur-2xl bg-background/70 border-b border-border/20"
      >
        <div className="flex items-center justify-between p-4 max-w-4xl mx-auto">
          <motion.button
            whileHover={{ scale: 1.05, x: -3 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate('/dashboard')}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-all duration-300"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="text-sm font-medium">Back</span>
          </motion.button>
          <motion.h1 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-xl font-bold text-gradient"
          >
            Profile
          </motion.h1>
          <div className="w-16" />
        </div>
      </motion.div>

      <motion.div 
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="p-4 sm:p-6 lg:p-8 space-y-6 relative z-10 max-w-4xl mx-auto"
      >
        {/* Avatar Section */}
        <motion.div 
          variants={itemVariants}
          className="flex flex-col items-center pt-4"
        >
          <motion.div 
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 200, delay: 0.3 }}
            className="relative"
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleAvatarUpload}
              accept="image/*"
              className="hidden"
            />
            <motion.button
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploadingAvatar}
              className="w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-gradient-to-br from-primary/40 via-accent/20 to-transparent border-2 border-primary/40 flex items-center justify-center overflow-hidden cursor-pointer hover:border-primary/60 transition-colors"
              animate={{ 
                boxShadow: [
                  '0 0 30px hsl(185 100% 50% / 0.3)',
                  '0 0 50px hsl(185 100% 50% / 0.5)',
                  '0 0 30px hsl(185 100% 50% / 0.3)'
                ]
              }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              {isUploadingAvatar ? (
                <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              ) : avatarUrl ? (
                <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                <User className="w-12 h-12 sm:w-14 sm:h-14 text-primary" />
              )}
            </motion.button>
            
            {/* Camera Icon Overlay */}
            <motion.div
              whileHover={{ scale: 1.1 }}
              onClick={() => fileInputRef.current?.click()}
              className="absolute -bottom-1 -left-1 w-8 h-8 rounded-full bg-primary flex items-center justify-center shadow-lg border-2 border-background cursor-pointer"
            >
              <Camera className="w-4 h-4 text-primary-foreground" />
            </motion.div>
            
            {/* VIP Badge */}
            {isVip && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.6, type: "spring" }}
                className="absolute -bottom-1 -right-1 w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gradient-to-br from-warning via-warning/90 to-warning/70 flex items-center justify-center shadow-lg border-2 border-background"
              >
                <Crown className="w-4 h-4 sm:w-5 sm:h-5 text-warning-foreground" />
              </motion.div>
            )}
          </motion.div>
          
          <motion.h2 
            variants={itemVariants}
            className="text-xl sm:text-2xl font-bold text-foreground mt-5"
          >
            {user.name || user.email?.split('@')[0] || 'User'}
          </motion.h2>
          
          <motion.div 
            variants={itemVariants}
            className="flex items-center gap-2 mt-2"
          >
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-semibold">{user.membership?.toUpperCase() || 'FREE'} Member</span>
          </motion.div>
        </motion.div>

        {/* Credit Exhausted Banner */}
        {hasNoCredits && (
          <motion.div variants={itemVariants}>
            <CreditExhaustedBanner onBuyCredits={() => navigate('/credits')} />
          </motion.div>
        )}

        {/* Stats Cards */}
        <motion.div 
          variants={itemVariants}
          className="grid grid-cols-2 sm:grid-cols-3 gap-4"
        >
          <motion.div 
            whileHover={{ scale: 1.03, y: -4 }}
            className="glass-panel p-4 sm:p-5 rounded-2xl text-center relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-call/10 to-transparent" />
            <motion.p 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.5, type: "spring" }}
              className={`text-3xl sm:text-4xl font-bold relative z-10 ${hasNoCredits ? 'text-put' : 'text-call'}`}
            >
              {user.credits}
            </motion.p>
            <p className="text-xs text-muted-foreground mt-2 relative z-10 font-medium">Credits Left</p>
          </motion.div>
          
          <motion.div 
            whileHover={{ scale: 1.03, y: -4 }}
            className="glass-panel p-4 sm:p-5 rounded-2xl text-center relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent" />
            <motion.p 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.6, type: "spring" }}
              className="text-3xl sm:text-4xl font-bold text-primary relative z-10"
            >
              {user.isActive ? '✓' : '✗'}
            </motion.p>
            <p className="text-xs text-muted-foreground mt-2 relative z-10 font-medium">
              {user.isActive ? 'Active' : 'Inactive'}
            </p>
          </motion.div>

          <motion.div 
            whileHover={{ scale: 1.03, y: -4 }}
            className="glass-panel p-4 sm:p-5 rounded-2xl text-center relative overflow-hidden col-span-2 sm:col-span-1"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-warning/10 to-transparent" />
            <motion.p 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.7, type: "spring" }}
              className="text-3xl sm:text-4xl font-bold text-warning relative z-10"
            >
              {user.membership?.toUpperCase().slice(0, 3) || 'FRE'}
            </motion.p>
            <p className="text-xs text-muted-foreground mt-2 relative z-10 font-medium">Package</p>
          </motion.div>
        </motion.div>

        {/* License Key Activation (for non-VIP users) */}
        {!isVip && (
          <motion.div variants={itemVariants} className="space-y-3">
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-widest px-1 flex items-center gap-2">
              <Key className="w-4 h-4" />
              Activate VIP License
            </h3>
            
            <div className="glass-panel p-4 rounded-xl space-y-4">
              <p className="text-sm text-muted-foreground">
                Enter your VIP license key to upgrade your account and unlock premium features.
              </p>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={licenseInput}
                  onChange={(e) => setLicenseInput(e.target.value.toUpperCase())}
                  placeholder="XXXX-XXXX-XXXX-XXXX"
                  className="flex-1 px-4 py-3 bg-secondary/50 border border-border/50 rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 font-mono text-sm"
                />
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleActivateLicense}
                  disabled={isActivating}
                  className="px-6 py-3 rounded-xl font-semibold bg-primary text-primary-foreground btn-glow disabled:opacity-50"
                >
                  {isActivating ? 'Activating...' : 'Activate'}
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}

        {/* Info Cards */}
        <motion.div variants={itemVariants} className="space-y-3">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-widest px-1">Account Details</h3>
          
          <div className="grid gap-3 sm:grid-cols-2">
            <motion.div 
              whileHover={{ scale: 1.01, x: 4 }}
              className="glass-panel p-4 rounded-xl flex items-center gap-4 transition-all duration-300"
            >
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-primary/30 to-accent/10 flex items-center justify-center">
                <Mail className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs text-muted-foreground">Email</p>
                <p className="text-sm font-medium text-foreground truncate">{user.email}</p>
              </div>
            </motion.div>

            {user.licenseKey && (
              <motion.div 
                whileHover={{ scale: 1.01, x: 4 }}
                className="glass-panel p-4 rounded-xl flex items-center gap-4 transition-all duration-300"
              >
                <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-warning/30 to-warning/10 flex items-center justify-center">
                  <Key className="w-5 h-5 text-warning" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-muted-foreground">License Key</p>
                  <p className="text-sm font-medium text-foreground font-mono truncate">{user.licenseKey}</p>
                </div>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={handleCopyLicense}
                  className="w-9 h-9 rounded-lg bg-muted/50 flex items-center justify-center hover:bg-muted transition-colors"
                >
                  {copied ? (
                    <Check className="w-4 h-4 text-call" />
                  ) : (
                    <Copy className="w-4 h-4 text-muted-foreground" />
                  )}
                </motion.button>
              </motion.div>
            )}

            <motion.div 
              whileHover={{ scale: 1.01, x: 4 }}
              className="glass-panel p-4 rounded-xl flex items-center gap-4 transition-all duration-300"
            >
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-call/30 to-call/10 flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-call" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-muted-foreground">Package</p>
                <p className="text-sm font-medium text-foreground">{user.membership?.toUpperCase() || 'FREE'}</p>
              </div>
            </motion.div>

            <motion.div 
              whileHover={{ scale: 1.01, x: 4 }}
              className="glass-panel p-4 rounded-xl flex items-center gap-4 transition-all duration-300"
            >
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-put/30 to-put/10 flex items-center justify-center">
                <Calendar className="w-5 h-5 text-put" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-muted-foreground">Expires</p>
                <p className="text-sm font-medium text-foreground">
                  {user.expiresAt ? format(new Date(user.expiresAt), 'MMM dd, yyyy') : 'Lifetime'}
                </p>
              </div>
            </motion.div>
          </div>
        </motion.div>

        {/* Warnings Section */}
        {warnings.length > 0 && (
          <motion.div variants={itemVariants} className="space-y-3">
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-widest px-1 flex items-center gap-2">
              <Bell className="w-4 h-4" />
              Admin Messages ({warnings.filter(w => !w.isRead).length} unread)
            </h3>
            
            <div className="space-y-2">
              {warnings.map((warning, index) => (
                <motion.div
                  key={warning._id || index}
                  whileHover={{ scale: 1.01, x: 4 }}
                  className={`glass-panel p-4 rounded-xl flex items-start gap-4 border ${
                    warning.type === 'critical' ? 'border-put/40' :
                    warning.type === 'warning' ? 'border-warning/40' : 'border-primary/40'
                  } ${!warning.isRead ? 'bg-primary/5' : ''}`}
                >
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    warning.type === 'critical' ? 'bg-put/20' :
                    warning.type === 'warning' ? 'bg-warning/20' : 'bg-primary/20'
                  }`}>
                    <AlertTriangle className={`w-5 h-5 ${
                      warning.type === 'critical' ? 'text-put' :
                      warning.type === 'warning' ? 'text-warning' : 'text-primary'
                    }`} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">{warning.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {format(new Date(warning.createdAt), 'MMM dd, yyyy HH:mm')}
                    </p>
                  </div>
                  {!warning.isRead && (
                    <button
                      onClick={() => handleDismissWarning(warning)}
                      className="text-xs text-primary hover:underline font-medium"
                    >
                      Mark read
                    </button>
                  )}
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Quick Links */}
        <motion.div variants={itemVariants} className="space-y-3">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-widest px-1">Quick Links</h3>
          
          <div className="grid gap-3 sm:grid-cols-2">
            <motion.button
              whileHover={{ scale: 1.02, x: 4 }}
              whileTap={{ scale: 0.99 }}
              onClick={() => navigate('/credits')}
              className="w-full glass-panel p-4 rounded-xl flex items-center gap-4 transition-all duration-300"
            >
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-primary/30 to-accent/10 flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 text-left">
                <p className="text-sm font-semibold text-foreground">Buy Credits</p>
                <p className="text-xs text-muted-foreground">Add more analysis credits</p>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02, x: 4 }}
              whileTap={{ scale: 0.99 }}
              onClick={() => navigate('/transactions')}
              className="w-full glass-panel p-4 rounded-xl flex items-center gap-4 transition-all duration-300"
            >
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-call/30 to-call/10 flex items-center justify-center">
                <Shield className="w-5 h-5 text-call" />
              </div>
              <div className="flex-1 text-left">
                <p className="text-sm font-semibold text-foreground">Transaction History</p>
                <p className="text-xs text-muted-foreground">View your past transactions</p>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </motion.button>
          </div>
        </motion.div>

        {/* Logout Button */}
        <motion.div variants={itemVariants}>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleLogout}
            className="w-full py-4 rounded-xl bg-gradient-to-r from-put/20 to-put/10 border border-put/30 text-put font-semibold flex items-center justify-center gap-2 hover:from-put/30 hover:to-put/20 transition-all duration-300"
          >
            <LogOut className="w-5 h-5" />
            <span>Sign Out</span>
          </motion.button>
        </motion.div>

        {/* Footer */}
        <motion.div 
          variants={itemVariants}
          className="text-center pt-6 pb-4"
        >
          <p className="text-xs text-muted-foreground">
            ARTRIX AI • Powered by <span className="text-primary font-semibold">ART TEAM</span>
          </p>
        </motion.div>
      </motion.div>
    </motion.div>
  );
}