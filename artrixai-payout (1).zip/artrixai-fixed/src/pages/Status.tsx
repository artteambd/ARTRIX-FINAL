import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, TrendingUp, BarChart3, User, Activity, LogOut, ChevronDown, Calculator } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useEffect, useMemo, useState } from 'react';
import { LICENSE_PACKAGES } from '@/types/license';
import { getTodayUsage, USAGE_UPDATED_EVENT } from '@/lib/usageTracking';
const tierDisplayNames: Record<string, string> = {
  free: 'Free',
  nano: 'Nano',
  starter: 'Starter',
  popular: 'Popular',
  expert: 'Expert',
  investor: 'Investor'
};

export default function Status() {
  const navigate = useNavigate();
  const { user, logout, refreshUser } = useAuth();
  const [activeTab, setActiveTab] = useState<'signal' | 'analysis'>('signal');
  const [showAccountDetails, setShowAccountDetails] = useState(false);
  const [todayUsage, setTodayUsage] = useState(() => getTodayUsage());
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);

  // Load avatar from localStorage
  useEffect(() => {
    const savedAvatar = localStorage.getItem('user_avatar_url');
    if (savedAvatar) {
      setAvatarUrl(savedAvatar);
    }
  }, []);
  if (!user) {
    navigate('/');
    return null;
  }

  useEffect(() => {
    // Sync credits from license verification (when applicable)
    refreshUser?.();

    const handleUpdate = () => setTodayUsage(getTodayUsage());

    window.addEventListener(USAGE_UPDATED_EVENT, handleUpdate as EventListener);
    window.addEventListener('focus', handleUpdate);

    return () => {
      window.removeEventListener(USAGE_UPDATED_EVENT, handleUpdate as EventListener);
      window.removeEventListener('focus', handleUpdate);
    };
  }, [refreshUser]);

  const totalCredits = useMemo(() => {
    if (user.isAdmin) return Math.max(0, user.credits);
    if (user.membership === 'free') return 5;
    const pkg = LICENSE_PACKAGES.find((p) => p.id === user.membership);
    return pkg?.credits ?? 0;
  }, [user.credits, user.isAdmin, user.membership]);

  const remainingCredits = Math.max(0, user.credits);
  const usedCredits = Math.max(0, totalCredits - remainingCredits);

  const activeUsedToday = activeTab === 'signal' ? todayUsage.signal : todayUsage.analysis;
  const usagePercent = totalCredits > 0 ? Math.min(100, Math.round((activeUsedToday / totalCredits) * 100)) : 0;


  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      {/* Animated background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <motion.div
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.1, 0.2, 0.1],
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/4 -right-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ 
            scale: [1.2, 1, 1.2],
            opacity: [0.15, 0.25, 0.15],
          }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-1/4 -left-1/4 w-80 h-80 bg-accent/20 rounded-full blur-3xl"
        />
      </div>

      {/* Header */}
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 z-50 bg-background/80 backdrop-blur-xl border-b border-primary/20"
      >
        <div className="flex items-center justify-between px-4 py-4">
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => navigate(-1)}
            className="w-10 h-10 rounded-xl bg-card/50 border border-primary/20 flex items-center justify-center text-foreground"
          >
            <ArrowLeft className="w-5 h-5" />
          </motion.button>
          <h1 className="text-lg font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Account Status
          </h1>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={handleLogout}
            className="w-10 h-10 rounded-xl bg-destructive/20 border border-destructive/30 flex items-center justify-center text-destructive"
          >
            <LogOut className="w-5 h-5" />
          </motion.button>
        </div>
      </motion.header>

      <main className="relative z-10 px-4 py-6 pb-32 space-y-6">
        {/* User Profile Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4"
        >
          <div className="relative">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-accent p-0.5">
              <div className="w-full h-full rounded-full bg-card flex items-center justify-center overflow-hidden">
                {avatarUrl ? (
                  <img 
                    src={avatarUrl} 
                    alt="User Avatar" 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <User className="w-8 h-8 text-primary" />
                )}
              </div>
            </div>
            <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-success border-2 border-background" />
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-bold text-foreground">{user.name || 'User'}</h2>
            <p className="text-sm text-muted-foreground">@{user.email?.split('@')[0]}</p>
          </div>
        </motion.div>

        {/* Today's Usage Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="rounded-2xl bg-card/60 backdrop-blur-sm border border-primary/30 p-5 space-y-5"
        >
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-success/20 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-success" />
              </div>
              <span className="text-lg font-semibold text-foreground">Today's Usage</span>
            </div>
            <span className="px-3 py-1 rounded-full text-xs font-medium bg-success/20 text-success border border-success/30">
              Active
            </span>
          </div>

          {/* Tab Buttons */}
          <div className="flex gap-3">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setActiveTab('signal')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                activeTab === 'signal'
                  ? 'bg-success text-success-foreground'
                  : 'bg-card border border-primary/20 text-muted-foreground'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              Live Signal
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setActiveTab('analysis')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                activeTab === 'analysis'
                  ? 'bg-accent text-accent-foreground'
                  : 'bg-card border border-primary/20 text-muted-foreground'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              Chart Analysis
            </motion.button>
          </div>

          {/* Usage Stats */}
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                {activeTab === 'signal' ? 'Signals used today' : 'Analysis used today'}
              </p>
              <div className="flex items-baseline gap-1">
                <span className="text-4xl font-bold text-foreground">
                  {activeTab === 'signal' ? todayUsage.signal : todayUsage.analysis}
                </span>
                <span className="text-lg text-muted-foreground">/{totalCredits}</span>
              </div>
              <div className="flex items-center gap-2 text-success">
                <Activity className="w-4 h-4" />
                <span className="text-sm">{remainingCredits} credits remaining</span>
              </div>
            </div>

            {/* Circular Progress */}
            <div className="relative w-24 h-24">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  className="fill-none stroke-primary/20"
                  strokeWidth="8"
                />
                <motion.circle
                  cx="48"
                  cy="48"
                  r="40"
                  className={`fill-none ${activeTab === 'signal' ? 'stroke-success' : 'stroke-accent'}`}
                  strokeWidth="8"
                  strokeLinecap="round"
                  initial={{ strokeDasharray: '251.2', strokeDashoffset: '251.2' }}
                  animate={{ strokeDashoffset: 251.2 - (251.2 * usagePercent) / 100 }}
                  transition={{ duration: 1, ease: 'easeOut' }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-xl font-bold text-foreground">{usagePercent}%</span>
                <span className="text-xs text-muted-foreground">used</span>
              </div>
              <div
                className={`absolute -top-1 -right-1 w-3 h-3 rounded-full ${activeTab === 'signal' ? 'bg-success' : 'bg-accent'}`}
              />
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-primary/20" />

          {/* Bottom Stats */}
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-success" />
              <span className="text-muted-foreground">Live Signal</span>
              <span className="text-foreground font-medium">({todayUsage.signal}/{totalCredits})</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-accent" />
              <span className="text-muted-foreground">Chart Analysis</span>
              <span className="text-foreground font-medium">({todayUsage.analysis}/{totalCredits})</span>
            </div>
          </div>
        </motion.div>

        {/* Account Type Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="rounded-2xl bg-card/60 backdrop-blur-sm border border-primary/30 overflow-hidden"
        >
          <motion.button
            whileTap={{ scale: 0.99 }}
            onClick={() => setShowAccountDetails(!showAccountDetails)}
            className="w-full flex items-center justify-between p-5"
          >
            <div className="flex items-center gap-3">
              <User className="w-5 h-5 text-primary" />
              <span className="text-base font-semibold text-primary">Your Account Type</span>
            </div>
            <motion.div
              animate={{ rotate: showAccountDetails ? 180 : 0 }}
              className="w-8 h-8 rounded-full bg-success flex items-center justify-center"
            >
              <ChevronDown className="w-5 h-5 text-success-foreground" />
            </motion.div>
          </motion.button>

          <motion.div
            initial={false}
            animate={{ 
              height: showAccountDetails ? 'auto' : 0,
              opacity: showAccountDetails ? 1 : 0
            }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 space-y-4">
              <div className="flex items-center justify-between py-3 border-b border-primary/10">
                <span className="text-muted-foreground">Type:</span>
                <span className="font-bold text-success">
                  ARTRIX {tierDisplayNames[user.membership] || 'Member'}
                </span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-primary/10">
                <span className="text-muted-foreground">Total Credits:</span>
                <span className="font-semibold text-foreground">{totalCredits}</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-primary/10">
                <span className="text-muted-foreground">Credits Used:</span>
                <span className="font-semibold text-foreground">{usedCredits}</span>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-primary/10">
                <span className="text-muted-foreground">Credits Left:</span>
                <span className="font-semibold text-success">{remainingCredits}</span>
              </div>
              <div className="flex items-center justify-between py-3">
                <span className="text-muted-foreground">Status:</span>
                <span className={`font-semibold ${user.isActive ? 'text-success' : 'text-destructive'}`}>
                  {user.isActive ? 'Active' : 'Inactive'}
                </span>
              </div>
            </div>
          </motion.div>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="grid grid-cols-3 gap-3"
        >
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => navigate('/credits')}
            className="p-4 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 border border-primary/30 text-center"
          >
            <TrendingUp className="w-6 h-6 text-primary mx-auto mb-2" />
            <span className="text-sm font-medium text-foreground">Buy Credits</span>
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => navigate('/money-management')}
            className="p-4 rounded-xl bg-gradient-to-br from-success/20 to-primary/20 border border-success/30 text-center"
          >
            <Calculator className="w-6 h-6 text-success mx-auto mb-2" />
            <span className="text-sm font-medium text-foreground">Money Mgmt</span>
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => navigate('/profile')}
            className="p-4 rounded-xl bg-gradient-to-br from-accent/20 to-primary/20 border border-accent/30 text-center"
          >
            <User className="w-6 h-6 text-accent mx-auto mb-2" />
            <span className="text-sm font-medium text-foreground">Profile</span>
          </motion.button>
        </motion.div>
      </main>
    </div>
  );
}
