import { motion } from 'framer-motion';
import { ArrowLeft, Receipt, Clock, CheckCircle, XCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

export default function Transactions() {
  const navigate = useNavigate();
  const { transactions, user } = useAuth();

  const userTransactions = transactions.filter(t => t.userId === user?.id);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-call" />;
      case 'rejected':
        return <XCircle className="w-5 h-5 text-put" />;
      default:
        return <Clock className="w-5 h-5 text-warning" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'text-call';
      case 'rejected':
        return 'text-put';
      default:
        return 'text-warning';
    }
  };

  return (
    <div className="min-h-screen pb-8">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center gap-3 px-4 py-4"
      >
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => navigate('/credits')}
          className="w-10 h-10 rounded-xl bg-secondary/50 flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </motion.button>
        <div>
          <h1 className="text-xl font-bold text-foreground">My Transactions</h1>
          <p className="text-xs text-muted-foreground">Payment history</p>
        </div>
      </motion.header>

      {/* Content */}
      <div className="px-4 mt-4">
        {userTransactions.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-card glow-border p-8 text-center"
          >
            <Receipt className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground">No Transactions</h3>
            <p className="text-sm text-muted-foreground mt-2">
              Your payment history will appear here
            </p>
          </motion.div>
        ) : (
          <div className="space-y-3">
            {userTransactions.map((transaction, index) => (
              <motion.div
                key={transaction.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="glass-card glow-border p-4"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(transaction.status)}
                    <div>
                      <p className="font-semibold text-foreground">{transaction.packageName}</p>
                      <p className="text-sm text-muted-foreground">
                        {transaction.credits} credits • ${transaction.amount}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-medium capitalize ${getStatusColor(transaction.status)}`}>
                      {transaction.status}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(transaction.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
