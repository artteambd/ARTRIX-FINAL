export type MembershipTier = 'free' | 'nano' | 'starter' | 'popular' | 'expert' | 'investor';

export interface User {
  id: string;
  email: string;
  name: string;
  credits: number;
  membership: MembershipTier;
  licenseKey: string;
  isAdmin: boolean;
  isActive: boolean;
  createdAt: Date;
  expiresAt?: Date;
}

export interface Package {
  id: string;
  name: string;
  tier: MembershipTier;
  credits: number;
  price: number;
  pricePerAnalysis: number;
  color: string;
  icon: string;
  popular?: boolean;
  durationDays: number;
  durationLabel: string;
}

export interface AnalysisResult {
  id: string;
  signal: 'CALL' | 'PUT' | 'NO SIGNAL';
  confidence: number;
  confidenceLevel: 'HIGH' | 'MEDIUM' | 'LOW';
  market: string;
  pair: string;
  timeframe: string;
  trend: 'Uptrend' | 'Downtrend' | 'Sideways';
  support: number;
  resistance: number;
  entryPrice: number;
  recommendation: 'BUY' | 'SELL' | 'NO SIGNAL';
  analysis: string;
  mtfStrategy: string;
  timestamp: Date;
  imageUrl?: string;
  isValid: boolean;
  // AI analysis details (from Quantum Trader V7)
  aiAnalysis?: {
    trend: string;
    structure: string;
    momentum: string;
    supportResistance: string;
    candlePattern: string;
    reasoning: string;
    direction: string | null;
    confidence: number;
    stage1Direction?: string | null;
    stage1Confidence?: number | null;
  } | null;
  // Pillar analysis details
  pillarAnalysis?: {
    pillar: string | null;
    trend: string | null;
    trendScore: number | null;
    confidence: number | null;
    lockedDirection: string | null;
    pillarBoost: number;
    gatedStrategies: number;
    totalStrategies: number;
  } | null;
  // Cross-validation status
  matchStatus?: string;
}

export interface TradeHistory {
  id: string;
  userId: string;
  analysis: AnalysisResult;
  createdAt: Date;
}

export interface Transaction {
  id: string;
  userId: string;
  packageId: string;
  packageName: string;
  amount: number;
  credits: number;
  status: 'pending' | 'completed' | 'rejected';
  createdAt: Date;
}

export type TradingMode = 'binary' | 'forex';

export interface MembershipConfig {
  id: MembershipTier;
  name: string;
  credits: number;
  price: number;
  icon: string;
  color: string;
}
