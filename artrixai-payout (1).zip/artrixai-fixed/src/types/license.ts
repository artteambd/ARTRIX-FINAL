export type LicenseTier = 'nano' | 'starter' | 'popular' | 'expert' | 'investor';
export type AppRole = 'admin' | 'user';

export interface License {
  id: string;
  user_id: string;
  license_key: string;
  tier: LicenseTier;
  credits: number;
  credits_used: number;
  starts_at: string;
  expires_at: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Profile {
  id: string;
  email: string;
  name: string | null;
  created_at: string;
  updated_at: string;
}

export interface UserRole {
  id: string;
  user_id: string;
  role: AppRole;
  created_at: string;
}

export interface LicensePackage {
  id: LicenseTier;
  name: string;
  credits: number;
  durationDays: number;
  durationLabel: string;
  price: number;
  color: string;
  icon: string;
  popular?: boolean;
}

export const LICENSE_PACKAGES: LicensePackage[] = [
  {
    id: 'nano',
    name: 'Nano',
    credits: 25,
    durationDays: 15,
    durationLabel: '15 Days',
    price: 5,
    color: 'cyan',
    icon: 'Zap',
  },
  {
    id: 'starter',
    name: 'Starter',
    credits: 100,
    durationDays: 30,
    durationLabel: '1 Month',
    price: 10,
    color: 'yellow',
    icon: 'Star',
  },
  {
    id: 'popular',
    name: 'Most Popular',
    credits: 150,
    durationDays: 35,
    durationLabel: '1.15 Months',
    price: 25,
    color: 'orange',
    icon: 'Crown',
    popular: true,
  },
  {
    id: 'expert',
    name: 'Expert',
    credits: 300,
    durationDays: 60,
    durationLabel: '2 Months',
    price: 50,
    color: 'emerald',
    icon: 'Diamond',
  },
  {
    id: 'investor',
    name: 'Investor',
    credits: 500,
    durationDays: 90,
    durationLabel: '3 Months',
    price: 100,
    color: 'rose',
    icon: 'Rocket',
  },
];

export function getPackageByTier(tier: LicenseTier): LicensePackage | undefined {
  return LICENSE_PACKAGES.find(p => p.id === tier);
}

export function calculateExpiryDate(durationDays: number): Date {
  const date = new Date();
  date.setDate(date.getDate() + durationDays);
  return date;
}

export function isLicenseExpired(expiresAt: string | Date): boolean {
  return new Date() > new Date(expiresAt);
}

export function getDaysRemaining(expiresAt: string | Date): number {
  const now = new Date();
  const expiry = new Date(expiresAt);
  const diffTime = expiry.getTime() - now.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return Math.max(0, diffDays);
}

export function isLicenseExpiringSoon(expiresAt: string | Date): boolean {
  const daysRemaining = getDaysRemaining(expiresAt);
  return daysRemaining > 0 && daysRemaining <= 3;
}

export function formatExpiryDate(date: string | Date): string {
  return new Date(date).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function getRemainingCredits(license: License): number {
  return Math.max(0, license.credits - license.credits_used);
}
