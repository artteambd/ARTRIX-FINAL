export const OTC_API_BASE = 'https://quotexcandles.bdtraderpro.xyz/proversion/quotexcandles/Qx.php';

export interface QuotexApiCandle {
  pair?: string;
  time?: string | number;
  datetime?: string | number;
  candle_time?: string | number;
  timestamp?: string | number;
  epoch?: string | number;
  open?: number | string;
  high?: number | string;
  low?: number | string;
  close?: number | string;
  o?: number | string;
  h?: number | string;
  l?: number | string;
  c?: number | string;
  volume?: number | string;
  v?: number | string;
  Volume?: number | string;
  vol?: number | string;
  tick_volume?: number | string;
  tickVolume?: number | string;
  real_volume?: number | string;
  realVolume?: number | string;
  payout?: number | string;
  colour?: string;
}

type QuotexApiResponse =
  | QuotexApiCandle[]
  | {
      success?: boolean;
      pair?: string;
      api_pair?: string;
      count?: number;
      data?: QuotexApiCandle[];
      candles?: QuotexApiCandle[];
    };

const QUOTEX_DEFAULT_TZ = '+06:00';

export function toNumericValue(value: unknown): number {
  const parsed = typeof value === 'number' ? value : parseFloat(String(value ?? '0'));
  return Number.isFinite(parsed) ? parsed : 0;
}

export function extractJsonPayload(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed.startsWith('<')) return trimmed;

  const arrayStart = trimmed.indexOf('[');
  const arrayEnd = trimmed.lastIndexOf(']');
  if (arrayStart !== -1 && arrayEnd > arrayStart) {
    return trimmed.slice(arrayStart, arrayEnd + 1);
  }

  const objectStart = trimmed.indexOf('{');
  const objectEnd = trimmed.lastIndexOf('}');
  if (objectStart !== -1 && objectEnd > objectStart) {
    return trimmed.slice(objectStart, objectEnd + 1);
  }

  return trimmed;
}

export function parseQuotexCandles(raw: string): QuotexApiCandle[] {
  const payload = extractJsonPayload(raw);
  const parsed = JSON.parse(payload) as QuotexApiResponse;

  if (Array.isArray(parsed)) return parsed;
  if (Array.isArray(parsed?.data)) return parsed.data;
  if (Array.isArray(parsed?.candles)) return parsed.candles;

  return [];
}

export function extractApiVolume(candle: QuotexApiCandle): number {
  const volumeKeys: Array<keyof QuotexApiCandle> = [
    'volume',
    'v',
    'Volume',
    'vol',
    'tick_volume',
    'tickVolume',
    'real_volume',
    'realVolume',
  ];

  for (const key of volumeKeys) {
    const rawValue = candle[key];
    if (rawValue === undefined || rawValue === null || rawValue === '') continue;

    const parsed = toNumericValue(rawValue);
    if (Number.isFinite(parsed)) return parsed;
  }

  return 0;
}

export function parseQuotexTimeToIso(value: string | number): string {
  if (typeof value === 'number') return new Date(value * 1000).toISOString();

  const trimmed = value.trim();
  const isoGuess = trimmed.includes('T') ? trimmed : trimmed.replace(' ', 'T');
  const hasZone = /Z$|[+-]\d{2}:?\d{2}$/.test(isoGuess);
  const withZone = hasZone ? isoGuess : `${isoGuess}${QUOTEX_DEFAULT_TZ}`;

  const d = new Date(withZone);
  if (!Number.isNaN(d.getTime())) return d.toISOString();

  const fallback = new Date(trimmed);
  if (!Number.isNaN(fallback.getTime())) return fallback.toISOString();

  return new Date().toISOString();
}

export function extractApiTime(candle: QuotexApiCandle): string {
  const directTime = candle.time ?? candle.datetime ?? candle.candle_time ?? candle.timestamp;
  if (directTime !== undefined && directTime !== null && directTime !== '') {
    return parseQuotexTimeToIso(directTime);
  }

  const epoch = toNumericValue(candle.epoch);
  if (epoch > 0) {
    return parseQuotexTimeToIso(epoch);
  }

  return new Date().toISOString();
}