import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { OTC_API_BASE, extractApiTime, extractApiVolume, parseQuotexCandles } from "../_shared/quotex.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const BACKEND_URL = 'https://chart-x-seven.vercel.app';
const OTC_FETCH_TIMEOUT_MS = 12000;
const OTC_FETCH_MAX_RETRIES = 3;

// ============================================================
// KEY COOLDOWN SYSTEM — exhausted keys sit in cooldown for 12 HOURS, then auto-rejoin.
// They are NOT scanned every request. Only live keys are tried.
// ============================================================
const KEY_COOLDOWN_MS = 12 * 60 * 60 * 1000; // 12 hours
const KEY_REQUEST_COOLDOWN_MS = 5 * 60 * 1000; // 5 min for transient 429s
const MIN_SIGNAL_RUNTIME_MS = 0;
const KEY_BATCH_WINDOW_MS = 15000; // Every 15s analysis window must rotate only the freshest keys
const FRESH_KEY_BATCH_SIZE = 6; // User requirement: use the freshest 6 keys per 15s window
const MIN_PER_KEY_TIMEOUT_MS = 2000;
const keyCooldownMap = new Map<string, number>(); // key → timestamp when cooldown expires
const keyLastAttemptMap = new Map<string, number>(); // key → last attempt timestamp
const keyLastSuccessMap = new Map<string, number>(); // key → last success timestamp

const GEMINI_KEY_NAMES = [
  'GEMINI_API_KEY',
  'GEMINI_API_KEY_2',
  'GEMINI_API_KEY_3',
  'GEMINI_API_KEY_4',
  'GEMINI_API_KEY_5',
  'GEMINI_API_KEY_6',
  'GEMINI_API_KEY_7',
  'GEMINI_API_KEY_8',
  'GEMINI_API_KEY_9',
  'GEMINI_API_KEY_10',
  'GEMINI_API_KEY_11',
  'GEMINI_API_KEY_12',
  'GEMINI_API_KEY_13',
  'GEMINI_API_KEY_14',
  'GEMINI_API_KEY_15',
  'GEMINI_API_KEY_16',
  'GEMINI_API_KEY_17',
  'GEMINI_API_KEY_18',
  'GEMINI_API_KEY_19',
  'GEMINI_API_KEY_20',
  'GEMINI_API_KEY_21',
  'GEMINI_API_KEY_22',
  'GEMINI_API_KEY_23',
  'GEMINI_API_KEY_24',
  'GEMINI_API_KEY_25',
];

function sanitizeGeminiKey(raw: string | null | undefined): string {
  return String(raw ?? '')
    .replace(/[\s\u200B-\u200D\uFEFF\u200E\u200F\u202A-\u202E]/g, '')
    .trim();
}

function getAllKeys(): string[] {
  const keys = GEMINI_KEY_NAMES
    .map((name) => sanitizeGeminiKey(Deno.env.get(name)))
    .filter((key) => key.startsWith('AIza') && key.length >= 20);

  return Array.from(new Set(keys));
}

function maskKey(key: string): string {
  return `…${key.slice(-6)}`;
}

function markKeyAttempt(key: string) {
  keyLastAttemptMap.set(key, Date.now());
}

function markKeySuccess(key: string) {
  const now = Date.now();
  keyLastAttemptMap.set(key, now);
  keyLastSuccessMap.set(key, now);
}

function selectFreshKeys(pool: string[], exhausted: Set<string>, limit = FRESH_KEY_BATCH_SIZE): string[] {
  const selected = pool
    .filter((key) => key && !exhausted.has(key) && !keyCooldownMap.has(key))
    .sort((a, b) => {
      const aAttempt = keyLastAttemptMap.get(a) ?? 0;
      const bAttempt = keyLastAttemptMap.get(b) ?? 0;
      if (aAttempt !== bAttempt) return aAttempt - bAttempt;

      const aSuccess = keyLastSuccessMap.get(a) ?? 0;
      const bSuccess = keyLastSuccessMap.get(b) ?? 0;
      return bSuccess - aSuccess;
    })
    .slice(0, limit);

  console.log(`[KEY-POOL] Selected ${selected.length} fresh keys for ${Math.round(KEY_BATCH_WINDOW_MS / 1000)}s window: ${selected.map(maskKey).join(', ') || 'none'}`);
  return selected;
}

function buildKeyPool(): string[] {
  const now = Date.now();
  for (const [k, expiresAt] of keyCooldownMap) {
    if (now >= expiresAt) {
      keyCooldownMap.delete(k);
      console.log(`[KEY-POOL] Key …${k.slice(-6)} cooldown expired, back in live pool`);
    }
  }
  return getAllKeys().filter(k => !keyCooldownMap.has(k));
}

// Move a key to cooldown — quota/auth errors get 12h, transient rate-limits get 5min
function cooldownKey(key: string, reason: string) {
  const isTransient = reason.startsWith('quota 429') || reason.startsWith('transient');
  const cooldownMs = isTransient ? KEY_REQUEST_COOLDOWN_MS : KEY_COOLDOWN_MS;
  const cooldownLabel = isTransient ? '5min' : '12h';
  keyCooldownMap.set(key, Date.now() + cooldownMs);
  const inCooldown = keyCooldownMap.size;
  const total = getAllKeys().length;
  console.log(`[KEY-POOL] Key ${maskKey(key)} → cooldown ${cooldownLabel} (${reason}). ${total - inCooldown}/${total} live`);
}

async function classifyGeminiError(res: Response): Promise<{
  shouldCooldown: boolean;
  shouldSkipForRequest: boolean;
  reason: string;
  details: string;
}> {
  const details = await res.text().catch(() => '');
  const normalized = details.toLowerCase();

  const isQuotaError =
    res.status === 429 ||
    res.status === 402 ||
    normalized.includes('resource_exhausted') ||
    normalized.includes('rate limit') ||
    normalized.includes('quota');

  const isTransientModelError =
    res.status === 503 ||
    normalized.includes('high demand') ||
    normalized.includes('temporarily unavailable') ||
    normalized.includes('"status":"unavailable"') ||
    normalized.includes('"status": "unavailable"');

  const isInvalidApiKeyError =
    (res.status === 400 || res.status === 403) && (
      normalized.includes('api key not valid') ||
      normalized.includes('api_key_invalid') ||
      normalized.includes('invalid api key')
    );

  const isKeyAuthError =
    res.status === 401 ||
    isInvalidApiKeyError ||
    (res.status === 403 && (
      normalized.includes('permission denied') ||
      normalized.includes('permission_denied') ||
      normalized.includes('denied access') ||
      normalized.includes('forbidden')
    ));

  if (isQuotaError) {
    return {
      shouldCooldown: true,
      shouldSkipForRequest: true,
      reason: `quota ${res.status}`,
      details,
    };
  }

  if (isTransientModelError) {
    return {
      shouldCooldown: true,
      shouldSkipForRequest: true,
      reason: `transient ${res.status}`,
      details,
    };
  }

  if (isKeyAuthError) {
    return {
      shouldCooldown: true,
      shouldSkipForRequest: true,
      reason: `auth ${res.status}`,
      details,
    };
  }

  return {
    shouldCooldown: false,
    shouldSkipForRequest: true,
    reason: `request ${res.status}`,
    details,
  };
}

function toJsonHeaders(extra: Record<string, string> = {}) {
  return { ...corsHeaders, 'Content-Type': 'application/json', ...extra };
}

function mapTrend(trend: string | undefined): 'Uptrend' | 'Downtrend' | 'Sideways' {
  const t = (trend || '').toUpperCase();
  if (t.includes('BULL') || t.includes('UP')) return 'Uptrend';
  if (t.includes('BEAR') || t.includes('DOWN')) return 'Downtrend';
  return 'Sideways';
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// ============================================================
// GEMINI TEXT EXTRACTION (skip thinking parts)
// ============================================================
function extractGeminiText(data: any): string {
  const parts = data?.candidates?.[0]?.content?.parts || [];
  const textParts = parts.filter((p: any) => p.text && !p.thought);
  if (textParts.length > 0) return textParts.map((p: any) => p.text).join('');
  return parts.map((p: any) => p.text || '').join('');
}

// ============================================================
// 4-LAYER JSON PARSER (handles massive thinking-mode outputs)
// ============================================================
function extractBalancedJson(text: string): string | null {
  const start = text.indexOf('{');
  if (start === -1) return null;
  let depth = 0;
  for (let i = start; i < text.length; i++) {
    if (text[i] === '{') depth++;
    else if (text[i] === '}') { depth--; if (depth === 0) return text.slice(start, i + 1); }
  }
  return null;
}

function extractJsonField(text: string, field: string): string {
  const patterns = [
    new RegExp(`"${field}"\\s*:\\s*"([^"]*)"`, 'i'),
    new RegExp(`"${field}"\\s*:\\s*(\\d+)`, 'i'),
  ];
  for (const p of patterns) { const m = text.match(p); if (m) return m[1]; }
  return '';
}

function parseGeminiJson(raw: string): Record<string, any> | null {
  const extracted = extractBalancedJson(raw);
  if (extracted) {
    try { return JSON.parse(extracted); } catch { /* continue */ }
    try {
      const fixed = extracted.replace(/,\s*([}\]])/g, '$1').replace(/[\x00-\x1F\x7F]/g, ' ');
      return JSON.parse(fixed);
    } catch { /* continue */ }
  }
  const direction = extractJsonField(raw, 'direction');
  const confidence = extractJsonField(raw, 'confidence');
  if (direction) {
    return {
      direction: direction.toUpperCase(), confidence: parseInt(confidence) || 60,
      trend: extractJsonField(raw, 'trend'), structure: extractJsonField(raw, 'structure'),
      momentum: extractJsonField(raw, 'momentum'), support_resistance: extractJsonField(raw, 'support_resistance'),
      candle_pattern: extractJsonField(raw, 'candle_pattern'), reasoning: extractJsonField(raw, 'reasoning'),
    };
  }
  const upCount = (raw.match(/\bUP\b/g) || []).length;
  const downCount = (raw.match(/\bDOWN\b/g) || []).length;
  return { direction: upCount >= downCount ? 'UP' : 'DOWN', confidence: 60, reasoning: '[FALLBACK KEYWORD COUNT]' };
}

// ============================================================
// MASTER OTC PAIR LIST — all 56 supported Quotex OTC pairs
// ============================================================
const ALL_OTC_PAIRS = [
  'AUDCAD-OTC', 'AUDJPY-OTC', 'AUDNZD-OTC', 'AUDUSD-OTC',
  'BRLUSD-OTC', 'CADCHF-OTC', 'CADJPY-OTC', 'CHFJPY-OTC',
  'EURAUD-OTC', 'EURCAD-OTC', 'EURCHF-OTC', 'EURGBP-OTC', 'EURJPY-OTC',
  'EURNZD-OTC', 'EURSGD-OTC', 'EURUSD-OTC', 'GBPAUD-OTC', 'GBPCAD-OTC',
  'GBPCHF-OTC', 'GBPJPY-OTC', 'GBPUSD-OTC', 'NZDUSD-OTC', 'USDARS-OTC',
  'USDBDT-OTC', 'USDCAD-OTC', 'USDCHF-OTC', 'USDEGP-OTC', 'USDGBP-OTC',
  'USDIDR-OTC', 'USDINR-OTC', 'USDJPY-OTC', 'USDMXN-OTC', 'USDNGN-OTC',
  'USDPKR-OTC', 'USDTRY-OTC', 'USDZAR-OTC', 'USDPHP-OTC',
  'BTCUSD-OTC', 'BCHUSD-OTC', 'ARBUSD-OTC', 'ZECUSD-OTC', 'ATOUSD-OTC', 'AXSUSD-OTC',
  'XAUUSD-OTC', 'XAGUSD-OTC', 'USCrude-OTC', 'UKBrent-OTC', 'FLOUSD-OTC',
  'AXP-OTC', 'PFE-OTC', 'INTL-OTC', 'JNJ-OTC', 'MCD-OTC', 'FB-OTC', 'BA-OTC', 'MSFT-OTC'
];

// Stock OTC pairs require special API format
const STOCK_OTC_MAP: Record<string, string> = {
  'AXP-OTC': 'AXP_otc', 'PFE-OTC': 'PFE_otc', 'INTL-OTC': 'INTL_otc',
  'JNJ-OTC': 'JNJ_otc', 'MCD-OTC': 'MCD_otc', 'FB-OTC': 'FB_otc',
  'BA-OTC': 'BA_otc', 'MSFT-OTC': 'MSFT_otc',
  'USCrude-OTC': 'USCrude_otc', 'UKBrent-OTC': 'UKBrent_otc',
  'FLOUSD-OTC': 'FLOUSD_otc',
};

// Comprehensive alias map: every possible AI-detected format → correct internal format
// Covers: slashes, spaces, reversed pairs, full names, Quotex display formats
const PAIR_ALIAS_MAP: Record<string, string> = {
  // === REVERSED CURRENCY PAIRS ===
  'USDBRL': 'BRLUSD-OTC', 'USD/BRL': 'BRLUSD-OTC', 'USDBRLOCT': 'BRLUSD-OTC', 'BRLUSD': 'BRLUSD-OTC', 'BRL/USD': 'BRLUSD-OTC',
  'EGPUSD': 'USDEGP-OTC', 'EGP/USD': 'USDEGP-OTC',
  'ARSUSD': 'USDARS-OTC', 'ARS/USD': 'USDARS-OTC',
  'BDTUSD': 'USDBDT-OTC', 'BDT/USD': 'USDBDT-OTC',
  'IDRUSD': 'USDIDR-OTC', 'IDR/USD': 'USDIDR-OTC',
  'INRUSD': 'USDINR-OTC', 'INR/USD': 'USDINR-OTC',
  'MXNUSD': 'USDMXN-OTC', 'MXN/USD': 'USDMXN-OTC',
  'NGNUSD': 'USDNGN-OTC', 'NGN/USD': 'USDNGN-OTC',
  'PKRUSD': 'USDPKR-OTC', 'PKR/USD': 'USDPKR-OTC',
  'TRYUSD': 'USDTRY-OTC', 'TRY/USD': 'USDTRY-OTC',
  'ZARUSD': 'USDZAR-OTC', 'ZAR/USD': 'USDZAR-OTC',
  'PHPUSD': 'USDPHP-OTC', 'PHP/USD': 'USDPHP-OTC',
  'GBPUSD': 'GBPUSD-OTC', 'GBP/USD': 'GBPUSD-OTC',
  // === STOCK ALIASES (full names, tickers, etc.) ===
  'INTEL': 'INTL-OTC', 'INTC': 'INTL-OTC', 'INTELOTC': 'INTL-OTC', 'INTLOTC': 'INTL-OTC',
  'META': 'FB-OTC', 'FACEBOOK': 'FB-OTC', 'METAOTC': 'FB-OTC', 'FBOTC': 'FB-OTC',
  'BOEING': 'BA-OTC', 'BOEINGOTC': 'BA-OTC', 'BAOTC': 'BA-OTC',
  'MCDONALDS': 'MCD-OTC', 'MCDONALD': 'MCD-OTC', 'MCDONALDSOTC': 'MCD-OTC', 'MCDOTC': 'MCD-OTC',
  'MICROSOFT': 'MSFT-OTC', 'MICROSOFTOTC': 'MSFT-OTC', 'MSFTOTC': 'MSFT-OTC',
  'AMERICANEXPRESS': 'AXP-OTC', 'AMEX': 'AXP-OTC', 'AXPOTC': 'AXP-OTC',
  'PFIZER': 'PFE-OTC', 'PFIZEROTC': 'PFE-OTC', 'PFEOTC': 'PFE-OTC',
  'JOHNSON': 'JNJ-OTC', 'JOHNSONJOHNSON': 'JNJ-OTC', 'JNJOTC': 'JNJ-OTC',
  // === COMMODITY ALIASES ===
  'GOLD': 'XAUUSD-OTC', 'GOLDOTC': 'XAUUSD-OTC', 'XAU/USD': 'XAUUSD-OTC', 'XAUUSD': 'XAUUSD-OTC', 'XAUUSDOTC': 'XAUUSD-OTC',
  'SILVER': 'XAGUSD-OTC', 'SILVEROTC': 'XAGUSD-OTC', 'XAG/USD': 'XAGUSD-OTC', 'XAGUSD': 'XAGUSD-OTC', 'XAGUSDOTC': 'XAGUSD-OTC',
  'CRUDEOIL': 'USCrude-OTC', 'CRUDE': 'USCrude-OTC', 'USCRUDE': 'USCrude-OTC', 'USCRUDEOIL': 'USCrude-OTC', 'USCRUDEOTC': 'USCrude-OTC',
  'BRENT': 'UKBrent-OTC', 'UKBRENT': 'UKBrent-OTC', 'UKBRENTOTC': 'UKBrent-OTC', 'BRENTOIL': 'UKBrent-OTC',
  'FLOUSD': 'FLOUSD-OTC', 'FLO/USD': 'FLOUSD-OTC', 'FLOUSDOTC': 'FLOUSD-OTC',
  // === CRYPTO ALIASES ===
  'BITCOIN': 'BTCUSD-OTC', 'BTC': 'BTCUSD-OTC', 'BTC/USD': 'BTCUSD-OTC', 'BTCUSD': 'BTCUSD-OTC', 'BTCUSDOTC': 'BTCUSD-OTC',
  'BITCOINCASH': 'BCHUSD-OTC', 'BCH': 'BCHUSD-OTC', 'BCH/USD': 'BCHUSD-OTC', 'BCHUSD': 'BCHUSD-OTC', 'BCHUSDOTC': 'BCHUSD-OTC',
  'ARBITRUM': 'ARBUSD-OTC', 'ARB': 'ARBUSD-OTC', 'ARB/USD': 'ARBUSD-OTC', 'ARBUSD': 'ARBUSD-OTC', 'ARBUSDOTC': 'ARBUSD-OTC',
  'ZCASH': 'ZECUSD-OTC', 'ZEC': 'ZECUSD-OTC', 'ZEC/USD': 'ZECUSD-OTC', 'ZECUSD': 'ZECUSD-OTC', 'ZECUSDOTC': 'ZECUSD-OTC',
  'COSMOS': 'ATOUSD-OTC', 'ATOM': 'ATOUSD-OTC', 'ATO': 'ATOUSD-OTC', 'ATO/USD': 'ATOUSD-OTC', 'ATOUSD': 'ATOUSD-OTC', 'ATOUSDOTC': 'ATOUSD-OTC',
  'AXIE': 'AXSUSD-OTC', 'AXS': 'AXSUSD-OTC', 'AXS/USD': 'AXSUSD-OTC', 'AXSUSD': 'AXSUSD-OTC', 'AXSUSDOTC': 'AXSUSD-OTC',
};

// Build a runtime lookup: strip all non-alpha from each ALL_OTC_PAIRS entry for fuzzy matching
const PAIR_CORE_MAP: Map<string, string> = new Map();
for (const p of ALL_OTC_PAIRS) {
  // "EURUSD-OTC" → core = "EURUSD", "USCrude-OTC" → core = "USCRUDE"
  const core = p.replace(/-OTC$/, '').toUpperCase();
  PAIR_CORE_MAP.set(core, p);
}

interface QuotexApiCandle {
  open?: number | string;
  high?: number | string;
  low?: number | string;
  close?: number | string;
  o?: number | string;
  h?: number | string;
  l?: number | string;
  c?: number | string;
  volume?: number | string;
  v?: number | string;
  vol?: number | string;
  Volume?: number | string;
  tick_volume?: number | string;
}

type QuotexApiResponse =
  | QuotexApiCandle[]
  | {
      success?: boolean;
      pair?: string;
      data?: QuotexApiCandle[];
      candles?: QuotexApiCandle[];
    };

function toNumericValue(value: unknown): number {
  const parsed = typeof value === 'number' ? value : parseFloat(String(value ?? '0'));
  return Number.isFinite(parsed) ? parsed : 0;
}

function buildApiPairCandidates(pair: string): string[] {
  const normalizedCore = pair.replace(/-OTC$/i, '').replace(/[^A-Za-z0-9]/g, '');
  const preferred = STOCK_OTC_MAP[pair] || `${normalizedCore}_otc`;
  const fallbackUpper = `${normalizedCore}_OTC`;
  const fallbackRaw = normalizedCore;

  return Array.from(new Set([preferred, fallbackUpper, fallbackRaw])).filter(Boolean);
}

// ============================================================
// BULLETPROOF PAIR NORMALIZATION
// Handles ANY format: "EUR/USD (OTC)", "EURUSD_otc", "EUR USD OTC", "eurusd-otc", etc.
// ============================================================
function normalizePairFromAI(rawPair: string): string {
  // Step 1: Clean — uppercase, remove all non-alphanumeric
  const upper = rawPair.toUpperCase().trim();
  const stripped = upper.replace(/[^A-Z0-9]/g, ''); // "EURUSDOTC", "USDBRLOTC", "GOLDOTC"

  // Step 2: Remove "OTC" suffix for core matching
  const withoutOTC = stripped.replace(/OTC$/, ''); // "EURUSD", "USDBRL", "GOLD"

  // Step 3: Check alias map (handles reversed pairs, full names, stock names)
  if (PAIR_ALIAS_MAP[withoutOTC]) return PAIR_ALIAS_MAP[withoutOTC];
  if (PAIR_ALIAS_MAP[stripped]) return PAIR_ALIAS_MAP[stripped];
  // Also check with slash format from the raw input
  const slashClean = upper.replace(/\s+/g, '').replace(/\(OTC\)/g, '').replace(/OTC/g, '').trim();
  if (PAIR_ALIAS_MAP[slashClean]) return PAIR_ALIAS_MAP[slashClean];

  // Step 4: Direct core match against ALL_OTC_PAIRS
  if (PAIR_CORE_MAP.has(withoutOTC)) return PAIR_CORE_MAP.get(withoutOTC)!;

  // Step 5: Try reversed 6-char currency pair (e.g., "USDEUR" → check if "EURUSD" exists)
  if (withoutOTC.length === 6 && /^[A-Z]{6}$/.test(withoutOTC)) {
    const reversed = withoutOTC.slice(3) + withoutOTC.slice(0, 3);
    if (PAIR_CORE_MAP.has(reversed)) {
      console.log(`[CHART-V8] Reversed pair: ${withoutOTC} → ${reversed}`);
      return PAIR_CORE_MAP.get(reversed)!;
    }
  }

  // Step 6: Substring match — find any pair whose core is contained in the input
  // e.g., "EURUSDM1OTC" would match "EURUSD"
  for (const [core, pair] of PAIR_CORE_MAP) {
    if (core.length >= 4 && withoutOTC.includes(core)) {
      console.log(`[CHART-V8] Substring match: "${rawPair}" contains ${core} → ${pair}`);
      return pair;
    }
  }

  // Step 7: Last resort — construct with -OTC suffix
  let fallback = withoutOTC;
  if (!fallback.endsWith('-OTC')) fallback += '-OTC';
  fallback = fallback.replace(/--+/g, '-');
  console.log(`[CHART-V8] Fallback normalization: "${rawPair}" → ${fallback}`);
  return fallback;
}

// ============================================================
// FETCH FRESH CANDLES FROM BROKER API
// ============================================================
async function fetchFreshCandles(pair: string): Promise<string | null> {
  const apiPairCandidates = buildApiPairCandidates(pair);

  for (const apiPair of apiPairCandidates) {
    for (let attempt = 1; attempt <= OTC_FETCH_MAX_RETRIES; attempt++) {
      try {
        const url = `${OTC_API_BASE}?pair=${encodeURIComponent(apiPair)}&timeframe=M1&count=500`;
        console.log(`[CHART-V8] Fetching candles from: ${url} (attempt ${attempt}/${OTC_FETCH_MAX_RETRIES})`);

        const res = await fetch(url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Lovable Cloud)',
            'Accept': 'application/json',
          },
          signal: AbortSignal.timeout(OTC_FETCH_TIMEOUT_MS),
        });

        if (!res.ok) {
          console.error(`[CHART-V8] Candle fetch failed for ${apiPair}:`, res.status);
          await res.text().catch(() => '');

          if (attempt < OTC_FETCH_MAX_RETRIES) {
            await sleep(attempt * 1000);
            continue;
          }

          break;
        }

        const rawText = await res.text();
        const candles = parseQuotexCandles(rawText);

        if (!candles.length) {
          console.warn(`[CHART-V8] Empty candle response for ${apiPair}`);
          break;
        }

        const orderedCandles = candles.slice().sort(
          (a, b) => new Date(extractApiTime(a)).getTime() - new Date(extractApiTime(b)).getTime(),
        );

        const rows = orderedCandles.map((c, i) => {
          const o = toNumericValue(c.open ?? c.o);
          const h = toNumericValue(c.high ?? c.h);
          const l = toNumericValue(c.low ?? c.l);
          const cl = toNumericValue(c.close ?? c.c);
          const v = extractApiVolume(c);
          return `${i + 1},${o},${h},${l},${cl},${v}`;
        });

        const nonZeroVolumeCandles = orderedCandles.filter(
          (c) => extractApiVolume(c) > 0,
        ).length;

        console.log(`[CHART-V8] Retrieved ${orderedCandles.length} candles for ${apiPair}; candles with volume: ${nonZeroVolumeCandles} (strict API volume, never epoch/time)`);
        return `#,O,H,L,C,V\n${rows.join('\n')}`;
      } catch (e) {
        console.error(`[CHART-V8] fetchFreshCandles error for ${apiPair} (attempt ${attempt}):`, e);

        if (attempt < OTC_FETCH_MAX_RETRIES) {
          await sleep(attempt * 1000);
          continue;
        }
      }
    }
  }

  return null;
}

// ============================================================
// GEMINI API CALL — ALL keys rotate, SHARED DEADLINE prevents timeout
// ============================================================
const REQUEST_DEADLINE_MS = 175000;
const MAX_GEMINI_KEYS_TO_TRY = FRESH_KEY_BATCH_SIZE;

// Shared deadline — set once per request in the main handler
let requestDeadline = 0;
function timeLeft(): number { return Math.max(0, requestDeadline - Date.now()); }

// No Lovable AI Gateway — using all 25 Gemini keys only

async function callGemini(
  prompt: string, keyPool: string[], maxTokens: number, thinkingBudget: number,
  _timeoutMs: number, exhausted: Set<string>, cooldowned: Set<string>,
): Promise<{ text: string; usedKey: string } | null> {
  const model = 'gemini-2.5-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
  const candidates = selectFreshKeys(keyPool, exhausted, MAX_GEMINI_KEYS_TO_TRY);
  const batchWindowMs = Math.min(KEY_BATCH_WINDOW_MS, Math.max(_timeoutMs, MIN_PER_KEY_TIMEOUT_MS), timeLeft());
  if (!candidates.length) { console.error('[CHART-V8] No live keys'); return null; }

  // Auto-disable thinking for very long prompts (>32k chars)
  const promptLength = prompt.length;
  const useThinking = promptLength <= 32000 && thinkingBudget > 0;

  const buildBody = (p: string) => {
    const body: Record<string, any> = {
      contents: [{ role: 'user', parts: [{ text: p }] }],
      generationConfig: { temperature: 0.25 },
    };
    if (useThinking) {
      body.generationConfig.thinkingConfig = { thinkingBudget };
    } else {
      body.generationConfig.maxOutputTokens = maxTokens;
    }
    return body;
  };

  console.log(`[CHART-V8] callGemini: ${candidates.length} keys, thinking=${useThinking} (prompt ${Math.round(promptLength/1000)}k chars), ${Math.round(batchWindowMs/1000)}s batch, ${Math.round(timeLeft()/1000)}s left`);

  const perKeyTimeoutMs = Math.max(MIN_PER_KEY_TIMEOUT_MS, Math.min(batchWindowMs, 25000));

  const attemptKey = async (key: string): Promise<{ text: string; usedKey: string }> => {
    markKeyAttempt(key);
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), perKeyTimeoutMs);
    try {
      const res = await fetch(`${url}?key=${key}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(buildBody(prompt)),
        signal: ctrl.signal,
      });
      clearTimeout(timer);
      if (!res.ok) {
        const classified = await classifyGeminiError(res);
        console.error(`[CHART-V8] Gemini ${res.status} (key ${maskKey(key)}):`, classified.details.slice(0, 240));
        if (classified.shouldCooldown) { cooldownKey(key, classified.reason); cooldowned.add(key); }
        if (classified.shouldSkipForRequest) exhausted.add(key);

        // If 400 with thinking, retry WITHOUT thinking
        if (res.status === 400 && useThinking) {
          console.log(`[CHART-V8] Retrying key ${maskKey(key)} WITHOUT thinking...`);
          const retryBody: Record<string, any> = {
            contents: [{ role: 'user', parts: [{ text: prompt }] }],
            generationConfig: { temperature: 0.25, maxOutputTokens: maxTokens },
          };
          const ctrl2 = new AbortController();
          const timer2 = setTimeout(() => ctrl2.abort(), perKeyTimeoutMs);
          const res2 = await fetch(`${url}?key=${key}`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(retryBody), signal: ctrl2.signal,
          });
          clearTimeout(timer2);
          if (res2.ok) {
            const data2 = await res2.json();
            const text2 = extractGeminiText(data2);
            if (text2) { markKeySuccess(key); return { text: text2, usedKey: key }; }
          }
        }
        throw new Error(`key failed: ${classified.reason}`);
      }
      const data = await res.json();
      const text = extractGeminiText(data);
      if (!text) { exhausted.add(key); throw new Error('empty response'); }
      markKeySuccess(key);
      console.log(`[CHART-V8] Success with key ${maskKey(key)} (${text.length} chars)`);
      return { text, usedKey: key };
    } catch (e) { clearTimeout(timer); exhausted.add(key); throw e; }
  };

  try {
    return await Promise.any(candidates.map(k => attemptKey(k)));
  } catch {
    console.warn(`[CHART-V8] All ${candidates.length} parallel keys failed`);
    return null;
  }
}

// ============================================================
// GEMINI IMAGE CALL — for pair detection from chart image
// Uses comprehensive pair list to guide AI detection
// ============================================================
async function callGeminiWithImage(
  imageBase64: string, keyPool: string[], exhausted: Set<string>, cooldowned: Set<string>,
): Promise<string | null> {
  const model = 'gemini-2.5-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
  
  // Give the AI the EXACT list of valid pairs to choose from
  const pairList = ALL_OTC_PAIRS.join(', ');
  const prompt = `You are a Quotex OTC trading chart pair detector. Look at this chart screenshot and identify the trading pair.

VALID PAIRS (you MUST return one of these EXACTLY):
${pairList}

DETECTION RULES:
1. Look for the pair name displayed on the chart (usually top-left or title area)
2. Quotex displays pairs like "EUR/USD (OTC)", "USD/BRL (OTC)", "Bitcoin (OTC)", "Gold (OTC)", etc.
3. Match what you see to the closest pair from the VALID PAIRS list above
4. Common mappings:
   - "EUR/USD (OTC)" or "EURUSD OTC" → EURUSD-OTC
   - "USD/BRL (OTC)" → BRLUSD-OTC (note: reversed!)
   - "Gold (OTC)" → XAUUSD-OTC
   - "Silver (OTC)" → XAGUSD-OTC
   - "Bitcoin (OTC)" → BTCUSD-OTC
   - "Intel (OTC)" → INTL-OTC
   - "Microsoft (OTC)" → MSFT-OTC
   - "US Crude (OTC)" → USCrude-OTC
   - "UK Brent (OTC)" → UKBrent-OTC
5. If you see a reversed pair like "USD/JPY", return it as "USDJPY-OTC" (keep the order shown)
6. If you cannot identify any valid pair, respond with "INVALID"

Return ONLY the pair name from the valid list above. No explanation, no JSON, just the exact pair name like: EURUSD-OTC`;

  const base64Data = imageBase64.startsWith('data:') ? imageBase64.split(',')[1] : imageBase64;
  const candidates = selectFreshKeys(keyPool, exhausted, MAX_GEMINI_KEYS_TO_TRY);
  const batchWindowMs = Math.min(KEY_BATCH_WINDOW_MS, timeLeft());
  const batchDeadline = Date.now() + batchWindowMs;
  const perKeyTimeoutMs = Math.max(
    MIN_PER_KEY_TIMEOUT_MS,
    Math.floor(batchWindowMs / Math.max(candidates.length, 1)),
  );

  console.log(`[CHART-V8] callGeminiWithImage: ${candidates.length} fresh keys, ${Math.round(batchWindowMs/1000)}s batch, ${Math.round(perKeyTimeoutMs/1000)}s/key, ${Math.round(timeLeft()/1000)}s left`);
  
  for (const key of candidates) {
    const remaining = Math.min(timeLeft(), batchDeadline - Date.now());
    if (remaining < 1500) {
      console.warn(`[CHART-V8] DEADLINE: only ${Math.round(remaining/1000)}s left in fresh-key image batch, stopping image detection`);
      break;
    }
    try {
      markKeyAttempt(key);
      const keyTimeout = Math.min(perKeyTimeoutMs, remaining);
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), keyTimeout);
      const res = await fetch(`${url}?key=${key}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ role: 'user', parts: [
            { text: prompt },
            { inline_data: { mime_type: 'image/png', data: base64Data } },
          ] }],
          generationConfig: { temperature: 0.1, maxOutputTokens: 200 },
        }),
        signal: ctrl.signal,
      });
      clearTimeout(timer);
      if (!res.ok) {
        const classified = await classifyGeminiError(res);
        console.error(`[CHART-V8] Gemini image ${res.status} (key ${maskKey(key)}):`, classified.details.slice(0, 240));
        if (classified.shouldCooldown) {
          cooldownKey(key, classified.reason);
          cooldowned.add(key);
        }
        if (classified.shouldSkipForRequest) exhausted.add(key);
        continue;
      }
      const data = await res.json();
      const text = extractGeminiText(data).trim();
      markKeySuccess(key);
      
      const cleanText = text.replace(/```/g, '').replace(/\n/g, ' ').trim();
      console.log(`[CHART-V8] Raw AI pair detection: "${cleanText}" (key ${maskKey(key)})`);
      
      for (const validPair of ALL_OTC_PAIRS) {
        if (cleanText.includes(validPair)) {
          console.log(`[CHART-V8] Exact match found: ${validPair}`);
          return validPair;
        }
      }
      
      return cleanText;
    } catch (e) { exhausted.add(key); continue; }
  }
  
  console.warn(`[CHART-V8] Fresh-key image batch exhausted (${candidates.length} tried in ${Math.round(batchWindowMs / 1000)}s) — no fallback available`);
  return null;
}

// ============================================================
// DIRECTION NORMALIZATION
// ============================================================
function normalizeDirection(dir: string, fullJson: string, fallbackCSV?: string): 'UP' | 'DOWN' {
  const d = (dir || '').trim().toUpperCase();
  if (d === 'UP' || d === 'DOWN') return d;
  const up = (fullJson.match(/\bUP\b/g) || []).length;
  const dn = (fullJson.match(/\bDOWN\b/g) || []).length;
  if (up !== dn) return up > dn ? 'UP' : 'DOWN';
  if (fallbackCSV) {
    const rows = fallbackCSV.trim().split('\n').filter(r => !r.startsWith('#'));
    const last = rows[rows.length - 1]?.split(',');
    if (last && last.length >= 5) return parseFloat(last[4]) >= parseFloat(last[1]) ? 'UP' : 'DOWN';
  }
  return 'UP';
}

// ============================================================
// PROMPT NORMALIZATION LOCK — enforce strict 4th-candle targeting
// ============================================================
function enforceFourthCandlePrompt(prompt: string): string {
  return prompt
    .replace(/\b3RD\b/g, '4TH')
    .replace(/\b3rd\b/g, '4th')
    .replace(/→3C/g, '→4C')
    .replace(/~2 minutes/g, '~3 minutes')
    .replace(/\b2 minutes\b/g, '3 minutes')
    .replace(/\b2 candles will form\b/g, '3 candles will form')
    .replace(/\b2 intermediate candles\b/g, '3 intermediate candles')
    .replace(/\bfor the 3rd candle\b/g, 'for the 4th candle')
    .replace(/\bfor 3rd candle\b/g, 'for 4th candle')
    .replace(/\bby the 3rd candle\b/g, 'by the 4th candle')
    .replace(/\bwhere the 3rd candle\b/g, 'where the 4th candle')
    .replace(/\b3RD CANDLE\b/g, '4TH CANDLE');
}

// ============================================================
// STAGE 1 PROMPT — 18-Step Elite Institutional Analysis + OTC-ALGO Intelligence
// ============================================================
function buildStage1Prompt(csvData: string, pair: string): string {
  return `You are QUANTUM-NEXUS V8 — the world's most advanced institutional-grade OTC binary options AI. Analyze the 1-minute OTC chart data for ${pair}.

INPUT DATA (500 candles, newest = last row):
${csvData}

MISSION: Predict what the 4TH CANDLE FROM NOW closes as — ABOVE (UP) or BELOW (DOWN) its opening price.
- CRITICAL: You are NOT predicting the next candle. You are predicting the candle that opens ~3 minutes from NOW.
- Between now and entry, 3 candles will form. Analyze what those 3 intermediate candles are LIKELY to do, then predict the 4th.
- FORWARD-PROJECT: IF momentum is fading → the 4th candle may reverse. IF momentum is building → the 4th candle continues.
- SINGLE CANDLE ONLY — predict the 4th candle's close direction
- NO DOUBLE-PREDICTION: "UP then DOWN" = invalid
- Confidence below 65 = NO TRADE (output 50-59 confidence)
- Loss prevention is PRIME — ambiguity → reduce confidence

WHY 4TH CANDLE LOGIC:
- The signal is delivered at ~3 minutes. The user enters the trade at the 4th candle's open.
- You must project through 3 intermediate candles to determine where the 4th candle closes.
- Key question: Does the current setup SUSTAIN or EXHAUST by the time 3 more candles form?

═══ OTC-ALGO INTELLIGENCE [Weight: 10%] — FOUNDATION + THROUGHOUT + FINAL ═══
OTC markets are ALGORITHMICALLY GENERATED — prices come from broker algorithms, NOT real interbank feeds.
OTC Intelligence carries 10% weight in the final score synthesis (Step 12).
It operates in THREE phases:
  PHASE 1 (START): Compute all 6 rules from raw data → provides context for Steps 1-22
  PHASE 2 (THROUGHOUT): Each step references OTC findings to validate/adjust its analysis
  PHASE 3 (FINAL — Step 23): Re-evaluate all 6 rules against full technical consensus → apply 10% weight adjustment

CRITICAL BALANCE: OTC Intelligence is an IMPORTANT analytical category (10% weight) — same as any major step.
It provides REAL intelligence about algorithmic behavior. But it does NOT override the other 90% of analysis.
Each step performs its FULL independent technical analysis FIRST, then checks OTC context for validation.

Compute the 6 OTC-ALGO rules FIRST:

OTC-ALGO RULE 1 — SYNTHETIC PRICE ENGINE DETECTION:
- Calculate autocorrelation of returns over 20/50/100/200 periods
- HIGH autocorrelation (>0.3) = TRENDING mode. Near-zero = RANDOM mode. NEGATIVE = MEAN-REVERSION mode
- Output: OTC_MODE, OTC_CYCLE_LENGTH, OTC_CYCLE_POSITION

OTC-ALGO RULE 2 — LIQUIDITY INJECTION DETECTION:
- Volume spike (>2.5x avg) with body <0.5x ATR = INJECTED VOLUME (fake)
- Build injection map. Output: INJECTION_COUNT, MANIPULATION_INTENSITY

OTC-ALGO RULE 3 — PAYOUT-DRIVEN MANIPULATION:
- 5+ same-dir candles with growing opposing wicks = broker fighting retail
- Output: BROKER_BIAS, PAYOUT_TRAP_ACTIVE

OTC-ALGO RULE 4 — SPREAD MANIPULATION:
- Spread proxy: avg(high-low) last 10 vs last 100. Output: SPREAD_STATUS

OTC-ALGO RULE 5 — ALGORITHMIC BOUNDARY DETECTION:
- Session open + max deviation over 200 candles. Boundary proximity for reversal probability
- Output: BOUNDARY_PROXIMITY (0-100%), BOUNDARY_DIRECTION

OTC-ALGO RULE 6 — PATTERN RECYCLING:
- Cross-correlate last 20 candles at offsets. Output: RECYCLING_ACTIVE, RECYCLING_PREDICTION

These 6 rules provide the OTC INTELLIGENCE CONTEXT (10% weight) that each step references alongside its primary technical analysis.

INTERCONNECTION PROTOCOL — Every step MUST:
1. Perform its FULL independent technical analysis FIRST — this is the PRIMARY finding (full depth, no shortcuts)
2. Cross-reference ALL prior steps for confluence or conflict (INTERCONNECTION — confirms/conflicts/amplifies)
3. Note OTC context relevance (OTC NOTE — how OTC intelligence adjusts weight/confidence of THIS step's finding)
- Conflicting inter-step findings → -8 confidence per conflict
- 3+ steps confirming same thesis → +5 per additional step beyond 3
- MESH NETWORK: Evidence flows BIDIRECTIONALLY — later steps can STRENGTHEN or WEAKEN earlier findings
- Every step output: TECHNICAL FINDING | INTERCONNECTION | OTC NOTE
- CRITICAL: Each step's TECHNICAL FINDING must be complete and thorough on its own. OTC NOTE is supplementary.

EXECUTE ALL STEPS IN ORDER (OTC context computed → Steps 1-22 full technical analysis → Step 23 OTC final synthesis):

═══════════════════════════════════════════════════════
STEP 1 — MULTI-TIMEFRAME TREND ARCHITECTURE [Weight: 10%]
═══════════════════════════════════════════════════════
Build the complete trend hierarchy — this is the FOUNDATION that ALL subsequent steps reference.

A) FRACTAL TIMEFRAME DECOMPOSITION:
- MACRO TREND (candles 1-200): Count HH+HL sequences (bullish) vs LH+LL sequences (bearish). Rate: STRONG (8+) / MODERATE (5-7) / WEAK (3-4) / EXHAUSTED (<3 or mixed)
- MID TREND (candles 200-400): Direction + EMA-20 slope angle + trend age in candles + pullback count (more pullbacks = healthier trend)
- MICRO TREND (last 20 candles): Direction, consecutive same-direction count, body size progression (expanding/stable/contracting), wick character (clean = strong, messy = weak)
- ULTRA-MICRO (last 5 candles): 8x weight — these are the FRESHEST reality. Exact body sizes, wick ratios, close positions within range
- NANO-MICRO (last 3 candles): 12x weight — the IMMEDIATE price action. Each candle described individually: body size vs ATR, close position ((close-low)/(high-low)), wick dominance, volume relative to 20-avg

B) SYNTHETIC HIGHER TIMEFRAME CONSTRUCTION:
- H1 PROXY: Aggregate last 60 M1 candles into 1-hour bars. Identify H1 trend direction, last H1 swing high/low, H1 EMA20 position
- H4 PROXY: Aggregate last 240 M1 candles. H4 trend, H4 OB zones, H4 FVG gaps
- D1 PROXY: All 500 candles = ~8 hours. Overall session bias
- RULE: Only trade AGAINST HTF if micro-setup is textbook-perfect with volume confirmation AND institutional SMC alignment (from Step 2)

C) TREND QUALITY ASSESSMENT:
- INSTITUTIONAL TREND GRADE: Driven by displacement candles (body >2x ATR with volume >1.5x avg) = REAL. Slow drift (small bodies, no volume) = WEAK/FAKE
- TREND MATURITY DECAY: 3-4 consecutive same-dir = FRESH. 5-6 = MATURE. 7-8 = OVEREXTENDED (70%+ reversal). 9+ = CRITICAL EXHAUSTION (85%+ reversal). Formula: base 50% + (consecutive - 4) × 8%
- TREND EXHAUSTION SIGNATURE: Diminishing impulse + expanding correction = trend DYING → Step 17 must project reversal
- EMA ALIGNMENT HEALTH: Price >0.4% above EMA20 = snap-back imminent. >0.6% = DANGEROUS. EMA7/8/20/50 stacked = STRONG. Any crossing = TRANSITION
- CHANNEL INTEGRITY: Linear regression R² of last 20 closes. R² > 0.85 = clean. 0.6-0.85 = moderate. < 0.6 = CHAOTIC → -15 conf
- OTC-ALGO TREND VALIDATION: Cross-reference OTC-ALGO RULE 1 autocorrelation. If algorithm is in RANDOM mode but chart shows "trend" → FAKE TREND (OTC noise) → -20 conf for trend-following setups
- OTC BOUNDARY CHECK: Cross-reference OTC-ALGO RULE 5. If trend is approaching max deviation boundary → trend is ABOUT TO REVERSE regardless of technical signals → +20 reversal conf

D) TREND-TO-STEP BRIDGE (feeds ALL subsequent steps):
- OUTPUT: TREND_DIRECTION (UP/DOWN/RANGING), TREND_STRENGTH (0-100), TREND_AGE (candles), EXHAUSTION_PROBABILITY (0-100%), HTF_ALIGNMENT (ALIGNED/CONFLICTING/NEUTRAL), OTC_ALGO_MODE (TRENDING/RANDOM/MEAN_REVERT), OTC_BOUNDARY_PROXIMITY (0-100%)

═══════════════════════════════════════════════════════
STEP 2 — SMART MONEY CONCEPTS (SMC) MASTER ANALYSIS [Weight: 12%]
═══════════════════════════════════════════════════════
Institutional ENGINE. MUST reference Step 1 TREND_DIRECTION and OTC-ALGO RULES.

A) MARKET STRUCTURE MAPPING:
- BOS: Last 3 confirmed BOS events. Each: candle number, direction, body-close (VALID) or wick-only (INVALID)?
- ChoCH: Counter-structural candle in last 15? ChoCH + Step 1 EXHAUSTION >60% = HIGH reversal
- Internal vs External Structure: Internal BOS = minor shift. External BOS = major change. External BOS against MACRO TREND = PARADIGM SHIFT
- STRUCTURE GRADE: CLEAR (consistent HH/HL or LH/LL) / MIXED / CHAOTIC. CHAOTIC = -18 conf, consider NO TRADE
- STRUCTURE-TREND FUSION: BOS matches Step 1? Match = +8. Conflict = -12
- OTC STRUCTURE REALITY: Cross-reference OTC-ALGO RULE 1. If algorithm is in RANDOM mode → BOS events are NOISE, not institutional signals → reduce BOS weight by 50%. If TRENDING mode → BOS is algorithm-driven (reliable)

B) ORDER BLOCK (OB) PRECISION ENGINE:
- Bullish OB = last bearish candle before bullish displacement (body >2x ATR). Mark exact levels
- Bearish OB = last bullish candle before bearish displacement. Mark levels
- OB FRESHNESS: 1st touch = 100%. 2nd = 40%. 3rd = DEAD (0%)
- OB MEAN THRESHOLD: Price closes beyond 50% of OB body = FAILED FLIP
- NESTED OB: OB inside larger HTF OB = EXTREME confluence (+20)
- OB-VOLUME VALIDATION: OB with volume >1.5x = INSTITUTIONAL. Without = retail-driven (-40% weight)
- OB DISTANCE DECAY: >80 candles old AND >1% away = STALE (-60% weight)
- DEMAND/SUPPLY ZONE: 2+ OBs within 0.03% = INSTITUTIONAL ZONE
- OTC OB RELIABILITY: Cross-reference OTC-ALGO RULE 2. If INJECTION CLUSTERING detected → OBs formed during injections are UNRELIABLE → discard those OBs. Only trust OBs formed with CLEAN volume

C) FAIR VALUE GAP (FVG) ARCHITECTURE:
- Bullish FVG: candle[n-1].high < candle[n+1].low. Bearish FVG: candle[n-1].low > candle[n+1].high
- FVG CONSEQUENT ENCROACHMENT (CE): 50% level = magnet
- iFVG: Broken FVG FLIPS polarity
- BPR (Balanced Price Range): Overlapping FVGs = VELOCITY zone. Escape direction = STRONG signal
- FVG SIZE FILTER: <2 pips = ignore. 2-10 = VALID. >10 = news-driven (-8)
- FVG AGE: >100 candles unfilled = STRONG magnets. <10 candles = IMMEDIATE targets
- OTC FVG FILTER: In OTC RANDOM mode (OTC-ALGO RULE 1) → FVGs fill probability drops from 85% to 55% → reduce FVG weight by 35%

D) DISPLACEMENT & INSTITUTIONAL FOOTPRINT:
- Body > 2.5x avg body = institutional displacement. Mark in last 50 candles
- 3+ consecutive = INSTITUTIONAL CAMPAIGN — do NOT trade against
- Displacement + 3+ small consolidation = ORDER FILLING → continuation
- OTC DISPLACEMENT FILTER: Cross-reference OTC-ALGO RULE 2. If displacement candle has INJECTED VOLUME → NOT institutional. It's broker manipulation → IGNORE as evidence

E) PREMIUM vs DISCOUNT ZONES:
- Swing high/low range from last 100. Above 50% = PREMIUM. Below = DISCOUNT
- OTE: 61.8%-78.6% Fibonacci = highest probability
- CALL in PREMIUM without OB/FVG = dangerous → -15. PUT in DISCOUNT without OB/FVG = dangerous → -15

F) BREAKER BLOCKS: Failed OB broken = BREAKER (polarity flip). Return = HIGH probability (+18)
G) MITIGATION BLOCKS: Extreme OB beyond IDM = target. Unmitigated = magnets
H) REJECTION BLOCKS: Long wick at key level closing away. Wick >60% = rejection. With volume >2x = INSTITUTIONAL
I) SMC COMPOSITE OUTPUT for Steps 3,8,12,16: SMC_DIRECTION, SMC_STRENGTH (0-100), SMC_ZONES, OTC_OB_RELIABILITY (HIGH/MEDIUM/LOW)

═══════════════════════════════════════════════════════
STEP 3 — LIQUIDITY ENGINEERING & OTC TRAP DETECTION [Weight: 12%]
═══════════════════════════════════════════════════════
MUST cross-reference Step 1 TREND, Step 2 SMC_ZONES, and ALL OTC-ALGO RULES.

A) LIQUIDITY POOL MAPPING:
- BSL: All swing highs. 2+ within 0.015% = pool
- SSL: All swing lows. 2+ within 0.015% = pool
- EQH/EQL: 2+ within 0.01% = INDUCEMENT
- LIQUIDITY VOID: Gap with no trading = future fill target
- POOL PROXIMITY: Exact distance to nearest BSL/SSL. Closer = more likely target
- POOL AGE: >50 candles untouched = STRONGER magnets
- MULTI-POOL STACKING: 2+ pools same side within 0.03% = MASSIVE target
- OTC POOL REALITY: In OTC markets, liquidity pools are VISIBLE to the broker's algorithm. The algorithm INTENTIONALLY sweeps pools to trigger stops. Pool sweep probability is HIGHER in OTC than real markets (+10% base sweep probability)

B) SWEEP MECHANICS:
- STANDARD SWEEP: Price beyond pool, closes back = REVERSAL (+15). Wick >60%
- STOP HUNT: Quick wick + immediate reversal = institutional. Within 1-2 candles
- DOUBLE SWEEP: Both sides within 8 candles = confusion CLEARED → strong move after 2nd sweep
- FAILED SWEEP: Didn't close back = REAL breakout
- SWEEP EXHAUSTION: 3+ sweeps same pool = DRAINED
- SWEEP-OB FUSION: Sweep reaching Step 2 OB = INSTITUTIONAL RELOAD (+22)
- OTC ALGORITHMIC SWEEP: Cross-reference OTC-ALGO RULE 3. If broker detected fighting retail → sweep is PROGRAMMATIC (100% intentional) → post-sweep reversal probability increases to 88%+

C) OTC-SPECIFIC 12-TRAP MATRIX — WORLD-CLASS DETECTION WITH OTC-ALGO CROSS-REFERENCE:
Each trap cross-references Steps 1,2,4,5,6 AND OTC-ALGO RULES for 100% detection.

1. VOLUME GHOST: Body >1.5x ATR + volume <0.5x avg = FAKE (78% reversal). Cross: Step 2 displacement? Step 4 MOM? OTC-ALGO RULE 2 injection? If injection confirmed → GUARANTEED fake (+20 reversal)
2. WICK ASSASSIN: 3+ wicks touching identical level (±0.005%) = algo accumulation. Cross: Step 2 OB + Step 5 S/R. OTC-ALGO: if OTC algorithm in MEAN_REVERT mode → wicks are the BOUNDARY → reversal 85%+
3. GAP BAIT: Opening gap fills within 3 candles = retail trap. Cross: Step 2 FVG + Step 4 momentum. OTC-ALGO RULE 6: if gap matches recycled pattern → fill probability 90%+
4. STAIRCASE TRAP: 5+ small bodies (<0.3x ATR) same-dir + declining volume = algo building reversal position. Probability: 72% + 4%/step. Cross: Step 1 EXHAUSTION + Step 2 OB at end. OTC-ALGO RULE 5: if staircase approaches boundary → 95%+ reversal
5. MIRROR TRAP: Pattern mirrors structure 50-100 candles ago (>85% correlation) = recycled. Cross: Step 9 Wyckoff + OTC-ALGO RULE 6 pattern recycling. If BOTH confirm → resolution prediction is 90%+ accurate
6. TIME BOMB: Consolidation at S/R 8+ candles + declining ATR = explosion imminent. Cross: Step 7 COMPRESSION + Step 3 nearest pool. OTC-ALGO: if OTC algorithm just switched from RANDOM to TRENDING mode → explosion direction = new trend
7. ROUND NUMBER VACUUM: Within 3 pips of .000/.500/.250/.750 = magnet. Overshoots 1-2 pips before reversing. Cross: Step 5 S/R + Step 2 OB. OTC-ALGO RULE 5: round numbers near boundary = DOUBLE REVERSAL MAGNET
8. WHIPSAW TRAP: Price crosses key level then reverses within 2 candles = stop-hunt. Cross: Step 3 EQH/EQL + Step 6 volume spike on reversal. OTC-ALGO RULE 3: if broker fighting retail → whipsaw is INTENTIONAL (+18 reversal conf)
9. FAKE BREAKOUT CASCADE: 2+ false breakouts of different S/R within 10 candles = trap mode. Cross: Step 5 S/R fails + Step 2 no BOS. OTC-ALGO RULE 1: if RANDOM mode → breakouts are ALL fake → -20, mean reversion
10. LIQUIDITY VOID TRAP: Rapid move through low-volume zone then reversal = institutional acceleration. Cross: Step 2 FVG in zone + Step 3 opposite pool. OTC-ALGO: void traps are 35% more common in OTC than real markets
11. EXHAUSTION SPIKE TRAP: Largest candle in 50+ lookback as last/2nd-last = CLIMACTIC. Cross: Step 4 deceleration after → 88% reversal. Step 1 exhaustion. OTC-ALGO RULE 5: if spike hits boundary → 96%+ reversal
12. SHADOW DIVERGENCE TRAP: Price new highs but RSI(10) equal/lower highs over 5-8 candles = HIDDEN divergence. Cross: Step 8 divergence + Step 2 OB nearby. OTC-ALGO: in TRENDING mode shadow divergence signals algorithm about to SWITCH modes

TRAP INTERCONNECTION PROTOCOL:
- Total traps: 0-2 = CLEAN. 3-4 = CAUTION (-12). 5+ = TRAP ZONE (-25, consider NO TRADE)
- CONVERGENT traps (same reversal direction) = 95%+ reversal probability
- CONFLICTING traps = CHAOTIC → NO TRADE
- Every trap must state which Steps AND which OTC-ALGO RULES it cross-referenced
- OTC TRAP AMPLIFIER: In OTC markets, traps are MORE reliable than in real markets because they're ALGORITHMICALLY GENERATED. When OTC-ALGO mode confirms trap → +8 additional confidence for trap's reversal direction

D) INDUCEMENT DETECTION: Minor liquidity grab baiting retail before REAL move. OTC-ALGO: IDM in OTC is almost always followed by the real move within 2-4 candles (broker needs to reverse)
E) ACCUMULATION/DISTRIBUTION SIGNATURES: 3+ identical highs/lows = institutional activity. OTC-ALGO: in OTC this may be the algorithm's BOUNDARY, not accumulation → cross-reference RULE 5
F) LIQUIDITY-SMC FUSION ENGINE: FVG near pool = DOUBLE MAGNET. OB at sweep = RELOAD (+22). BOS + sweep = CONFIRMED INSTITUTIONAL (+25)
G) OUTPUT: LIQ_DIRECTION, LIQ_SWEEP_ACTIVE, LIQ_TRAP_COUNT, LIQ_TRAP_CONVERGENCE, LIQ_SMC_FUSION_SCORE, OTC_ALGO_TRAP_BOOST (0-30)

═══════════════════════════════════════════════════════
STEP 4 — MOMENTUM DYNAMICS [Weight: 8%]
═══════════════════════════════════════════════════════
MUST reference Step 1 TREND_STRENGTH, Step 2 DISPLACEMENT, and OTC-ALGO RULES.

A) BODY PROGRESSION: Last 10 body sizes. EXPANDING (>10% growth) / STABLE (±10%) / CONTRACTING (>10% shrink). DECELERATION >25%/candle = DEAD MOMENTUM. ACCELERATION >30% = sustains. OTC-ALGO: In MEAN_REVERT mode, acceleration is SHORT-LIVED (max 3-4 candles) → 4th candle WILL reverse
B) CONSECUTIVE CANDLE REVERSAL: 3=58%, 4=68%, 5=78%, 6=85%, 7=90%, 8+=94%. Caveats: Step 2 CAMPAIGN → -15% reversal. Step 3 unswept pool in direction → -12%. OTC-ALGO RULE 5 boundary approaching → +15% reversal (overrides caveats)
C) CANDLE QUALITY: Wick vs body ratio. Wicks > bodies = CHOPPY (-15). Bodies >2x wicks = CLEAN. CLIMACTIC candle in last 5 = 82%+ reversal unless Step 2 campaign. OTC-ALGO: climactic candles in OTC are often the ALGORITHM'S reversal trigger → +10% reversal probability
D) INSTITUTIONAL MOMENTUM: Volume-weighted body. Big body + big volume = REAL. Big body + low volume = RETAIL TRAP (cross Step 3 VOLUME GHOST). ABSORPTION: High volume + small body = opposing force → reversal 2-3 candles. OTC-ALGO RULE 2: filter out INJECTED VOLUME before calculating
E) OUTPUT: MOM_DIRECTION, MOM_STRENGTH (0-100), MOM_EXHAUSTION (T/F), MOM_4C_PROJECTION, OTC_ALGO_MOM_OVERRIDE (none/reversal/continuation)

═══════════════════════════════════════════════════════
STEP 5 — SUPPORT & RESISTANCE ARCHITECTURE [Weight: 8%]
═══════════════════════════════════════════════════════
Cross-reference Step 2 OB/FVG and Step 3 pools. OTC-ALGO RULES 5,7.

A) DYNAMIC S/R: Top 5 resistance + top 5 support. Strength = touches × (1/sqrt(recency)) × (1 + wick_rejections × 0.3). At Step 2 OB = 2x. At Step 3 pool = 2x. At BOTH = ULTRA S/R (4x). OTC-ALGO RULE 5: S/R near algorithm boundary = UNBREAKABLE S/R (+30% strength)
B) PSYCHOLOGICAL LEVELS: .000/.500/.250/.750. With S/R = MONSTER. Cross Step 3 trap #7. OTC-ALGO: OTC algorithms RESPECT round numbers more than real markets → psychological levels are 40% MORE reliable
C) S/R BEHAVIOR: Within 0.025% = rejection expected. Breakout: volume >2.2x + body >1.5x ATR + Step 2 BOS. Fake breakout: wick only = 85%+. COMPRESSION: 4+ tightening = explosion. POLARITY FLIP: confirmed = HIGH confidence. OTC-ALGO: In RANDOM mode → S/R rejections are 25% less reliable. In MEAN_REVERT → 30% MORE reliable
D) OUTPUT: NEAREST_SUPPORT, NEAREST_RESISTANCE, PRICE_POSITION, S/R_INSTITUTIONAL, OTC_BOUNDARY_LEVEL (if applicable)

═══════════════════════════════════════════════════════
STEP 6 — VOLUME INTELLIGENCE [Weight: 6%]
═══════════════════════════════════════════════════════
Volume = TRUTH DETECTOR. OTC-ALGO RULE 2 filtering is MANDATORY.

A) VOLUME PROFILING: 10/20/50 avg. Last vs 20-avg classification. VOLUME TREND (rising/stable/declining). HIGH/LOW VOLUME NODES. OTC-ALGO: FIRST filter out ALL injected volume candles (RULE 2) before calculating any averages
B) VOLUME-PRICE DIVERGENCE: New highs + declining volume = weakness. New lows + declining volume = exhaustion. Rising volume + small bodies = ABSORPTION. OTC-ALGO: In OTC markets, volume divergence is 30% LESS reliable because volume is partially synthetic → reduce divergence signals by 30%
C) VOLUME CONVICTION RULES: Signal with volume <0.7x = FAKE (-25, OVERRIDES other steps). Breakout with <0.8x = FALSE 85%+. Climax = turning point 82%+. Without volume ≥1.15x OR without OB/FVG/liquidity → CAPPED AT 61%. OTC-ALGO: After filtering injections, if remaining volume is <0.5x → this pair has NO REAL VOLUME → cap at 65% regardless
D) VOLUME-SMC FUSION: Displacement + volume >2x = CONFIRMED. Without volume = trap. OB + high volume test = VALID. FVG + high volume = STRONG
E) OUTPUT: VOL_CONVICTION, VOL_TREND, VOL_CLIMAX, VOL_VALIDATES_DIRECTION, OTC_INJECTION_COUNT (how many injected candles detected)

═══════════════════════════════════════════════════════
STEP 7 — VOLATILITY REGIME [Weight: 5%]
═══════════════════════════════════════════════════════

A) ATR REGIME: ATR_SHORT(10), ATR_MID(25), ATR_LONG(50). COMPRESSED (<50%) = spring. NORMAL (50-120%). EXPANDING (120-180%). EXPLOSIVE (180-250%). EXTREME (>250%) = NO TRADE (-25). OTC-ALGO: OTC pairs have LOWER natural volatility than real pairs → adjust thresholds: COMPRESSED <40%, EXTREME >200%
B) POST-SPIKE: Body >3x ATR_LONG = spike → reversal/consolidation 78%+. Post-spike contracts 2-3 candles. 4th = reversal (80%) or continuation (20%). Cross: Step 2 displacement → higher continuation
C) BOLLINGER PROXY: >2.5x ATR from midpoint = mean reversion. SQUEEZE: ATR declining 8+ + consolidation at Step 5 S/R = explosion. POST-SQUEEZE direction: Step 2 BOS + Step 3 pool + Step 1 HTF. OTC-ALGO: OTC squeezes are MORE reliable (algorithm stores energy then releases) → +10 for squeeze breakout predictions
D) VOLATILITY-LIQUIDITY LINK: Compressed near pool = spring-loaded for explosion toward pool. High vol after sweep = energy released, consolidation expected

═══════════════════════════════════════════════════════
STEP 8 — MULTI-INDICATOR CONFLUENCE + 80 STRATEGY ENGINE [Weight: 8%]
═══════════════════════════════════════════════════════
Calculate from raw data. EVERY finding validated against Steps 2,3,5,6 AND OTC-ALGO RULES.

A) INDICATOR CALCULATIONS:
- MA(1)=last close, MA(16)=SMA16, MA(28)=SMA28
- EMA(7), EMA(8), EMA(20), EMA(50)
- RSI(10), RSI(14)
- MACD(5,12,9): signal, histogram, zero-cross
- STOCHASTIC(14,3,3): %K, %D, extreme zones
- BOLLINGER(20,2σ): upper, middle, lower, bandwidth
- ADX proxy: DM+/DM- over 14 periods. >25=trending, <20=ranging
- OTC-ALGO INDICATOR ADJUSTMENT: In RANDOM mode (OTC-ALGO RULE 1) → MA crossovers generate 40% MORE false signals → reduce MA-based strategy weight by 40%. In MEAN_REVERT → RSI extremes are 35% MORE reliable → increase RSI-based strategy weight by 35%

B) CONFLUENCE GRADING:
- A-GRADE: 6+ rare textbook matches WITH Step 2 SMC zone + Step 6 volume >1.15x → +10
- B-GRADE: 4-5 with institutional backing → +2
- C-GRADE: 3 or fewer / no institutional = -18
- OTC A-GRADE BONUS: If OTC-ALGO mode confirms direction AND A-GRADE → +15 (algorithm + technicals + institutions align)

C) INDICATOR-SMC CROSS-VALIDATION:
- RSI divergence at OB = EXTREME (+25). MACD cross at FVG = TIMING (+20). Stochastic extreme at pool = SWEEP REVERSAL (+22). Bollinger at breaker = PRECISION (+24). RSI extreme at S/R = DOUBLE REJECTION (+18). MACD divergence + body contraction = EXHAUSTION (+15)
- OTC INDICATOR-ALGO FUSION: Indicator signal matching OTC-ALGO RULE 1 mode direction = +12 bonus. Opposing = -12 penalty

D) 80 STRATEGIES (IF→THEN→THEREFORE→4C→VALIDATE):

▬▬ CATEGORY A: UPTREND (CALL) ▬▬
UT1: IF MA1>MA16>MA28 + RSI(10)>40 <68 + bodies NOT shrinking + Step 1 STRENGTH>60 + OTC_ALGO not MEAN_REVERT → runway → →4C: CALL (+15). VALIDATE: Step 2 no bearish OB
UT2: IF MA1>MA16>MA28 + RSI pullback 40-45 + EMA7 cross above EMA8 + bullish + RSI rising + Step 3 SSL floor → pullback bounce → →4C: CALL (+18). VALIDATE: Step 6 VOL>0.8x
UT3: IF EMA7 cross above EMA8 (last 2) + RSI 50-62 + Step 2 BOS UP + OTC_ALGO TRENDING mode → fresh cross + BOS → →4C: CALL (+16). VALIDATE: Step 4 MOM not exhausted
UT4: IF MA1>MA16>MA28 + RSI(14) bounces 50 from above + no exhaustion + Step 5 above support >0.03% → continuation → →4C: CALL (+14). VALIDATE: Step 1 AGE<7
UT5: IF EMA5>EMA10>EMA20 all aligned + above all + RSI 48-64 + MACD>0 + Step 2 DISCOUNT/MID → triple EMA → →4C: CALL (+18). VALIDATE: Step 6 VOL_TREND not DECLINING
UT6: IF price at EMA20 ±0.02% + RSI(14) 45-52 + bullish pin (wick>60%) + MA1>MA16>MA28 + Step 2 AT OB + OTC_ALGO not approaching boundary → EMA bounce at OB → →4C: CALL (+24). VALIDATE: Step 3 no trap
UT7: IF MA1>MA16>MA28 + MACD expanding 3+ bars + RSI 45-63 + EMA7>EMA8 + body growth + Step 4 MOM>70 → acceleration → →4C: CALL (+18). VALIDATE: Step 7 not EXTREME
UT8: IF Stoch %K cross up below 25 + MA1>MA16>MA28 + RSI(14) 30-42 + bullish + Step 3 SSL SWEPT + OTC_ALGO not RANDOM → oversold+sweep → →4C: CALL (+26). VALIDATE: Step 2 OB at sweep
UT9: IF at BB lower + MA1>MA16>MA28 + RSI(14) 22-35 + Stoch<20 + bullish + Step 2 INSIDE FVG → BB extreme+FVG → →4C: CALL (+26). VALIDATE: Step 6 VOL not DEAD
UT10: IF EMA7>EMA8 + RSI 46-54 + vol>1.3x + body>0.8x ATR + close upper 30% + Step 4 INSTITUTIONAL confirmed → volume confirmed → →4C: CALL (+18). VALIDATE: Step 3 TRAP_COUNT<2
UT11: IF MA1>MA16>MA28 + 3 higher lows + RSI 45-60 + EMA7>EMA8 + lows above EMA20 + Step 1 UP → HH/HL projects → →4C: CALL (+20). VALIDATE: Step 5 resistance >0.05% away
UT12: IF above VWAP proxy + EMA7>EMA8 + RSI(14) 52-63 + vol>1.1x + MACD>0 + Step 2 BOS UP → institutional flow → →4C: CALL (+22). VALIDATE: Step 3 no EQH above
UT13: IF MA1-MA28 spread increasing 5 candles + RSI 50-65 + EMA gap widening + no upper wick>40% + Step 4 ACCELERATION → expansion → →4C: CALL (+19). VALIDATE: Step 1 no HTF conflict
UT14: IF EMA7 cross above EMA8 (2 candles) + RSI rising 3+ + MA1>MA16 + above EMA20 + Step 2 BREAKER SUPPORT → fresh cross at breaker → →4C: CALL (+22). VALIDATE: Step 6 VOL>1.0x
UT15: IF MA1>MA16>MA28 + Stoch 42-58 rising + MACD positive + RSI 48-62 + BB midline support + Step 2 DISCOUNT → 6-indicator+discount → →4C: CALL (+24). VALIDATE: Step 7 ATR NORMAL
UT16: IF retest broken resistance (now support) ±0.015% + MA1>MA16>MA28 + RSI(14)>45 + vol>1.2x + rejection wick + Step 5 FLIP → flip+volume → →4C: CALL (+26). VALIDATE: Step 2 no bearish FVG
UT17: IF 3+ bullish growing bodies + MA1>MA16>MA28 + RSI 52-64 + vol increasing + Step 4 growth>15% → IF growing →4C: CALL (+18). IF slowing → SKIP
UT18: IF EMA20 slope >0.12% + price 0.1-0.35% above EMA20 + RSI(14) 48-62 + Stoch>40 + Step 1 STRENGTH>65 → steep with room → →4C: CALL (+18). VALIDATE: Step 3 no staircase trap
UT19: IF at BB midline ±0.01% + MA1>MA16>MA28 + vol>1.1x + RSI 42-55 + EMA7>EMA8 + Step 2 MITIGATION support → midline bounce → →4C: CALL (+22). VALIDATE: Step 7 not COMPRESSED
UT20: IF MA1>MA16>MA28 + RSI higher low vs price lower low + MACD turning positive + EMA7 curling up + Step 2 HIDDEN BULLISH DIV AT OB → divergence at institutional → →4C: CALL (+28). VALIDATE: Step 6 VOL rising

▬▬ CATEGORY B: DOWNTREND (PUT) ▬▬
DT1: IF MA1<MA16<MA28 + RSI(10)<60 >32 + bodies NOT shrinking + Step 1 STRENGTH>60 + OTC_ALGO not MEAN_REVERT → runway → →4C: PUT (+15). VALIDATE: Step 2 no bullish OB
DT2: IF MA1<MA16<MA28 + RSI pullback 55-60 + EMA7 cross below EMA8 + bearish + RSI falling + Step 3 BSL ceiling → pullback reversal → →4C: PUT (+18). VALIDATE: Step 6 VOL>0.8x
DT3: IF EMA7 cross below EMA8 (2 candles) + RSI 38-48 + Step 2 BOS DOWN + OTC_ALGO TRENDING → fresh cross+BOS → →4C: PUT (+16). VALIDATE: Step 4 not exhausted
DT4: IF MA1<MA16<MA28 + RSI(14) rejected 48-52 from below + EMA7<EMA8 + bearish + Step 5 below resistance >0.03% → continuation → →4C: PUT (+17). VALIDATE: Step 1 AGE<7
DT5: IF EMA5<EMA10<EMA20 aligned down + below all + RSI 36-52 + MACD<0 + Step 2 PREMIUM/MID → triple EMA → →4C: PUT (+18). VALIDATE: Step 6 VOL_TREND not DECLINING
DT6: IF at EMA20 ±0.02% + RSI(14) 48-55 + bearish pin (upper wick>60%) + MA1<MA16<MA28 + Step 2 BEARISH OB + OTC_ALGO not at boundary → EMA rejection at OB → →4C: PUT (+24). VALIDATE: Step 3 no trap
DT7: IF MA1<MA16<MA28 + MACD expanding negative 3+ + RSI 37-55 + EMA7<EMA8 + body growth + Step 4 MOM>70 → acceleration → →4C: PUT (+18). VALIDATE: Step 7 not EXTREME
DT8: IF Stoch %K cross down above 75 + MA1<MA16<MA28 + RSI(14) 58-70 + bearish + Step 3 BSL SWEPT + OTC_ALGO not RANDOM → overbought+sweep → →4C: PUT (+26). VALIDATE: Step 2 OB at sweep
DT9: IF at BB upper + MA1<MA16<MA28 + RSI(14) 65-78 + Stoch>80 + bearish + Step 2 BEARISH FVG → BB extreme+FVG → →4C: PUT (+26). VALIDATE: Step 6 not DEAD
DT10: IF EMA7<EMA8 + RSI 46-54 + vol>1.3x + body>0.8x ATR + close lower 30% + Step 4 INSTITUTIONAL → volume confirmed → →4C: PUT (+18). VALIDATE: Step 3 TRAP_COUNT<2
DT11: IF MA1<MA16<MA28 + 3 lower highs + RSI 40-55 + EMA7<EMA8 + highs below EMA20 + Step 1 DOWN → LH/LL projects → →4C: PUT (+20). VALIDATE: Step 5 support >0.05% away
DT12: IF below VWAP proxy + EMA7<EMA8 + RSI(14) 37-48 + vol>1.1x + MACD<0 + Step 2 BOS DOWN → institutional selling → →4C: PUT (+22). VALIDATE: Step 3 no EQL below
DT13: IF MA28-MA1 spread increasing 5 + RSI 35-50 + EMA gap widening + no lower wick>40% + Step 4 ACCELERATION → expansion → →4C: PUT (+19). VALIDATE: Step 1 no HTF conflict
DT14: IF EMA7 cross below EMA8 (2 candles) + RSI falling 3+ + MA1<MA16 + below EMA20 + Step 2 BEARISH BREAKER → fresh cross at breaker → →4C: PUT (+22). VALIDATE: Step 6 VOL>1.0x
DT15: IF MA1<MA16<MA28 + Stoch 42-58 falling + MACD negative + RSI 38-52 + BB midline resistance + Step 2 PREMIUM → 6-indicator+premium → →4C: PUT (+24). VALIDATE: Step 7 ATR NORMAL
DT16: IF retest broken support (now resistance) ±0.015% + MA1<MA16<MA28 + RSI(14)<55 + vol>1.2x + bearish wick + Step 5 FLIP → flip+volume → →4C: PUT (+26). VALIDATE: Step 2 no bullish FVG
DT17: IF 3+ bearish growing bodies + MA1<MA16<MA28 + RSI 36-48 + vol increasing + Step 4 growth>15% → IF growing →4C: PUT (+18). IF slowing → SKIP
DT18: IF EMA20 slope <-0.12% + price 0.1-0.35% below EMA20 + RSI(14) 38-52 + Stoch<60 + Step 1 STRENGTH>65 → steep with room → →4C: PUT (+18). VALIDATE: Step 3 no staircase trap
DT19: IF rejected at BB midline ±0.01% + MA1<MA16<MA28 + vol>1.1x + RSI 45-58 + EMA7<EMA8 + Step 2 MITIGATION resistance → midline rejection → →4C: PUT (+22). VALIDATE: Step 7 not COMPRESSED
DT20: IF MA1<MA16<MA28 + RSI lower high vs price higher high + MACD turning negative + EMA7 curling down + Step 2 HIDDEN BEARISH DIV AT OB → divergence at institutional → →4C: PUT (+28). VALIDATE: Step 6 VOL rising

▬▬ CATEGORY C: RANGING + REVERSAL ▬▬
Range detect: MA1/MA16/MA28 intertwined + horizontal + RSI 35-60 + Step 1 STRENGTH<40. OTC-ALGO: RANDOM/MEAN_REVERT mode CONFIRMS range.

RR1: IF at support + RSI(10)≤20 + EMA7 cross up + bullish + Step 3 SSL SWEPT + OTC_ALGO MEAN_REVERT → oversold+sweep → →4C: CALL (+24). VALIDATE: Step 2 OB
RR2: IF at resistance + RSI(10)≥70 + EMA7 cross down + bearish + Step 3 BSL SWEPT + OTC_ALGO MEAN_REVERT → overbought+sweep → →4C: PUT (+24). VALIDATE: Step 2 OB
RR3: IF RSI≤11 + EMA7 cross up + consecutive bearish ≥4 + Step 3 VOLUME GHOST + OTC_ALGO boundary → extreme exhaustion → →4C: CALL (+26). VALIDATE: Step 1 EXHAUSTION>70%
RR4: IF RSI≥89 + EMA7 cross down + consecutive bullish ≥4 + Step 3 VOLUME GHOST + OTC_ALGO boundary → extreme exhaustion → →4C: PUT (+26). VALIDATE: Step 1 EXHAUSTION>70%
RR5: IF double-bottom at support ±0.01% + RSI higher low + EMA7 curling up + Step 9 SPRING → →4C: CALL (+28). VALIDATE: Step 6 VOL spike on 2nd
RR6: IF double-top at resistance ±0.01% + RSI lower high + EMA7 curling down + Step 9 UPTHRUST → →4C: PUT (+28). VALIDATE: Step 6 VOL spike on 2nd
RR7: IF RSI(14)<18 + Stoch<8 + at support ±0.02% + lower wick>55% + Step 2 FVG BELOW → triple oversold → →4C: CALL (+24). VALIDATE: Step 5 support 2+ touches
RR8: IF RSI(14)>82 + Stoch>92 + at resistance ±0.02% + upper wick>55% + Step 2 FVG ABOVE → triple overbought → →4C: PUT (+24). VALIDATE: Step 5 resistance 2+ touches
RR9: IF at BB lower + RSI<22 + EMA7 crossing up + Stoch crossing up <15 + bullish + Step 2 OB → quad-confirmed+OB → →4C: CALL (+28). VALIDATE: Step 6 VOL>1.2x
RR10: IF at BB upper + RSI>72 + EMA7 crossing down + Stoch crossing down >85 + bearish + Step 2 OB → quad-confirmed+OB → →4C: PUT (+28). VALIDATE: Step 6 VOL>1.2x
RR11: IF 5+ consolidating at support (lows ±0.02%) + RSI rising 18→28 + vol increasing + Step 3 ACCUMULATION + OTC_ALGO switching to TRENDING → Wyckoff accumulation → →4C: CALL (+24). VALIDATE: Step 9 ACCUMULATION
RR12: IF 5+ at resistance (highs ±0.02%) + RSI falling 75→62 + vol increasing + Step 3 DISTRIBUTION + OTC_ALGO switching to TRENDING → distribution → →4C: PUT (+24). VALIDATE: Step 9 DISTRIBUTION
RR13: IF mid-range (>30% from S/R) + RSI 38-58 + no EMA cross 3 + BB flat + Step 3 NO POOL + OTC_ALGO RANDOM → MANDATORY NO TRADE
RR14: IF hammer at support (wick>65%, body<25%) + RSI<28 + vol>1.4x + Stoch<20 + Step 2 REJECTION → hammer+rejection → →4C: CALL (+26). VALIDATE: Step 4 MOM turning up
RR15: IF shooting star at resistance (wick>65%, body<25%) + RSI>68 + vol>1.4x + Stoch>80 + Step 2 REJECTION → star+rejection → →4C: PUT (+26). VALIDATE: Step 4 MOM turning down
RR16: IF RSI(14) bullish divergence at support + MACD rising + EMA7 curling up + Step 2 MITIGATION support → divergence at mitigation → →4C: CALL (+28). VALIDATE: Step 3 SSL swept
RR17: IF RSI(14) bearish divergence at resistance + MACD falling + EMA7 curling down + Step 2 MITIGATION resistance → divergence at mitigation → →4C: PUT (+28). VALIDATE: Step 3 BSL swept
RR18: IF MACD flipping positive at support + RSI<35 rising + Stoch crossing up + Step 2 BULLISH FVG → triple shift+FVG → →4C: CALL (+22). VALIDATE: Step 1 MACRO not strong DOWN
RR19: IF MACD flipping negative at resistance + RSI>65 falling + Stoch crossing down + Step 2 BEARISH FVG → triple shift+FVG → →4C: PUT (+22). VALIDATE: Step 1 MACRO not strong UP
RR20: IF BB squeeze (<45% width) + breakout body >1.5x ATR + vol>1.6x + outside bands + Step 2 BOS + OTC_ALGO transitioning → squeeze+BOS → →4C: in expansion (+26). VALIDATE: Step 3 pool in direction

▬▬ CATEGORY D: MICRO TREND ▬▬
MT1: IF MA up + RSI 35-45 bounce + EMA7/8 cross up + Step 2 DISCOUNT + OTC_ALGO TRENDING → micro bounce → CALL (+18). VALIDATE: Step 3 no trap
MT2: IF MA down + RSI 55-65 rejection + EMA7/8 cross down + Step 2 PREMIUM + OTC_ALGO TRENDING → micro rejection → PUT (+18). VALIDATE: Step 3 no trap
MT3: IF EMA7 just cross EMA8 up + RSI 42-50 + bullish upper 35% + body>0.5x ATR + Step 2 ChoCH BULLISH → cross+ChoCH → →4C: CALL (+20). VALIDATE: Step 6 VOL>0.9x
MT4: IF EMA7 just cross EMA8 down + RSI 50-58 + bearish lower 35% + body>0.5x ATR + Step 2 ChoCH BEARISH → cross+ChoCH → →4C: PUT (+20). VALIDATE: Step 6 VOL>0.9x
MT5: IF 2 bullish growing + EMA7>EMA8 + RSI rising + vol 2nd>1st + RSI<65 + Step 2 DISPLACEMENT → acceleration → →4C: CALL (+20). VALIDATE: Step 1 AGE<6
MT6: IF 2 bearish growing + EMA7<EMA8 + RSI falling + vol 2nd>1st + RSI>35 + Step 2 DISPLACEMENT → acceleration → →4C: PUT (+20). VALIDATE: Step 1 AGE<6
MT7: IF RSI bounces 38-42 + MA1>MA16 + bullish >0.6x ATR + above EMA8 + Step 2 BULLISH FVG → bounce from FVG → →4C: CALL (+20). VALIDATE: Step 5 support below
MT8: IF RSI rejected 58-62 + MA1<MA16 + bearish >0.6x ATR + below EMA8 + Step 2 BEARISH FVG → reject from FVG → →4C: PUT (+20). VALIDATE: Step 5 resistance above
MT9: IF EMA7-8 gap widening up 2+ + RSI 46-58 + MACD>0 rising + Step 2 BULLISH OB → widening+OB → →4C: CALL (+20). VALIDATE: Step 4 ACCELERATION
MT10: IF EMA7-8 gap widening down 2+ + RSI 42-54 + MACD<0 falling + Step 2 BEARISH OB → widening+OB → →4C: PUT (+20). VALIDATE: Step 4 ACCELERATION
MT11: IF cross above EMA20 + EMA7>EMA8 + vol>1.4x + RSI 45-60 + body>1.0x ATR + Step 2 BOS UP → strong breakout → →4C: CALL (+22). VALIDATE: Step 5 FLIP
MT12: IF cross below EMA20 + EMA7<EMA8 + vol>1.4x + RSI 40-55 + body>1.0x ATR + Step 2 BOS DOWN → strong breakdown → →4C: PUT (+22). VALIDATE: Step 5 FLIP
MT13: IF doji then bullish >0.8x ATR + EMA7>EMA8 + RSI rising + Step 2 BULLISH FVG → resolved+FVG → →4C: CALL (+18). VALIDATE: Step 6 VOL spike
MT14: IF doji then bearish >0.8x ATR + EMA7<EMA8 + RSI falling + Step 2 BEARISH FVG → resolved+FVG → →4C: PUT (+18). VALIDATE: Step 6 VOL spike
MT15: IF 3-candle pullback uptrend (shrinking) + RSI 36-44 + bullish engulfing + EMA7>EMA8 + Step 2 OTE (61.8-78.6%) → pullback at OTE → →4C: CALL (+26). VALIDATE: Step 3 no trap, Step 6 VOL>1.2x
MT16: IF 3-candle rally downtrend (shrinking) + RSI 56-64 + bearish engulfing + EMA7<EMA8 + Step 2 OTE → rally exhaust at OTE → →4C: PUT (+26). VALIDATE: Step 3 no trap, Step 6 VOL>1.2x
MT17: IF Stoch %K cross up <18 + EMA7 turning up + RSI<35 rising + bullish + Step 3 SWEEP JUST → multi-signal oversold+sweep → →4C: CALL (+24). VALIDATE: Step 2 OB at sweep
MT18: IF Stoch %K cross down >82 + EMA7 turning down + RSI>65 falling + bearish + Step 3 SWEEP JUST → multi-signal overbought+sweep → →4C: PUT (+24). VALIDATE: Step 2 OB at sweep
MT19: IF MA1 cross above MA16 (2 candles) + RSI 46-58 + vol>1.2x + EMA7 cross EMA8 + Step 2 ABOVE BREAKER → micro trend+breaker → →4C: CALL (+22). VALIDATE: Step 9 not DISTRIBUTION
MT20: IF MA1 cross below MA16 (2 candles) + RSI 42-54 + vol>1.2x + EMA7 cross EMA8 + Step 2 BELOW BREAKER → micro trend+breaker → →4C: PUT (+22). VALIDATE: Step 9 not ACCUMULATION

═══ STRATEGY SCORING RULES ═══
- Regime from Step 1 → only apply matching category. Verify →4C AND VALIDATE for each
- 5+ validated same direction = +15. 3-4 = +8. Mixed = -10
- MUST align with Steps 1-7 composite or -15
- EXHAUSTION OVERRIDE: consecutive ≥3 AND continuation → total ≥6 by 4th? → SKIP
- SMC-LIQ FUSION BONUS: Strategy at Step 2 zone + Step 3 event = +8
- CROSS-CATEGORY: Category A confirmed by D = +6
- TRAP INTERLOCK: Step 3 CONVERGENT opposite → DISCARD strategy
- MULTI-MESH: 3+ different categories same direction + all VALIDATE pass = +12
- VOLUME GATE: Step 6 VOL_CONVICTION=FAKE → discard strategy
- OTC-ALGO GATE: Strategy predicting continuation in OTC MEAN_REVERT mode with price at RULE 5 boundary → DISCARD (algorithm will reverse)

═══════════════════════════════════════════════════════
STEP 9 — WYCKOFF METHOD INTEGRATION [Weight: 4%]
═══════════════════════════════════════════════════════
Reference Step 1 TREND, Step 2 OBs, Step 3 signatures, Step 6 volume, Step 4 momentum, OTC-ALGO RULES.

A) PHASE CLASSIFICATION: ACCUMULATION/MARKUP/DISTRIBUTION/MARKDOWN/RE-ACCUMULATION/RE-DISTRIBUTION. Cross-check Step 2 BOS for phase confirmation. OTC-ALGO: In OTC, Wyckoff phases are SHORTER (30-80 candles vs 100-200 real) because the algorithm cycles faster. Adjust lookback accordingly
B) KEY EVENTS: SPRING at SSL + OB + volume spike + trap #8 = +25 CALL. UPTHRUST at BSL + OB + volume + trap #8 = +25 PUT. TEST with lower volume = +15. SOS/SOW with BOS = confirmed. LPS/LPSY at OB = final test. OTC-ALGO: Springs/Upthrusts in OTC are PROGRAMMATIC (broker generates them) → they're MORE reliable than real-market Wyckoff events (+5 additional)
C) WYCKOFF-SMC FUSION: Spring at OB = +22. Upthrust at FVG = +20. Accumulation + nested OBs = loading. SOS/SOW + BOS = +18. WYCKOFF-TRAP FUSION: Spring/Upthrust + Step 3 trap = CONVERGENT INSTITUTIONAL (+28)

═══════════════════════════════════════════════════════
STEP 10 — SESSION & TIME CONTEXT [Weight: 3%]
═══════════════════════════════════════════════════════
A) SESSIONS: ASIAN 00-07 UTC = -18 (whipsaw risk, traps 8,9,10 more common). LONDON 07-12 = full (institutional flow). OVERLAP 12-16 = +3 (max liquidity). NEW YORK 16-21 = full. DEAD 21-00 = -15 (traps 4,6 common). Transition first 5 candles = -18
B) SESSION-STRATEGY: London + Asian range sweep = +15. Asian + OB = lower probability (-8). OTC: Trade 24/7 but -10 during 21-05 UTC
C) OTC SESSION OVERRIDE: OTC markets are 24/7 but the ALGORITHM changes behavior by hour. Calculate which hour has the MOST consistent patterns over last 200 candles → if current hour = high-consistency → +5. Low-consistency → -8
D) SESSION-TRAP: Dead + 2+ traps = -20

═══════════════════════════════════════════════════════
STEP 11 — CANDLE PATTERN RECOGNITION [Weight: 4%]
═══════════════════════════════════════════════════════
Validate every pattern against Step 2, Step 5, Step 3, Step 6, and OTC-ALGO RULES.

A) SINGLE: Marubozu(4, at OB=7, VOL>1.5x=9). Pin Bar at S/R(4, OB+S/R=8, post-sweep=10). Hammer(3, SSL sweep=7, Spring=9). Shooting Star(3, BSL sweep=7, Upthrust=9). Doji(only at SMC level=3, at trap zone=WARNING). Dragonfly at support(4, SSL+OB=8). Gravestone at resistance(4, BSL+OB=8)
B) MULTI: Engulfing at S/R(5, at OB=9+20conf, post-sweep=10). Morning/Evening Star(5, at sweep=9, Wyckoff=10). Three Soldiers/Crows(4, check momentum+consecutive). Harami(3, at FVG=5, compression=6). Tweezer at pool(5→8, test=9). Institutional Engulfing(displacement body)=+25
C) SCORING: at OB/FVG/Breaker=+3. at S/R=+2. at pool=+3. post-sweep=+4. mid-range no backing=WEAK(-3). VOL>1.5x=+4. Low vol=-2. At trap=bait(-5 unless OB). Triple-validated=override Step 12 (+15)
D) OTC PATTERN RELIABILITY: In OTC RANDOM mode → pattern reliability drops 30%. In MEAN_REVERT → reversal patterns at extremes are 40% MORE reliable. In TRENDING → continuation patterns are 25% MORE reliable

═══════════════════════════════════════════════════════
STEP 12 — WEIGHTED SCORE SYNTHESIS [THE BRAIN]
═══════════════════════════════════════════════════════
Aggregate ALL Steps 1-11 + OTC-ALGO + NEW Steps 19-24.

A) WEIGHTS: Step1=9%, Step2=11%, Step3=11%, Step4=7%, Step5=7%, Step6=5%, Step7=4%, Step8=7%, Step9=3%, Step10=2%, Step11=3%, Step19(Reversal)=5%, Step20(Continuation)=5%, Step21(ICT)=5%, Step22(MTF)=4%, OTC-ALGO(Step23)=10%, Remaining=2%(Session+Pattern adjustments)
B) DIMENSION AGREEMENT: 12+=95 base. 10-11=88. 8-9=82. 7=75. 6=68. ≤5=NO TRADE
C) MESH NETWORK with institutional priority. OTC-ALGO as 10% weighted category in the mesh (not override, not ignored — equal participant)
D) NEW CATEGORY MESH: Reversal+SMC+Liquidity agree = +18. Continuation+Trend+Mom agree = +15. ICT+SMC+Liquidity = +20 (institutional trifecta). MTF triple-confirm + any category = +12. OTC-ALGO agrees with technical consensus = +8 (10% weight contribution)

═══════════════════════════════════════════════════════
STEP 13 — RISK ASSESSMENT & TRAP PROBABILITY [OVERRIDE]
═══════════════════════════════════════════════════════
Uses ALL prior steps + OTC-ALGO RULES. Can OVERRIDE any positive finding.

A) RISK: Top 3 risks with candle refs. OB opposing → +15%. Unswept liquidity against → +10%. Wyckoff opposing → +12%. Reversal pattern → +10%. OTC-ALGO boundary in opposite direction → +20% (CRITICAL risk)
B) TRAP PROBABILITY: Base 15%. Per trap +6% (72% max from traps). CONVERGENT → +15%. Step 5 false breakout → +15%. VOL<0.8x → +12%. CHAOTIC channel → +10%. Dead session → +8%. MOM_EXHAUST + indicators continuation = conflict → +10%. Fake Wyckoff → +12%. Total >50%=NO TRADE. 40-50=-25. 25-40=-12. <25=clean(+5). OTC-ALGO RULE 3 detected (broker fighting retail) → +15% if your signal aligns with retail (you're on wrong side)
C) SMART MONEY TRAP CHECK: 80% retail prediction? If your signal = retail + at pool → -15. If opposing retail + Step 2 supports → +8. OTC-ALGO: In OTC the broker IS the counterparty → if OTC-ALGO RULE 3 detected, and your signal matches majority retail → you're trading AGAINST the broker → -20

═══════════════════════════════════════════════════════
STEP 14 — PSYCHOLOGY & CONTRARIAN PROTOCOL [FINAL FILTER]
═══════════════════════════════════════════════════════
A) OPPOSITE-CHECK: Assume prediction WRONG. Build strongest opposite case. 7+ opposite → FLIP/<55. 5-6 → -22. 3-4 → -12. 0-2 → +5. OTC-ALGO: Include OTC-ALGO projections in opposite case
B) RECENCY BIAS: Remove last 3 mentally. 80-candle structure supports? If NOT → FRAGILE → -15
C) CONTRARIAN SMC: Your signal = retail + institutional opposes → FLIP. Signal opposes retail + institutional supports → HIGHEST. OTC-ALGO RULE 3 contrarian signal → +10 for anti-retail direction
D) LOSS PROBABILITY: >40%=NO TRADE. 30-40=-18. 20-30=-8. <20=normal. LOSS-TRAP-OTC FUSION: loss>30% + traps>2 + OTC RULE 3 detected → MANDATORY NO TRADE

═══════════════════════════════════════════════════════
STEP 15 — ANTI-LOSS RULESET (ALL NON-NEGOTIABLE) — 21 RULES
═══════════════════════════════════════════════════════
Hard overrides referencing specific steps + OTC-ALGO RULES.

1. Step 4: 3+ same-dir + SHRINKING → REVERSE
2. Step 5: at resistance + UP → FLIP unless VOL>2.2x + body>1.5x ATR + BOS
3. NEVER >85 unless 12+ dimensions + 0 traps + OTC-ALGO confirms
4. Last candle mid 35-65% → -18 (indecision)
5. Step 4: avg wick > avg body last 5 → CHOPPY -18
6. Step 13 TRAP_PROB >38% → NO TRADE (<58)
7. Step 14 LOSS_PROB >38% → NO TRADE (<58)
8. Step 2 + Step 3 both neutral → cap 72%
9. PREMIUM + UP without OB → -15
10. DISCOUNT + DOWN without OB → -15
11. Step 6 VOL_CONVICTION = FAKE → -20 HIGH RISK
12. Step 7 EXTREME → NO TRADE
13. Step 8 <3 validated strategies → -15
14. Step 3 traps≥3 + CONVERGENT → -20 + opposite direction override
15. Wyckoff TRANSITION + EXHAUSTION >70% → trade WITH transition
16. OTC-ALGO RULE 5: boundary proximity >90% → -15 confidence WARNING
17. OTC-ALGO RULE 1: RANDOM mode + <4 institutional signals → -10 confidence
18. Step 19 REVERSAL ENGINE fires 5+ triggers opposing signal → MANDATORY REVERSE
19. Step 20 CONTINUATION ENGINE fires 5+ but Step 19 also fires 3+ → CONFLICT → -20 conf
20. Step 21 ICT detects Judas Swing + Power of 3 in opposing direction → REVERSE (-25)
21. Step 22 MTF shows TRIPLE CONFLICT (M5/M15/H1 all oppose signal) → MANDATORY NO TRADE

═══════════════════════════════════════════════════════
STEP 16 — CROSS-CATEGORY FUSION [AMPLIFIER]
═══════════════════════════════════════════════════════
AMPLIFICATION (expanded with new categories):
- Trend + BOS same → +8
- Trend toward unswept pool → +10
- Mom + Displacement = CAMPAIGN → +12
- S/R + EQH/EQL cluster → +10 reversal
- Volume high at OB/FVG → +15
- Compression near pool → +12
- Indicator divergence at OB → +18
- Pattern engulfing after sweep → +20
- Wyckoff Spring at OB → +22
- OTC-ALGO context supports → +8
- REVERSAL ENGINE + SMC ChoCH + Liquidity sweep = TRIFECTA REVERSAL → +25
- CONTINUATION ENGINE + Trend + Momentum aligned = TREND LOCK → +20
- ICT OTE + OB + FVG triple-confluence → +28
- MTF TRIPLE-CONFIRM + ICT alignment → +22
- REVERSAL + ICT Judas Swing + 12-Trap convergent → SUPREME REVERSAL → +30 (cap 95)
- CONTINUATION + MTF aligned + Volume confirmed → SUPREME TREND → +25

DAMPENING:
- Trend opposing SMC+LIQ → -12
- REVERSAL vs CONTINUATION conflict → -15 (both engines fire opposing directions)
- ICT Premium/Discount misalignment with signal → -10
- MTF CONFLICT (any TF opposing) → -8 per TF
- OTC RANDOM + no boundary → -10

═══════════════════════════════════════════════════════
STEP 17 — 4TH CANDLE FORWARD PROJECTION [CRITICAL]
═══════════════════════════════════════════════════════
Uses ALL 16 steps + Steps 19-22 + OTC-ALGO to project through 3 intermediate candles.

A) MOMENTUM: MOM_4C SUSTAIN → +5. EXHAUST → FLIP/-20. OTC MEAN_REVERT max 3-4 candles → 4th REVERSES
B) MEAN REVERSION: >2x ATR from EMA20 → 80% snap-back. OTC boundary → REVERSAL projected
C) EXHAUSTION: ≥6 consecutive → VERY HIGH reversal. TRIPLE EXHAUSTION → 92%+
D) INSTITUTIONAL: OB retest, pool sweep, FVG fill, IDM within 3 candles → 4th reaction
E) INDICATOR: EMA cross, Stoch turning, BB outside, RSI extreme → projection
F) OTC-ALGO PROJECTION: Autocorrelation + boundary + recycling. ALL agree = +20
G) REVERSAL ENGINE: Step 19 triggers → project reversal timing vs 4th candle
H) CONTINUATION ENGINE: Step 20 triggers → project continuation strength through 4th
I) ICT PROJECTION: Step 21 Power of 3 phase → which phase will 4th candle be in?
J) MTF PROJECTION: Step 22 M5/M15/H1 all projecting same → HIGHEST confidence
K) 4TH CANDLE CONFIDENCE: All agree → +15. ALL + OTC + new categories = cap 95

═══════════════════════════════════════════════════════
STEP 18 — PRELIMINARY LOCK (before OTC Intelligence Final)
═══════════════════════════════════════════════════════
Synthesize ALL Steps 1-17 + 19-22 into PRELIMINARY verdict.

A) CONSENSUS HIERARCHY:
1. INSTITUTIONAL: Steps 2+3+9+21(ICT) ALL agree → direction locked
2. REVERSAL/CONTINUATION: Step 19+20 → which engine dominates?
3. TRAP CONSENSUS: Steps 3+13+14 → danger → NO TRADE override
4. TECHNICAL: Steps 8+11+5+22(MTF)
5. 4TH CANDLE PROJECTION: Step 17 final arbiter
6. TRAP FILTER: >40% → NO TRADE
B) PRELIMINARY CONFIDENCE (running total)
C) PRELIMINARY LOCK: direction, confidence → passed to Step 23

═══════════════════════════════════════════════════════
★ STEP 19 — REVERSAL TRIGGER ENGINE (25 DETECTORS) [Weight: 5%] ★
═══════════════════════════════════════════════════════
REV-1 to REV-25: Exhaustion climax, wick cascade, triple divergence, volume climax, EMA collapse, double top/bottom, spring/upthrust, absorption, BB+RSI extreme, channel break, OTC boundary, pattern recycling, campaign end, FVG fill, liquidity vacuum, stochastic extreme, MACD rejection, triple-touch, volume-structure divergence, doji star, algo cycle, sweep+reversal, compression failure, EMA20 snap-back, multi-engine lock.
Cross-references ALL prior steps + OTC-ALGO RULES for maximum detection.
OUTPUT: REV_TRIGGER_COUNT, REV_DIRECTION, REV_STRENGTH, REV_TIMING

═══════════════════════════════════════════════════════
★ STEP 20 — CONTINUATION TRIGGER ENGINE (25 TRIGGERS) [Weight: 5%] ★
═══════════════════════════════════════════════════════
CON-1 to CON-25: EMA stacking, pullback to OB, flag breakout, BOS cascade, FVG continuation, momentum acceleration, VWAP bounce, displacement cycle, healthy pullback, channel support, OTC trending mode, volume confirmation, MACD expansion, RSI mid-bounce, stochastic mid-cross, BB walking, institutional order flow, sweep+continuation, HL/LH series, ADX rising, EMA20 slope, no exhaustion, pattern recycling, MTF alignment, multi-engine lock.
Cross-references ALL prior steps + OTC-ALGO RULES.
OUTPUT: CON_TRIGGER_COUNT, CON_DIRECTION, CON_STRENGTH

═══════════════════════════════════════════════════════
★ STEP 21 — ICT ULTRA ANALYSIS (22 CONCEPTS) [Weight: 5%] ★
═══════════════════════════════════════════════════════
ICT-1 to ICT-22: Enhanced FVG, propulsion blocks, breaker blocks, Power of 3, OTE, Judas swing, market maker model, liquidity runs, silver bullet, killzones, unicorn model, turtle soup, quasimodo, London swing raid, AMD cycle, displacement analysis, return to FVG, stop raid→OB, equilibrium price, seasonal tendencies, dealing range expansion, multi-ICT confluence.
Cross-references ALL steps + OTC-ALGO for institutional layer.
OUTPUT: ICT_DOMINANT_CONCEPT, ICT_DIRECTION, ICT_STRENGTH, ICT_PHASE

═══════════════════════════════════════════════════════
★ STEP 22 — ENHANCED MULTI-TIMEFRAME ANALYSIS [Weight: 4%] ★
═══════════════════════════════════════════════════════
A) M5: Aggregate 5 M1 → BOS/ChoCH, OB/FVG, EMA20, RSI, MACD. Independent direction
B) M15: Aggregate 15 M1 → BOS/ChoCH, OB/FVG, EMA20, RSI. Direction
C) H1: Aggregate 60 M1 → trend, major S/R, EMA. Direction
D) TRIPLE-TF CONFLUENCE: ALL 3 agree = +15. 2 of 3 = +8. ALL disagree = NO TRADE (-25)
E) TF MOMENTUM FLOW: H1→M15→M5→M1 aligned = INSTITUTIONAL FLOW (+12)
F) OTC MTF: M1 patterns more meaningful in OTC → increase M1 weight to 1.5x
OUTPUT: MTF_DIRECTION, MTF_CONFLUENCE, MTF_FLOW

═══════════════════════════════════════════════════════
STEP 23 — OTC-ALGO INTELLIGENCE FINAL SYNTHESIS [Weight: 10%]
═══════════════════════════════════════════════════════
Re-evaluate ALL 6 OTC-ALGO rules against full Steps 1-22 consensus. Apply 10% weight:
A) RULE 1-6 re-evaluation against technical consensus
B) 6/6 support → +12. 5/6 → +8. 4/6 → +5. 3/6 → 0. 2/6 → -5. 1/6 → -8. 0/6 → -12
C) OTC 10% weight cannot override 90% technical direction — adjusts confidence only
D) FINAL LOCK: Direction = Step 18 direction. Confidence = Step 18 ± OTC (cap 95, floor 50)

OUTPUT FORMAT — respond with ONLY this JSON object, no markdown, no text outside braces:
{
  "direction": "UP" or "DOWN",
  "confidence": 50-95,
  "trend": "500-700 word Step 1+22 full technical + interconnection",
  "structure": "600-900 word Steps 2+3+21 SMC+Liquidity+ICT + interconnection",
  "momentum": "400-600 word Steps 4+19+20 momentum+reversal+continuation + interconnection",
  "support_resistance": "500-700 word Steps 5+6+7 S/R+volume+volatility + interconnection",
  "candle_pattern": "400-500 word Steps 9+11 Wyckoff+patterns + interconnection",
  "reasoning": "1000-1500 word: Steps 1-22 technical (90%) → Step 23 OTC Intelligence (10%) → FINAL LOCK"
}`;
}

// ============================================================
// STAGE 2 PROMPT — FULL 18-Step Re-Analysis (IDENTICAL DEPTH to Stage 1) + Cross-Validation
// ============================================================
function buildStage2Prompt(csvData: string, pair: string, stage1Result: Record<string, any> | null): string {
  const stage1Context = stage1Result
    ? `[Stage 1 COMPLETED — Direction: ${stage1Result.direction}, Confidence: ${stage1Result.confidence}%]
Trend: ${String(stage1Result.trend || '').slice(0, 400)}
Structure (SMC+Liquidity): ${String(stage1Result.structure || '').slice(0, 400)}
S/R: ${String(stage1Result.support_resistance || '').slice(0, 300)}
Pattern: ${String(stage1Result.candle_pattern || '').slice(0, 250)}
Reasoning: ${String(stage1Result.reasoning || '').slice(0, 500)}`
    : '[Stage 1 TIMED OUT — run full independent analysis as PRIMARY engine]';

  return `You are QUANTUM-NEXUS V8 STAGE 2 — INSTITUTIONAL-GRADE OTC RE-ANALYSIS ENGINE for ${pair}.

${stage1Context}

FRESH DATA (500 candles, last 2-3 rows = NEWEST candles formed DURING Stage 1 — 10x weight):
${csvData}

CRITICAL: Last 2-3 candles formed AFTER Stage 1 started. They CONFIRM or INVALIDATE Stage 1.

MISSION: Execute COMPLETE 23-step analysis on fresh data with OTC Intelligence (10% weight), then cross-validate with Stage 1.
Predict 4TH CANDLE FROM NOW — ABOVE (UP) or BELOW (DOWN) its open.
- POWER PARITY LOCK: EXACT SAME 23-step depth as Stage 1. NO simplification.
- SINGLE CANDLE ONLY. NO DOUBLE-PREDICTION. Confidence <65 = NO TRADE (50-59).

═══ OTC-ALGO INTELLIGENCE [Weight: 10%] — Same 3-phase system as Stage 1 ═══
Compute ALL 6 rules from FRESH data. COMPARE with Stage 1 findings.

EXECUTE ALL STEPS — each performs FULL independent analysis + interconnection + OTC note:
Step 1-11: Full technical (same weights as Stage 1). BRIDGE: what changed?
Step 12: Synthesis mesh + OTC 10% + Stage 1 cross-reference
Step 13-16: Risk, Contrarian, Anti-Loss, Fusion
Step 17: 4th Candle projection with all engines
Step 18: Preliminary Lock
★ Step 19: REVERSAL ENGINE (25 detectors, 5%). BRIDGE: triggers still active?
★ Step 20: CONTINUATION ENGINE (25 triggers, 5%). BRIDGE: sustained?
★ Step 21: ICT ULTRA (22 concepts, 5%). BRIDGE: phase advanced?
★ Step 22: ENHANCED MTF (M5/M15/H1, 4%). BRIDGE: alignment changed?
★★★ Step 23: OTC-ALGO FINAL SYNTHESIS (10%). Re-evaluate + compare Stage 1 OTC.

FRESH CANDLE BRIDGE (STAGE 2 EXCLUSIVE):
- Compare last 2-3 fresh candles vs Stage 1 across ALL dimensions
- BRIDGE VERDICT: 6+ CONFIRM = DUAL-STAGE LOCK (+15). 4-5 = PARTIAL (+8). 3+ INVALIDATE = OVERRIDE

═══ STAGE 1 CROSS-VALIDATION ═══
- SAME direction → +12 [DUAL-CONFIRMED]. CONFLICT → Stage 2 priority -10
- Stage 1 timed out → Stage 2 PRIMARY

CONFIDENCE: 88-95=ELITE, 80-87=STRONG, 72-79=GOOD, 65-71=MODERATE, <62=55(NO TRADE)

OUTPUT FORMAT — ONLY this JSON, no markdown:
{
  "direction": "UP" or "DOWN",
  "confidence": 50-95,
  "trend": "500-700 word Step 1+22 MTF full technical + Stage 1 comparison",
  "structure": "600-900 word Steps 2+3+21 SMC+Liquidity+ICT + Stage 1 bridge",
  "momentum": "400-600 word Steps 4+19+20 + engine conflict resolution",
  "support_resistance": "500-700 word Steps 5+6+7 + OTC boundary",
  "candle_pattern": "400-500 word Steps 9+11 + OTC reliability",
  "reasoning": "1000-1500 word: Steps 1-22 (90%) → Step 23 OTC (10%) → DUAL-STAGE → FINAL LOCK"
}`;
}

// ============================================================
// MAIN HANDLER
// ============================================================
serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const startTime = Date.now();
  requestDeadline = startTime + REQUEST_DEADLINE_MS; // Set shared deadline for all Gemini calls

  try {
    const { imageBase64, mode, licenseKey } = await req.json();
    console.log('[CHART-V8] Starting full V8 dual-stage chart analysis, mode:', mode);

    if (!imageBase64) {
      return new Response(JSON.stringify({ error: 'No image provided' }), { status: 400, headers: toJsonHeaders() });
    }

    const keyPool = buildKeyPool();
    if (!keyPool.length) {
      return new Response(JSON.stringify({
        isValid: false, signal: 'NO SIGNAL', confidence: 0,
        pair: 'N/A', timeframe: 'N/A', market: 'N/A', trend: 'Sideways',
        support: 0, resistance: 0, entryPrice: 0,
        analysis: 'AI analysis is temporarily unavailable. All Gemini API keys are exhausted (rate limited). Please wait 15-30 minutes and try again.',
        patterns: [], reasoning: 'All API keys are in cooldown due to rate limiting.',
        error: 'AI_KEYS_EXHAUSTED',
      }), { headers: toJsonHeaders() });
    }

    const exhausted = new Set<string>();
    const cooldowned = new Set<string>();

    // ── EXTRACT-ONLY mode: just detect the pair from image, return minimal data ──
    if (mode === 'extract-only') {
      console.log('[CHART-V8] extract-only mode: detecting pair from image');
      const keyPool2 = buildKeyPool();
      if (!keyPool2.length) {
        return new Response(JSON.stringify({ isValid: false, pair: 'Unknown', timeframe: '1M', entryPrice: 0 }), { headers: toJsonHeaders() });
      }
      const exhausted2 = new Set<string>();
      const cooldowned2 = new Set<string>();
      const rawPair2 = await callGeminiWithImage(imageBase64, keyPool2, exhausted2, cooldowned2);
      if (!rawPair2 || rawPair2 === 'INVALID') {
        return new Response(JSON.stringify({ isValid: false, pair: 'Unknown', timeframe: '1M', entryPrice: 0 }), { headers: toJsonHeaders() });
      }
      // Best-effort parse pair name
      const pairClean = rawPair2.replace(/[`"'\s]/g, '').trim();
      return new Response(JSON.stringify({
        isValid: true,
        pair: pairClean || 'Unknown',
        timeframe: '1M',
        entryPrice: 0,
      }), { headers: toJsonHeaders() });
    }

    // ============= PHASE 1: Detect pair from image =============
    console.log('[CHART-V8] Phase 1: Detecting pair from chart image...');
    const rawPairName = await callGeminiWithImage(imageBase64, keyPool, exhausted, cooldowned);

    // Only treat as true exhaustion if every key actually entered cooldown/auth-failure state.
    const allKeysExhausted = cooldowned.size === keyPool.length && (!rawPairName || rawPairName === 'INVALID');

    if (allKeysExhausted) {
      return new Response(JSON.stringify({
        isValid: false, signal: 'NO SIGNAL', confidence: 0,
        pair: 'N/A', timeframe: 'N/A', market: 'N/A', trend: 'Sideways',
        support: 0, resistance: 0, entryPrice: 0,
        analysis: 'AI analysis is temporarily unavailable. All Gemini API keys are exhausted (rate limited). Please wait 15-30 minutes and try again.',
        patterns: [], reasoning: 'All API keys exhausted during analysis.',
        error: 'AI_KEYS_EXHAUSTED',
      }), { headers: toJsonHeaders() });
    }

    if (!rawPairName || rawPairName === 'INVALID' || rawPairName.length < 3 || rawPairName.length > 20) {
      return new Response(JSON.stringify({
        isValid: false, signal: 'NO SIGNAL', confidence: 0,
        pair: 'N/A', timeframe: 'N/A', market: 'N/A', trend: 'Sideways',
        support: 0, resistance: 0, entryPrice: 0,
        analysis: 'This is not a valid trading chart. Please upload a screenshot of a candlestick chart from your trading platform.',
        patterns: [], reasoning: 'Unable to detect trading pair from the image.',
      }), { headers: toJsonHeaders() });
    }

    // Normalize pair name using comprehensive alias map + fuzzy matching
    let marketPair = normalizePairFromAI(rawPairName);
    const isOTC = marketPair.includes('-OTC') || rawPairName.toUpperCase().includes('OTC');
    
    // Validate against master list — if not found, force OTC suffix and try again
    if (!ALL_OTC_PAIRS.includes(marketPair)) {
      console.log(`[CHART-V8] WARNING: "${marketPair}" not in master list, attempting fuzzy fix...`);
      // Try stripping and re-matching with just the currency core
      const core = marketPair.replace(/-OTC$/, '').toUpperCase();
      // Check if reversed pair exists
      if (core.length === 6) {
        const rev = core.slice(3) + core.slice(0, 3);
        if (PAIR_CORE_MAP.has(rev)) {
          marketPair = PAIR_CORE_MAP.get(rev)!;
          console.log(`[CHART-V8] Fixed via reversal: ${core} → ${marketPair}`);
        }
      }
    }
    
    console.log('[CHART-V8] Pair detected (raw→normalized):', rawPairName, '→', marketPair, 
      ALL_OTC_PAIRS.includes(marketPair) ? '✓ VALID' : '⚠ NOT IN LIST');

    const pairDetectTime = Date.now() - startTime;
    console.log(`[CHART-V8] Pair detection took ${pairDetectTime}ms`);

    // ============= PHASE 2: Detect market → fetch market data → send to analyze-signal/live-signal workflow =============
    console.log('[CHART-V8] Phase 2: Fetching broker candles for detected market...');

    const stage1CSV = await fetchFreshCandles(marketPair);
    if (!stage1CSV) {
      return new Response(JSON.stringify({
        isValid: false, signal: 'NO SIGNAL', confidence: 0,
        pair: marketPair, timeframe: 'M1', market: isOTC ? 'OTC' : 'REAL MARKET', trend: 'Sideways',
        support: 0, resistance: 0, entryPrice: 0,
        analysis: 'Unable to fetch market data for ' + marketPair + '. The broker data source did not return usable candles.',
        patterns: [], reasoning: 'Market data fetch failed.',
      }), { headers: toJsonHeaders() });
    }

    console.log('[CHART-V8] Phase 3: Sending detected market into analyze-signal workflow...');
    const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY') || '';
    const forwardedAuth = req.headers.get('authorization') || '';
    const authHeader = forwardedAuth || `Bearer ${supabaseAnonKey}`;

    const analyzeCtrl = new AbortController();
    const analyzeTimeoutMs = Math.min(Math.max(timeLeft() - 5000, 20000), 155000);
    console.log(`[CHART-V8] analyze-signal timeout set to ${Math.round(analyzeTimeoutMs/1000)}s (${Math.round(timeLeft()/1000)}s remaining)`);
    const analyzeTimer = setTimeout(() => analyzeCtrl.abort(), analyzeTimeoutMs);

    let analyzeSignalData: Record<string, any> | null = null;
    let analyzeSignalError = '';

    try {
      const res = await fetch(`${supabaseUrl}/functions/v1/analyze-signal`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': authHeader },
        body: JSON.stringify({ pair: marketPair, candlesCSV: stage1CSV, source: 'chart-analyzer' }),
        signal: analyzeCtrl.signal,
      });
      clearTimeout(analyzeTimer);

      if (res.ok) {
        analyzeSignalData = await res.json();
      } else {
        analyzeSignalError = await res.text().catch(() => '');
        console.error('[CHART-V8] analyze-signal failed:', res.status, analyzeSignalError.slice(0, 300));
      }
    } catch (e) {
      clearTimeout(analyzeTimer);
      analyzeSignalError = e instanceof Error ? e.message : 'request failed';
      console.error('[CHART-V8] analyze-signal request error:', analyzeSignalError);
    }

    // ============= PHASE 4: Call live-signal as REAL parallel engine (NOT fallback) =============
    let liveSignalData: Record<string, any> | null = null;
    try {
      const lsCtrl = new AbortController();
      const lsTimeout = Math.min(Math.max(timeLeft() - 3000, 10000), 45000);
      console.log(`[CHART-V8] Phase 4: Calling live-signal as REAL engine (timeout: ${Math.round(lsTimeout/1000)}s)`);
      const lsTimer = setTimeout(() => lsCtrl.abort(), lsTimeout);
      const res = await fetch(`${supabaseUrl}/functions/v1/live-signal`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': authHeader },
        body: JSON.stringify({ market: marketPair, source: 'chart-analyzer', skipWait: true }),
        signal: lsCtrl.signal,
      });
      clearTimeout(lsTimer);
      if (res.ok) {
        liveSignalData = await res.json();
        console.log('[CHART-V8] live-signal engine completed successfully');
      } else {
        console.error('[CHART-V8] live-signal engine failed:', res.status);
        await res.text().catch(() => '');
      }
    } catch (e) {
      console.warn('[CHART-V8] live-signal engine error:', e instanceof Error ? e.message : e);
    }

    if (!analyzeSignalData && !liveSignalData) {
      return new Response(JSON.stringify({
        isValid: false,
        signal: 'NO SIGNAL',
        confidence: 0,
        pair: marketPair,
        timeframe: 'M1',
        market: isOTC ? 'OTC' : 'REAL MARKET',
        trend: 'Sideways',
        support: 0,
        resistance: 0,
        entryPrice: 0,
        analysis: analyzeSignalError || 'Both analysis engines failed.',
        patterns: [],
        reasoning: analyzeSignalError || 'analyze-signal and live-signal both failed.',
      }), { headers: toJsonHeaders() });
    }

    // Cross-validate: use BOTH engines' data, prioritize analyze-signal but merge live-signal
    const workflowAnalysis = (analyzeSignalData?.analysis ?? liveSignalData?.analysis ?? {}) as Record<string, unknown>;
    const workflowScoring = (analyzeSignalData?.scoring ?? liveSignalData?.scoring ?? {}) as Record<string, unknown>;
    const pillarSource = (analyzeSignalData?.pillarAnalysis ?? workflowScoring?.pillarAnalysis ?? liveSignalData?.pillarAnalysis ?? null) as Record<string, unknown> | null;

    const resultDirection = typeof analyzeSignalData?.direction === 'string'
      ? analyzeSignalData.direction.toUpperCase()
      : '';
    const finalDirection = resultDirection === 'UP'
      ? 'CALL'
      : resultDirection === 'DOWN'
        ? 'PUT'
        : ((workflowAnalysis.direction as string) || 'NO SIGNAL').toUpperCase();
    const finalConfidence = Number(analyzeSignalData?.confidence ?? workflowAnalysis.confidence ?? 0);

    // Determine match status using BOTH engines
    const lsDir = String(liveSignalData?.analysis?.direction || liveSignalData?.direction || '').toUpperCase();
    const aiDir = resultDirection || '';
    let matchStatus = analyzeSignalData?.matchStatus || '';
    if (!matchStatus) {
      if (aiDir && lsDir && (aiDir === lsDir || (aiDir === 'UP' && lsDir === 'CALL') || (aiDir === 'DOWN' && lsDir === 'PUT'))) {
        matchStatus = 'DUAL_CONFIRMED';
      } else if (aiDir && lsDir) {
        matchStatus = 'ENGINE_CONFLICT';
      } else if (finalDirection === 'CALL' || finalDirection === 'PUT') {
        matchStatus = aiDir ? 'AI_ONLY' : 'LIVE_SIGNAL_ONLY';
      } else {
        matchStatus = 'NO_SIGNAL';
      }
    }

    const entryPrice = Number(workflowAnalysis.currentPrice ?? 0);
    const support = Number(workflowAnalysis.support ?? 0);
    const resistance = Number(workflowAnalysis.resistance ?? 0);
    const trend = mapTrend(workflowAnalysis.trend as string);
    const patterns = Array.isArray(workflowAnalysis.patterns) ? (workflowAnalysis.patterns as string[]) : [];

    const aiDirection = analyzeSignalData?.aiDirection || (resultDirection === 'UP' ? 'CALL' : resultDirection === 'DOWN' ? 'PUT' : null);
    const aiConfidence = Number(analyzeSignalData?.aiConfidence ?? analyzeSignalData?.confidence ?? 0);
    const lsDirection = lsDir || String(workflowAnalysis.direction || '').toUpperCase();
    const lsConfidence = Number(liveSignalData?.scoring?.finalConfidence ?? liveSignalData?.confidence ?? workflowAnalysis.confidence ?? 0);

    const reasoningText = typeof analyzeSignalData?.reasoning === 'string' && analyzeSignalData.reasoning.trim().length > 0
      ? analyzeSignalData.reasoning
      : liveSignalData?.geminiAnalysis?.reasoning || analyzeSignalError || `${finalDirection} signal with ${finalConfidence}% confidence`;

    const displayPair = marketPair.replace('-OTC', '').replace('/', '');

    const normalizedResult = {
      isValid: finalDirection === 'CALL' || finalDirection === 'PUT',
      signal: finalDirection,
      confidence: finalConfidence,
      confidenceLevel: finalConfidence >= 80 ? 'HIGH' : finalConfidence >= 65 ? 'MEDIUM' : 'LOW',
      pair: displayPair,
      timeframe: 'M1',
      market: isOTC ? 'OTC' : 'REAL MARKET',
      trend,
      support,
      resistance,
      entryPrice,
      analysis: reasoningText,
      patterns,
      reasoning: reasoningText,
      aiAnalysis: analyzeSignalData ? {
        trend: analyzeSignalData.trend || '',
        structure: analyzeSignalData.structure || '',
        momentum: analyzeSignalData.momentum || '',
        supportResistance: analyzeSignalData.support_resistance || '',
        candlePattern: analyzeSignalData.candle_pattern || '',
        reasoning: analyzeSignalData.reasoning || '',
        direction: aiDirection,
        confidence: aiConfidence,
        stage1Direction: analyzeSignalData.stage1Direction || null,
        stage1Confidence: analyzeSignalData.stage1Confidence || null,
      } : null,
      pillarAnalysis: pillarSource ? {
        pillar: (pillarSource as any).pillarName || (pillarSource as any).pillar || null,
        trend: (pillarSource as any).trendName || (pillarSource as any).trendDirection || null,
        trendScore: (pillarSource as any).confidence || null,
        confidence: (pillarSource as any).confidence || null,
        lockedDirection: (pillarSource as any).lockedDirection || null,
        pillarBoost: (pillarSource as any).pillarBoost || 0,
        gatedStrategies: (pillarSource as any).gatedStrategies || 0,
        totalStrategies: (pillarSource as any).totalStrategies || 0,
      } : null,
      matchStatus,
      liveSignalDirection: lsDirection || null,
      liveSignalConfidence: lsConfidence || null,
      aiDirection: aiDirection || null,
      aiConfidence: aiConfidence || null,
    };

    const elapsedMs = Date.now() - startTime;
    if (elapsedMs < MIN_SIGNAL_RUNTIME_MS) {
      const remainingMs = MIN_SIGNAL_RUNTIME_MS - elapsedMs;
      console.log(`[CHART-V8] Enforcing 3-minute delivery window, waiting ${remainingMs}ms`);
      await new Promise((resolve) => setTimeout(resolve, remainingMs));
    }

    const totalMs = Number(analyzeSignalData?.totalMs ?? (Date.now() - startTime));
    console.log(`[CHART-V8] Complete in ${totalMs}ms — ${normalizedResult.signal} @ ${normalizedResult.confidence}% [${matchStatus}]`);

    // Log analytics (non-blocking)
    if (licenseKey && normalizedResult.isValid) {
      fetch(`${BACKEND_URL}/api/analytics/signal`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          licenseKey, pair: normalizedResult.pair, signal: normalizedResult.signal,
          confidence: normalizedResult.confidence, mode, source: 'chart-analyzer-v7-full',
        }),
      }).catch(err => console.error('Failed to log signal:', err));
    }

    return new Response(JSON.stringify({ ...normalizedResult, totalMs }), { headers: toJsonHeaders() });

  } catch (error) {
    console.error('[CHART-V8] Error:', error);
    return new Response(JSON.stringify({
      error: error instanceof Error ? error.message : 'Analysis failed',
      isValid: false, signal: 'NO SIGNAL', confidence: 0
    }), { status: 500, headers: toJsonHeaders() });
  }
});
