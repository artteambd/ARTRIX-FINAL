import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { OTC_API_BASE, extractApiTime, extractApiVolume, parseQuotexCandles } from "../_shared/quotex.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// ============================================================
// QUANTUM-TRADER V7 — 2-Stage Gemini AI Analysis Engine
// ============================================================

// KEY COOLDOWN SYSTEM — exhausted keys sit in cooldown for 12 HOURS, then auto-rejoin.
// They are NOT scanned every request. Only live keys are tried.
const KEY_COOLDOWN_MS = 12 * 60 * 60 * 1000; // 12 hours — keys rest properly before rejoining
const KEY_REQUEST_COOLDOWN_MS = 5 * 60 * 1000; // 5 min cooldown for transient rate-limits (429)
const TARGET_SIGNAL_WINDOW_MS = 180000; // 3-minute analysis-to-delivery window (enforced by client)
const MIN_PER_KEY_TIMEOUT_MS = 2000;
const REQUEST_DEADLINE_MS = 175000; // 175s total budget
// FIX: No key-batch size limit — try ALL available keys in parallel.
// Previously limited to 6 (FRESH_KEY_BATCH_SIZE), causing 19 keys to be permanently
// ignored each stage → fake exhaustion. Now: all non-cooldown non-exhausted keys race.
const MAX_GEMINI_KEYS_TO_TRY = 25; // try all 25 keys; Promise.any uses the fastest winner
// THINKING BUDGETS calibrated to fit both stages within the 3-minute window:
// Stage 1 gets 100s, Stage 2 gets remaining ~65-70s. Flash thinking is ~2000 tok/s.
// Stage 1: 10000 thinking (~5s) + ~8000 output (~20s) + overhead = ~30-40s ✓
// Stage 2: 5000 thinking (~2.5s) + ~8000 output (~20s) + overhead = ~25-30s ✓
const STAGE1_THINKING_BUDGET = 10000;
const STAGE1_MAX_TOKENS = 8192;
const STAGE2_THINKING_BUDGET = 5000;
const STAGE2_MAX_TOKENS = 8192;
const keyCooldownMap = new Map<string, number>(); // key → timestamp when cooldown expires
const keyLastAttemptMap = new Map<string, number>(); // key → last attempt timestamp
const keyLastSuccessMap = new Map<string, number>(); // key → last success timestamp

// Per-request deadline — Edge Function warm instances serve multiple concurrent requests.
// A shared module-level variable would be overwritten by concurrent requests, causing one
// request to read another request's deadline (premature aborts / stale timeouts).
// FIX: No module-level mutable deadline. Each request creates its own localDeadline and
// passes it into callGemini directly — zero cross-request pollution.
function makeTimeLeft(deadline: number) { return () => Math.max(0, deadline - Date.now()); }

const GEMINI_KEY_NAMES = [
  'GEMINI_API_KEY',
  'GEMINI_API_KEY_2',
  'GEMINI_API_KEY_3',
  'GEMINI_API_KEY_4',
  'GEMINI_API_KEY_5',
  'GEMINI_API_KEY_6',
  'GEMINI_API_KEY_7',
  'GEMINI_API_KEY_8',
  'GEMINI_API_KEY_9',
  'GEMINI_API_KEY_10',
  'GEMINI_API_KEY_11',
  'GEMINI_API_KEY_12',
  'GEMINI_API_KEY_13',
  'GEMINI_API_KEY_14',
  'GEMINI_API_KEY_15',
  'GEMINI_API_KEY_16',
  'GEMINI_API_KEY_17',
  'GEMINI_API_KEY_18',
  'GEMINI_API_KEY_19',
  'GEMINI_API_KEY_20',
  'GEMINI_API_KEY_21',
  'GEMINI_API_KEY_22',
  'GEMINI_API_KEY_23',
  'GEMINI_API_KEY_24',
  'GEMINI_API_KEY_25',
];

function sanitizeGeminiKey(raw: string | null | undefined): string {
  return String(raw ?? '')
    .replace(/[\s\u200B-\u200D\uFEFF\u200E\u200F\u202A-\u202E]/g, '')
    .trim();
}

function getAllKeys(): string[] {
  const keys = GEMINI_KEY_NAMES
    .map((name) => sanitizeGeminiKey(Deno.env.get(name)))
    .filter((key) => key.startsWith('AIza') && key.length >= 20);

  return Array.from(new Set(keys));
}

function maskKey(key: string): string {
  return `…${key.slice(-6)}`;
}

function markKeyAttempt(key: string) {
  keyLastAttemptMap.set(key, Date.now());
}

function markKeySuccess(key: string) {
  const now = Date.now();
  keyLastAttemptMap.set(key, now);
  keyLastSuccessMap.set(key, now);
}

function selectFreshKeys(pool: string[], exhausted: Set<string>): string[] {
  // FIX: Use ALL available keys, not just 6. Previously .slice(0, 6) left 19 keys
  // permanently untried each stage — any quota hit on those 6 caused fake exhaustion.
  // Now: all non-cooldown non-exhausted keys are selected, sorted so keys that haven't
  // been tried recently go first (best chance of immediate success), but NO limit on count.
  // Promise.any races all of them and uses the first success — others are aborted cleanly.
  const selected = pool
    .filter((key) => key && !exhausted.has(key) && !keyCooldownMap.has(key))
    .sort((a, b) => {
      // Primary: least recently attempted first (most rested keys lead)
      const aAttempt = keyLastAttemptMap.get(a) ?? 0;
      const bAttempt = keyLastAttemptMap.get(b) ?? 0;
      if (aAttempt !== bAttempt) return aAttempt - bAttempt;
      // Secondary: most recently successful first (proven working keys are preferred)
      const aSuccess = keyLastSuccessMap.get(a) ?? 0;
      const bSuccess = keyLastSuccessMap.get(b) ?? 0;
      return bSuccess - aSuccess;
    });

  console.log(`[KEY-POOL] Racing ${selected.length}/${pool.length} available keys: ${selected.slice(0,6).map(maskKey).join(', ')}${selected.length > 6 ? ` +${selected.length-6} more` : ''}`);
  return selected;
}

// Build pool: only LIVE keys (not in cooldown). Expired cooldowns are auto-cleared.
function buildKeyPool(): string[] {
  const now = Date.now();
  // Clear expired cooldowns
  for (const [k, expiresAt] of keyCooldownMap) {
    if (now >= expiresAt) {
      keyCooldownMap.delete(k);
      console.log(`[KEY-POOL] Key …${k.slice(-6)} cooldown expired, back in live pool`);
    }
  }
  return getAllKeys().filter(k => !keyCooldownMap.has(k));
}

// Move a key to cooldown.
// COOLDOWN POLICY (Fixed — previous policy was too aggressive):
//   - Auth errors (401/403/invalid key): 12h — key is genuinely broken
//   - Quota 429 (rate limit): 30 min — key hit a rate limit, but NOT broken
//     Previously this was 12h, causing fake exhaustion all day from one bad request.
//   - Transient (503): No longer called — transient errors skip without cooldown (Fix 4)
const KEY_QUOTA_COOLDOWN_MS = 30 * 60 * 1000; // 30 min for 429 rate limits
function cooldownKey(key: string, reason: string) {
  const isAuth = reason.startsWith('auth');
  // quota 429 → 30min cooldown. auth errors → 12h cooldown.
  const cooldownMs = isAuth ? KEY_COOLDOWN_MS : KEY_QUOTA_COOLDOWN_MS;
  const cooldownLabel = isAuth ? '12h' : '30min';
  keyCooldownMap.set(key, Date.now() + cooldownMs);
  const inCooldown = keyCooldownMap.size;
  const total = getAllKeys().length;
  console.log(`[KEY-POOL] Key ${maskKey(key)} → cooldown ${cooldownLabel} (${reason}). ${total - inCooldown}/${total} live`);
}

async function classifyGeminiError(res: Response): Promise<{
  shouldCooldown: boolean;
  shouldSkipForRequest: boolean;
  reason: string;
  details: string;
}> {
  const details = await res.text().catch(() => '');
  const normalized = details.toLowerCase();

  const isQuotaError =
    res.status === 429 ||
    res.status === 402 ||
    normalized.includes('resource_exhausted') ||
    normalized.includes('rate limit') ||
    normalized.includes('quota');

  const isTransientModelError =
    res.status === 503 ||
    normalized.includes('high demand') ||
    normalized.includes('temporarily unavailable') ||
    normalized.includes('"status":"unavailable"') ||
    normalized.includes('"status": "unavailable"');

  const isInvalidApiKeyError =
    (res.status === 400 || res.status === 403) && (
      normalized.includes('api key not valid') ||
      normalized.includes('api_key_invalid') ||
      normalized.includes('invalid api key')
    );

  const isKeyAuthError =
    res.status === 401 ||
    isInvalidApiKeyError ||
    (res.status === 403 && (
      normalized.includes('permission denied') ||
      normalized.includes('permission_denied') ||
      normalized.includes('denied access') ||
      normalized.includes('forbidden')
    ));

  if (isQuotaError) {
    return {
      shouldCooldown: true,
      shouldSkipForRequest: true,
      reason: `quota ${res.status}`,
      details,
    };
  }

  if (isTransientModelError) {
    // FIX: 503 / "temporarily unavailable" is a GEMINI SERVICE error, not a key error.
    // Previously: shouldCooldown=true put the key in 5-min cooldown.
    // This caused: if ALL keys got 503s in one request → entire pool in 5-min cooldown
    // → next request sees empty pool → PILLAR_ONLY (fake exhaustion).
    // Fix: skip for current request only, do NOT cooldown the key itself.
    return {
      shouldCooldown: false,
      shouldSkipForRequest: true,
      reason: `transient ${res.status}`,
      details,
    };
  }

  if (isKeyAuthError) {
    return {
      shouldCooldown: true,
      shouldSkipForRequest: true,
      reason: `auth ${res.status}`,
      details,
    };
  }

  return {
    shouldCooldown: false,
    shouldSkipForRequest: true,
    reason: `request ${res.status}`,
    details,
  };
}

// Fetch 500 candles from OTC API → CSV format using API volume only
async function fetchFreshCandles(pair: string, attempt = 1): Promise<string | null> {
  try {
    const apiPair = pair.replace('-OTC', '_otc').replace('/', '');
    const url = `${OTC_API_BASE}?pair=${apiPair}&timeframe=M1&count=500`;
    console.log(`[QUANTUM-V8] Fetching candles from: ${url} (attempt ${attempt})`);
    const res = await fetch(url, { signal: AbortSignal.timeout(12000) });
    if (!res.ok) {
      console.error('[QUANTUM-V8] Candle fetch failed:', res.status);
      if (attempt < 3) { await new Promise(r => setTimeout(r, 2000 * attempt)); return fetchFreshCandles(pair, attempt + 1); }
      return null;
    }
    const rawText = await res.text();
    const candles = parseQuotexCandles(rawText);
    if (!candles.length) return null;

    const orderedCandles = candles.slice().sort(
      (a: any, b: any) => new Date(extractApiTime(a)).getTime() - new Date(extractApiTime(b)).getTime(),
    );

    const nonZeroVolumeCount = orderedCandles.filter((c: any) => extractApiVolume(c) > 0).length;
    console.log(`[QUANTUM-V8] API volume candles: ${nonZeroVolumeCount}/${orderedCandles.length} non-zero (strict API volume, never epoch/time)`);

    const rows = orderedCandles.map((c: any, i: number) => {
      const o = parseFloat(c.open || c.o || 0);
      const h = parseFloat(c.high || c.h || 0);
      const l = parseFloat(c.low || c.l || 0);
      const cl = parseFloat(c.close || c.c || 0);
      const v = extractApiVolume(c);
      return `${i + 1},${o},${h},${l},${cl},${v}`;
    });

    console.log(`[QUANTUM-V8] Parsed ${rows.length} candles with API volume only`);
    return `#,O,H,L,C,V\n${rows.join('\n')}`;
  } catch (e) {
    console.error('[QUANTUM-V8] fetchFreshCandles error:', e);
    if (attempt < 3) { await new Promise(r => setTimeout(r, 2000 * attempt)); return fetchFreshCandles(pair, attempt + 1); }
    return null;
  }
}

// ============================================================
// JSON EXTRACTION — 4-layer robust parser
// ============================================================
function extractBalancedJson(text: string): string | null {
  const start = text.indexOf('{');
  if (start === -1) return null;
  let depth = 0;
  for (let i = start; i < text.length; i++) {
    if (text[i] === '{') depth++;
    else if (text[i] === '}') {
      depth--;
      if (depth === 0) return text.slice(start, i + 1);
    }
  }
  return null;
}

function extractJsonField(text: string, field: string): string {
  const patterns = [
    new RegExp(`"${field}"\\s*:\\s*"([^"]*)"`, 'i'),
    new RegExp(`"${field}"\\s*:\\s*(\\d+)`, 'i'),
  ];
  for (const p of patterns) {
    const m = text.match(p);
    if (m) return m[1];
  }
  return '';
}

function parseGeminiJson(raw: string): Record<string, any> | null {
  // Layer 1: balanced brace scan
  const extracted = extractBalancedJson(raw);
  if (extracted) {
    // Layer 2: standard parse
    try { return JSON.parse(extracted); } catch { /* continue */ }
    // Layer 3: auto-fix
    try {
      const fixed = extracted
        .replace(/,\s*([}\]])/g, '$1')
        .replace(/[\x00-\x1F\x7F]/g, ' ');
      return JSON.parse(fixed);
    } catch { /* continue */ }
  }
  // Layer 4: field-by-field regex
  const direction = extractJsonField(raw, 'direction');
  const confidence = extractJsonField(raw, 'confidence');
  if (direction) {
    const normalizedDir = direction.toUpperCase();
    // FIX: Normalize CALL/PUT/BUY/SELL → UP/DOWN at extraction time
    const finalDir =
      normalizedDir === 'UP' || normalizedDir === 'CALL' || normalizedDir === 'BUY' ? 'UP' :
      normalizedDir === 'DOWN' || normalizedDir === 'PUT' || normalizedDir === 'SELL' ? 'DOWN' :
      normalizedDir;
    return {
      direction: finalDir,
      confidence: parseInt(confidence) || 60,
      trend: extractJsonField(raw, 'trend'),
      structure: extractJsonField(raw, 'structure'),
      momentum: extractJsonField(raw, 'momentum'),
      support_resistance: extractJsonField(raw, 'support_resistance'),
      candle_pattern: extractJsonField(raw, 'candle_pattern'),
      reasoning: extractJsonField(raw, 'reasoning'),
    };
  }
  // FIX: Keyword count was scanning entire raw text (including reasoning paragraphs).
  // Now: scan only the first 500 chars (likely the JSON opening with the direction field).
  const scanZone = raw.slice(0, 500);
  const upCount = (scanZone.match(/\bUP\b/g) || []).length;
  const downCount = (scanZone.match(/\bDOWN\b/g) || []).length;
  return {
    direction: upCount >= downCount ? 'UP' : 'DOWN',
    confidence: 55,
    reasoning: '[FALLBACK KEYWORD COUNT — LOW CONFIDENCE]',
  };
}

// Extract Gemini text response — skip thinking parts
function extractGeminiText(data: any): string {
  const parts = data?.candidates?.[0]?.content?.parts || [];
  const textParts = parts.filter((p: any) => p.text && !p.thought);
  if (textParts.length > 0) return textParts.map((p: any) => p.text).join('');
  return parts.map((p: any) => p.text || '').join('');
}

// No Lovable AI Gateway — using all 25 Gemini keys only

// ============================================================
// STAGE 1 PROMPT — 18-Step Elite Institutional Analysis
// ============================================================
function buildStage1Prompt(csvData: string, pair: string): string {
  return `You are QUANTUM-NEXUS V8 — the world's most advanced institutional-grade OTC binary options AI. Analyze the 1-minute OTC chart data for ${pair}.

INPUT DATA (500 candles, newest = last row):
${csvData}

MISSION: Predict what the 4TH CANDLE FROM NOW closes as — ABOVE (UP) or BELOW (DOWN) its opening price.
- CRITICAL: You are NOT predicting the next candle. You are predicting the candle that opens ~3 minutes from NOW.
- Between now and entry, 3 candles will form. Analyze what those 3 intermediate candles are LIKELY to do, then predict the 4th.
- FORWARD-PROJECT: IF momentum is fading → the 4th candle may reverse. IF momentum is building → the 4th candle continues.
- SINGLE CANDLE ONLY — predict the 4th candle's close direction
- NO DOUBLE-PREDICTION: "UP then DOWN" = invalid
- Confidence below 65 = NO TRADE (output 50-59 confidence)
- Loss prevention is PRIME — ambiguity → reduce confidence

WHY 4TH CANDLE LOGIC:
- The signal is delivered at ~3 minutes. The user enters the trade at the 4th candle's open.
- You must project through 3 intermediate candles to determine where the 4th candle closes.
- Key question: Does the current setup SUSTAIN or EXHAUST by the time 3 more candles form?
═══ OTC-ALGO INTELLIGENCE [Weight: 10%] — FOUNDATION + THROUGHOUT + FINAL ═══
OTC markets are ALGORITHMICALLY GENERATED — prices come from broker algorithms, NOT real interbank feeds.
OTC Intelligence carries 10% weight in the final score synthesis (Step 12).
It operates in THREE phases:
  PHASE 1 (START): Compute all 6 rules from raw data → provides context for Steps 1-22
  PHASE 2 (THROUGHOUT): Each step references OTC findings to validate/adjust its analysis
  PHASE 3 (FINAL — Step 23): Re-evaluate all 6 rules against full technical consensus → apply 10% weight adjustment

CRITICAL BALANCE: OTC Intelligence is an IMPORTANT analytical category (10% weight) — same as any major step.
It provides REAL intelligence about algorithmic behavior. But it does NOT override the other 90% of analysis.
Each step performs its FULL independent technical analysis FIRST, then checks OTC context for validation.

Compute the 6 OTC-ALGO rules FIRST:

OTC-ALGO RULE 1 — SYNTHETIC PRICE ENGINE DETECTION:
- Calculate autocorrelation of returns over 20/50/100/200 periods
- HIGH autocorrelation (>0.3) = TRENDING mode. Near-zero = RANDOM mode. NEGATIVE = MEAN-REVERSION mode
- Output: OTC_MODE, OTC_CYCLE_LENGTH, OTC_CYCLE_POSITION

OTC-ALGO RULE 2 — LIQUIDITY INJECTION DETECTION:
- Volume spike (>2.5x avg) with body <0.5x ATR = INJECTED VOLUME (fake)
- Build injection map. Output: INJECTION_COUNT, MANIPULATION_INTENSITY

OTC-ALGO RULE 3 — PAYOUT-DRIVEN MANIPULATION:
- 5+ same-dir candles with growing opposing wicks = broker fighting retail
- Output: BROKER_BIAS, PAYOUT_TRAP_ACTIVE

OTC-ALGO RULE 4 — SPREAD MANIPULATION:
- Spread proxy: avg(high-low) last 10 vs last 100. Output: SPREAD_STATUS

OTC-ALGO RULE 5 — ALGORITHMIC BOUNDARY DETECTION:
- Session open + max deviation over 200 candles. Boundary proximity for reversal probability
- Output: BOUNDARY_PROXIMITY (0-100%), BOUNDARY_DIRECTION

OTC-ALGO RULE 6 — PATTERN RECYCLING:
- Cross-correlate last 20 candles at offsets. Output: RECYCLING_ACTIVE, RECYCLING_PREDICTION

These 6 rules provide the OTC INTELLIGENCE CONTEXT (10% weight) that each step references alongside its primary technical analysis.

INTERCONNECTION PROTOCOL — Every step MUST:
1. Perform its FULL independent technical analysis FIRST — this is the PRIMARY finding (full depth, no shortcuts)
2. Cross-reference ALL prior steps for confluence or conflict (INTERCONNECTION — confirms/conflicts/amplifies)
3. Note OTC context relevance (OTC NOTE — how OTC intelligence adjusts weight/confidence of THIS step's finding)
- Conflicting inter-step findings → -8 confidence per conflict
- 3+ steps confirming same thesis → +5 per additional step beyond 3
- MESH NETWORK: Evidence flows BIDIRECTIONALLY — later steps can STRENGTHEN or WEAKEN earlier findings
- Every step output: TECHNICAL FINDING | INTERCONNECTION | OTC NOTE
- CRITICAL: Each step's TECHNICAL FINDING must be complete and thorough on its own. OTC NOTE is supplementary.

EXECUTE ALL STEPS IN ORDER (OTC context computed → Steps 1-22 full technical analysis → Step 23 OTC final synthesis):

═══════════════════════════════════════════════════════
STEP 1 — MULTI-TIMEFRAME TREND ARCHITECTURE [Weight: 10%]
═══════════════════════════════════════════════════════
Build the complete trend hierarchy — this is the FOUNDATION that ALL subsequent steps reference.

A) FRACTAL TIMEFRAME DECOMPOSITION:
- MACRO TREND (candles 1-200): Count HH+HL sequences (bullish) vs LH+LL sequences (bearish). Rate: STRONG (8+) / MODERATE (5-7) / WEAK (3-4) / EXHAUSTED (<3 or mixed)
- MID TREND (candles 200-400): Direction + EMA-20 slope angle + trend age in candles + pullback count (more pullbacks = healthier trend)
- MICRO TREND (last 20 candles): Direction, consecutive same-direction count, body size progression (expanding/stable/contracting), wick character (clean=strong, messy=weak)
- ULTRA-MICRO (last 5 candles): 8x weight — FRESHEST reality. Exact body sizes, wick ratios, close positions within range
- NANO-MICRO (last 3 candles): 12x weight — IMMEDIATE price action. Each candle: body size vs ATR, close position ((close-low)/(high-low)), wick dominance, volume relative to 20-avg

B) SYNTHETIC HIGHER TIMEFRAME CONSTRUCTION:
- M5 PROXY: Aggregate every 5 M1 candles. Build M5 trend, swing structure, EMA positions
- M15 PROXY: Aggregate every 15 M1 candles. M15 BOS/ChoCH events, FVG detection, OB mapping
- H1 PROXY: Aggregate last 60 M1 candles. H1 trend direction, last H1 swing high/low, H1 EMA20 position
- H4 PROXY: Aggregate last 240 M1 candles. H4 trend, H4 OB zones, H4 FVG gaps
- D1 PROXY: All 500 candles = ~8 hours. Overall session bias
- TRIPLE-TF CONFLUENCE: Only when M5+M15+H1 ALL agree on direction = TRIPLE CONFIRMED (+15). Any single TF opposing = CONFLICT (-8 per opposing TF)
- RULE: Only trade AGAINST HTF if micro-setup is textbook-perfect with volume confirmation AND institutional SMC alignment (from Step 2)

C) TREND QUALITY ASSESSMENT:
- INSTITUTIONAL TREND GRADE: Driven by displacement candles (body >2x ATR with volume >1.5x avg) = REAL. Slow drift (small bodies, no volume) = WEAK/FAKE
- TREND MATURITY DECAY: 3-4 consecutive same-dir = FRESH. 5-6 = MATURE. 7-8 = OVEREXTENDED (70%+ reversal). 9+ = CRITICAL EXHAUSTION (85%+ reversal). Formula: base 50% + (consecutive - 4) × 8%
- TREND EXHAUSTION SIGNATURE: Diminishing impulse + expanding correction = trend DYING → Step 17 must project reversal
- EMA ALIGNMENT HEALTH: Price >0.4% above EMA20 = snap-back imminent. >0.6% = DANGEROUS. EMA7/8/20/50 stacked = STRONG. Any crossing = TRANSITION
- CHANNEL INTEGRITY: Linear regression R² of last 20 closes. R² > 0.85 = clean. 0.6-0.85 = moderate. < 0.6 = CHAOTIC → -15 conf
- OTC-ALGO TREND VALIDATION: Cross-reference OTC-ALGO RULE 1 autocorrelation. If algorithm is in RANDOM mode but chart shows "trend" → FAKE TREND (OTC noise) → -20 conf for trend-following setups
- OTC BOUNDARY CHECK: Cross-reference OTC-ALGO RULE 5. If trend is approaching max deviation boundary → trend is ABOUT TO REVERSE regardless of technical signals → +20 reversal conf

D) TREND-TO-STEP BRIDGE (feeds ALL subsequent steps):
- OUTPUT: TREND_DIRECTION (UP/DOWN/RANGING), TREND_STRENGTH (0-100), TREND_AGE (candles), EXHAUSTION_PROBABILITY (0-100%), HTF_ALIGNMENT (ALIGNED/CONFLICTING/NEUTRAL), OTC_ALGO_MODE (TRENDING/RANDOM/MEAN_REVERT), OTC_BOUNDARY_PROXIMITY (0-100%), MTF_CONFLUENCE (TRIPLE/DOUBLE/SINGLE/CONFLICT)

═══════════════════════════════════════════════════════
STEP 2 — SMART MONEY CONCEPTS (SMC) MASTER ANALYSIS [Weight: 12%]
═══════════════════════════════════════════════════════
Institutional ENGINE. MUST reference Step 1 TREND_DIRECTION and OTC-ALGO RULES.

A) MARKET STRUCTURE MAPPING:
- BOS: Last 3 confirmed BOS events. Each: candle number, direction, body-close (VALID) or wick-only (INVALID)?
- ChoCH: Counter-structural candle in last 15? ChoCH + Step 1 EXHAUSTION >60% = HIGH reversal
- Internal vs External Structure: Internal BOS = minor shift. External BOS = major change. External BOS against MACRO TREND = PARADIGM SHIFT
- STRUCTURE GRADE: CLEAR (consistent HH/HL or LH/LL) / MIXED / CHAOTIC. CHAOTIC = -18 conf, consider NO TRADE
- STRUCTURE-TREND FUSION: BOS matches Step 1? Match = +8. Conflict = -12
- OTC STRUCTURE REALITY: Cross-reference OTC-ALGO RULE 1. If algorithm is in RANDOM mode → BOS events are NOISE, not institutional signals → reduce BOS weight by 50%. If TRENDING mode → BOS is algorithm-driven (reliable)

B) ORDER BLOCK (OB) PRECISION ENGINE:
- Bullish OB = last bearish candle before bullish displacement (body >2x ATR). Mark exact levels
- Bearish OB = last bullish candle before bearish displacement. Mark levels
- OB FRESHNESS: 1st touch = 100%. 2nd = 40%. 3rd = DEAD (0%)
- OB MEAN THRESHOLD: Price closes beyond 50% of OB body = FAILED FLIP
- NESTED OB: OB inside larger HTF OB = EXTREME confluence (+20)
- OB-VOLUME VALIDATION: OB with volume >1.5x = INSTITUTIONAL. Without = retail-driven (-40% weight)
- OB DISTANCE DECAY: >80 candles old AND >1% away = STALE (-60% weight)
- DEMAND/SUPPLY ZONE: 2+ OBs within 0.03% = INSTITUTIONAL ZONE
- OTC OB RELIABILITY: Cross-reference OTC-ALGO RULE 2. If INJECTION CLUSTERING detected → OBs formed during injections are UNRELIABLE → discard those OBs. Only trust OBs formed with CLEAN volume

C) FAIR VALUE GAP (FVG) ARCHITECTURE:
- Bullish FVG: candle[n-1].high < candle[n+1].low. Bearish FVG: candle[n-1].low > candle[n+1].high
- FVG CONSEQUENT ENCROACHMENT (CE): 50% level = magnet
- iFVG: Broken FVG FLIPS polarity
- BPR (Balanced Price Range): Overlapping FVGs = VELOCITY zone. Escape direction = STRONG signal
- FVG SIZE FILTER: <2 pips = ignore. 2-10 = VALID. >10 = news-driven (-8)
- FVG AGE: >100 candles unfilled = STRONG magnets. <10 candles = IMMEDIATE targets
- OTC FVG FILTER: In OTC RANDOM mode (OTC-ALGO RULE 1) → FVGs fill probability drops from 85% to 55% → reduce FVG weight by 35%

D) DISPLACEMENT & INSTITUTIONAL FOOTPRINT:
- Body > 2.5x avg body = institutional displacement. Mark in last 50 candles
- 3+ consecutive = INSTITUTIONAL CAMPAIGN — do NOT trade against
- Displacement + 3+ small consolidation = ORDER FILLING → continuation
- OTC DISPLACEMENT FILTER: Cross-reference OTC-ALGO RULE 2. If displacement candle has INJECTED VOLUME → NOT institutional. It's broker manipulation → IGNORE as evidence

E) PREMIUM vs DISCOUNT ZONES:
- Swing high/low range from last 100. Above 50% = PREMIUM. Below = DISCOUNT
- OTE: 61.8%-78.6% Fibonacci = highest probability
- CALL in PREMIUM without OB/FVG = dangerous → -15. PUT in DISCOUNT without OB/FVG = dangerous → -15

F) BREAKER BLOCKS: Failed OB broken = BREAKER (polarity flip). Return = HIGH probability (+18)
G) MITIGATION BLOCKS: Extreme OB beyond IDM = target. Unmitigated = magnets
H) REJECTION BLOCKS: Long wick at key level closing away. Wick >60% = rejection. With volume >2x = INSTITUTIONAL
I) SMC COMPOSITE OUTPUT for Steps 3,8,12,16: SMC_DIRECTION, SMC_STRENGTH (0-100), SMC_ZONES, OTC_OB_RELIABILITY (HIGH/MEDIUM/LOW)

═══════════════════════════════════════════════════════
STEP 3 — LIQUIDITY ENGINEERING & OTC TRAP DETECTION [Weight: 12%]
═══════════════════════════════════════════════════════
MUST cross-reference Step 1 TREND, Step 2 SMC_ZONES, and ALL OTC-ALGO RULES.

A) LIQUIDITY POOL MAPPING:
- BSL: All swing highs. 2+ within 0.015% = pool
- SSL: All swing lows. 2+ within 0.015% = pool
- EQH/EQL: 2+ within 0.01% = INDUCEMENT
- LIQUIDITY VOID: Gap with no trading = future fill target
- POOL PROXIMITY: Exact distance to nearest BSL/SSL. Closer = more likely target
- POOL AGE: >50 candles untouched = STRONGER magnets
- MULTI-POOL STACKING: 2+ pools same side within 0.03% = MASSIVE target
- OTC POOL REALITY: In OTC markets, liquidity pools are VISIBLE to the broker's algorithm. The algorithm INTENTIONALLY sweeps pools to trigger stops. Pool sweep probability is HIGHER in OTC than real markets (+10% base sweep probability)

B) SWEEP MECHANICS:
- STANDARD SWEEP: Price beyond pool, closes back = REVERSAL (+15). Wick >60%
- STOP HUNT: Quick wick + immediate reversal = institutional. Within 1-2 candles
- DOUBLE SWEEP: Both sides within 8 candles = confusion CLEARED → strong move after 2nd sweep
- FAILED SWEEP: Didn't close back = REAL breakout
- SWEEP EXHAUSTION: 3+ sweeps same pool = DRAINED
- SWEEP-OB FUSION: Sweep reaching Step 2 OB = INSTITUTIONAL RELOAD (+22)
- OTC ALGORITHMIC SWEEP: Cross-reference OTC-ALGO RULE 3. If broker detected fighting retail → sweep is PROGRAMMATIC (100% intentional) → post-sweep reversal probability increases to 88%+

C) OTC-SPECIFIC 12-TRAP MATRIX:
Each trap cross-references Steps 1,2,4,5,6 AND OTC-ALGO RULES for 100% detection.
1. VOLUME GHOST: Body >1.5x ATR + volume <0.5x avg = FAKE (78% reversal). Cross: OTC-ALGO RULE 2 injection? If confirmed → GUARANTEED fake (+20 reversal)
2. WICK ASSASSIN: 3+ wicks touching identical level (±0.005%) = algo accumulation. OTC-ALGO: if MEAN_REVERT mode → wicks are BOUNDARY → reversal 85%+
3. GAP BAIT: Opening gap fills within 3 candles = retail trap. OTC-ALGO RULE 6: if gap matches recycled pattern → fill probability 90%+
4. STAIRCASE TRAP: 5+ small bodies (<0.3x ATR) same-dir + declining volume = algo building reversal. OTC-ALGO RULE 5: if approaching boundary → 95%+ reversal
5. MIRROR TRAP: Pattern mirrors structure 50-100 candles ago (>85% correlation). OTC-ALGO RULE 6: if BOTH confirm → resolution prediction 90%+ accurate
6. TIME BOMB: Consolidation at S/R 8+ candles + declining ATR = explosion imminent. OTC-ALGO: if switching RANDOM→TRENDING → explosion direction = new trend
7. ROUND NUMBER VACUUM: Within 3 pips of .000/.500/.250/.750 = magnet. OTC-ALGO RULE 5: near boundary = DOUBLE REVERSAL MAGNET
8. WHIPSAW TRAP: Price crosses key level then reverses within 2 candles. OTC-ALGO RULE 3: if broker fighting retail → INTENTIONAL (+18 reversal conf)
9. FAKE BREAKOUT CASCADE: 2+ false breakouts within 10 candles. OTC-ALGO RULE 1: if RANDOM mode → ALL breakouts fake → -20, mean reversion
10. LIQUIDITY VOID TRAP: Rapid move through low-volume zone then reversal. OTC-ALGO: 35% more common in OTC
11. EXHAUSTION SPIKE TRAP: Largest candle in 50+ lookback as last = CLIMACTIC. OTC-ALGO RULE 5: if spike hits boundary → 96%+ reversal
12. SHADOW DIVERGENCE TRAP: Price new highs but RSI(10) equal/lower. OTC-ALGO: in TRENDING mode → signals algorithm SWITCHING modes

D) TRAP INTERCONNECTION PROTOCOL:
- 0-2 = CLEAN. 3-4 = CAUTION (-12). 5+ = TRAP ZONE (-25, consider NO TRADE)
- CONVERGENT traps (same direction) = 95%+ probability. CONFLICTING = CHAOTIC → NO TRADE
- OTC TRAP AMPLIFIER: traps in OTC are MORE reliable because they're ALGORITHMICALLY GENERATED → +8 when OTC-ALGO confirms

E) INDUCEMENT + ACCUMULATION/DISTRIBUTION signatures
F) LIQUIDITY-SMC FUSION ENGINE: FVG near pool = DOUBLE MAGNET (+22). BOS + sweep = CONFIRMED (+25)
G) OUTPUT: LIQ_DIRECTION, LIQ_SWEEP_ACTIVE, LIQ_TRAP_COUNT, LIQ_TRAP_CONVERGENCE, OTC_ALGO_TRAP_BOOST

═══════════════════════════════════════════════════════
STEP 4 — MOMENTUM DYNAMICS [Weight: 8%]
═══════════════════════════════════════════════════════
MUST reference Step 1 TREND_STRENGTH, Step 2 DISPLACEMENT, and OTC-ALGO RULES.

A) BODY PROGRESSION: Last 10 body sizes. EXPANDING/STABLE/CONTRACTING. DECELERATION >25%/candle = DEAD MOMENTUM. OTC-ALGO: In MEAN_REVERT mode, acceleration max 3-4 candles → 4th candle REVERSES
B) CONSECUTIVE CANDLE REVERSAL: 3=58%, 4=68%, 5=78%, 6=85%, 7=90%, 8+=94%. OTC-ALGO RULE 5 boundary → +15% reversal (overrides caveats)
C) CANDLE QUALITY: Wick vs body ratio. Wicks > bodies = CHOPPY (-15). CLIMACTIC candle = 82%+ reversal. OTC-ALGO: climactic = ALGORITHM'S reversal trigger → +10%
D) INSTITUTIONAL MOMENTUM: Volume-weighted body. Big body + big volume = REAL. Big body + low volume = RETAIL TRAP. ABSORPTION: High volume + small body = reversal 2-3 candles. OTC-ALGO RULE 2: filter INJECTED VOLUME
E) OUTPUT: MOM_DIRECTION, MOM_STRENGTH, MOM_EXHAUSTION, MOM_4C_PROJECTION, OTC_ALGO_MOM_OVERRIDE

═══════════════════════════════════════════════════════
STEP 5 — SUPPORT & RESISTANCE ARCHITECTURE [Weight: 8%]
═══════════════════════════════════════════════════════
Cross-reference Step 2 OB/FVG and Step 3 pools. OTC-ALGO RULES 5,7.

A) DYNAMIC S/R: Top 5 each. Strength = touches × (1/sqrt(recency)) × (1 + wick_rejections × 0.3). At OB = 2x. At pool = 2x. At BOTH = 4x. OTC-ALGO RULE 5: near boundary = UNBREAKABLE (+30%)
B) PSYCHOLOGICAL LEVELS: .000/.500/.250/.750. OTC algorithms RESPECT round numbers 40% MORE than real markets
C) S/R BEHAVIOR: COMPRESSION 4+ = explosion. POLARITY FLIP = HIGH confidence. OTC-ALGO: RANDOM → rejections 25% less reliable. MEAN_REVERT → 30% MORE reliable
D) OUTPUT: NEAREST_SUPPORT, NEAREST_RESISTANCE, PRICE_POSITION, OTC_BOUNDARY_LEVEL

═══════════════════════════════════════════════════════
STEP 6 — VOLUME INTELLIGENCE [Weight: 6%]
═══════════════════════════════════════════════════════
OTC-ALGO RULE 2 filtering is MANDATORY.

A) VOLUME PROFILING: FIRST filter ALL injected volume (RULE 2). Then calculate 10/20/50 avg. Classification: HIGH/NORMAL/LOW/DEAD
B) VOLUME-PRICE DIVERGENCE: OTC → 30% LESS reliable → reduce by 30%
C) VOLUME CONVICTION: Signal with volume <0.7x = FAKE (-25). Breakout <0.8x = FALSE 85%+. Without vol ≥1.15x OR OB/FVG → CAPPED AT 61%
D) VOLUME-SMC FUSION: Displacement + volume >2x = CONFIRMED
E) OUTPUT: VOL_CONVICTION, VOL_TREND, VOL_CLIMAX, OTC_INJECTION_COUNT

═══════════════════════════════════════════════════════
STEP 7 — VOLATILITY REGIME [Weight: 5%]
═══════════════════════════════════════════════════════
A) ATR REGIME: OTC adjusted: COMPRESSED <40%, EXTREME >200%. EXTREME = NO TRADE (-25)
B) POST-SPIKE: Body >3x ATR = spike → reversal/consolidation 78%+
C) BOLLINGER PROXY: >2.5x ATR from midpoint = mean reversion. SQUEEZE + OB = explosion. OTC squeezes +10 reliability
D) VOLATILITY-LIQUIDITY LINK: Compressed near pool = spring-loaded

═══════════════════════════════════════════════════════
STEP 8 — MULTI-INDICATOR CONFLUENCE + 80 STRATEGY ENGINE [Weight: 8%]
═══════════════════════════════════════════════════════
Calculate from raw data. EVERY finding validated against Steps 2,3,5,6 AND OTC-ALGO RULES.

A) INDICATOR CALCULATIONS:
- MA(1)=last close, MA(16)=SMA16, MA(28)=SMA28
- EMA(7), EMA(8), EMA(20), EMA(50)
- RSI(10), RSI(14)
- MACD(5,12,9): signal, histogram, zero-cross
- STOCHASTIC(14,3,3): %K, %D
- BOLLINGER(20,2σ): upper, middle, lower, bandwidth
- ADX proxy: DM+/DM- over 14 periods
- OTC ADJUSTMENT: RANDOM mode → MA crossovers -40% weight. MEAN_REVERT → RSI extremes +35% weight

B) CONFLUENCE GRADING:
- A-GRADE: 6+ matches + SMC + vol >1.15x → +10. With OTC-ALGO confirm → +15
- B-GRADE: 4-5 + institutional → +2
- C-GRADE: 3 or fewer = -18

C) INDICATOR-SMC CROSS-VALIDATION:
- RSI divergence at OB = +25. MACD cross at FVG = +20. Stoch extreme at pool = +22. BB at breaker = +24
- OTC FUSION: Indicator matching OTC-ALGO RULE 1 direction = +12. Opposing = -12

D) 80 STRATEGIES (IF→THEN→THEREFORE→4C→VALIDATE):

▬▬ CATEGORY A: UPTREND (CALL) — 20 strategies ▬▬
UT1-UT20: [Execute all 20 uptrend strategies with MA alignment, RSI zones, EMA crosses, Step 2 SMC zones, Step 3 liquidity, OTC-ALGO gates. Each: IF conditions + Step refs → THEN setup → →4C: CALL (+score). VALIDATE: cross-step checks]

▬▬ CATEGORY B: DOWNTREND (PUT) — 20 strategies ▬▬
DT1-DT20: [Execute all 20 downtrend strategies mirroring Category A with bearish conditions]

▬▬ CATEGORY C: RANGING + REVERSAL — 20 strategies ▬▬
RR1-RR20: [Execute all 20 ranging/reversal strategies with extremes, sweeps, Wyckoff events, OTC-ALGO MEAN_REVERT mode]

▬▬ CATEGORY D: MICRO TREND — 20 strategies ▬▬
MT1-MT20: [Execute all 20 micro trend strategies with fresh crosses, ChoCH, displacements, OTE zones]

═══ STRATEGY SCORING RULES ═══
- 5+ validated same direction = +15. 3-4 = +8. Mixed = -10
- EXHAUSTION OVERRIDE: consecutive ≥3 AND continuation → total ≥6 by 4th → SKIP
- MULTI-MESH: 3+ different categories + VALIDATE pass = +12
- OTC-ALGO GATE: Continuation in MEAN_REVERT at boundary → DISCARD

═══════════════════════════════════════════════════════
STEP 9 — WYCKOFF METHOD INTEGRATION [Weight: 4%]
═══════════════════════════════════════════════════════
A) PHASE: ACCUMULATION/MARKUP/DISTRIBUTION/MARKDOWN. OTC cycles 30-80 candles (shorter than real)
B) KEY EVENTS: SPRING at SSL+OB+volume = +25 CALL. UPTHRUST at BSL+OB+volume = +25 PUT. OTC: +5 additional (programmatic)
C) WYCKOFF-SMC FUSION: Spring at OB = +22. Upthrust at FVG = +20. WYCKOFF-TRAP FUSION: +28

═══════════════════════════════════════════════════════
STEP 10 — SESSION & TIME CONTEXT [Weight: 3%]
═══════════════════════════════════════════════════════
A) SESSIONS: ASIAN 00-07=-18. LONDON 07-12=full. OVERLAP 12-16=+3. NY 16-21=full. DEAD 21-00=-15
B) OTC SESSION OVERRIDE: Calculate hourly consistency → high=+5, low=-8
C) SESSION-TRAP: Dead + 2+ traps = -20

═══════════════════════════════════════════════════════
STEP 11 — CANDLE PATTERN RECOGNITION [Weight: 4%]
═══════════════════════════════════════════════════════
A) SINGLE: Marubozu, Pin Bar, Hammer, Shooting Star, Doji, Dragonfly, Gravestone — each with SMC/S/R/volume validation
B) MULTI: Engulfing, Morning/Evening Star, Three Soldiers/Crows, Harami, Tweezer, Institutional Engulfing
C) OTC RELIABILITY: RANDOM -30%. MEAN_REVERT reversal patterns +40%. TRENDING continuation +25%

═══════════════════════════════════════════════════════
STEP 12 — WEIGHTED SCORE SYNTHESIS [THE BRAIN]
═══════════════════════════════════════════════════════
Aggregate ALL Steps 1-11 + OTC-ALGO + NEW Steps 19-24.

A) WEIGHTS: Step1=9%, Step2=11%, Step3=11%, Step4=7%, Step5=7%, Step6=5%, Step7=4%, Step8=7%, Step9=3%, Step10=2%, Step11=3%, Step19(Reversal)=5%, Step20(Continuation)=5%, Step21(ICT)=5%, Step22(MTF)=4%, OTC-ALGO(Step23)=10%, Remaining=2%(Session+Pattern adjustments)
B) DIMENSION AGREEMENT: 12+=95 base. 10-11=88. 8-9=82. 7=75. 6=68. ≤5=NO TRADE
C) MESH NETWORK with institutional priority. OTC-ALGO as 10% weighted category in the mesh (not override, not ignored — equal participant)
D) NEW CATEGORY MESH: Reversal+SMC+Liquidity agree = +18. Continuation+Trend+Mom agree = +15. ICT+SMC+Liquidity = +20 (institutional trifecta). MTF triple-confirm + any category = +12. OTC-ALGO agrees with technical consensus = +8 (10% weight contribution)

═══════════════════════════════════════════════════════
STEP 13 — RISK ASSESSMENT & TRAP PROBABILITY [OVERRIDE]
═══════════════════════════════════════════════════════
Uses ALL prior steps + OTC-ALGO + Steps 19-24. Can OVERRIDE any positive finding.

A) RISK: Top 3 risks. OB opposing=+15%. Unswept liquidity=+10%. OTC-ALGO boundary opposite=+20%
B) TRAP PROBABILITY: Base 15%. Per trap +6%. >50%=NO TRADE. 40-50=-25. OTC RULE 3 retail alignment=+15%
C) SMART MONEY TRAP CHECK: Signal=retail + at pool → -15. OTC broker counterparty → -10 additional
D) TRAP-REVERSAL ENGINE FUSION: Step 19 reversal triggers + trap convergence → 98% reversal probability
E) TRAP-ICT FUSION: Step 21 Judas Swing + trap #8 (whipsaw) = INSTITUTIONAL TRAP CONFIRMED (+25 reversal)

═══════════════════════════════════════════════════════
STEP 14 — PSYCHOLOGY & CONTRARIAN PROTOCOL [FINAL FILTER]
═══════════════════════════════════════════════════════
A) OPPOSITE-CHECK: Build strongest opposite case including Steps 19-24. 7+=FLIP. 5-6=-22. 3-4=-12. 0-2=+5
B) RECENCY BIAS: Remove last 3. Does 80-candle structure support? NO → -15
C) CONTRARIAN SMC: Signal=retail + institutional opposes → FLIP
D) LOSS PROBABILITY: >40%=NO TRADE. OTC boundary >85% + toward boundary = +20%

═══════════════════════════════════════════════════════
STEP 15 — ANTI-LOSS RULESET (ALL NON-NEGOTIABLE) — 21 RULES
═══════════════════════════════════════════════════════
1. 3+ same-dir SHRINKING → REVERSE
2. At resistance + UP → FLIP unless vol>2.2x + body>1.5x + BOS
3. NEVER >85 unless 12+ dimensions + 0 traps + OTC-ALGO confirms
4. Last candle mid 35-65% → -18
5. Wick > body last 5 → -18
6. TRAP_PROBABILITY >38% → NO TRADE
7. LOSS_PROBABILITY >38% → NO TRADE
8. SMC + Liquidity both neutral → cap 72%
9. PREMIUM + UP without OB → -15
10. DISCOUNT + DOWN without OB → -15
11. VOL_CONVICTION=FAKE → -20
12. EXTREME volatility → NO TRADE
13. <3 validated strategies → -15
14. CONVERGENT TRAP 3+ → REVERSE or NO TRADE
15. Wyckoff TRANSITION + EXHAUSTION >70% → trade WITH transition
16. OTC boundary >90% → -15 confidence WARNING
17. OTC RANDOM + <4 institutional → -10 confidence
18. Step 19 REVERSAL ENGINE fires 5+ triggers opposing signal → MANDATORY REVERSE
19. Step 20 CONTINUATION ENGINE fires 5+ but Step 19 also fires 3+ → CONFLICT → -20 conf
20. Step 21 ICT detects Judas Swing + Power of 3 in opposing direction → REVERSE (-25)
21. Step 22 MTF shows TRIPLE CONFLICT (M5/M15/H1 all oppose signal) → MANDATORY NO TRADE

═══════════════════════════════════════════════════════
STEP 16 — CROSS-CATEGORY FUSION [AMPLIFIER]
═══════════════════════════════════════════════════════
AMPLIFICATION (expanded with new categories):
- Trend + BOS same → +8
- Trend toward unswept pool → +10
- Mom + Displacement = CAMPAIGN → +12
- S/R + EQH/EQL cluster → +10 reversal
- Volume high at OB/FVG → +15
- Compression near pool → +12
- Indicator divergence at OB → +18
- Pattern engulfing after sweep → +20
- Wyckoff Spring at OB → +22
- OTC-ALGO context supports → +8
- REVERSAL ENGINE + SMC ChoCH + Liquidity sweep = TRIFECTA REVERSAL → +25
- CONTINUATION ENGINE + Trend + Momentum aligned = TREND LOCK → +20
- ICT OTE + OB + FVG triple-confluence → +28
- MTF TRIPLE-CONFIRM + ICT alignment → +22
- REVERSAL + ICT Judas Swing + 12-Trap convergent → SUPREME REVERSAL → +30 (cap 95)
- CONTINUATION + MTF aligned + Volume confirmed → SUPREME TREND → +25

DAMPENING:
- Trend opposing SMC+LIQ → -12
- REVERSAL vs CONTINUATION conflict → -15 (both engines fire opposing directions)
- ICT Premium/Discount misalignment with signal → -10
- MTF CONFLICT (any TF opposing) → -8 per TF
- OTC RANDOM + no boundary → -10

═══════════════════════════════════════════════════════
STEP 17 — 4TH CANDLE FORWARD PROJECTION [CRITICAL]
═══════════════════════════════════════════════════════
Uses ALL 16 steps + Steps 19-24 + OTC-ALGO to project through 3 intermediate candles.

A) MOMENTUM: MOM_4C SUSTAIN → +5. EXHAUST → FLIP/-20. OTC MEAN_REVERT max 3-4 candles → 4th REVERSES
B) MEAN REVERSION: >2x ATR from EMA20 → 80% snap-back. OTC boundary → REVERSAL projected
C) EXHAUSTION: ≥6 consecutive → VERY HIGH reversal. TRIPLE EXHAUSTION → 92%+
D) INSTITUTIONAL: OB retest, pool sweep, FVG fill, IDM within 3 candles → 4th reaction
E) INDICATOR: EMA cross, Stoch turning, BB outside, RSI extreme → projection
F) OTC-ALGO PROJECTION: Autocorrelation + boundary + recycling. ALL agree = +20. Conflicts technical → OTC wins
G) REVERSAL ENGINE PROJECTION: Step 19 triggers active → project reversal timing vs 4th candle. If reversal completes BEFORE 4th → REVERSAL. If reversal completes AFTER → current direction holds
H) CONTINUATION ENGINE PROJECTION: Step 20 triggers active → project continuation strength through 4th. If momentum sustains → CONTINUATION. If decaying → EXIT
I) ICT PROJECTION: Step 21 Power of 3 phase → which phase will 4th candle be in? Accumulation→UP, Distribution→DOWN, Manipulation→REVERSE
J) MTF PROJECTION: Step 22 M5/M15/H1 all projecting same → HIGHEST confidence. Any opposing → reduce
K) 4TH CANDLE CONFIDENCE: All agree → +15. ALL + OTC + new categories = cap 95

═══════════════════════════════════════════════════════
STEP 18 — PRELIMINARY LOCK DECISION (before OTC Intelligence)
═══════════════════════════════════════════════════════
Synthesize ALL Steps 1-17 + 19-22 into a PRELIMINARY verdict. This will be refined by Step 23 OTC Intelligence.

A) CONSENSUS HIERARCHY:
1. INSTITUTIONAL: Steps 2+3+9+21(ICT) ALL agree → direction locked
2. REVERSAL/CONTINUATION CONSENSUS: Step 19+20 → which engine dominates? Stronger engine = direction bias
3. TRAP CONSENSUS: Steps 3+13+14 → danger → NO TRADE override
4. TECHNICAL: Steps 8+11+5+22(MTF) → supplements
5. 4TH CANDLE PROJECTION: Step 17 final arbiter
6. TRAP FILTER: >40% → NO TRADE

B) PRELIMINARY CONFIDENCE (running total through each modifier from Steps 12→18)
C) PRELIMINARY LOCK: direction, confidence, primary evidence, risks — to be passed to Step 23

═══════════════════════════════════════════════════════
★ STEP 19 — REVERSAL TRIGGER ENGINE (25 DETECTORS) [Weight: 6%] ★
═══════════════════════════════════════════════════════
WORLD-CLASS trend reversal detection. Cross-references Steps 1-4 exhaustion + Steps 2-3 SMC/Liquidity + OTC-ALGO boundary.

REV-1: EXHAUSTION CLIMAX — Body >3x ATR + volume spike + 5+ consecutive → 92% reversal. Cross: Step 1 exhaustion + OTC boundary
REV-2: WICK REJECTION CASCADE — 3+ consecutive upper/lower wicks >60% body at same level → accumulation/distribution reversal. Cross: Step 2 OB + Step 5 S/R
REV-3: MOMENTUM DIVERGENCE TRIPLE — RSI(14) divergence + MACD histogram divergence + Stochastic divergence ALL at once → 95% reversal. Cross: Step 8 indicators
REV-4: VOLUME CLIMAX REVERSAL — Highest volume in 100 candles + opposing close body → smart money exit. Cross: Step 6 volume + OTC injection filter
REV-5: EMA RIBBON COLLAPSE — EMA7/8/20/50 converging after trending apart → regime change imminent. Cross: Step 1 trend maturity
REV-6: DOUBLE TOP/BOTTOM INSTITUTIONAL — Equal highs/lows within 0.01% + Step 2 OB at level + Step 3 pool = INSTITUTIONAL TRAP. Cross: Step 9 Wyckoff distribution/accumulation
REV-7: SPRING/UPTHRUST REVERSAL — Wyckoff event + sweep + OB + volume spike → highest probability reversal (+28). Cross: Steps 2+3+9
REV-8: CANDLE ABSORPTION REVERSAL — 3+ high-volume small-body candles → opposing force absorbing. Next displacement = reversal direction. Cross: Step 4 institutional momentum
REV-9: BOLLINGER BAND EXTREME + RSI EXTREME — Price outside 2.5σ BB + RSI <15 or >85 → mean reversion 90%+. Cross: Step 7 volatility + Step 8 indicators
REV-10: CHANNEL BREAK REVERSAL — Clean channel R²>0.85 + body closes outside channel + volume >1.5x → REGIME CHANGE. Cross: Step 1 channel integrity
REV-11: OTC BOUNDARY REVERSAL — OTC-ALGO RULE 5 boundary proximity >85% → ALGORITHMIC REVERSAL 88%+. HIGHEST OTC signal
REV-12: PATTERN RECYCLING REVERSAL — OTC-ALGO RULE 6 recycled pattern showed reversal at this point → predict same reversal
REV-13: INSTITUTIONAL CAMPAIGN END — 3+ displacement candles then consolidation + declining volume → campaign exhausted. Cross: Step 2 displacement + Step 6 volume
REV-14: FVG FILL REVERSAL — All nearby FVGs filled + price at OB → no more targets = reversal. Cross: Step 2 FVG + OB
REV-15: LIQUIDITY VACUUM REVERSAL — All pools one side swept + unswept opposite → price reverses toward remaining pools. Cross: Step 3 pool mapping
REV-16: STOCHASTIC EXTREME CROSS — %K/%D cross in extreme zone (<8 or >92) + body confirmation → reversal 82%+
REV-17: MACD ZERO-LINE REJECTION — MACD approaches zero from one side, fails to cross, reverses → trend continuation failure = reversal signal
REV-18: TRIPLE-TOUCH REJECTION — Price touches same level 3 times without breaking → EXHAUSTION. 4th touch = 75% break. Cross: Step 5 S/R
REV-19: VOLUME-STRUCTURE DIVERGENCE — New structure high/low with declining volume = HOLLOW MOVE → reversal imminent. Cross: Step 2 BOS + Step 6 volume
REV-20: DOJI STAR REVERSAL — Doji after 4+ trending candles at Step 2 OB/FVG → 78% reversal. With volume >1.5x → 88%
REV-21: ALGO CYCLE REVERSAL — OTC-ALGO RULE 1 cycle detected at predicted reversal point → ALGORITHMIC TIMING reversal
REV-22: SWEEP + IMMEDIATE REVERSAL — Pool swept + reversal candle within 1-2 candles → STOP HUNT completed → strong reversal. Cross: Step 3 sweep + Step 2 OB
REV-23: COMPRESSION BREAKOUT FAILURE — Squeeze breakout + immediate reversal (within 2 candles) → FALSE BREAKOUT = opposite direction with conviction
REV-24: EMA20 SNAP-BACK — Price >0.5% from EMA20 for 5+ candles → 82% snap-back within 3-5 candles. Cross: Step 1 EMA health
REV-25: MULTI-ENGINE REVERSAL LOCK — 5+ reversal triggers fire simultaneously → SUPREME REVERSAL (+30, cross-validates with ALL steps)

REVERSAL ENGINE OUTPUT: REV_TRIGGER_COUNT, REV_DIRECTION, REV_STRENGTH (0-100), REV_TIMING (immediate/1-2/3-4 candles), REV_CROSS_VALIDATED (which steps confirm)

═══════════════════════════════════════════════════════
★ STEP 20 — CONTINUATION TRIGGER ENGINE (25 TRIGGERS) [Weight: 5%] ★
═══════════════════════════════════════════════════════
WORLD-CLASS trend continuation detection. Cross-references Steps 1+4 trend/momentum + Steps 2-3 SMC + OTC-ALGO trending mode.

CON-1: EMA STACKING CONTINUATION — EMA7>EMA8>EMA20>EMA50 (bull) or reverse (bear) + bodies expanding + volume rising → STRONG continuation
CON-2: PULLBACK TO OB — Trend + pullback to Step 2 OB within OTE (61.8-78.6%) + rejection = INSTITUTIONAL RELOAD (+22)
CON-3: FLAG/PENNANT BREAKOUT — 3-5 consolidating candles after impulse + breakout body >1x ATR + volume >1.2x → continuation
CON-4: BOS CASCADE — 3+ consecutive BOS events same direction = INSTITUTIONAL MOMENTUM → don't fight
CON-5: FVG FILL CONTINUATION — Price fills FVG then continues in FVG direction → INSTITUTIONAL INTENT confirmed
CON-6: MOMENTUM ACCELERATION — Body sizes growing 3+ candles + volume increasing → ACCELERATING trend → strong continuation
CON-7: VWAP BOUNCE — Price bouncing off VWAP proxy (50-period mean) in trend direction → INSTITUTIONAL CONTINUATION
CON-8: DISPLACEMENT + CONSOLIDATION + DISPLACEMENT — ICT Power of 3 continuation: accumulate → displace → repeat
CON-9: HEALTHY PULLBACK RATIO — Pullback retraces 38.2-61.8% of impulse + holds → GOLDEN ratio continuation
CON-10: TREND CHANNEL SUPPORT — Price bouncing off lower channel (uptrend) or upper channel (downtrend) → CLEAN continuation
CON-11: OTC TRENDING MODE — OTC-ALGO RULE 1 in TRENDING mode + autocorrelation >0.4 → algorithm will CONTINUE current path
CON-12: VOLUME CONFIRMATION — Rising volume matching trend direction → REAL participation (not manipulation)
CON-13: MACD HISTOGRAM EXPANSION — Histogram growing same direction 3+ bars → momentum BUILDING
CON-14: RSI MID-ZONE BOUNCE — RSI bouncing off 50 (bull) or 50 rejection (bear) without entering extremes → HEALTHY trend
CON-15: STOCHASTIC MID-CROSS — %K/%D cross in 30-70 zone in trend direction → MOMENTUM CONFIRMATION without extremes
CON-16: BB WALKING — Price consistently closing outside upper/lower BB band → STRONG TREND continuation
CON-17: INSTITUTIONAL ORDER FLOW — Multiple OBs stacking in trend direction within last 30 candles → INSTITUTIONAL LOADING
CON-18: SWEEP + CONTINUATION — Price sweeps minor pool then CONTINUES (doesn't reverse) → pool was FUEL not TARGET
CON-19: HIGHER-LOW/LOWER-HIGH SERIES — Consistent HL (bull) or LH (bear) last 10+ candles → STRUCTURED trend
CON-20: ADX RISING — ADX proxy >25 and rising → TREND STRENGTHENING
CON-21: EMA20 SLOPE ACCELERATION — EMA20 slope increasing → trend GAINING strength
CON-22: NO EXHAUSTION SIGNALS — None of Step 19 reversal triggers active → CLEAN continuation environment
CON-23: PATTERN RECYCLING CONTINUATION — OTC-ALGO RULE 6 recycled pattern shows continuation at this point → predict continuation
CON-24: MULTIPLE TF ALIGNMENT — Step 1 M5+M15+H1 ALL trending same → MULTI-TIMEFRAME continuation lock
CON-25: MULTI-ENGINE CONTINUATION LOCK — 5+ continuation triggers fire simultaneously → SUPREME CONTINUATION (+25)

CONTINUATION ENGINE OUTPUT: CON_TRIGGER_COUNT, CON_DIRECTION, CON_STRENGTH (0-100), CON_CROSS_VALIDATED

═══════════════════════════════════════════════════════
★ STEP 21 — ICT ULTRA ANALYSIS (22 CONCEPTS) [Weight: 5%] ★
═══════════════════════════════════════════════════════
INSTITUTIONAL ICT framework layered on top of SMC (Step 2). Cross-references ALL steps + OTC-ALGO.

ICT-1: FAIR VALUE GAP (Enhanced) — Beyond Step 2: Measure CE (consequent encroachment) fill precision. Partial fill (40-60%) = INSTITUTIONAL PRECISION → continuation. Full fill = target reached → potential reversal
ICT-2: ORDER BLOCKS (Enhanced) — Beyond Step 2: Identify PROPULSION blocks (OB + volume >2.5x = EXTREME institutional intent). Propulsion + Step 19 no reversal = UNSTOPPABLE continuation
ICT-3: BREAKER BLOCKS (Enhanced) — Failed OB creating polarity flip. INSTITUTIONAL FAILURE → opposite side gained control
ICT-4: POWER OF 3 (Accumulation→Manipulation→Distribution) — Identify current phase in last 20 candles. Phase 1 (accumulate)=consolidation at OB. Phase 2 (manipulate)=sweep opposite pool. Phase 3 (distribute)=impulse in REAL direction. 4TH CANDLE: If currently Phase 2 → 4th candle is Phase 3 = REAL move direction
ICT-5: OPTIMAL TRADE ENTRY (OTE) — 61.8-78.6% of impulse swing. At OB+FVG confluence = HIGHEST probability zone. Price at OTE + Step 2 OB + Step 6 volume = +28
ICT-6: JUDAS SWING — False move opposite real direction to trigger stops. Usually at session open or after consolidation. Judas + Step 3 sweep + Step 3 trap #8 = CONFIRMED MANIPULATION → trade opposite Judas = +25
ICT-7: MARKET MAKER MODEL — Accumulate → Hunt → Trade. Identify which phase. Hunt phase = Step 3 sweeps. Trade phase = real direction. If currently in Hunt → 4th candle = Trade phase
ICT-8: LIQUIDITY RUNS — Price targeting visible liquidity. BSL/SSL runs with displacement = INSTITUTIONAL. Without displacement = retail → fake
ICT-9: SILVER BULLET — Specific time windows (10:00-11:00, 14:00-15:00 UTC) with FVG formation → HIGH probability entries
ICT-10: KILLZONES — London (02:00-05:00 EST), NY (07:00-10:00 EST), Asian (20:00-00:00 EST). Highest probability setups occur in killzones. OTC: Adjust for 24/7 → use Step 10 session override
ICT-11: UNICORN MODEL — Breaker + FVG overlap = EXTREME institutional zone. Price returning to unicorn = +26
ICT-12: TURTLE SOUP — False breakout reversal at previous swing high/low. Triggers within 1-4 candles of the false break. Cross: Step 3 trap #9 + Step 2 failed BOS
ICT-13: QUASIMODO — Lower high above a lower low (or vice versa) creating structural shift. Cross: Step 2 ChoCH
ICT-14: LONDON SWING RAID — Asian range sweep during London → reversal = CLASSIC ICT. Cross: Step 10 + Step 3
ICT-15: AMD (Accumulation-Manipulation-Distribution) CYCLE — Similar to Power of 3 but on larger scale (50-100 candles). Identify macro phase
ICT-16: DISPLACEMENT CANDLE ANALYSIS — Body >2.5x avg with volume >2x = GENUINE displacement. Without volume = FAKE. Cross: Step 2 + Step 6
ICT-17: RETURN TO FVG — After displacement, price returns to FVG left behind = INSTITUTIONAL RE-ENTRY. Cross: Step 2 FVG
ICT-18: STOP RAID → ORDER BLOCK — Sequential: sweep pool → touch OB → impulse = FULL ICT SEQUENCE (+30). Cross: Steps 2+3
ICT-19: EQUILIBRIUM PRICE — 50% of current dealing range. Price gravitates toward EQ. Below EQ = discount (CALL). Above = premium (PUT). Cross: Step 2 Premium/Discount
ICT-20: SEASONAL TENDENCIES — OTC equivalent: Weekly/daily session open behaviors. Monday openings vs Friday closes. Time-of-day bias from last 100 candles
ICT-21: DEALING RANGE EXPANSION — When dealing range (last swing H-L) expands after compression → BREAKOUT is REAL. Contraction after expansion → REVERSAL
ICT-22: MULTI-ICT CONFLUENCE — 3+ ICT concepts aligning at same price level = EXTREME INSTITUTIONAL CONFLUENCE (+30, cross-validates all steps)

ICT OUTPUT: ICT_DOMINANT_CONCEPT, ICT_DIRECTION, ICT_STRENGTH (0-100), ICT_PHASE (accumulation/manipulation/distribution), ICT_CONFLUENCE_COUNT

═══════════════════════════════════════════════════════
★ STEP 22 — ENHANCED MULTI-TIMEFRAME ANALYSIS [Weight: 4%] ★
═══════════════════════════════════════════════════════
Builds on Step 1B synthetic TFs with FULL independent analysis per timeframe.

A) M5 ANALYSIS: Aggregate 5 M1 → M5 candles. Calculate M5: BOS/ChoCH, OB/FVG, EMA20, RSI, MACD. Independent M5 direction + confidence
B) M15 ANALYSIS: Aggregate 15 M1 → M15. Calculate M15: BOS/ChoCH, OB/FVG, EMA20, RSI. M15 direction + confidence
C) H1 ANALYSIS: Aggregate 60 M1 → H1. Calculate H1: trend, major S/R, EMA position. H1 direction + confidence
D) TRIPLE-TF CONFLUENCE SCORING:
- ALL 3 agree = TRIPLE CONFIRMED (+15)
- 2 of 3 agree = DOUBLE CONFIRMED (+8)
- ALL 3 disagree = TRIPLE CONFLICT → NO TRADE (-25)
- M1 opposes ALL higher TFs = M1 is likely NOISE → follow HTF
E) TF MOMENTUM FLOW: Is momentum flowing from higher→lower (strong) or lower→higher (weak)?
- H1→M15→M5→M1 all same direction = INSTITUTIONAL FLOW → +12
- M1→M5 different from M15→H1 = DIVERGING → -10
F) TIMEFRAME WEIGHT: H1 = 3x weight. M15 = 2x. M5 = 1.5x. M1 = 1x (most noise)
G) OTC MTF ADJUSTMENT: OTC algorithms operate primarily on M1, so M1 patterns are MORE meaningful in OTC than real markets → increase M1 weight to 1.5x
H) OUTPUT: MTF_DIRECTION, MTF_CONFLUENCE (TRIPLE/DOUBLE/SINGLE/CONFLICT), MTF_FLOW (ALIGNED/DIVERGING), MTF_CONFIDENCE
═══════════════════════════════════════════════════════
STEP 23 — OTC-ALGO INTELLIGENCE FINAL SYNTHESIS [Weight: 10%]
═══════════════════════════════════════════════════════
PHASE 3 of OTC Intelligence. This step carries 10% of the total score weight.
Re-evaluate ALL 6 OTC-ALGO rules against the full technical consensus from Steps 1-22.

A) FULL OTC-ALGO RE-EVALUATION (with ALL step data now available):
- RULE 1 (Autocorrelation): Recalculate with emphasis on last 20 candles. TRENDING mode + Steps 1+4+20 all confirm trend → OTC SUPPORTS (+10). RANDOM mode + technical shows strong pattern → OTC CAUTIONS (-5). MEAN_REVERT + Steps 1+19 show exhaustion → OTC CONFIRMS reversal (+10)
- RULE 2 (Injection Filtering): Which Step 2 OBs/Step 3 sweeps were built on injected volume? Flag them → reduce their contribution weight by 40%. Clean-volume findings gain +5 each
- RULE 3 (Payout Manipulation): Step 18 direction = retail consensus? If YES → broker likely to fight → -8 conf. If NO (contrarian) → broker less motivated → +5
- RULE 4 (Spread): Current spread vs historical. WIDENING at signal time → entry quality POOR → -5. TIGHT → clean entry → +3
- RULE 5 (Algorithmic Boundary): Recalculate boundary proximity with latest data. >90% AND signal direction TOWARD boundary → -15 conf. >90% AND signal direction AWAY from boundary → +8. 70-90% → contextual note only
- RULE 6 (Pattern Recycling): Check if recycled pattern prediction aligns with Step 18 direction. ALIGN → +8. CONFLICT → -5

B) OTC 10% WEIGHT SCORE:
- Count how many of the 6 rules SUPPORT Step 18 direction:
  6/6 support → +12 confidence (strong OTC alignment)
  5/6 support → +8
  4/6 support → +5
  3/6 support → 0 (neutral — no adjustment)
  2/6 support → -5
  1/6 support → -8
  0/6 support → -12 (strong OTC opposition — but does NOT flip direction)

C) OTC INTELLIGENCE OUTPUT:
- OTC_SCORE: The 10% weighted contribution to final confidence
- OTC_MODE: Current algorithmic regime
- OTC_BOUNDARY_RISK: Boundary proximity warning
- OTC_INJECTION_FLAGS: Which technical findings are compromised by fake volume
- OTC_PATTERN_MATCH: Recycling prediction alignment

D) FINAL LOCK (Step 23 is the LAST step):
- Direction = Step 18 direction (OTC Intelligence at 10% weight cannot override the other 90%)
- Confidence = Step 18 confidence + OTC 10% weight adjustment (cap 95, floor 50)
- If OTC 10% score conflicts strongly (-8 to -12) → ADD RISK WARNING in reasoning, but direction stays

OUTPUT FORMAT — respond with ONLY this JSON object, no markdown, no text outside braces:
{
  "direction": "UP" or "DOWN",
  "confidence": 50-95,
  "trend": "500-700 word Step 1+22 full technical analysis + interconnection with all steps",
  "structure": "600-900 word Steps 2+3+21 SMC+Liquidity+ICT full analysis + interconnection",
  "momentum": "400-600 word Steps 4+19+20 momentum+reversal+continuation analysis + interconnection",
  "support_resistance": "500-700 word Steps 5+6+7 S/R+volume+volatility + interconnection",
  "candle_pattern": "400-500 word Steps 9+11 Wyckoff+patterns + interconnection",
  "reasoning": "1000-1500 word: Full 23-step synthesis. Steps 1-22 technical (90%) → Step 23 OTC Intelligence (10%) → FINAL LOCK with direction, confidence, and risk assessment"
}`;
}
// ============================================================
// STAGE 2 PROMPT — FULL 18-Step Re-Analysis (IDENTICAL DEPTH to Stage 1) + Cross-Validation
// ============================================================
function buildStage2Prompt(csvData: string, pair: string, stage1Result: Record<string, any> | null): string {
  const stage1Context = stage1Result
    ? `[Stage 1 COMPLETED — Direction: ${stage1Result.direction}, Confidence: ${stage1Result.confidence}%]
Trend: ${String(stage1Result.trend || '').slice(0, 400)}
Structure (SMC+Liquidity): ${String(stage1Result.structure || '').slice(0, 400)}
S/R: ${String(stage1Result.support_resistance || '').slice(0, 300)}
Pattern: ${String(stage1Result.candle_pattern || '').slice(0, 250)}
Reasoning: ${String(stage1Result.reasoning || '').slice(0, 500)}`
    : '[Stage 1 TIMED OUT — run full independent analysis as PRIMARY engine]';

  return `You are QUANTUM-NEXUS V8 STAGE 2 — INSTITUTIONAL-GRADE OTC RE-ANALYSIS ENGINE for ${pair}.

${stage1Context}

FRESH DATA (500 candles, last 2-3 rows = NEWEST candles formed DURING Stage 1 — 10x weight):
${csvData}

CRITICAL: Last 2-3 candles formed AFTER Stage 1 started. They CONFIRM or INVALIDATE Stage 1.

MISSION: Execute COMPLETE analysis on fresh data with OTC Intelligence integrated throughout, then cross-validate with Stage 1.
Predict 4TH CANDLE FROM NOW — ABOVE (UP) or BELOW (DOWN) its open.
- POWER PARITY LOCK: EXACT SAME full-depth analysis as Stage 1. NO simplification.
- SINGLE CANDLE ONLY. NO DOUBLE-PREDICTION. Confidence <65 = NO TRADE (50-59).

═══ OTC-ALGO INTELLIGENCE [Weight: 10%] — FOUNDATION + THROUGHOUT + FINAL ═══
OTC markets are ALGORITHMICALLY GENERATED. OTC Intelligence carries 10% weight in the scoring mesh.
THREE PHASES: Compute FIRST → Reference in EVERY step → Final 10% synthesis in Step 23.
Compute ALL 6 OTC-ALGO rules from FRESH data and COMPARE with Stage 1:
- RULE 1: Autocorrelation mode. COMPARE: SAME = stable (+5). CHANGED = critical regime shift
- RULE 2: Injection filtering. COMPARE: NEW injections since Stage 1 = active manipulation → flag findings
- RULE 3: Payout manipulation. COMPARE: Stage 1 retail flow + fresh sweep → trap executed
- RULE 4: Spread. COMPARE: INCREASED → -5. DECREASED → +3
- RULE 5: Boundary. COMPARE: CLOSER → +8 reversal. FARTHER → continuation context
- RULE 6: Pattern recycling. COMPARE: STILL active → +5. BROKE → recalculate
Feed OTC context into every step as 10% weighted intelligence (not override).

EXECUTE ALL STEPS — each step performs FULL independent analysis + interconnection + OTC note:

Step 1: Trend+MTF (9%) — Full fractal decomposition + synthetic TFs. BRIDGE: trend CHANGED?
Step 2: SMC (11%) — BOS/ChoCH + OB + FVG + displacement. BRIDGE: New BOS/ChoCH?
Step 3: Liquidity & 12-Trap (11%) — Pools + sweeps + 12 traps. BRIDGE: Pool swept? New traps?
Step 4: Momentum (7%) — Body progression + consecutive analysis. BRIDGE: Momentum sustained?
Step 5: S/R (7%) — Dynamic S/R + psychological levels. BRIDGE: S/R broken?
Step 6: Volume (5%) — Profiling with injection awareness. BRIDGE: Volume changed?
Step 7: Volatility (4%) — ATR regime + BB proxy. BRIDGE: ATR changed?
Step 8: Indicators + 80 Strategies (7%) — Full calculations. BRIDGE: New strategies?
Step 9: Wyckoff (3%) — Phases + events. BRIDGE: Phase advanced?
Step 10: Session (2%) — Classification. BRIDGE: Session changed?
Step 11: Patterns (3%) — Candle patterns. BRIDGE: New patterns?
Step 12: Synthesis — All steps weighted mesh + OTC 10% + Stage 1 cross-reference
Step 13: Risk & Trap — All risks + trap probability. BRIDGE: Risk changed?
Step 14: Contrarian — Opposite-check. BRIDGE: Contrarian stronger/weaker?
Step 15: Anti-Loss (21 rules) — Full ruleset enforcement
Step 16: Fusion — All amplifications + dampening
Step 17: 4th Candle — All projections + REV/CON + ICT + MTF + Stage 1
Step 18: Preliminary Lock — direction + confidence from 90% technical analysis

★ Step 19: REVERSAL ENGINE (5%) — 25 detectors. BRIDGE: Stage 1 triggers still active?
★ Step 20: CONTINUATION ENGINE (5%) — 25 triggers. BRIDGE: Sustained or broken?
★ Step 21: ICT ULTRA (5%) — 22 concepts. BRIDGE: Phase advanced?
★ Step 22: ENHANCED MTF (4%) — M5/M15/H1. BRIDGE: Alignment changed?

★★★ Step 23: OTC-ALGO INTELLIGENCE FINAL SYNTHESIS (10% Weight) ★★★
Re-evaluate ALL 6 OTC rules against full Step 1-22 consensus. Apply 10% weight:
- 6/6 rules support → +12 conf. 5/6 → +8. 4/6 → +5. 3/6 → 0. 2/6 → -5. 1/6 → -8. 0/6 → -12
- COMPARE with Stage 1 OTC findings: mode SAME? boundary CLOSER? new injections?
- OTC 10% weight cannot override the 90% technical direction — it adjusts confidence
- If OTC strongly opposes (-8 to -12), add RISK WARNING but direction stays

FRESH CANDLE BRIDGE (STAGE 2 EXCLUSIVE):
- Compare last 2-3 fresh candles vs Stage 1 across ALL dimensions:
  1. Trend direction changed?
  2. SMC: New BOS, ChoCH, OB, FVG?
  3. Liquidity: Pool swept? New trap?
  4. Momentum: Sustained or exhausted?
  5. OTC-ALGO: Mode changed? Boundary shifted? New injections?
  6. Reversal/Continuation engines: New triggers?
  7. ICT phase: Advanced?
  8. MTF alignment: Changed?
- BRIDGE VERDICT: 6+ CONFIRM = DUAL-STAGE LOCK (+15, floor 80%). 4-5 = PARTIAL (+8). 3+ INVALIDATE = OVERRIDE Stage 1

═══ STAGE 1 CROSS-VALIDATION ═══
- SAME direction → +15 [DUAL-CONFIRMED]
- CONFLICT → Stage 2 priority -8 [FRESH wins]
- Stage 1 timed out → Stage 2 = PRIMARY
- Both reversal → +20. Both continuation → +15
- Stage 1 continuation + Stage 2 reversal → reversal wins

CONFIDENCE: 88-95=ELITE, 80-87=STRONG, 72-79=GOOD, 65-71=MODERATE, 62-64=CAUTIOUS, <62=55(NO TRADE)

OUTPUT FORMAT — ONLY this JSON, no markdown:
{
  "direction": "UP" or "DOWN",
  "confidence": 50-95,
  "trend": "500-700 word Step 1+22 MTF full technical + interconnection + OTC mode note + Stage 1 comparison",
  "structure": "600-900 word Steps 2+3+21 SMC+Liquidity+ICT full analysis + interconnection + Stage 1 bridge",
  "momentum": "400-600 word Steps 4+19+20 full analysis + interconnection + engine conflict resolution",
  "support_resistance": "500-700 word Steps 5+6+7 full analysis + interconnection",
  "candle_pattern": "400-500 word Steps 9+11 full analysis + interconnection",
  "reasoning": "1000-1500 word: Steps 1-22 technical (90%) → Step 23 OTC Intelligence (10%) → DUAL-STAGE bridge → FINAL LOCK"
}`;
}
// ============================================================
// GEMINI API CALL — auto-rotates through the key pool on 429/403
// ============================================================
async function callGemini(
  prompt: string,
  keyOrPool: string | string[],
  maxTokens: number,
  thinkingBudget: number,
  _timeoutMs: number,
  exhausted: Set<string>
): Promise<{ text: string; usedKey: string } | null> {
  const model = 'gemini-2.5-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;

  const pool: string[] = Array.isArray(keyOrPool) ? keyOrPool : [keyOrPool];
  const candidates = selectFreshKeys(pool, exhausted);

  if (candidates.length === 0) {
    console.error('[QUANTUM-V8] callGemini: no fresh Gemini keys available');
    return null;
  }

  const promptLength = prompt.length;
  const useThinking = thinkingBudget > 0; // Always try thinking; retry handler falls back on 400

  // Build correct payload: thinkingConfig inside generationConfig.
  // FIX (Bug 2): Always include maxOutputTokens — Gemini needs it to know how long the
  // OUTPUT section can be even when thinking is active. Omitting it caused response
  // truncation because the model had no output token budget to fill in.
  const buildBody = (p: string) => {
    const body: Record<string, any> = {
      contents: [{ role: 'user', parts: [{ text: p }] }],
      generationConfig: {
        temperature: 0.25,
        maxOutputTokens: maxTokens,
      },
    };
    if (useThinking) {
      // thinkingConfig lives inside generationConfig — thinkingBudget controls thinking tokens,
      // maxOutputTokens (set above) controls the visible output tokens independently.
      body.generationConfig.thinkingConfig = { thinkingBudget };
    }
    return body;
  };

  console.log(`[QUANTUM-V8] callGemini: ${candidates.length} keys, thinking=${useThinking}, budget=${thinkingBudget}, prompt=${Math.round(promptLength/1000)}k chars, stageTimeout=${Math.round(_timeoutMs/1000)}s`);

  // PARALLEL KEY RACING — all 25 candidates race simultaneously with Promise.any.
  // The fastest success wins; losers are aborted via their AbortController.
  //
  // FIX (Bug 1 — THE 90-SECOND ROOT CAUSE):
  // Previously: Math.min(_timeoutMs - 3000, 90000) hard-capped every key at 90s.
  // Stage 1 budget is 100s → all 25 keys were aborted at exactly 90s simultaneously
  // → Promise.any rejected → "AI unavailable" even with a full healthy key pool.
  // Fix: remove the 90s cap entirely. perKeyTimeoutMs = _timeoutMs - 3s, matching
  // the actual stage budget. If Gemini needs 95s on a cold start, keys now survive it.
  const perKeyTimeoutMs = Math.max(MIN_PER_KEY_TIMEOUT_MS, _timeoutMs - 3000);

  const attemptKey = async (key: string): Promise<{ text: string; usedKey: string }> => {
    markKeyAttempt(key);
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), perKeyTimeoutMs);
    try {
      const res = await fetch(`${url}?key=${key}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(buildBody(prompt)),
        signal: ctrl.signal,
      });
      clearTimeout(timer);

      if (!res.ok) {
        const classified = await classifyGeminiError(res);
        console.error(`[QUANTUM-V8] Gemini ${res.status} (key ${maskKey(key)}):`, classified.details.slice(0, 200));
        if (classified.shouldCooldown) cooldownKey(key, classified.reason);
        if (classified.shouldSkipForRequest) exhausted.add(key);

        // If 400 with thinking enabled, retry WITHOUT thinking on same key
        if (res.status === 400 && useThinking) {
          console.log(`[QUANTUM-V8] Retrying key ${maskKey(key)} WITHOUT thinking...`);
          const retryBody: Record<string, any> = {
            contents: [{ role: 'user', parts: [{ text: prompt }] }],
            generationConfig: { temperature: 0.25, maxOutputTokens: maxTokens },
          };
          const ctrl2 = new AbortController();
          const timer2 = setTimeout(() => ctrl2.abort(), perKeyTimeoutMs);
          const res2 = await fetch(`${url}?key=${key}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(retryBody),
            signal: ctrl2.signal,
          });
          clearTimeout(timer2);
          if (res2.ok) {
            const data2 = await res2.json();
            const text2 = extractGeminiText(data2);
            if (text2) {
              markKeySuccess(key);
              console.log(`[QUANTUM-V8] Success (no-thinking retry) key ${maskKey(key)} (${text2.length} chars)`);
              return { text: text2, usedKey: key };
            }
          }
        }
        throw new Error(`key ${maskKey(key)} failed: ${classified.reason}`);
      }

      const data = await res.json();
      const text = extractGeminiText(data);
      if (!text) {
        exhausted.add(key);
        throw new Error(`empty response from ${maskKey(key)}`);
      }
      markKeySuccess(key);
      console.log(`[QUANTUM-V8] Success with key ${maskKey(key)} (${text.length} chars)`);
      return { text, usedKey: key };
    } catch (e) {
      clearTimeout(timer);
      // FIX: Do NOT mark key as exhausted on AbortError (timeout).
      // A timeout means Gemini needed more time — NOT that the key is rate-limited.
      // Marking timed-out keys as exhausted drains the pool and causes FAKE exhaustion.
      // Only add to exhausted for genuine API errors (not abort/network drops).
      const isAbort = e instanceof DOMException && e.name === 'AbortError';
      const isKeyError = e instanceof Error && e.message.startsWith('key ');
      if (!isAbort && !isKeyError) {
        exhausted.add(key);
      }
      throw e;
    }
  };

  try {
    const result = await Promise.any(candidates.map(k => attemptKey(k)));
    return result;
  } catch (e) {
    console.warn(`[QUANTUM-V8] All ${candidates.length} parallel keys failed — no fallback available`);
    return null;
  }
}


// ============================================================
// DIRECTION NORMALIZATION
// ============================================================
function normalizeDirection(dir: string, fullJson: string, fallbackCandles?: string): 'UP' | 'DOWN' {
  const d = (dir || '').trim().toUpperCase();
  if (d === 'UP' || d === 'DOWN') return d;
  if (d === 'CALL' || d === 'BUY' || d === 'BULLISH') return 'UP';
  if (d === 'PUT' || d === 'SELL' || d === 'BEARISH') return 'DOWN';

  // FIX: Keyword count ONLY on the direction field value, not the full JSON.
  // Previously: counted "UP"/"DOWN" in the entire JSON response — this caused wrong flips
  // because the reasoning text contains many directional words unrelated to the trade signal
  // (e.g., "price moving UP toward resistance" → counted as UP even if signal is DOWN).
  // Now: try to extract just the "direction" field value first, then last-candle fallback.
  const dirFieldMatch = fullJson.match(/"direction"\s*:\s*"([^"]+)"/i);
  if (dirFieldMatch) {
    const extracted = dirFieldMatch[1].toUpperCase().trim();
    if (extracted === 'UP' || extracted === 'CALL' || extracted === 'BUY') return 'UP';
    if (extracted === 'DOWN' || extracted === 'PUT' || extracted === 'SELL') return 'DOWN';
  }

  // Last candle fallback (price-based — ground truth)
  if (fallbackCandles) {
    const rows = fallbackCandles.trim().split('\n').filter(r => !r.startsWith('#'));
    const last = rows[rows.length - 1]?.split(',');
    if (last && last.length >= 5) {
      const open = parseFloat(last[1]);
      const close = parseFloat(last[4]);
      if (!isNaN(open) && !isNaN(close) && open !== close) {
        return close >= open ? 'UP' : 'DOWN';
      }
    }
  }
  return 'UP';
}

// ============================================================
// MAIN HANDLER
// ============================================================
serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const startTime = Date.now();
  // Each request keeps its own deadline — no module-level global to avoid cross-request pollution.
  const localDeadline = startTime + REQUEST_DEADLINE_MS;
  const _timeLeftMs = makeTimeLeft(localDeadline); // request-scoped closure, safe for concurrent requests

  try {
    const body = await req.json();
    const { pair, candlesCSV } = body as { pair: string; candlesCSV?: string };

    if (!pair) {
      return new Response(JSON.stringify({ error: 'pair is required' }), {
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log(`[QUANTUM-V7] Starting analysis for ${pair}`);

    const keyPool = buildKeyPool();
    const aiPoolEmpty = keyPool.length === 0;
    if (aiPoolEmpty) {
      console.warn('[QUANTUM-V8] No live Gemini keys available — will rely on pillar fallback only (PILLAR_ONLY mode)');
    }

    const exhausted = new Set<string>();

    // ── STAGE 1: Deep 18-step analysis + Live Signal Pillar in parallel ──
    let stage1CSV = await fetchFreshCandles(pair);
    if (!stage1CSV && candlesCSV) {
      console.log('[QUANTUM-V8] Falling back to client candles for Stage 1');
      stage1CSV = candlesCSV;
    }
    if (!stage1CSV) {
      return new Response(JSON.stringify({ error: 'Unable to fetch market data for ' + pair }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const stage1Prompt = buildStage1Prompt(stage1CSV, pair);
    let stage1Result: Record<string, any> | null = null;

    // STAGE1_DEADLINE = 100s: gives Stage 1 full analysis time while guaranteeing
    // Stage 2 gets at least 70s (REQUEST_DEADLINE 175s - 100s = 75s buffer).
    // With thinkingBudget=10000, Stage 1 typically completes in 35-55s (well under 100s).
    const STAGE1_DEADLINE = 100000;

    // Run Stage 1 AI + Live Signal Pillar in PARALLEL (same as analyze-chart)
    const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY') || '';
    const forwardedAuth = req.headers.get('authorization') || '';
    const authHeader = forwardedAuth || `Bearer ${supabaseAnonKey}`;

    console.log(`[QUANTUM-V8] Stage 1 + Live Signal Pillar starting in parallel... (${keyPool.length - exhausted.size} live keys)`);

    const [s1Response, lsResult] = await Promise.allSettled([
      // AI Stage 1
      callGemini(stage1Prompt, keyPool, STAGE1_MAX_TOKENS, STAGE1_THINKING_BUDGET, STAGE1_DEADLINE, exhausted),
      // Live Signal Pillar engine (for pillar analysis + scoring data)
      (async () => {
        try {
          const res = await fetch(`${supabaseUrl}/functions/v1/live-signal`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': authHeader },
            body: JSON.stringify({ market: pair, source: 'telegram-signal', skipWait: true }),
          });
          if (res.ok) return await res.json();
          console.error('[QUANTUM-V8] Live signal pillar failed:', res.status);
          return null;
        } catch (e) {
          console.error('[QUANTUM-V8] Live signal pillar error:', e);
          return null;
        }
      })(),
    ]);

    const s1Data = s1Response.status === 'fulfilled' ? s1Response.value : null;
    if (s1Data?.text) {
      stage1Result = parseGeminiJson(s1Data.text);
      console.log('[QUANTUM-V8] Stage 1 completed:', stage1Result?.direction, stage1Result?.confidence);
    } else {
      console.log('[QUANTUM-V8] Stage 1 timed out or failed');
    }

    const liveSignalData = lsResult.status === 'fulfilled' ? lsResult.value : null;
    if (liveSignalData) {
      console.log('[QUANTUM-V8] Live Signal Pillar data received');
    }

    // ── STAGE 2: Full Power Re-Analysis — original 4th candle targeting with fresh data ──
    const elapsed = Date.now() - startTime;
    const stage2Deadline = Math.max(65000, 170000 - elapsed); // At least 65s: enough for thinkingBudget=5000 + output

    exhausted.clear();
    // FIX: Rebuild key pool before Stage 2 — during Stage 1 (~120s), cooldowns that were
    // set in this or a previous request may have expired. The old keyPool misses those
    // recovered keys, so Stage 2 would use a staler, smaller pool than necessary.
    const stage2KeyPool = buildKeyPool();
    const stage2PoolGain = stage2KeyPool.length - keyPool.length;
    console.log(`[QUANTUM-V8] Stage 2 key pool rebuilt: ${stage2KeyPool.length} live keys (${stage2PoolGain >= 0 ? '+' : ''}${stage2PoolGain} vs Stage 1)`);

    // Fetch fresh candles again (captures candles formed during Stage 1)
    let stage2CSV = await fetchFreshCandles(pair);
    if (!stage2CSV) {
      stage2CSV = stage1CSV; // reuse Stage 1 data
    }

    const stage2Prompt = buildStage2Prompt(stage2CSV, pair, stage1Result);
    let stage2Result: Record<string, any> | null = null;

    console.log(`[QUANTUM-V8] Stage 2 starting... (${Math.round(stage2Deadline/1000)}s budget, ${Math.round(elapsed/1000)}s elapsed)`);
    // FIX: Use stage2KeyPool (rebuilt above) so Stage 2 benefits from any recovered keys
    const s2Response = await callGemini(
      stage2Prompt, stage2KeyPool, STAGE2_MAX_TOKENS, STAGE2_THINKING_BUDGET, stage2Deadline, exhausted
    );

    if (s2Response?.text) {
      stage2Result = parseGeminiJson(s2Response.text);
      console.log('[QUANTUM-V8] Stage 2 completed:', stage2Result?.direction, stage2Result?.confidence);
    } else {
      console.log('[QUANTUM-V8] Stage 2 timed out or failed');
    }

    // ── FINAL MERGE: AI Result ──
    let aiResult: Record<string, any> | null = null;
    let reasoningPrefix = '';

    if (stage2Result) {
      const s1Info = stage1Result
        ? `Stage1:${stage1Result.direction} ${stage1Result.confidence}% in ${Math.round((Date.now() - startTime) / 1000)}s`
        : 'Stage1:FAILED';
      reasoningPrefix = `[V8 DUAL-STAGE | ${s1Info} | Stage2 sniper confirmed]`;
      aiResult = { ...stage2Result };
      aiResult.reasoning = reasoningPrefix + ' ' + (stage2Result.reasoning || '');
      // Carry forward Stage 1 detailed analysis
      if (stage1Result) {
        aiResult.trend = stage1Result.trend || aiResult.trend;
        aiResult.structure = stage1Result.structure || aiResult.structure;
        aiResult.momentum = stage1Result.momentum || aiResult.momentum;
        aiResult.support_resistance = stage1Result.support_resistance || aiResult.support_resistance;
        aiResult.candle_pattern = stage1Result.candle_pattern || aiResult.candle_pattern;
      }
    } else if (stage1Result) {
      reasoningPrefix = '[V8 STAGE 1 ONLY — Stage 2 sniper failed]';
      aiResult = { ...stage1Result };
      aiResult.reasoning = reasoningPrefix + ' ' + (stage1Result.reasoning || '');
    }

    if (!aiResult && !liveSignalData?.analysis) {
      // FIX: Never 503. Last-resort: 3-candle majority vote for direction.
      console.warn('[QUANTUM-V8] Both AI and pillar failed — using last-resort candle direction');
      const csvToUse = stage2CSV || stage1CSV || '';
      const rows = csvToUse.trim().split('\n').filter((r: string) => !r.startsWith('#') && r.trim());
      const last3 = rows.slice(-3);
      let upVotes = 0; let downVotes = 0;
      for (const row of last3) {
        const parts = row.split(',');
        if (parts.length >= 5) {
          const o = parseFloat(parts[1]); const c = parseFloat(parts[4]);
          if (!isNaN(o) && !isNaN(c)) { if (c >= o) upVotes++; else downVotes++; }
        }
      }
      const lastResortDir = upVotes >= downVotes ? 'UP' : 'DOWN';
      console.log(`[QUANTUM-V8] Last-resort candle: ${lastResortDir} (up:${upVotes} dn:${downVotes})`);
      return new Response(JSON.stringify({
        direction: lastResortDir, confidence: 55,
        trend: '', structure: '', momentum: '', support_resistance: '', candle_pattern: '',
        reasoning: '[LAST RESORT — AI and pillar unavailable. Candle direction used.]',
        stage1Direction: null, stage1Confidence: null,
        totalMs: Date.now() - startTime, recommendedClientDelayMs: 0,
        targetDeliveryAt: new Date().toISOString(),
        analysis: null, payout: null, selfCorrection: null,
        filtered: false, filterReason: null, matchStatus: 'CANDLE_FALLBACK',
        aiDirection: null, aiConfidence: null,
        liveSignalDirection: null, liveSignalConfidence: null,
        pillarAnalysis: null, scoring: null,
      }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    if (!aiResult) {
      console.warn('[QUANTUM-V8] AI stages unavailable — using live-signal pillar fallback response');
    }

    // Direction normalization — GUARD against null aiResult
    if (aiResult) {
      aiResult.direction = normalizeDirection(String(aiResult.direction || ''), JSON.stringify(aiResult), stage2CSV || stage1CSV);
      if (isNaN(Number(aiResult.confidence))) aiResult.confidence = 60;
      aiResult.confidence = Math.min(95, Math.max(50, Number(aiResult.confidence)));
    }

    // ════════ AI AUTHORITY MODE — Pillar FOLLOWS AI Direction (same as live-signal + chart-analyzer) ════════
    const analysis = (liveSignalData?.analysis ?? {}) as Record<string, unknown>;
    const scoring = (liveSignalData?.scoring ?? {}) as Record<string, unknown>;
    let pillarData = (scoring.pillarAnalysis ?? null) as Record<string, unknown> | null;

    const lsDirection = (analysis.direction as string || '').toUpperCase();
    const lsConfidence = Number(analysis.confidence ?? 0);

    const aiDirection = aiResult ? (aiResult.direction === 'UP' ? 'CALL' : aiResult.direction === 'DOWN' ? 'PUT' : null) : null;
    const aiConfidence = Number(aiResult?.confidence ?? 0);

    console.log(`[QUANTUM-V8] AI Authority Mode: AI=${aiDirection}(${aiConfidence}%) | Pillar=${lsDirection}(${lsConfidence}%)`);

    let finalDirection = 'NO_SIGNAL';
    let finalConfidence = 0;
    let matchStatus = 'NO_MATCH';

    // AI AUTHORITY + PILLAR FOLLOWS AI:
    // 1. AI UP → CALL + Force Pillar 1 (Uptrend DNA)
    // 2. AI DOWN → PUT + Force Pillar 2 (Downtrend DNA)
    // 3. Only fire if confidence > 50%
    // 4. Pillar forced to align — no independent decision

    if (aiDirection && aiConfidence > 50) {
      finalDirection = aiResult?.direction || (aiDirection === 'CALL' ? 'UP' : 'DOWN');
      finalConfidence = aiConfidence;

      // Force pillar to match AI direction
      const forcedPillar = aiDirection === 'CALL' ? 'Pillar 1: Uptrend DNA (AI-FORCED)' : 'Pillar 2: Downtrend DNA (AI-FORCED)';
      console.log(`[QUANTUM-V8] 🎯 AI→PILLAR: ${aiDirection} → Forced ${forcedPillar}`);

      pillarData = {
        ...(pillarData || {}),
        pillarName: forcedPillar,
        lockedDirection: aiDirection,
        trendDirection: aiDirection === 'CALL' ? 'UPTREND' : 'DOWNTREND',
        forcedByAI: true,
      };

      // Check if pillar originally agreed
      if (lsDirection === aiDirection || (lsDirection === 'UP' && aiDirection === 'CALL') || (lsDirection === 'DOWN' && aiDirection === 'PUT')) {
        matchStatus = 'DUAL_CONFIRMED';
        finalConfidence = Math.min(98, aiConfidence + 5);
        console.log(`[QUANTUM-V8] ✅ AI AUTHORITY + PILLAR AGREES: ${finalDirection} @ ${finalConfidence}%`);
      } else {
        matchStatus = 'AI_AUTHORITY';
        console.log(`[QUANTUM-V8] 🎯 AI AUTHORITY: ${finalDirection} @ ${finalConfidence}% (Pillar forced to align)`);
      }
    } else if (aiDirection && aiConfidence <= 50) {
      // FIX: AI low-confidence — fall through to pillar before blocking. Never block if pillar exists.
      if ((lsDirection === 'CALL' || lsDirection === 'PUT' || lsDirection === 'UP' || lsDirection === 'DOWN') && lsConfidence > 0) {
        finalDirection = lsDirection === 'CALL' ? 'UP' : lsDirection === 'PUT' ? 'DOWN' : lsDirection;
        finalConfidence = Math.max(55, lsConfidence);
        matchStatus = 'PILLAR_FALLBACK';
        console.log(`[QUANTUM-V8] ⚠️ AI low-conf (${aiConfidence}%) → PILLAR FALLBACK: ${finalDirection} @ ${finalConfidence}%`);
      } else {
        // FIX: Even with no pillar, use the AI direction at floor 55% — never return NO_SIGNAL
        finalDirection = aiResult?.direction || 'UP';
        finalConfidence = 55;
        matchStatus = 'AI_AUTHORITY';
        console.log(`[QUANTUM-V8] ⚠️ AI low-conf ${aiConfidence}%, no pillar — forcing AI direction at 55%: ${finalDirection}`);
      }
    } else if (!aiDirection && (lsDirection === 'CALL' || lsDirection === 'PUT' || lsDirection === 'UP' || lsDirection === 'DOWN') && lsConfidence >= 50) {
      finalDirection = lsDirection === 'CALL' ? 'UP' : lsDirection === 'PUT' ? 'DOWN' : lsDirection;
      finalConfidence = Math.max(55, lsConfidence);
      matchStatus = aiPoolEmpty ? 'PILLAR_ONLY' : 'PILLAR_FALLBACK';
      console.log(`[QUANTUM-V8] 🔄 ${aiPoolEmpty ? 'PILLAR_ONLY' : 'PILLAR_FALLBACK'}: ${finalDirection} @ ${finalConfidence}%`);
    } else if (!aiDirection && (lsDirection === 'CALL' || lsDirection === 'PUT' || lsDirection === 'UP' || lsDirection === 'DOWN') && lsConfidence > 0) {
      // FIX: Sub-50 pillar is still better than no signal — rescue at 55%
      finalDirection = lsDirection === 'CALL' ? 'UP' : lsDirection === 'PUT' ? 'DOWN' : lsDirection;
      finalConfidence = 55;
      matchStatus = aiPoolEmpty ? 'PILLAR_ONLY' : 'PILLAR_FALLBACK';
      console.log(`[QUANTUM-V8] 🔄 Low-conf pillar rescued at 55%: ${finalDirection}`);
    } else {
      // FIX: Absolute last resort inside the direction block — derive from candles.
      // This fires only when: AI failed AND live-signal returned no direction at all.
      // (Normal case handled by CANDLE_FALLBACK block above, this is the intra-block guard.)
      const csvForFallback = stage2CSV || stage1CSV || '';
      const fbRows = csvForFallback.trim().split('\n').filter((r: string) => !r.startsWith('#') && r.trim());
      const fbLast = fbRows[fbRows.length - 1]?.split(',');
      let fbDir = 'UP';
      if (fbLast && fbLast.length >= 5) {
        const fbO = parseFloat(fbLast[1]); const fbC = parseFloat(fbLast[4]);
        if (!isNaN(fbO) && !isNaN(fbC)) fbDir = fbC >= fbO ? 'UP' : 'DOWN';
      }
      finalDirection = fbDir;
      finalConfidence = 55;
      matchStatus = 'CANDLE_FALLBACK';
      console.log(`[QUANTUM-V8] ⚠️ No AI/pillar direction — last-candle fallback: ${finalDirection}`);
    }

    const signalFiltered = finalDirection === 'NO_SIGNAL';
    const filterReason = signalFiltered ? `Confidence ${finalConfidence}% <= 50% threshold or no direction` : null;

    if (signalFiltered) {
      console.log(`[QUANTUM-V8] ⚠️ Signal BLOCKED: ${filterReason}`);
    }

    const totalMs = Date.now() - startTime;
    const recommendedClientDelayMs = Math.max(0, TARGET_SIGNAL_WINDOW_MS - totalMs);
    const targetDeliveryAt = new Date(startTime + TARGET_SIGNAL_WINDOW_MS).toISOString();
    console.log(`[QUANTUM-V8] Complete in ${totalMs}ms — ${finalDirection} @ ${finalConfidence}% [${matchStatus}]`);

    return new Response(JSON.stringify({
      direction: signalFiltered ? 'NO_SIGNAL' : finalDirection,
      confidence: finalConfidence,
      trend: aiResult?.trend || '',
      structure: aiResult?.structure || '',
      momentum: aiResult?.momentum || '',
      support_resistance: aiResult?.support_resistance || '',
      candle_pattern: aiResult?.candle_pattern || '',
      reasoning: aiResult?.reasoning || '',
      stage1Direction: stage1Result?.direction || null,
      stage1Confidence: stage1Result?.confidence || null,
      totalMs,
      recommendedClientDelayMs,
      targetDeliveryAt,
      // BUG FIX: Expose internal live-signal data so frontend can use market data
      // (currentPrice, rsi, support etc.) even when the frontend's own live-signal call fails.
      analysis: liveSignalData?.analysis || null,
      payout: (liveSignalData as any)?.payout || null,
      selfCorrection: (liveSignalData as any)?.selfCorrection || null,
      // AI Authority + Pillar
      filtered: signalFiltered,
      filterReason,
      matchStatus,
      aiDirection: aiDirection || null,
      aiConfidence: aiConfidence || null,
      liveSignalDirection: lsDirection || null,
      liveSignalConfidence: lsConfidence || null,
      pillarAnalysis: pillarData ? {
        pillar: (pillarData as any).pillarName || (pillarData as any).pillar || null,
        trend: (pillarData as any).trendName || (pillarData as any).trendDirection || null,
        trendScore: (pillarData as any).confidence || null,
        confidence: (pillarData as any).confidence || null,
        lockedDirection: (pillarData as any).lockedDirection || null,
        pillarBoost: (pillarData as any).pillarBoost || 0,
        gatedStrategies: (pillarData as any).gatedStrategies || 0,
        totalStrategies: (pillarData as any).totalStrategies || 0,
      } : null,
      // Live signal scoring data
      scoring: liveSignalData?.scoring || null,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (err) {
    console.error('[QUANTUM-V8] Fatal error:', err);
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
