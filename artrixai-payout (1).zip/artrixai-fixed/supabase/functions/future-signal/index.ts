import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// ═══════════════════════════════════════════════════════════
// GEMINI API KEY ROTATION POOL (up to 25 keys)
// ═══════════════════════════════════════════════════════════

const GEMINI_KEY_NAMES = [
  'GEMINI_API_KEY', 'GEMINI_API_KEY_2', 'GEMINI_API_KEY_3', 'GEMINI_API_KEY_4',
  'GEMINI_API_KEY_5', 'GEMINI_API_KEY_6', 'GEMINI_API_KEY_7', 'GEMINI_API_KEY_8',
  'GEMINI_API_KEY_9', 'GEMINI_API_KEY_10', 'GEMINI_API_KEY_11',
  'GEMINI_API_KEY_12', 'GEMINI_API_KEY_13', 'GEMINI_API_KEY_14', 'GEMINI_API_KEY_15',
  'GEMINI_API_KEY_16', 'GEMINI_API_KEY_17', 'GEMINI_API_KEY_18', 'GEMINI_API_KEY_19',
  'GEMINI_API_KEY_20', 'GEMINI_API_KEY_21', 'GEMINI_API_KEY_22', 'GEMINI_API_KEY_23',
  'GEMINI_API_KEY_24', 'GEMINI_API_KEY_25',
];

function getGeminiKeys(): string[] {
  return GEMINI_KEY_NAMES
    .map(name => Deno.env.get(name))
    .filter((k): k is string => !!k && k.length > 10);
}

let keyIndex = Math.floor(Math.random() * GEMINI_KEY_NAMES.length);
function getNextKey(keys: string[]): string {
  keyIndex = (keyIndex + 1) % keys.length;
  return keys[keyIndex];
}

// ═══════════════════════════════════════════════════════════
// CANDLE DATA TYPES & FETCHING
// ═══════════════════════════════════════════════════════════

interface Candle {
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  time: string;
}

const PAIR_API_MAP: Record<string, string> = {
  'AXP-OTC': 'AXP_otc', 'PFE-OTC': 'PFE_otc', 'INTL-OTC': 'INTL_otc',
  'JNJ-OTC': 'JNJ_otc', 'MCD-OTC': 'MCD_otc', 'FB-OTC': 'FB_otc',
  'BA-OTC': 'BA_otc', 'MSFT-OTC': 'MSFT_otc',
  'USCrude-OTC': 'USCrude_otc', 'UKBrent-OTC': 'UKBrent_otc',
  'FLOUSD-OTC': 'FLOUSD_otc',
};

function extractApiVolume(c: any): number {
  const parsed = Number(c?.volume ?? c?.v ?? c?.Volume ?? c?.vol ?? c?.tick_volume ?? 0);
  return Number.isFinite(parsed) ? parsed : 0;
}

function extractApiTime(c: any): string {
  const directTime = c?.time ?? c?.datetime ?? c?.candle_time;
  if (directTime) return String(directTime);

  const epoch = Number(c?.epoch);
  if (Number.isFinite(epoch) && epoch > 0) {
    return new Date(epoch * 1000).toISOString();
  }

  return '';
}

function parseCandles(text: string): Candle[] {
  let json = text;
  const arrMatch = text.match(/\[[\s\S]*\]/);
  if (arrMatch) {
    json = arrMatch[0];
  } else {
    const objMatch = text.match(/\{[\s\S]*\}/);
    if (objMatch) {
      try {
        const obj = JSON.parse(objMatch[0]);
        if (obj.candles) json = JSON.stringify(obj.candles);
        else if (obj.data) json = JSON.stringify(obj.data);
        else json = objMatch[0];
      } catch {
        return [];
      }
    } else {
      return [];
    }
  }

  const raw = JSON.parse(json);
  if (!Array.isArray(raw)) return [];

  const candles: Candle[] = raw
    .map((c: any) => ({
      open: parseFloat(c.open ?? c.o ?? 0),
      high: parseFloat(c.high ?? c.h ?? 0),
      low: parseFloat(c.low ?? c.l ?? 0),
      close: parseFloat(c.close ?? c.c ?? 0),
      volume: extractApiVolume(c),
      time: extractApiTime(c),
    }))
    .filter((c: Candle) => c.open > 0 && c.close > 0 && !!c.time);

  candles.sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime());
  if (candles.length > 1) candles.pop();

  console.log(`[DATA] Parsed ${candles.length} candles | API volume non-zero: ${candles.filter(c => c.volume > 0).length}/${candles.length} (no fallback)`);
  return candles;
}

async function fetchLiveCandles(pair: string): Promise<Candle[]> {
  const apiPair = PAIR_API_MAP[pair] || pair.replace('-OTC', '_otc');
  const url = `https://quotexcandles.bdtraderpro.xyz/proversion/quotexcandles/Qx.php?pair=${encodeURIComponent(apiPair)}&timeframe=M1&count=2000`;

  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      console.log(`[DATA] Fetching live candles (attempt ${attempt}): ${url}`);
      const response = await fetch(url, { signal: AbortSignal.timeout(20000) });
      if (!response.ok) {
        console.warn(`[DATA] HTTP ${response.status} for ${pair}, attempt ${attempt}`);
        if (attempt < 3) {
          await new Promise(r => setTimeout(r, attempt * 2000));
          continue;
        }
        return [];
      }

      const raw = await response.json();
      const candleArray = Array.isArray(raw) ? raw : (raw.data || raw.candles || []);
      if (!candleArray.length) {
        console.warn(`[DATA] No candle data in response for ${pair}`);
        if (attempt < 3) {
          await new Promise(r => setTimeout(r, 2000));
          continue;
        }
        return [];
      }

      const candles: Candle[] = candleArray
        .map((c: any) => ({
          open: parseFloat(c.open ?? c.o ?? 0),
          high: parseFloat(c.high ?? c.h ?? 0),
          low: parseFloat(c.low ?? c.l ?? 0),
          close: parseFloat(c.close ?? c.c ?? 0),
          volume: extractApiVolume(c),
          time: extractApiTime(c),
        }))
        .filter((c: Candle) => c.open > 0 && c.close > 0 && !!c.time);

      candles.sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime());
      if (candles.length > 1) candles.pop();

      console.log(`[DATA] Got ${candles.length} candles for ${pair} | API volume non-zero: ${candles.filter(c => c.volume > 0).length}/${candles.length} (no fallback)`);
      if (candles.length > 0) return candles;

      if (attempt < 3) {
        await new Promise(r => setTimeout(r, 2000));
        continue;
      }
      return [];
    } catch (err) {
      console.error(`[DATA] Attempt ${attempt} failed for ${pair}:`, err);
      if (attempt < 3) await new Promise(r => setTimeout(r, attempt * 2000));
    }
  }

  return [];
}

async function fetchBacktestCandles(pair: string): Promise<Candle[]> {
  try {
    const apiPair = PAIR_API_MAP[pair] || pair.replace('-OTC', '_otc');
    const url = `https://quotexcandles.bdtraderpro.xyz/proversion/checker/Qxotc_checker.php/?pair=${encodeURIComponent(apiPair)}&timeframe=M1&day=1-10`;
    console.log(`[DATA] Fetching backtest candles: ${url}`);
    const response = await fetch(url, { signal: AbortSignal.timeout(25000) });
    if (!response.ok) return [];
    return parseCandles(await response.text());
  } catch (err) {
    console.error(`[DATA] Failed to fetch backtest candles for ${pair}:`, err);
    return [];
  }
}

// ═══════════════════════════════════════════════════════════
// ENHANCED TECHNICAL ANALYSIS ENGINE
// ═══════════════════════════════════════════════════════════

function ema(data: number[], period: number): number {
  if (data.length < period) return data[data.length - 1] || 0;
  const k = 2 / (period + 1);
  let val = data.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < data.length; i++) val = data[i] * k + val * (1 - k);
  return val;
}

function sma(data: number[], period: number): number {
  const slice = data.slice(-period);
  return slice.reduce((a, b) => a + b, 0) / slice.length;
}

function linRegSlope(data: number[]): number {
  const n = data.length;
  if (n < 2) return 0;
  let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
  for (let i = 0; i < n; i++) {
    sumX += i; sumY += data[i]; sumXY += i * data[i]; sumX2 += i * i;
  }
  return (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
}

interface TechnicalSummary {
  // Trend
  ema9: number; ema13: number; ema20: number; ema50: number; ema100: number; ema200: number;
  emaStack: string; ema20Angle: number;
  trendShort: string; trendMedium: string; trendLong: string;
  linRegSlope20: number; linRegSlope50: number;
  // Momentum
  rsi4: number; rsi7: number; rsi14: number; rsi21: number;
  macdLine: number; macdSignal: number; macdHistogram: number;
  stochK: number; stochD: number;
  cci: number; williamsR: number;
  roc5: number; roc10: number;
  // Volume
  volume: number; avgVolume20: number; avgVolume50: number; volumeRatio: number;
  obvTrend: string; mfi: number;
  // Volatility
  atr14: number; atrRatio: number;
  bbUpper: number; bbMiddle: number; bbLower: number; bbWidth: number; bbPosition: number;
  bbSqueeze: boolean; bbExpanding: boolean;
  // Price Action
  lastClose: number; lastOpen: number; lastHigh: number; lastLow: number;
  bodySize: number; upperWick: number; lowerWick: number; range: number; avgBody: number;
  isBullish: boolean; isDoji: boolean; isMarubozu: boolean;
  consecutiveSameColor: number; consecutiveDirection: string;
  // Levels
  support: number; resistance: number;
  nearRoundNumber: boolean; roundNumberDistance: number;
  distanceToSupport: number; distanceToResistance: number;
  // Structure
  hhCount: number; hlCount: number; lhCount: number; llCount: number;
  adxApprox: number;
  // Last candle time
  candleTime: string;
}

function calculateTechnicalSummary(candles: Candle[]): TechnicalSummary | null {
  if (candles.length < 200) return null;
  
  const closes = candles.map(c => c.close);
  const highs = candles.map(c => c.high);
  const lows = candles.map(c => c.low);
  const volumes = candles.map(c => c.volume);
  const last = candles[candles.length - 1];
  const last50 = candles.slice(-50);

  // EMAs
  const ema9 = ema(closes, 9);
  const ema13 = ema(closes, 13);
  const ema20v = ema(closes, 20);
  const ema50v = ema(closes, 50);
  const ema100v = ema(closes, 100);
  const ema200v = ema(closes, 200);
  const prev20 = ema(closes.slice(0, -1), 20);
  const ema20Angle = ((ema20v - prev20) / (last.close || 1)) * 10000;

  // EMA Stack
  let emaStack = 'MIXED';
  if (ema9 > ema20v && ema20v > ema50v && ema50v > ema200v) emaStack = 'PERFECT_BULL';
  else if (ema9 < ema20v && ema20v < ema50v && ema50v < ema200v) emaStack = 'PERFECT_BEAR';
  else if (ema20v > ema50v && ema50v > ema200v) emaStack = 'BULL';
  else if (ema20v < ema50v && ema50v < ema200v) emaStack = 'BEAR';

  // Trend determination
  const trendShort = last.close > ema20v ? 'BULLISH' : last.close < ema20v ? 'BEARISH' : 'NEUTRAL';
  const trendMedium = ema20v > ema50v ? 'BULLISH' : ema20v < ema50v ? 'BEARISH' : 'NEUTRAL';
  const trendLong = ema50v > ema200v ? 'BULLISH' : ema50v < ema200v ? 'BEARISH' : 'NEUTRAL';

  // Linear Regression Slopes
  const avgPrice = sma(closes.slice(-50), 50);
  const linRegSlope20v = (linRegSlope(closes.slice(-20)) / avgPrice) * 10000;
  const linRegSlope50v = (linRegSlope(closes.slice(-50)) / avgPrice) * 10000;

  // RSI (multiple periods)
  function calcRSI(data: number[], period: number): number {
    const slice = data.slice(-(period + 1));
    let gains = 0, losses = 0;
    for (let i = 1; i < slice.length; i++) {
      const diff = slice[i] - slice[i - 1];
      if (diff > 0) gains += diff; else losses -= diff;
    }
    gains /= period; losses /= period;
    if (losses === 0) return 100;
    return 100 - (100 / (1 + gains / losses));
  }
  const rsi4 = calcRSI(closes, 4);
  const rsi7 = calcRSI(closes, 7);
  const rsi14 = calcRSI(closes, 14);
  const rsi21 = calcRSI(closes, 21);

  // MACD
  const ema12 = ema(closes, 12);
  const ema26 = ema(closes, 26);
  const macdLine = ema12 - ema26;
  // Signal line approximation
  const macdValues: number[] = [];
  for (let i = Math.max(0, closes.length - 50); i < closes.length; i++) {
    const slice = closes.slice(0, i + 1);
    macdValues.push(ema(slice, 12) - ema(slice, 26));
  }
  const macdSignal = ema(macdValues, 9);
  const macdHistogram = macdLine - macdSignal;

  // Stochastic
  const stochPeriod = 14;
  const stochLows = lows.slice(-stochPeriod);
  const stochHighs = highs.slice(-stochPeriod);
  const lowest14 = Math.min(...stochLows);
  const highest14 = Math.max(...stochHighs);
  const stochK = highest14 !== lowest14 ? ((last.close - lowest14) / (highest14 - lowest14)) * 100 : 50;
  // Smooth K for D
  const stochD = stochK; // Simplified

  // CCI
  const typicalPrices = candles.slice(-20).map(c => (c.high + c.low + c.close) / 3);
  const tpMean = sma(typicalPrices, 20);
  const meanDev = typicalPrices.reduce((a, tp) => a + Math.abs(tp - tpMean), 0) / typicalPrices.length;
  const cci = meanDev !== 0 ? ((typicalPrices[typicalPrices.length - 1] - tpMean) / (0.015 * meanDev)) : 0;

  // Williams %R
  const williamsR = highest14 !== lowest14 ? ((highest14 - last.close) / (highest14 - lowest14)) * -100 : -50;

  // Rate of Change
  const roc5 = closes.length > 5 ? ((last.close - closes[closes.length - 6]) / closes[closes.length - 6]) * 100 : 0;
  const roc10 = closes.length > 10 ? ((last.close - closes[closes.length - 11]) / closes[closes.length - 11]) * 100 : 0;

  // Volume
  const avgVolume20 = sma(volumes.slice(-20), 20);
  const avgVolume50 = sma(volumes.slice(-50), 50);
  const volumeRatio = avgVolume20 > 0 ? last.volume / avgVolume20 : 1;

  // OBV Trend
  let obv = 0;
  const obvValues: number[] = [];
  for (let i = 1; i < Math.min(50, candles.length); i++) {
    const idx = candles.length - 50 + i;
    if (idx < 1) continue;
    if (candles[idx].close > candles[idx - 1].close) obv += candles[idx].volume;
    else if (candles[idx].close < candles[idx - 1].close) obv -= candles[idx].volume;
    obvValues.push(obv);
  }
  const obvTrend = obvValues.length > 10
    ? (linRegSlope(obvValues.slice(-10)) > 0 ? 'RISING' : linRegSlope(obvValues.slice(-10)) < 0 ? 'FALLING' : 'FLAT')
    : 'FLAT';

  // MFI
  let mfiPositiveFlow = 0, mfiNegativeFlow = 0;
  for (let i = candles.length - 14; i < candles.length; i++) {
    if (i < 1) continue;
    const tp = (candles[i].high + candles[i].low + candles[i].close) / 3;
    const prevTp = (candles[i-1].high + candles[i-1].low + candles[i-1].close) / 3;
    const rawFlow = tp * candles[i].volume;
    if (tp > prevTp) mfiPositiveFlow += rawFlow;
    else mfiNegativeFlow += rawFlow;
  }
  const mfi = mfiNegativeFlow > 0 ? 100 - (100 / (1 + mfiPositiveFlow / mfiNegativeFlow)) : 100;

  // ATR
  const trValues: number[] = [];
  for (let i = candles.length - 14; i < candles.length; i++) {
    if (i < 1) continue;
    trValues.push(Math.max(
      candles[i].high - candles[i].low,
      Math.abs(candles[i].high - candles[i-1].close),
      Math.abs(candles[i].low - candles[i-1].close)
    ));
  }
  const atr14 = trValues.length > 0 ? trValues.reduce((a, b) => a + b, 0) / trValues.length : 0;
  
  // ATR average (for ratio)
  const trValuesLong: number[] = [];
  for (let i = Math.max(1, candles.length - 50); i < candles.length - 14; i++) {
    trValuesLong.push(Math.max(
      candles[i].high - candles[i].low,
      Math.abs(candles[i].high - candles[i-1].close),
      Math.abs(candles[i].low - candles[i-1].close)
    ));
  }
  const atrAvg = trValuesLong.length > 0 ? trValuesLong.reduce((a, b) => a + b, 0) / trValuesLong.length : atr14;
  const atrRatio = atrAvg > 0 ? atr14 / atrAvg : 1;

  // Bollinger Bands
  const bb20 = closes.slice(-20);
  const bbMiddle = sma(bb20, 20);
  const bbStd = Math.sqrt(bb20.reduce((a, b) => a + (b - bbMiddle) ** 2, 0) / bb20.length);
  const bbUpper = bbMiddle + 2 * bbStd;
  const bbLower = bbMiddle - 2 * bbStd;
  const bbWidth = bbUpper - bbLower;
  const bbPosition = bbWidth > 0 ? ((last.close - bbLower) / bbWidth) * 100 : 50;
  
  const prevBB = closes.slice(-21, -1);
  const prevMid = sma(prevBB, 20);
  const prevStd = Math.sqrt(prevBB.reduce((a, b) => a + (b - prevMid) ** 2, 0) / prevBB.length);
  const prevWidth = (prevMid + 2 * prevStd) - (prevMid - 2 * prevStd);
  const bbSqueeze = bbWidth < prevWidth * 0.85;
  const bbExpanding = bbWidth > prevWidth * 1.15;

  // Price Action
  const bodySize = Math.abs(last.close - last.open);
  const upperWick = last.high - Math.max(last.open, last.close);
  const lowerWick = Math.min(last.open, last.close) - last.low;
  const range = last.high - last.low || 0.00001;
  const avgBody = last50.reduce((a, c) => a + Math.abs(c.close - c.open), 0) / last50.length;
  const isBullish = last.close > last.open;
  const isDoji = bodySize < range * 0.15;
  const isMarubozu = bodySize > range * 0.85;

  // Consecutive same color
  let consecutiveSameColor = 0;
  const lastColor = isBullish;
  for (let i = candles.length - 1; i >= 0; i--) {
    if ((candles[i].close > candles[i].open) === lastColor) consecutiveSameColor++;
    else break;
  }

  // Support/Resistance (100 candles)
  const srCandles = candles.slice(-100);
  const support = Math.min(...srCandles.map(c => c.low));
  const resistance = Math.max(...srCandles.map(c => c.high));
  const distToSup = ((last.close - support) / last.close) * 100;
  const distToRes = ((resistance - last.close) / last.close) * 100;

  // Round number
  const roundDist = Math.min(
    Math.abs((last.close * 1000) % 1) / 1000,
    Math.abs(1 - (last.close * 1000) % 1) / 1000
  );
  const halfDist = Math.min(
    Math.abs((last.close * 1000 - 500) % 1000) / 1000,
    Math.abs(1000 - ((last.close * 1000 - 500) % 1000)) / 1000
  );
  const roundNumberDistance = Math.min(roundDist, halfDist);

  // Structure (5 segments of 50 candles)
  const structCandles = candles.slice(-50);
  const segLen = 10;
  let hhCount = 0, hlCount = 0, lhCount = 0, llCount = 0;
  for (let i = 1; i < 5; i++) {
    const prev = structCandles.slice((i-1) * segLen, i * segLen);
    const curr = structCandles.slice(i * segLen, (i+1) * segLen);
    if (prev.length && curr.length) {
      const prevHigh = Math.max(...prev.map(c => c.high));
      const currHigh = Math.max(...curr.map(c => c.high));
      const prevLow = Math.min(...prev.map(c => c.low));
      const currLow = Math.min(...curr.map(c => c.low));
      if (currHigh > prevHigh) hhCount++; else lhCount++;
      if (currLow > prevLow) hlCount++; else llCount++;
    }
  }

  return {
    ema9, ema13, ema20: ema20v, ema50: ema50v, ema100: ema100v, ema200: ema200v,
    emaStack, ema20Angle,
    trendShort, trendMedium, trendLong,
    linRegSlope20: linRegSlope20v, linRegSlope50: linRegSlope50v,
    rsi4, rsi7, rsi14, rsi21,
    macdLine, macdSignal, macdHistogram,
    stochK, stochD, cci, williamsR,
    roc5, roc10,
    volume: last.volume, avgVolume20, avgVolume50, volumeRatio,
    obvTrend, mfi,
    atr14, atrRatio,
    bbUpper, bbMiddle, bbLower, bbWidth, bbPosition,
    bbSqueeze, bbExpanding,
    lastClose: last.close, lastOpen: last.open, lastHigh: last.high, lastLow: last.low,
    bodySize, upperWick, lowerWick, range, avgBody,
    isBullish, isDoji, isMarubozu,
    consecutiveSameColor,
    consecutiveDirection: isBullish ? 'BULLISH' : 'BEARISH',
    support, resistance,
    nearRoundNumber: roundNumberDistance < 0.0003,
    roundNumberDistance,
    distanceToSupport: distToSup,
    distanceToResistance: distToRes,
    hhCount, hlCount, lhCount, llCount,
    adxApprox: Math.abs(ema20Angle) * 1.5,
    candleTime: last.time,
  };
}

// ═══════════════════════════════════════════════════════════
// BACKTEST STATISTICS ENGINE (7000+ candles)
// ═══════════════════════════════════════════════════════════

interface BacktestStats {
  totalCandles: number;
  bullishPercent: number;
  bearishPercent: number;
  avgBodySize: number;
  avgRange: number;
  explosiveMoves: number; // >3x avg body
  avgTrendPersistence: number;
  maxConsecutiveBull: number;
  maxConsecutiveBear: number;
  meanReversionRate: number; // % of 2x ATR moves that reverse within 5 candles
  hourlyBullPercent: Record<number, number>;
  supportClusters: number[];
  resistanceClusters: number[];
  recentPatterns: string[];
}

function calculateBacktestStats(candles: Candle[]): BacktestStats {
  const totalCandles = candles.length;
  let bullCount = 0, bearCount = 0;
  let totalBodySize = 0, totalRange = 0;
  let explosiveMoves = 0;
  const bodies: number[] = [];

  for (const c of candles) {
    const body = Math.abs(c.close - c.open);
    const range = c.high - c.low;
    bodies.push(body);
    totalBodySize += body;
    totalRange += range;
    if (c.close > c.open) bullCount++; else bearCount++;
  }

  const avgBody = totalBodySize / totalCandles;
  const avgRange = totalRange / totalCandles;

  // Explosive moves
  for (const b of bodies) {
    if (b > avgBody * 3) explosiveMoves++;
  }

  // Trend persistence
  let maxConsBull = 0, maxConsBear = 0, curCons = 0, curDir = true;
  const persistences: number[] = [];
  for (let i = 0; i < candles.length; i++) {
    const bull = candles[i].close > candles[i].open;
    if (bull === curDir) {
      curCons++;
    } else {
      persistences.push(curCons);
      if (curDir && curCons > maxConsBull) maxConsBull = curCons;
      if (!curDir && curCons > maxConsBear) maxConsBear = curCons;
      curDir = bull;
      curCons = 1;
    }
  }
  const avgPersistence = persistences.length > 0 ? persistences.reduce((a, b) => a + b, 0) / persistences.length : 1;

  // Mean reversion rate (sample last 2000)
  let reversionCount = 0, reversionTotal = 0;
  const sampleCandles = candles.slice(-Math.min(2000, candles.length));
  for (let i = 14; i < sampleCandles.length - 5; i++) {
    const localATR = sampleCandles.slice(i - 14, i).reduce((a, c) => a + (c.high - c.low), 0) / 14;
    const move = Math.abs(sampleCandles[i].close - sampleCandles[i - 1].close);
    if (move > localATR * 2) {
      reversionTotal++;
      const moveDir = sampleCandles[i].close > sampleCandles[i - 1].close;
      for (let j = 1; j <= 5 && i + j < sampleCandles.length; j++) {
        const reversal = moveDir
          ? sampleCandles[i + j].close < sampleCandles[i].close
          : sampleCandles[i + j].close > sampleCandles[i].close;
        if (reversal) { reversionCount++; break; }
      }
    }
  }

  // Hourly bull percentage (sample)
  const hourlyBull: Record<number, { bull: number; total: number }> = {};
  for (const c of sampleCandles) {
    if (!c.time) continue;
    const hour = new Date(c.time).getHours();
    if (!hourlyBull[hour]) hourlyBull[hour] = { bull: 0, total: 0 };
    hourlyBull[hour].total++;
    if (c.close > c.open) hourlyBull[hour].bull++;
  }
  const hourlyBullPercent: Record<number, number> = {};
  for (const [h, v] of Object.entries(hourlyBull)) {
    hourlyBullPercent[parseInt(h)] = Math.round((v.bull / v.total) * 100);
  }

  // Support/Resistance clusters (price density)
  const pricePoints = sampleCandles.flatMap(c => [c.low, c.high]);
  pricePoints.sort((a, b) => a - b);
  const step = (pricePoints[pricePoints.length - 1] - pricePoints[0]) / 20;
  const buckets: { price: number; count: number }[] = [];
  if (step > 0) {
    for (let p = pricePoints[0]; p <= pricePoints[pricePoints.length - 1]; p += step) {
      const count = pricePoints.filter(pp => pp >= p && pp < p + step).length;
      buckets.push({ price: p + step / 2, count });
    }
    buckets.sort((a, b) => b.count - a.count);
  }

  const currentPrice = candles[candles.length - 1].close;
  const supportClusters = buckets.filter(b => b.price < currentPrice).slice(0, 3).map(b => b.price);
  const resistanceClusters = buckets.filter(b => b.price > currentPrice).slice(0, 3).map(b => b.price);

  // Recent patterns (last 20 candles)
  const recentPatterns: string[] = [];
  const recent20 = candles.slice(-20);
  // Check for hammers, dojis, engulfings
  for (let i = 1; i < recent20.length; i++) {
    const c = recent20[i];
    const p = recent20[i - 1];
    const body = Math.abs(c.close - c.open);
    const range = c.high - c.low;
    const lw = Math.min(c.open, c.close) - c.low;
    const uw = c.high - Math.max(c.open, c.close);
    
    if (body < range * 0.15) recentPatterns.push(`Doji@${i}`);
    if (lw > body * 2.5 && uw < body * 0.5) recentPatterns.push(`Hammer@${i}`);
    if (uw > body * 2.5 && lw < body * 0.5) recentPatterns.push(`ShootingStar@${i}`);
    if (Math.abs(c.close - c.open) > Math.abs(p.close - p.open) * 1.5 &&
        (c.close > c.open) !== (p.close > p.open)) {
      recentPatterns.push(`Engulfing@${i}`);
    }
  }

  return {
    totalCandles,
    bullishPercent: Math.round((bullCount / totalCandles) * 100),
    bearishPercent: Math.round((bearCount / totalCandles) * 100),
    avgBodySize: avgBody,
    avgRange,
    explosiveMoves,
    avgTrendPersistence: Math.round(avgPersistence * 10) / 10,
    maxConsecutiveBull: maxConsBull,
    maxConsecutiveBear: maxConsBear,
    meanReversionRate: reversionTotal > 0 ? Math.round((reversionCount / reversionTotal) * 100) : 0,
    hourlyBullPercent,
    supportClusters,
    resistanceClusters,
    recentPatterns: recentPatterns.slice(0, 15),
  };
}

// ═══════════════════════════════════════════════════════════
// COMPACT CANDLE DATA FOR AI (last 50 candles)
// ═══════════════════════════════════════════════════════════

function formatRecentCandles(candles: Candle[], count: number = 50): string {
  const recent = candles.slice(-count);
  const lines = recent.map((c, i) => {
    const body = Math.abs(c.close - c.open);
    const dir = c.close > c.open ? '🟢' : '🔴';
    const time = c.time ? new Date(c.time).toISOString().slice(11, 16) : '??:??';
    return `${dir} ${time} O:${c.open.toFixed(5)} H:${c.high.toFixed(5)} L:${c.low.toFixed(5)} C:${c.close.toFixed(5)} V:${Math.round(c.volume)} B:${body.toFixed(5)}`;
  });
  return lines.join('\n');
}

// ═══════════════════════════════════════════════════════════
// 62-STEP ELITE PROTOCOL — WORLD-CLASS AI ANALYSIS PROMPT BUILDER
// ═══════════════════════════════════════════════════════════

function buildAnalysisPrompt(
  pair1: string, tech1: TechnicalSummary, backtest1: BacktestStats, recentCandles1: string,
  pair2: string | null, tech2: TechnicalSummary | null, backtest2: BacktestStats | null, recentCandles2: string | null,
  startTime: string, endTime: string
): string {
  function formatTech(pair: string, t: TechnicalSummary, b: BacktestStats, candles: string): string {
    return `
═══════════════════════════════════════════════════
📊 PAIR: ${pair}
═══════════════════════════════════════════════════

🔸 CURRENT PRICE: ${t.lastClose.toFixed(5)} | TIME: ${t.candleTime}
🔸 LAST CANDLE: O:${t.lastOpen.toFixed(5)} H:${t.lastHigh.toFixed(5)} L:${t.lastLow.toFixed(5)} C:${t.lastClose.toFixed(5)}
🔸 BODY: ${t.bodySize.toFixed(5)} | UPPER_WICK: ${t.upperWick.toFixed(5)} | LOWER_WICK: ${t.lowerWick.toFixed(5)} | RANGE: ${t.range.toFixed(5)}
🔸 AVG_BODY(50): ${t.avgBody.toFixed(5)} | BODY_RATIO: ${(t.bodySize / t.avgBody).toFixed(2)}x
🔸 TYPE: ${t.isDoji ? '🕯️DOJI' : t.isMarubozu ? '🏋️MARUBOZU' : t.isBullish ? '🟢BULLISH' : '🔴BEARISH'}
🔸 CONSECUTIVE: ${t.consecutiveSameColor} ${t.consecutiveDirection}

──── TREND & STRUCTURE ────
🔹 EMA9: ${t.ema9.toFixed(5)} | EMA13: ${t.ema13.toFixed(5)} | EMA20: ${t.ema20.toFixed(5)}
🔹 EMA50: ${t.ema50.toFixed(5)} | EMA100: ${t.ema100.toFixed(5)} | EMA200: ${t.ema200.toFixed(5)}
🔹 EMA_STACK: ${t.emaStack} | EMA20_ANGLE: ${t.ema20Angle.toFixed(2)}°
🔹 TREND_SHORT: ${t.trendShort} | TREND_MED: ${t.trendMedium} | TREND_LONG: ${t.trendLong}
🔹 LIN_REG_SLOPE_20: ${t.linRegSlope20.toFixed(3)} | LIN_REG_SLOPE_50: ${t.linRegSlope50.toFixed(3)}
🔹 STRUCTURE: HH=${t.hhCount} HL=${t.hlCount} LH=${t.lhCount} LL=${t.llCount}
🔹 ADX≈${t.adxApprox.toFixed(1)}

──── MOMENTUM & OSCILLATORS ────
🔹 RSI(4): ${t.rsi4.toFixed(1)} | RSI(7): ${t.rsi7.toFixed(1)} | RSI(14): ${t.rsi14.toFixed(1)} | RSI(21): ${t.rsi21.toFixed(1)}
🔹 MACD_LINE: ${t.macdLine.toFixed(6)} | SIGNAL: ${t.macdSignal.toFixed(6)} | HISTOGRAM: ${t.macdHistogram.toFixed(6)}
🔹 STOCH_K: ${t.stochK.toFixed(1)} | STOCH_D: ${t.stochD.toFixed(1)}
🔹 CCI: ${t.cci.toFixed(1)} | WILLIAMS_%R: ${t.williamsR.toFixed(1)}
🔹 ROC(5): ${t.roc5.toFixed(4)}% | ROC(10): ${t.roc10.toFixed(4)}%

──── VOLUME & LIQUIDITY ────
🔹 VOLUME: ${Math.round(t.volume)} | AVG_VOL_20: ${Math.round(t.avgVolume20)} | AVG_VOL_50: ${Math.round(t.avgVolume50)}
🔹 VOL_RATIO: ${t.volumeRatio.toFixed(2)}x | OBV_TREND: ${t.obvTrend} | MFI: ${t.mfi.toFixed(1)}

──── VOLATILITY ────
🔹 ATR(14): ${t.atr14.toFixed(5)} | ATR_RATIO: ${t.atrRatio.toFixed(2)}x
🔹 BB_UPPER: ${t.bbUpper.toFixed(5)} | BB_MID: ${t.bbMiddle.toFixed(5)} | BB_LOWER: ${t.bbLower.toFixed(5)}
🔹 BB_WIDTH: ${t.bbWidth.toFixed(5)} | BB_POSITION: ${t.bbPosition.toFixed(1)}%
🔹 BB_SQUEEZE: ${t.bbSqueeze ? '✅YES' : '❌NO'} | BB_EXPANDING: ${t.bbExpanding ? '✅YES' : '❌NO'}

──── KEY LEVELS ────
🔹 SUPPORT: ${t.support.toFixed(5)} (${t.distanceToSupport.toFixed(3)}% away)
🔹 RESISTANCE: ${t.resistance.toFixed(5)} (${t.distanceToResistance.toFixed(3)}% away)
🔹 ROUND_NUMBER: ${t.nearRoundNumber ? '⚠️NEAR' : '✅CLEAR'} (dist: ${t.roundNumberDistance.toFixed(5)})

──── BACKTEST DATA (${b.totalCandles.toLocaleString()} candles) ────
🔹 BULLISH: ${b.bullishPercent}% | BEARISH: ${b.bearishPercent}%
🔹 AVG_BODY: ${b.avgBodySize.toFixed(5)} | AVG_RANGE: ${b.avgRange.toFixed(5)}
🔹 EXPLOSIVE_MOVES(>3x): ${b.explosiveMoves} occurrences
🔹 TREND_PERSISTENCE: avg ${b.avgTrendPersistence} candles
🔹 MAX_CONSECUTIVE_BULL: ${b.maxConsecutiveBull} | MAX_BEAR: ${b.maxConsecutiveBear}
🔹 MEAN_REVERSION_RATE: ${b.meanReversionRate}% (of 2xATR moves reverse within 5 candles)
🔹 SUPPORT_CLUSTERS: ${b.supportClusters.map(p => p.toFixed(5)).join(', ') || 'none'}
🔹 RESISTANCE_CLUSTERS: ${b.resistanceClusters.map(p => p.toFixed(5)).join(', ') || 'none'}
🔹 RECENT_PATTERNS: ${b.recentPatterns.join(', ') || 'none'}
🔹 HOURLY_BULL%: ${Object.entries(b.hourlyBullPercent).map(([h, p]) => `H${h}:${p}%`).join(' ')}

──── LAST 50 CANDLES ────
${candles}
`;
  }

  const pair1Data = formatTech(pair1, tech1, backtest1, recentCandles1);
  const pair2Data = pair2 && tech2 && backtest2 && recentCandles2
    ? formatTech(pair2, tech2, backtest2, recentCandles2)
    : '';

  return `You are **QUANTUM-NEXUS V14 ELITE** — the world's most advanced binary options future signal prediction AI engine with institutional-grade Smart Money analysis.

⚡ YOUR MISSION: Analyze ${pair2 ? '2 currency pairs' : '1 currency pair'} using 2,000 live M1 candles + 7,000+ historical backtest candles and predict CALL/PUT signals with exact entry times within the window ${startTime} to ${endTime} (Bangladesh UTC+6).

🎯 SIGNAL GENERATION RULES:
- You MUST generate at least 3-5 signals per pair — there is ALWAYS a tradeable setup in any market condition
- Every market has a direction bias — trending, ranging, or reversing — USE IT to predict entries
- Confidence range 50-100%: high confidence (75%+) for strong setups, lower (50-65%) for weaker/uncertain ones
- Do NOT return an empty signals array — analyze the data deeply and find the best entry points
- Use trend persistence, mean reversion, hourly patterns, SMC, liquidity, and momentum to determine WHEN to enter

🔬 CRITICAL — FULL 62-STEP PER-SIGNAL ANALYSIS REQUIREMENT:
- You MUST complete ALL 62 steps across ALL 12 CATEGORIES thoroughly BEFORE generating any signal
- Each signal's "reasoning" MUST reference conclusions from ALL 12 CATEGORIES:
  ✅ Cat A (TREND): EMA stack, slope, structure, ADX verdict
  ✅ Cat B (MOMENTUM): RSI gradient, MACD histogram, Stochastic, CCI, divergence
  ✅ Cat C (VOLUME): Volume spike, OBV, MFI, climax verdict
  ✅ Cat D (CANDLES): Pattern detected, reversal/continuation type
  ✅ Cat E (KEY LEVELS): S/R distance, BB position, Fibonacci, round numbers
  ✅ Cat F (VOLATILITY): ATR regime, BB squeeze, risk-reward
  ✅ Cat G (SMC): Order blocks, FVG, BOS/CHoCH, institutional footprint
  ✅ Cat H (LIQUIDITY): Liquidity pools, sweeps, OTC traps, manipulation detection
  ✅ Cat I (BACKTEST): Win rate, explosive move AI-optimized best-entry, mean reversion
  ✅ Cat J (MARKET CONDITION): Condition type, confidence calibration, entry optimization
  ✅ Cat K (WYCKOFF): Accumulation/distribution phase, spring/upthrust, composite man
  ✅ Cat L (SYNTHESIS): Confluence count, anti-loss filters, final verdict
- DO NOT generate ANY signal without proving ALL 12 categories were analyzed
- Reasoning: 1000-2000 words with SPECIFIC indicator values from each category
- Confidence = how many of the 12 categories AGREE (12/12=95-100%, 10/12=83%, 8/12=67%)

═══════════════════════════════════════════════════════════════
🏆 62-STEP ELITE DIAGNOSTIC PROTOCOL (World-Class Precision)
═══════════════════════════════════════════════════════════════

📋 INSTRUCTIONS: Execute ALL 62 steps for EACH pair sequentially.
Each step has a UNIQUE analytical job — NO overlap.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌊 CATEGORY A — TREND & REGIME (Steps 1-6)
PURPOSE: Determine dominant trend direction, strength, and regime with surgical precision.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📌 Step 1: EMA Stack Hierarchy + Spacing Analysis
JOB: Classify EMA alignment (9/13/20/50/100/200) into: PERFECT_BULL, PERFECT_BEAR, BULL, BEAR, or MIXED.
- Measure EMA SPACING — tightly clustered EMAs = weak/transitional trend. Fan-out = strong conviction.
- Calculate distance between EMA9 and EMA200 as % of price. >0.5% = strong fan, <0.1% = compression.
- Check if EMA9 is ACCELERATING away from EMA20 (slope increasing) or DECELERATING (convergence approaching).
OUTPUT: Regime label, spacing grade (TIGHT/NORMAL/WIDE), acceleration status.

📌 Step 2: EMA20 Slope + Second Derivative (Momentum of Momentum)
JOB: Measure EMA20 angle AND its rate of change.
- Slope(5) > Slope(10) = ACCELERATING trend. Slope(5) < Slope(10) = DECELERATING trend.
- Check EMA9-EMA20 gap: narrowing = crossover imminent (within 3-5 candles estimate).
OUTPUT: Slope angle, acceleration/deceleration status, crossover proximity.

📌 Step 3: Price Structure — HH/HL vs LH/LL + BOS/CHoCH Detection
JOB: Count HH/HL (bullish) vs LH/LL (bearish) with structure break detection.
- BOS (Break of Structure): price takes out previous swing = trend continuation confirmed
- CHoCH (Change of Character): price breaks structure AGAINST trend = possible reversal
- Count clean swings (>2x ATR amplitude) vs noise swings (<0.5x ATR) — only count clean ones.
OUTPUT: Structure type, BOS/CHoCH detected, clean swing count, agreement score with Step 1.

📌 Step 4: Linear Regression + Channel Position
JOB: Use LR slope over 20 & 50 candle windows + measure position within LR channel.
- Price above LR line = extended upside (PUT bias building). Below = CALL bias building. AT = decision point.
- LR20 vs LR50 AGREEMENT: both positive = strong bull. Divergent = transition.
OUTPUT: LR slopes, channel position (UPPER/MIDDLE/LOWER), conviction level.

📌 Step 5: ADX Trend Strength + DI Directional Split
JOB: Classify ADX: <12=DEAD/CHOPPY, 12-20=WEAK, 20-30=DEVELOPING, 30-45=STRONG, >45=EXTREME.
- DI+ >> DI- = bullish dominance. DI- >> DI+ = bearish dominance. DI+ ≈ DI- = NO edge.
- ADX >45 + DI convergence = EXHAUSTION (reduce confidence by 10%).
OUTPUT: ADX value, strength class, DI split direction, exhaustion warning.

📌 Step 6: Final Market Regime Verdict
JOB: Synthesize Steps 1-5 with WEIGHTED scoring:
- EMA Stack (25%) + Structure (25%) + ADX/DI (25%) + LR Slope (15%) + EMA20 Momentum (10%)
- Must reach MAJORITY AGREEMENT (3/5+ components) for confident regime call.
OUTPUT: Regime verdict, confidence %, dissenting components.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🚀 CATEGORY B — MOMENTUM BATTERY (Steps 7-12)
PURPOSE: Multi-oscillator momentum assessment with divergence scanning.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📌 Step 7: RSI Multi-Period Gradient Analysis
JOB: Analyze RSI(4), RSI(7), RSI(14), RSI(21) simultaneously.
- GRADIENT: if RSI(4) > RSI(7) > RSI(14) > RSI(21) = BULLISH momentum cascade. Reverse = BEARISH cascade.
- DIVERGENCE: price making new high but RSI(14) making lower high = BEARISH divergence (or vice versa).
- HIDDEN DIVERGENCE: price making higher low + RSI making lower low = trend CONTINUATION signal.
- EXTREME ZONES: RSI(4) >90 or <10 = micro-extreme (1-2 candle reversal likely).
OUTPUT: Gradient direction, divergence type, hidden divergence, extreme alert.

📌 Step 8: Stochastic Zone + Crossover Timing
JOB: Stochastic position with cross precision.
- ZONE: >80=overbought, <20=oversold, 40-60=neutral.
- CROSS: %K crossing %D from below in oversold = CALL. From above in overbought = PUT.
- DOUBLE BOTTOM/TOP: Stochastic making two dips in oversold without crossing 50 = strong reversal setup.
- FAILURE SWING: %K fails to reach opposite extreme before reversing = momentum exhaustion.
OUTPUT: Zone, cross type, failure swing detected, directional bias.

📌 Step 9: MACD Histogram Momentum Dynamics
JOB: MACD histogram slope + zero-cross analysis.
- HISTOGRAM SLOPE: positive bars getting TALLER = ACCELERATING momentum. Getting shorter = DECELERATING.
- ZERO CROSS: histogram crossing zero = momentum shifting. Anticipate 1-2 candles ahead.
- MACD-SIGNAL DIVERGENCE: MACD line and signal line spreading apart = strong move continuing.
- SQUEEZE: MACD line very close to signal with tiny histogram = coiled energy, breakout imminent.
OUTPUT: Histogram trend, zero-cross proximity, MACD squeeze, momentum grade.

📌 Step 10: Rate of Change Burst Detection
JOB: ROC(5) and ROC(10) for explosive momentum detection.
- ROC(5) > 3x ROC(10) = SHORT-TERM BURST (micro trend starting).
- ROC(5) and ROC(10) same sign and strong = SUSTAINED momentum.
- ROC REVERSAL: ROC(5) flipping sign while ROC(10) holds = pullback in trend (entry opportunity).
- EXHAUSTION: ROC(5) at extreme (>99th percentile from backtest) = unsustainable, reversal imminent.
OUTPUT: Burst detected, sustained momentum, reversal signal, exhaustion warning.

📌 Step 11: CCI Extreme + Williams %R Confirmation
JOB: CCI and Williams %R dual-oscillator extreme detection.
- CCI >200 or <-200 = EXTREME (reversal zone). CCI crossing 0 = trend shift.
- Williams %R <-80 = oversold, >-20 = overbought. Cross confirmation with CCI.
- DUAL EXTREME: both CCI extreme AND Williams %R extreme = HIGH PROBABILITY reversal zone.
- CCI HOOK: CCI turns from extreme without reaching zero = weakening reversal (trend may resume).
OUTPUT: CCI zone, Williams %R zone, dual extreme confirmed, CCI hook alert.

📌 Step 12: Multi-Oscillator Divergence Scan
JOB: Scan ALL oscillators (RSI, MACD, Stochastic, CCI) for divergence alignment.
- SINGLE DIVERGENCE: 1 oscillator diverging = weak signal (60% reliability).
- DOUBLE DIVERGENCE: 2 oscillators diverging = moderate signal (72% reliability).
- TRIPLE DIVERGENCE: 3+ oscillators diverging = POWERFUL signal (85% reliability).
- CONVERGENCE: ALL oscillators agree with price = TREND CONTINUATION confirmed (no reversal expected).
OUTPUT: Divergence count, which oscillators, reliability %, convergence status.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💰 CATEGORY C — VOLUME & FLOW (Steps 13-16)
PURPOSE: Volume analysis for institutional activity detection.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📌 Step 13: Volume Spike Classification + Institutional Footprint
JOB: Classify volume spikes with institutional activity grading.
- MINOR SPIKE: 1.5-2x avg volume = retail interest.
- MAJOR SPIKE: 2-3x avg volume = institutional activity probable.
- CLIMAX SPIKE: >3x avg volume = institutional climax (often marks reversal or acceleration).
- INSTITUTIONAL FOOTPRINT: large volume + small body = ABSORPTION (smart money absorbing, reversal imminent).
- INSTITUTIONAL DRIVE: large volume + large body = INITIATION (smart money driving price).
OUTPUT: Spike classification, institutional footprint type (absorption/initiation/none).

📌 Step 14: OBV Directional + Accumulation/Distribution Line
JOB: OBV trend confirmation with A/D line cross-validation.
- OBV RISING + price rising = CONFIRMED trend (healthy).
- OBV FALLING + price rising = DISTRIBUTION (smart money selling into strength — reversal approaching).
- OBV RISING + price falling = ACCUMULATION (smart money buying into weakness — reversal approaching).
- A/D LINE: (close - low) - (high - close) / (high - low) * volume — confirms or denies OBV signal.
OUTPUT: OBV trend, price-OBV agreement, accumulation/distribution detected, A/D confirmation.

📌 Step 15: Money Flow Index Pressure Reading
JOB: MFI extreme and divergence detection.
- MFI >80 = overbought (selling pressure building). MFI <20 = oversold (buying pressure building).
- MFI DIVERGENCE: price new high + MFI lower high = smart money exiting (STRONG reversal signal).
- MFI + VOLUME SPIKE: if MFI extreme occurs WITH volume spike = HIGH CONFIDENCE reversal zone.
- GREEN/RED RATIO: positive flow / negative flow ratio over 14 periods — trend of buying vs selling pressure.
OUTPUT: MFI zone, divergence detected, volume-confirmed extreme, flow ratio.

📌 Step 16: Volume Climax & Exhaustion Detection
JOB: Detect volume exhaustion patterns marking trend termination.
- SELLING CLIMAX: huge volume + large bearish candle + long lower wick = smart money buying at bottom.
- BUYING CLIMAX: huge volume + large bullish candle + long upper wick = smart money selling at top.
- VOLUME DRY-UP: 3+ candles with volume <0.5x avg = participants leaving, breakout or reversal imminent.
- POST-CLIMAX: volume declining after climax = confirmation that climax marked the turning point.
OUTPUT: Climax type (buying/selling/none), exhaustion confirmed, dry-up detected, post-climax validation.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🕯️ CATEGORY D — CANDLE PATTERNS (Steps 17-21)
PURPOSE: Advanced candlestick pattern recognition with reliability scoring.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📌 Step 17: Single-Candle Reversal Patterns
JOB: Hammer, Inverted Hammer, Hanging Man, Shooting Star, Dragonfly/Gravestone Doji.
- WICK-TO-BODY RATIO: must be >2.5x for valid reversal candle (strict). >3.5x = ULTRA-strong.
- LOCATION FILTER: reversal candle AT S/R level = A-GRADE. Mid-range = C-GRADE (ignore).
- VOLUME: reversal candle with volume >1.5x avg = validated. Low volume = unconfirmed.
- SHADOW TRAP: long wick that swept a level then reversed = liquidity sweep reversal (highest grade).
OUTPUT: Pattern type, wick ratio, location grade, volume confirmed, shadow trap alert.

📌 Step 18: Engulfing Pattern + Institutional Validation
JOB: Standard and institutional engulfing detection.
- STRONG ENGULFING: body fully engulfs previous body AND closes beyond previous wick = highest reliability.
- SIZE RATIO: engulfing body >1.5x previous. >2x = POWERFUL. >3x = INSTITUTIONAL ORDER BLOCK CREATION.
- VOLUME: engulfing candle volume MUST be higher than engulfed — otherwise FAKE (ignore).
- INSTITUTIONAL ENGULFING: body >3x avg + volume spike = ORDER BLOCK formed (mark for Cat G).
OUTPUT: Engulfing type, size ratio, volume confirmed, institutional OB created.

📌 Step 19: Pin Bar + Multi-Rejection Cluster Analysis
JOB: Pin bars AND multi-rejection detection with institutional level identification.
- PIN BAR: wick >3x body (strict). Long lower wick = bullish rejection. Long upper wick = bearish.
- REJECTION CLUSTER: 2+ rejections from SAME level within 10 candles = INSTITUTIONAL DEFENSE LEVEL.
- 3+ REJECTIONS = SMART MONEY DEFENDING (highest conviction reversal from that level).
- PIN BAR + VOLUME SPIKE + at S/R = TRIPLE-VALIDATED rejection (highest reliability signal).
- FALSE PIN: pin bar immediately violated next candle = TRAP (trade OPPOSITE direction).
OUTPUT: Pin bars found, rejection level, cluster count, triple-validated alert, false pin.

📌 Step 20: Inside Bar Compression + Breakout Prediction
JOB: Inside bar counting with smart money breakout direction prediction.
- SINGLE inside bar = mild compression. DOUBLE = STRONG compression. TRIPLE = EXTREME (massive move imminent).
- BREAKOUT DIRECTION: EMA stack + momentum + smart money positioning (from Cat G) predicts direction.
- MOTHER BAR ANALYSIS: the candle containing the inside bar — its direction and volume reveal institutional intent.
- INSTITUTIONAL INSIDE BAR: inside bar forming AFTER an institutional engulfing = consolidation before continuation.
OUTPUT: Inside bar count, compression strength, predicted direction, mother bar analysis.

📌 Step 21: Multi-Candle Formations + 4-Criteria Reliability Score
JOB: Morning Star, Evening Star, Three Soldiers/Crows, Tweezers.
- 4-CRITERIA SCORING (max 4 points):
  1) Volume increases across formation candles (+1)
  2) Formation at S/R level or order block (+1)
  3) Formation aligned with EMA trend (+1)
  4) Third candle closes strongly beyond first candle (+1)
- 4/4=ULTRA-RELIABLE(90%+). 3/4=STRONG(75%). 2/4=MODERATE(60%). 1/4=WEAK(ignore).
OUTPUT: Formation type, 4-criteria score, reliability rating, direction.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏰 CATEGORY E — KEY LEVELS (Steps 22-25)
PURPOSE: Map critical price levels with reaction probability.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📌 Step 22: Dynamic S/R + Touch Count Strength Rating
JOB: S/R distances with historical touch-count strength.
- 1-2 touches = WEAK level. 3-4 = MODERATE (60% hold). 5+ = STRONG (80%+ hold).
- PROXIMITY: within 0.5x ATR = DANGER ZONE. Within 1x ATR = APPROACH. Beyond 2x = CLEAR.
- FIRST TOUCH from new direction = strongest reaction probability.
- S/R ROLE FLIP: broken support becomes resistance (and vice versa) — check if price is retesting a flipped level.
OUTPUT: S/R values, touch counts, proximity zone, role flip detected.

📌 Step 23: Bollinger Band Position + Walk-the-Band Detection
JOB: BB position with band walk and extreme detection.
- WALK-THE-BAND: 3+ candles closing near upper band (>85%) = strong trend (DO NOT fade).
- BB EXTREME: price closing OUTSIDE bands = first close = possible breakout, multiple = mean reversion coming.
- BAND WIDTH PERCENTILE: compare to last 100 candles. <20th percentile = EXTREME squeeze.
- BB + KELTNER SQUEEZE: if BB inside Keltner Channel equivalent (ATR-based envelope) = TTM Squeeze (explosive breakout imminent).
OUTPUT: BB position %, walk-the-band, extreme alert, squeeze status.

📌 Step 24: Fibonacci Multi-Level Confluence + Historical Validation
JOB: Calculate Fib levels AND validate with historical reactions.
- ALL levels: 0.236, 0.382, 0.5, 0.618, 0.786 from 100-candle swing.
- VALIDATED FIB: level with 3+ historical reactions = high confidence. 0 reactions = ignore.
- CONFLUENCE: Fib + EMA + horizontal S/R within 1x ATR = SUPER-LEVEL (highest accuracy entry).
- GOLDEN POCKET: 0.618-0.65 zone = institutional favorite entry zone (highest win rate historically).
OUTPUT: Fib levels with validation, golden pocket active, confluence count.

📌 Step 25: Round Number + Psychological Level Gravity
JOB: Round number proximity with magnetic/barrier effect.
- APPROACHING from >2x ATR = gravitational pull TOWARD it. AT round number = STALL. Just broke through = ACCELERATION.
- HALF-LEVELS (x.x500) act as mini-barriers.
- OTC-SPECIFIC: OTC platforms often reverse at round numbers due to dealer manipulation — EXTRA weight on round number proximity.
OUTPUT: Nearest round number, distance, approach/at/broken status, OTC manipulation risk.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌡️ CATEGORY F — VOLATILITY & RISK (Steps 26-29)
PURPOSE: Volatility regime assessment and risk-reward optimization.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📌 Step 26: ATR Regime + Volatility Trend Direction
JOB: ATR classification with volatility expansion/contraction analysis.
- >2.0x=EXTREME, 1.5-2.0=HIGH, 0.8-1.5=NORMAL, 0.5-0.8=LOW, <0.5=DEAD.
- VOLATILITY TREND: ATR increasing = EXPANDING (momentum trades). Decreasing = CONTRACTING (breakout anticipation).
- EXTREME ATR WARNING: >2x normal = erratic market, reduce confidence by 5%.
OUTPUT: ATR regime, volatility trend, extreme warning.

📌 Step 27: BB Squeeze Duration + Fire Direction Prediction
JOB: BB squeeze with historical duration and predicted fire direction.
- DURATION: 5-10 candles=minor(1-2x ATR breakout), 10-20=moderate(2-3x), 20+=major(3-5x explosive).
- FIRE DIRECTION: EMA trend + last 3 candles + volume trend = prediction.
- POST-FIRE ENTRY: enter on first candle AFTER squeeze fire (BB width jumps >15%).
OUTPUT: Squeeze status, duration, expected magnitude, predicted direction.

📌 Step 28: Volatility Cycle Phase + Timing
JOB: 4-phase cycle mapping:
1) COMPRESSED: BB squeezing, ATR declining → breakout in ~5-15 candles
2) EXPANDING: squeeze fired, ATR rising → ride for 5-10 candles
3) PEAK: ATR maximum, extreme bodies → reversal in 1-3 candles
4) CONTRACTING: ATR declining from peak → new compression coming
OUTPUT: Current phase, candles until next transition, trade rule.

📌 Step 29: Risk-Reward + Asymmetric Opportunity Score
JOB: R:R with asymmetric opportunity detection.
- R:R for CALL (risk=distance to support, reward=distance to resistance) and PUT (reverse).
- ASYMMETRIC OPPORTUNITY: one direction R:R >2.5:1 vs <1:1 = STRONG directional bias.
- MIN THRESHOLDS: Trending=1.5:1, Ranging=2:1, Choppy=3:1. Below threshold = SUBOPTIMAL.
OUTPUT: R:R CALL, R:R PUT, asymmetry score, optimal direction.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏦 CATEGORY G — ADVANCED SMC & INSTITUTIONAL ORDER FLOW (Steps 30-34)
PURPOSE: Deep institutional Smart Money Concepts analysis — INTERCONNECTED with ALL other categories.
INTERCONNECTION MAP: G feeds into H (Liquidity), I (Backtest), J (Market Condition), K (Wyckoff), L (Synthesis).
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📌 Step 30: ADVANCED Order Block Detection + Multi-Layer Validity + Cross-Category Validation
JOB: Identify ALL order blocks with institutional-grade validation using data from prior categories.
- BULLISH OB: last bearish candle before impulsive bullish displacement (body >2x avg from Step 17).
- BEARISH OB: last bullish candle before impulsive bearish displacement.
- ADVANCED OB CLASSIFICATION (6 types):
  1) STANDARD OB: single candle OB with basic validity
  2) INSTITUTIONAL OB: OB created with volume spike (Vol >2x avg from Step 13) + displacement
  3) NESTED OB: OB inside a larger OB = EXTREME confluence zone (+20 confidence)
  4) REFINED OB (50% LEVEL): institutional fill zone at 50% of OB body — optimal entry precision
  5) DEMAND/SUPPLY ZONE: cluster of 2-3 OBs within 1x ATR = INSTITUTIONAL ZONE
  6) FRESH vs MITIGATED: Count touches — 1st touch = 85% reaction, 2nd = 60%, 3rd+ = dead zone
- CROSS-CATEGORY OB VALIDATION (MANDATORY — connects to ALL prior steps):
  ▸ Step 1 (EMA): OB aligned with EMA stack direction? PERFECT_BULL + bullish OB = +8 conf. AGAINST = -12.
  ▸ Step 3 (Structure): OB at BOS level = STRUCTURAL OB (+10). OB at CHoCH = REVERSAL OB (+15).
  ▸ Step 7 (RSI): RSI divergence AT the OB zone = EXTREME setup (+18). RSI mid-range at OB = standard.
  ▸ Step 9 (MACD): MACD cross at OB = INSTITUTIONAL TIMING (+14). MACD flat at OB = weak reaction.
  ▸ Step 13 (Volume): Volume spike at OB creation = CONFIRMED institutional (+12). Low volume = suspicious.
  ▸ Step 15 (MFI): MFI extreme at OB = smart money flow confirmed (+10). MFI neutral = no extra confidence.
  ▸ Step 17 (Candle): Engulfing at OB = INSTITUTIONAL ENGULFING (+16). Pin bar at OB = rejection confirmation (+12).
  ▸ Step 22 (S/R): OB overlapping with S/R level = DOUBLE-DEFENSE zone (+15).
  ▸ Step 24 (Fibonacci): OB at Golden Pocket (0.618-0.65) = INSTITUTIONAL PRECISION ZONE (+20).
  ▸ Step 26 (ATR): OB reaction expected within 1x ATR distance = IMMINENT. Beyond 2x = DISTANT.
  ▸ Step 27 (BB Squeeze): BB squeeze + price approaching OB = SPRING-LOADED for explosive reaction.
- OB QUALITY GRADE: A+ (7+ cross-validations), A (5-6), B (3-4), C (1-2), F (0 or against trend).
OUTPUT: OB locations, types, quality grades, cross-validation count, nearest OB distance, institutional confirmation score.

📌 Step 31: ADVANCED Fair Value Gap (FVG) + Multi-Type Imbalance Architecture + Interconnection
JOB: Map ALL imbalance types with institutional precision and cross-category validation.
- 6 TYPES OF IMBALANCES (expanded from basic 2):
  1) STANDARD FVG: candle[n-1].high < candle[n+1].low (bullish) or reverse (bearish)
  2) INVERSE FVG (iFVG): FVG broken through = polarity flip → becomes opposite signal
  3) BPR (Balanced Price Range): overlapping bullish + bearish FVGs = VELOCITY zone, explosive move
  4) VOLUME IMBALANCE: gap between two candle bodies (not wicks) where volume concentration shifts
  5) OPENING GAP: time-based gaps at session transitions = DEALER MANIPULATION signal in OTC
  6) CONSEQUENT ENCROACHMENT (CE): 50% level of FVG = institutional equilibrium target (MAGNET)
- FVG FILL ANALYSIS WITH BACKTEST DATA (connects to Step 40-41):
  ▸ Use backtest stats to calculate ACTUAL fill rate for this pair's FVGs
  ▸ OTC fill rate typically >70% within 20 candles — validate against pair-specific data
  ▸ UNFILLED FVG = MAGNET (price drawn toward it). Multiple unfilled = directional bias
- FVG SIZE FILTER (connects to Step 26 ATR):
  ▸ FVG < 0.3x ATR = noise (ignore). 0.3-1x ATR = standard. 1-2x ATR = significant. >2x = news-driven (unreliable)
- FVG CROSS-CATEGORY FUSION:
  ▸ FVG + OB overlap = SUPER-ZONE (institutional will defend aggressively, +22 conf from Step 30)
  ▸ FVG + Fibonacci level (Step 24) = PRECISION TARGET (+15)
  ▸ FVG + S/R (Step 22) = TRIPLE-LAYER defense (+18)
  ▸ FVG + EQH/EQL nearby (connects to Step 35) = LIQUIDITY-IMBALANCE FUSION (highest probability setup +25)
  ▸ FVG direction agrees with EMA trend (Step 1) = CONFIRMED imbalance. Against = potential TRAP.
  ▸ FVG with volume climax at creation (Step 16) = INSTITUTIONAL URGENCY (+12)
OUTPUT: All FVG types found, fill probabilities (pair-specific), CE levels, fusion scores, nearest unfilled FVG.

📌 Step 32: ADVANCED BOS/CHoCH + Structure Hierarchy + Full Category Integration
JOB: Multi-layer structure analysis with institutional context from ALL prior steps.
- STRUCTURE HIERARCHY (3 layers, each cross-validated):
  1) MICRO STRUCTURE (last 20 candles): minor swing breaks, noise-filtered
  2) INTERMEDIATE STRUCTURE (last 50 candles): main trading structure, BOS/CHoCH detection
  3) MACRO STRUCTURE (last 200 candles): HTF proxy structure, major trend breaks
- BOS QUALITY SCORING (connects to multiple steps):
  ▸ STRONG BOS: break with displacement candle (body >2x avg from Step 17) + volume spike (Step 13) = +15
  ▸ MODERATE BOS: break with standard candle + normal volume = +8
  ▸ WEAK BOS: break with wick only or small body = POTENTIAL TRAP (-5). Cross-check with Step 38 traps.
  ▸ BOS + OB left behind (Step 30) = CONFIRMED INSTITUTIONAL MOVE. The OB becomes entry zone.
  ▸ BOS + FVG left behind (Step 31) = IMBALANCED BREAK. Price will return to fill FVG before continuing.
- CHoCH DETECTION (EARLIEST REVERSAL SIGNAL):
  ▸ ChoCH = FIRST structure break AGAINST trend. More important than ANY oscillator divergence (Steps 7-12).
  ▸ ChoCH + volume spike (Step 13) = CONFIRMED reversal (+18). Without volume = TENTATIVE (wait for retest).
  ▸ ChoCH + RSI divergence (Step 7) = DOUBLE REVERSAL confirmation (+22)
  ▸ ChoCH + Engulfing pattern (Step 18) = INSTITUTIONAL REVERSAL (+20)
  ▸ ChoCH at OB zone (Step 30) = REVERSAL FROM INSTITUTIONAL LEVEL (+25)
  ▸ ChoCH + Wyckoff Spring/Upthrust (connects to Step 57) = INSTITUTIONAL PHASE SHIFT (+28)
- STRUCTURE-TREND ALIGNMENT (connects to Steps 1-6):
  ▸ Macro BOS direction = EMA Stack direction = ALIGNED (full conviction). Misaligned = TRANSITION.
  ▸ ADX (Step 5) >30 + BOS in ADX direction = STRONG INSTITUTIONAL TREND.
  ▸ ADX <15 + no clear BOS = RANGING/CHOPPY (reduce all SMC confidence by 10%).
- BOS COUNT & TREND MATURITY:
  ▸ 1 BOS = FRESH trend (strong, high probability continuation)
  ▸ 2-3 BOS = DEVELOPING (good continuation probability)
  ▸ 4-5 BOS = MATURE (exhaustion approaching, look for CHoCH)
  ▸ 6+ BOS = EXHAUSTED (reversal imminent, CHoCH likely within 10-20 candles)
OUTPUT: Structure map (3 layers), BOS quality scores, CHoCH locations, trend maturity, cross-validation count.

📌 Step 33: ADVANCED Liquidity Void + Institutional Imbalance Architecture + Void-Category Fusion
JOB: Deep void analysis connecting to ALL categories for probability scoring.
- VOID CLASSIFICATION (connects to Step 26 ATR):
  ▸ MINOR VOID: <1x ATR = price may skip it. Fill probability: 40%.
  ▸ MODERATE VOID: 1-2x ATR = significant imbalance. Fill probability: 65%.
  ▸ MAJOR VOID: >2x ATR = massive institutional push. Fill probability: 80%+ within 50 candles.
  ▸ CASCADING VOID: 2+ consecutive voids = EXTREME IMBALANCE (institutional campaign active).
- VOID DIRECTION ANALYSIS (connects to Steps 1-6 Trend):
  ▸ Void BEHIND price in trend direction = SUPPORT/RESISTANCE zone (price defended here).
  ▸ Void AHEAD in trend direction = POTENTIAL TARGET (price magnetically drawn).
  ▸ Void AGAINST current trend = REVERSION TARGET (if mean reversion from Step 43 is active).
- VOID-CATEGORY CROSS-REFERENCE:
  ▸ Void + unfilled FVG (Step 31) = DOUBLE MAGNET (very high probability fill, +20 conf)
  ▸ Void + OB (Step 30) within void = INSTITUTIONAL RELOAD zone (+18)
  ▸ Void + Fibonacci level (Step 24) crossing through = FIBONACCI-VOID CONFLUENCE (+15)
  ▸ Void + EQH/EQL (connects to Step 35) at void boundary = LIQUIDITY TRAP at imbalance (+22)
  ▸ Void + BB expanding (Step 27) INTO the void = momentum filling void (+10)
  ▸ Void + Volume dry-up (Step 16) approaching void = anticipation of fill (+12)
  ▸ Void + Backtest (Step 40): did similar voids fill historically? Calculate pair-specific fill rate.
OUTPUT: Void locations/sizes, fill probabilities (pair-specific), direction relative to trend, fusion scores.

📌 Step 34: ADVANCED Mitigation + Breaker + Propulsion + Rejection Blocks + Full SMC Architecture
JOB: Complete institutional block architecture with cross-category grading.
- 5 ADVANCED BLOCK TYPES:
  1) MITIGATION BLOCK: OB partially mitigated (price entered but didn't break 50%).
     ▸ 1st mitigation = 70%+ reaction. 2nd = 50%. 3rd = broken.
     ▸ Mitigation + RSI extreme (Step 7) = HIGH PROBABILITY reversal (+15)
     ▸ Mitigation + Volume spike (Step 13) at mitigation = INSTITUTIONAL DEFENDING (+18)
  2) BREAKER BLOCK: failed OB (price broke through) → polarity flip.
     ▸ Breaker = trapped traders zone. Return to breaker = high accuracy entry.
     ▸ Breaker + EMA retest (Step 1) = DYNAMIC CONFLUENCE (+12)
     ▸ Breaker + Stochastic extreme (Step 8) = TIMING PRECISION entry (+14)
  3) PROPULSION BLOCK: 3+ small candles consolidation before explosive move.
     ▸ Return to propulsion = original direction resumes.
     ▸ Propulsion + BB squeeze (Step 27) = DOUBLE COMPRESSION (explosive move imminent +15)
     ▸ Propulsion + MACD squeeze (Step 9) = TRIPLE ENERGY STORAGE (+18)
  4) REJECTION BLOCK: long wick at key level with body closing away.
     ▸ Upper wick >60% at resistance = bearish rejection. Lower >60% at support = bullish.
     ▸ Rejection + EQH/EQL nearby (Step 35) = SWEEP REJECTION (+20)
     ▸ Rejection + Wyckoff Phase C (Step 56) = SPRING/UPTHRUST REJECTION (+25)
  5) TURTLE SOUP BLOCK: price breaks old high/low by small amount then reverses violently.
     ▸ Classic institutional trap — highest win-rate pattern in OTC.
     ▸ Turtle Soup + Volume Ghost (Step 37) = DEALER TRAP CONFIRMED (+22)
- OTC DEALER BLOCK DEFENSE:
  ▸ OTC dealers create fake breaks through OBs to sweep stops, then reverse.
  ▸ Small break (<0.3x ATR beyond OB) + reversal candle = DEALER TRAP → trade reversal.
  ▸ Cross-validate with Step 37 manipulation patterns and Step 38 trap matrix.
- INSTITUTIONAL BLOCK GRADE (connects to ALL prior categories):
  ▸ A+ = Block + FVG + Sweep + Divergence + Volume + Fibonacci + Wyckoff (7+ confluences)
  ▸ A = Block + 4-6 cross-category confirmations
  ▸ B = Block + 2-3 confirmations
  ▸ C = Block alone (standard probability)
  ▸ F = Block AGAINST trend + against momentum + against volume = IGNORE
OUTPUT: All block types, locations, grades, cross-validation count, OTC dealer trap status.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💧 CATEGORY H — ADVANCED LIQUIDITY & OTC TRAP DETECTION (Steps 35-39)
PURPOSE: Institutional liquidity mapping with FULL interconnection to SMC (Cat G), Trend (Cat A), Momentum (Cat B), Volume (Cat C), and all other categories.
INTERCONNECTION MAP: H receives from A-G, feeds into I (Backtest), J (Market Condition), K (Wyckoff), L (Synthesis).
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📌 Step 35: ADVANCED Liquidity Pool Mapping + Multi-Layer Institutional Targeting
JOB: Comprehensive liquidity architecture with cross-category probability scoring.
- LIQUIDITY POOL DETECTION (5 types):
  1) EQUAL HIGHS (EQH): 2+ candles with highs within 0.1x ATR (Step 26) = BSL pool above.
  2) EQUAL LOWS (EQL): 2+ candles with lows within 0.1x ATR = SSL pool below.
  3) UNTAKEN SWING LEVELS: each untested swing high/low = liquidity target. Count above + below.
  4) TRENDLINE LIQUIDITY: stops pile up beyond respected trendlines. Break = sweep event.
  5) PSYCHOLOGICAL LIQUIDITY: round numbers (Step 25) attract stops = artificial liquidity pools.
- POOL STRENGTH SCORING (connects to multiple categories):
  ▸ CLUSTER SIZE: 2 candles = minor pool. 3-4 = moderate. 5+ = MAJOR pool (institutional target).
  ▸ AGE: pool from last 20 candles = FRESH (high probability sweep). 50-100 candles = aged. 100+ = may be forgotten.
  ▸ PROXIMITY: within 1x ATR (Step 26) = IMMINENT target. 1-3x = APPROACHING. >3x = DISTANT.
- LIQUIDITY-CATEGORY CROSS-VALIDATION (MANDATORY — connects to ALL prior steps):
  ▸ Step 1 (Trend): trend direction TOWARD liquidity pool = pool is the DESTINATION (+15 sweep probability)
  ▸ Step 3 (Structure): BOS pointing toward pool = structural momentum will SWEEP it (+12)
  ▸ Step 5 (ADX): ADX >25 toward pool = STRONG INSTITUTIONAL DRIVE to sweep (+10)
  ▸ Step 7 (RSI): RSI extreme AWAY from pool = reversal toward pool likely (+8)
  ▸ Step 9 (MACD): MACD accelerating toward pool = momentum will carry to sweep (+10)
  ▸ Step 13 (Volume): Volume increasing toward pool = INSTITUTIONAL TARGETING (+12)
  ▸ Step 22 (S/R): pool AT S/R level = PRIME TARGET (institutions sweep S/R stops, +18)
  ▸ Step 24 (Fibonacci): pool AT Fibonacci level = PRECISION LIQUIDITY (institutional favorite, +15)
  ▸ Step 27 (BB Squeeze): squeeze near pool = SPRING-LOADED for sweep (+14)
  ▸ Step 30 (OB): OB BEYOND the pool = POST-SWEEP ENTRY zone. This is the SEQUENCE: sweep pool → enter at OB.
  ▸ Step 31 (FVG): unfilled FVG between price and pool = price fills FVG en route to pool (+10)
  ▸ Step 32 (BOS): BOS in direction of pool = structure CONFIRMS sweep intention (+12)
OUTPUT: All pool locations/types, strength scores, cross-validation count, nearest pool distance, sweep sequence.

📌 Step 36: ADVANCED Stop Hunt & Sweep Detection + Institutional Reversal Timing
JOB: Real-time sweep detection with multi-category reversal confirmation.
- SWEEP DETECTION TYPES:
  1) COMPLETED SWEEP: wick beyond key level + close back inside = REVERSAL IMMINENT.
  2) INDUCEMENT (IDM): minor fake breakout before the REAL move. IDM → real target further away.
  3) TURTLE SOUP: break old high/low by small amount → violent reversal.
  4) DOUBLE SWEEP: both BSL and SSL swept within 8 candles = VERY strong directional move incoming.
  5) FAILED SWEEP: sweep attempt that didn't close back = REAL breakout (not a trap).
- SWEEP REVERSAL CONFIRMATION (cross-category requirements — minimum 3 of 7):
  ▸ ✅ Volume spike on sweep candle (Step 13) = institutional stop-hunting CONFIRMED
  ▸ ✅ Reversal candle body >1.5x avg (Step 17 candle analysis) = conviction reversal
  ▸ ✅ RSI extreme reversal (Step 7) at sweep level = momentum confirms
  ▸ ✅ MACD histogram turning (Step 9) = momentum shifting with sweep
  ▸ ✅ OB at sweep level (Step 30) = institutional reload zone ACTIVATED
  ▸ ✅ FVG left by sweep candle (Step 31) = imbalance created by sweep
  ▸ ✅ ChoCH after sweep (Step 32) = structure shift confirms reversal
  ▸ 3/7 confirmations = MODERATE reversal (+10). 5/7 = STRONG (+18). 7/7 = EXTREME (+25).
- POST-SWEEP ENTRY PROTOCOL (connects to Step 42 Best-Entry):
  ▸ After sweep confirmation, the OPTIMAL entry = OB retest behind sweep level
  ▸ If no OB exists, enter at FVG fill level
  ▸ If neither exists, enter on close of first confirmation candle
  ▸ Connect to Step 54 for exact entry timing
- INDUCEMENT-TO-TARGET MAPPING:
  ▸ IDM sweep → calculate distance to REAL target (major liquidity pool beyond IDM)
  ▸ Use ATR (Step 26) to estimate candles to reach real target
  ▸ Connect to Step 42 for optimal entry within the IDM→target move
OUTPUT: Active sweeps, confirmation score (X/7), reversal timing, entry protocol, IDM→target distance.

📌 Step 37: ADVANCED OTC Dealer Manipulation Detection + AI Pattern Recognition
JOB: Detect ALL OTC-specific dealer manipulation with cross-category AI validation.
- 7 DEALER MANIPULATION PATTERNS (upgraded with cross-category detection):
  1) SPIKE & REVERSE: 3-5x ATR spike → complete reversal.
     ▸ Detect: body >3x ATR (Step 26) + volume ghost (volume <0.5x avg from Step 13) = FAKE spike
     ▸ Cross-validate: RSI (Step 7) extreme without prior momentum = MANUFACTURED spike
     ▸ ACTION: trade the reversal. Entry = close of first reversal candle.
  2) SLOW GRIND THEN DUMP: 8-12 small bullish candles → 1-2 massive bearish candles.
     ▸ Detect: 8+ consecutive with body <0.5x avg (Step 17) + shrinking bodies + rising volume (Step 13)
     ▸ Cross-validate: OBV (Step 14) diverging from price = DISTRIBUTION in disguise
     ▸ Cross-validate: Stochastic (Step 8) hitting extreme without crossing back = TRAP loading
     ▸ ACTION: expect opposite explosive move when pattern completes.
  3) RANGE MANIPULATION: 15+ candle range with fake breakouts on both sides.
     ▸ Detect: BB squeeze (Step 27) + ADX <15 (Step 5) + 1-2 false breaks already occurred
     ▸ Cross-validate: Wyckoff Phase B (Step 56) = BUILDING A CAUSE = next break is REAL
     ▸ Cross-validate: Volume accumulation pattern (Step 16) = institutional positioning
     ▸ ACTION: 3rd breakout attempt with volume >1.5x = REAL break.
  4) TIME-BASED MANIPULATION: reversals at H:00, H:30 boundaries.
     ▸ Detect: check current time proximity to boundary
     ▸ Cross-validate: Session context (if applicable) + volume shift at boundary
     ▸ ACTION: reduce confidence by 5% within 5 minutes of time boundary.
  5) VOLUME GHOST: large body + zero/minimal volume = dealer-driven.
     ▸ Detect: body >2x avg + volume <0.5x avg (Steps 13, 17)
     ▸ Cross-validate: MFI (Step 15) not confirming = NO real money flow
     ▸ ACTION: expect full reversal within 3-5 candles. Trade opposite.
  6) MIRROR TRAP: price action mirrors exact pattern from 50-100 candles ago.
     ▸ Detect: compare last 10 candle OHLC pattern to all 10-candle windows in backtest (Step 40)
     ▸ Cross-validate: same volume profile = ALGORITHM RECYCLING pattern
     ▸ ACTION: predict same outcome as original pattern BUT with lower confidence (-10%).
  7) STAIRCASE TO CLIFF: gradual stairs up/down → sudden cliff opposite.
     ▸ Detect: 5+ equal-sized small candles in same direction (stairs) + ATR declining
     ▸ Cross-validate: OBV flat (Step 14) during stairs = NO real accumulation
     ▸ Cross-validate: Inside compression (Step 20) at each stair step
     ▸ ACTION: cliff probability = stair count × 12%. >80% = IMMINENT.
- MANIPULATION SEVERITY SCORING: each pattern scored 1-3 severity.
  ▸ Score 1 = minor (-3% conf). Score 2 = moderate (-7%). Score 3 = severe (-12%).
  ▸ 2+ patterns simultaneously = MANIPULATED MARKET (-20% conf minimum).
OUTPUT: Active manipulation patterns, severity scores, cross-validation evidence, total confidence adjustment.

📌 Step 38: ADVANCED Smart Money Trap Matrix — 7-Trap System + Cross-Category AI Scoring
JOB: Comprehensive trap detection with AI-powered severity scoring using ALL prior categories.
- TRAP 1 — FAKEOUT TRAP: S/R break → immediate reversal (1-2 candles). Body beyond <0.3x ATR.
  ▸ Cross-check: Volume (Step 13) on break < avg = CONFIRMED fake. High volume = might be real.
  ▸ Cross-check: EMA alignment (Step 1). Break AGAINST EMA stack = almost certainly fake.
  ▸ Cross-check: FVG (Step 31). If break creates inverse FVG = FAKEOUT confirmed.
- TRAP 2 — EXHAUSTION TRAP: 8+ same-color candles with shrinking bodies + growing wicks.
  ▸ Cross-check: RSI (Step 7) in extreme zone. Stochastic (Step 8) hooking. CCI (Step 11) extreme.
  ▸ Cross-check: Volume declining (Step 16) = volume dry-up + exhaustion = REVERSAL IMMINENT.
  ▸ Cross-check: OBV (Step 14) diverging = DISTRIBUTION/ACCUMULATION during exhaustion.
- TRAP 3 — DOUBLE-TAP TRAP: 2 tests of level → 3rd break has small body + long wick = still trapped.
  ▸ Cross-check: Volume on 3rd test < previous tests (Step 13) = weakening conviction.
  ▸ Cross-check: MFI (Step 15) not confirming break = NO institutional participation.
- TRAP 4 — BREAKOUT-RETEST TRAP: break level → pullback retest → retest shows reversal pattern.
  ▸ Cross-check: Reversal pattern at retest (Step 17-21) = trap confirmation.
  ▸ Cross-check: BOS analysis (Step 32). If retest creates mini-ChoCH = fake breakout.
- TRAP 5 — MOMENTUM TRAP: RSI >80 or <20 + volume climax = looks like continuation but exhaustion.
  ▸ Cross-check: Multiple oscillators (Step 12) diverging = TRIPLE DIVERGENCE = exhaustion confirmed.
  ▸ Cross-check: ATR extreme (Step 26) = post-climactic volatility decay expected.
- TRAP 6 — EMA CROSS TRAP: EMA9 crosses EMA20 but ADX <15 = fake signal in ranging market.
  ▸ Cross-check: Market condition (Step 44). If CHOPPY/FFLC detected = cross is meaningless.
  ▸ Cross-check: BB width (Step 23). Narrow = ranging = cross trap likely.
- TRAP 7 — DIVERGENCE TRAP: single oscillator divergence without structural confirmation.
  ▸ Cross-check: BOS/CHoCH (Step 32). No structure break = divergence is premature.
  ▸ Cross-check: OB/FVG (Steps 30-31). No institutional zone nearby = divergence lacks catalyst.
- AI TRAP SEVERITY SCORING:
  ▸ Each trap: count cross-category confirmations. 0 = no trap. 1-2 = minor (severity 1). 3-4 = moderate (severity 2). 5+ = severe (severity 3).
  ▸ Total trap penalties: severity 1 = -3%. Severity 2 = -7%. Severity 3 = -12%.
  ▸ 3+ active traps with severity 2+ = MANDATORY NO TRADE.
OUTPUT: Active traps (list), per-trap cross-validation count, severity scores, total confidence adjustment.

📌 Step 39: ADVANCED Liquidity-Based Entry Optimization + Full-Stack Institutional Sequencing
JOB: Use ALL prior analysis to find the SINGLE BEST entry where smart money positions.
- INSTITUTIONAL ENTRY SEQUENCE (ranked by probability, each with cross-category scoring):
  1) POST-SWEEP OB ENTRY (#1 BEST): liquidity swept (Step 36) → price reverses → enters OB zone (Step 30).
     ▸ Requirements: Sweep confirmed (3+/7 criteria) + OB quality A or A+ + FVG between sweep and OB.
     ▸ Cross-validate: RSI divergence (Step 7) at OB = EXTREME PRECISION entry (+28 conf).
     ▸ Cross-validate: Wyckoff Spring/Upthrust (Step 57) at sweep = INSTITUTIONAL PHASE C entry (+30 conf).
     ▸ Connect to: Step 42 for optimal candle within post-sweep move.
  2) FVG FILL + TREND ENTRY (#2): price returns to fill FVG (Step 31) in direction of trend (Step 1).
     ▸ Requirements: FVG unfilled + trend aligned + volume confirming (Step 13).
     ▸ Cross-validate: Fibonacci confluence (Step 24) at FVG = PRECISION TARGET (+15).
     ▸ Connect to: Step 54 for entry timing when FVG fill starts.
  3) BREAKER RETEST ENTRY (#3): price retests breaker block (Step 34) for polarity flip trade.
     ▸ Requirements: Breaker confirmed + ChoCH prior (Step 32) + momentum shifting (Step 9).
     ▸ Cross-validate: Stochastic cross (Step 8) at breaker = TIMING entry (+14).
  4) OB + GOLDEN POCKET ENTRY (#4): OB at 0.618-0.65 Fibonacci (Step 24) = highest R:R zone.
     ▸ Requirements: OB quality B+ + Fibonacci validated (3+ historical reactions) + trend aligned.
     ▸ Cross-validate: BB position (Step 23) at golden pocket = TRIPLE CONFLUENCE (+20).
  5) PROPULSION ZONE RE-ENTRY (#5): price returns to propulsion block (Step 34) for continuation.
     ▸ Requirements: propulsion + trend continuation confirmed (Step 6) + volume rising (Step 13).
- AVOID ZONES (NO ENTRY regardless of other signals):
  ▸ Mid-range with no institutional activity (no OB, no FVG, no pool within 2x ATR)
  ▸ Inside active liquidity void (price will accelerate through, no stable entry)
  ▸ Between two untaken liquidity pools (price will oscillate unpredictably)
  ▸ During active manipulation pattern (Step 37 severity 2+)
- ENTRY TIMING PRECISION (connects to Steps 42 and 54):
  ▸ Calculate estimated candles until price reaches nearest optimal entry zone
  ▸ Factor in current momentum (Step 4 body progression) and volatility (Step 26 ATR)
  ▸ Provide EXACT entry_time combining liquidity analysis + optimal candle from Step 42
OUTPUT: Ranked entry zones with confidence scores, nearest optimal entry, estimated timing, avoid zones, final entry protocol.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🧬 CATEGORY I — BACKTEST VALIDATION (Steps 40-43)
PURPOSE: Validate setup against 7000+ historical candles with statistical rigor.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📌 Step 40: Historical Pattern Match — 8-Factor Similarity Scoring
JOB: Find similar conditions in backtest with comprehensive similarity measurement.
- SIMILARITY SCORING across 8 factors (each 0-1, total 0-8):
  1) RSI(14) within ±5 of current (+1)
  2) Same EMA stack regime (+1)
  3) Same volatility regime (ATR ratio within ±0.3) (+1)
  4) Same market structure (HH/HL vs LH/LL) (+1)
  5) Volume ratio within ±0.5x (+1)
  6) Same BB position zone (within ±15%) (+1)
  7) Same SMC context (near OB/FVG or not) (+1)
  8) Similar consecutive candle count (±2) (+1)
- Only count matches with score ≥5/8 (highly similar). Minimum 10 matches required.
OUTPUT: Match count, average similarity, outcome distribution, sample sufficiency.

📌 Step 41: Backtest Win Rate — Direction + Time + SMC Filtering
JOB: Win rate with triple filtering for maximum accuracy.
- OVERALL win rate for CALL and PUT from matches.
- TIME-FILTERED: only matches within ±2 hours of current time.
- SMC-FILTERED: only matches that occurred near similar SMC structures (OBs, FVGs).
- Use the MOST SPECIFIC filter that has ≥10 samples. Time+SMC filtered > Time filtered > Overall.
- >60%=STRONG, 55-60%=MODERATE, 52-55%=MARGINAL(-5%), <52%=NO EDGE(discard direction).
OUTPUT: Win rates (all filters), applied filter, threshold verdict.

📌 Step 42: Explosive Move Analysis + AI-Optimized Best Entry Selection
JOB: Match current pattern to pre-explosive patterns. Find the BEST entry dynamically.
- EXPLOSIVE MOVE: 3+ consecutive candles with body >2x avg body in same direction.
- PRE-EXPLOSIVE SIGNATURES:
  1) COMPRESSION → EXPANSION: 3+ small body candles → first impulsive candle = pre-explosive.
  2) VOLUME ACCUMULATION: volume dry-up (3-5 candles <0.5x avg) → sudden volume surge.
  3) BB SQUEEZE → FIRE: BB width at minimum → first expansion candle.
  4) SMC SPRING: price sweeps a liquidity pool then gets a CHoCH = pre-explosive reversal.
  5) ORDER BLOCK ACCEPTANCE: price enters OB zone AND holds with reversal candle = pre-explosive continuation.
- AI-OPTIMIZED BEST ENTRY (NOT hardcoded middle):
  - Find average explosive duration from backtest (e.g., avg 7 candles).
  - ANALYZE EACH candle position (1 through N) individually:
    * Score each position on: momentum strength, volume confirmation, body-to-wick ratio, exhaustion risk, historical win rate at that position, SMC structure alignment.
    * EARLY ENTRY (candle 1-2): higher reward, lower confirmation. Valid if: BOS confirmed + volume surge started.
    * OPTIMAL ENTRY (varies): the candle where momentum peaks AND exhaustion hasn't started. Usually where volume is highest + body is largest relative to wicks.
    * LATE ENTRY (last 20%): momentum fading, exhaustion signals appearing. AVOID unless trend is very strong.
  - SELECT the candle with HIGHEST composite score. Could be candle 2, 3, 5, or 7 — wherever analysis shows optimal risk/reward.
  - Example: 10-candle move — if candle 3 has 78% win rate + highest volume = choose candle 3.
  - NEVER default to middle. The BEST entry is DATA-DRIVEN.
- PROBABILITY: what % of similar pre-explosive patterns actually exploded in backtest?
OUTPUT: Pre-explosive match (which signature), duration, BEST entry candle (with reasoning), explosion probability %.

📌 Step 43: Mean Reversion Probability — ATR-Calibrated + SMC-Validated
JOB: Mean reversion analysis with institutional level validation.
- EXTENSION: distance from EMA20 in ATR multiples:
  - <1x = not extended. 1-2x = mild (35% reversion). 2-3x = significant. >3x = EXTREME (75%+ reversion).
- BACKTEST VALIDATION: use historical reversion rates. >65% = valid. 50-65% = mixed. <50% = trend persists.
- SMC VALIDATION: is there an unfilled FVG or unmitigated OB in the reversion direction?
  - YES = reversion has a TARGET (higher probability). NO = reversion may be shallow or absent.
- TIMING: average candles until reversion from backtest = expected entry timing.
OUTPUT: Extension level, reversion rate, SMC target exists, expected timing.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 CATEGORY J — MARKET CONDITION ANALYSIS (Steps 44-55)
PURPOSE: 12-step specialized analysis for 8 market conditions.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📌 Step 44: Market Condition Detection — 10-Factor Classification
JOB: Classify into ONE of 8 conditions using 10 factors:
- PURE_UPTREND: ADX>25 + PERFECT_BULL EMA + HH/HL + LR>0.5 + DI+>>DI- + BOS confirmed + OBs bullish
- PURE_DOWNTREND: mirror of above
- PULLBACK_TREND: primary trend intact + price retracing to EMA/Fib + volume declining + OB retest zone
- WIDE_RANGE: ADX<20 + clear S/R + range>3x ATR + mean reversion>60% + liquidity pools at boundaries
- MEDIUM_RANGE: ADX 15-20 + range 1.5-3x ATR + BB contracting + no SMC directional bias
- MICRO_TREND: 5-15 candle burst + ROC(5) strong + 3-5 consecutive + EMA9 steep + mini-BOS
- FFLC: color switch >70% + ADX<12 + body<0.5x avg + no structure + volume dying
- CHOPPY: 3+ of [switch>75%, ADX<12 falling, body<0.4x avg, mixed structure, MACD alternating]
OUTPUT: Condition, 5+ evidence points, classification confidence (0-100%).

📌 Step 45: Pure Uptrend — Dynamic Support + OB Entry
JOB: Precision pullback-to-dynamic-support entry with SMC validation.
- Dynamic EMA support (EMA9/13/20 depending on strength) + bullish OB alignment.
- RSI(14) 40-60 during pullback. Volume declining on pullback, rising on bounce.
- EXHAUSTION GUARD: 7+ consecutive bull candles → wait for 2+ pullback candles.
- SMC BONUS: if bounce occurs at a valid bullish OB = +8% confidence.
OUTPUT: Dynamic EMA, bounce confirmed, OB alignment, exhaustion status.

📌 Step 46: Pure Downtrend — Dynamic Resistance + OB Entry (mirror of Step 45)

📌 Step 47: Pullback Trend — Triple-Confluence + SMC Entry
JOB: Find entry where Fib + EMA + S/R + Order Block all align.
- QUADRUPLE CONFLUENCE: Fib + EMA + S/R + OB within 1x ATR = ULTRA-ENTRY.
- GOLDEN POCKET (0.618-0.65 Fib) overlapping OB = INSTITUTIONAL ENTRY ZONE (highest win rate).
- Confirmation candle required at confluence zone.
OUTPUT: Confluence count (1-4), golden pocket active, confirmation candle.

📌 Step 48: Wide Range — Boundary + Liquidity Sweep Entry
JOB: Trade at range extremes with SMC liquidity sweep validation.
- Boundary = price level with 5+ touches from backtest.
- LIQUIDITY SWEEP ENTRY: if price sweeps beyond boundary (takes EQH/EQL) then reverses = BEST range entry.
- Standard boundary fade if no sweep, but lower confidence.
- BREAKOUT ESCAPE: close beyond boundary with volume >2x + BOS = switch to breakout trade.
OUTPUT: Boundary values, sweep detected, entry type, breakout escape triggered.

📌 Step 49: Medium Range — Ultra-Selective with Trap Filter
JOB: MOST DANGEROUS condition. Trade only at extreme 10% of range.
- DOUBLE CONFIRMATION: candlestick reversal + RSI extreme (<20 or >80) at boundary.
- TRAP FILTER: check Step 38 traps. Any severity 2+ trap active = NO SIGNAL.
- BB SQUEEZE OVERRIDE: squeeze fire in medium range → switch to breakout.
- BASE PENALTY: -10% confidence. Backtest reversion <55% → SKIP entirely.
OUTPUT: Boundary proximity, confirmation met, trap filter, validity.

📌 Step 50: Micro Trend — Quick Entry + SMC Alignment
JOB: 3-5 consecutive same-color candles with momentum.
- Entry AFTER 2-3 candles confirm, on first 1-candle pullback.
- EXHAUSTION: body sizes shrinking = fading. Accelerating = enter.
- SMC ALIGNMENT: micro trend in direction of nearest OB/FVG = higher confidence (+7%). Against = lower (-12%).
OUTPUT: Micro direction, body ratio, SMC alignment, RSI(4) confirmed.

📌 Step 51: FFLC — Breakout-Only with 4-Gate System
JOB: Only trade on confirmed breakout. ALL 4 gates required:
1) Breakout body >2x avg 2) Volume >1.5x avg 3) Confirmation close beyond breakout 4) EMA9 turns
- MAX CONFIDENCE: 55%. False breakout = TRAP (trade opposite).
OUTPUT: Gate criteria, signal generated, false breakout detected.

📌 Step 52: Choppy Market Absolute Filter — 5-Criteria Scoring
JOB: Score choppiness 0-5:
  C1: Switch >75% last 20 candles. C2: ADX<12 falling. C3: Body<0.4x avg. C4: Mixed structure. C5: MACD alternating.
- 0-1=normal, 2=borderline(-5%), 3=choppy(-15%), 4-5=severe(-25%). Below 50% after penalty = DISCARD.
OUTPUT: Choppy score, penalties, signals allowed.

📌 Step 53: Confidence Calibration — Graduated Adjustment
JOB: Apply condition-specific confidence adjustments:
- PURE_TREND: +12%. PULLBACK: +7%. WIDE_RANGE at boundary: +3%.
- MICRO with-macro: +5%. Counter-macro: -8%. MEDIUM: -7%. FFLC: -15%. CHOPPY: -20 to -25%.
- SMC ALIGNMENT BONUS: signal direction matches SMC structure (OB/FVG/sweep) = +5%.
OUTPUT: Base confidence, condition adjustment, SMC bonus, final calibrated confidence.

📌 Step 54: Entry Time Optimization — Candle-Level Precision
JOB: Optimize entry timing based on condition + SMC structure:
- POST-SWEEP: entry = reversal candle close after sweep.
- OB RETEST: entry = candle close when price reaches OB zone.
- TREND PULLBACK: entry = bounce confirmation candle + 1 minute.
- EXPLOSIVE BEST-ENTRY: use AI-analyzed optimal candle from Step 42.
- All times within ${startTime}-${endTime} window.
OUTPUT: Optimized entry time (HH:MM), entry trigger type.

📌 Step 55: Risk Summary — Traffic Light + SMC Grade
JOB: Compile risk assessment:
- 🟢 GREEN: Pure trend + SMC aligned + OB entry + ADX>25.
- 🟡 YELLOW: Micro trend, pullback with single confluence, range with 2-3 touches.
- 🔴 RED: Medium range, FFLC, choppy 2+, counter-SMC signal.
- ⛔ BLACK: Choppy 4-5 + no SMC structure. NO TRADING.
- SMC GRADE: A (OB+FVG+sweep confluence), B (1-2 SMC structures), C (no SMC support), F (against SMC).
OUTPUT: Risk level, SMC grade, min confidence threshold, allowed signals.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔮 CATEGORY K — WYCKOFF & ACCUMULATION/DISTRIBUTION (Steps 56-59)
PURPOSE: Wyckoff method analysis for detecting institutional accumulation and distribution phases.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📌 Step 56: Wyckoff Phase Detection — 5-Phase Classification
JOB: Determine which Wyckoff phase the market is currently in.
- PHASE A — STOPPING ACTION: after a prolonged trend, volume increases dramatically, range expands. Preliminary Support/Supply appears.
  - Detect: trend exhaustion (7+ consecutive candles) + volume climax + first opposite-color strong candle.
- PHASE B — BUILDING A CAUSE: extended sideways range with multiple tests of boundaries. Volume gradually decreases.
  - Detect: 15+ candles in range + declining volume trend + multiple boundary tests (3+).
- PHASE C — TEST (SPRING/UPTHRUST): price briefly breaks below support (Spring) or above resistance (Upthrust) then reverses.
  - SPRING: break below range support with quick reversal = INSTITUTIONAL BUYING (strongest CALL signal).
  - UPTHRUST: break above range resistance with quick reversal = INSTITUTIONAL SELLING (strongest PUT signal).
  - Volume on spring/upthrust should be HIGH, followed by low-volume pullback = CONFIRMATION.
- PHASE D — MARKUP/MARKDOWN: trend begins with increasing volume and expanding range. BOS confirmed.
  - Detect: breakout from range + volume surge + EMA fan-out + consecutive candles in breakout direction.
- PHASE E — DISTRIBUTION/REDISTRIBUTION: trend mature, volume declining, bodies shrinking.
  - Detect: 5+ candles in trend direction but bodies <0.7x avg and declining.
OUTPUT: Current Wyckoff phase, supporting evidence, phase confidence %, expected next phase.

📌 Step 57: Spring & Upthrust Detection — Precision Entry
JOB: Identify active Spring/Upthrust setups for highest-probability reversal entries.
- SPRING CRITERIA (ALL required):
  1) Price breaks below range low/support by <1x ATR (shallow break)
  2) Reversal candle appears within 1-3 candles (close back above support)
  3) Volume spike on the break candle (stops getting swept)
  4) Subsequent candle(s) show bullish conviction (body >1.5x avg)
- UPTHRUST CRITERIA: mirror of Spring for resistance.
- FALSE SPRING/UPTHRUST: break is deep (>1.5x ATR) and NO reversal candle within 3 candles = genuine breakout (not a trap).
- SPRING + ORDER BLOCK: if a bullish OB exists at the Spring level = ULTRA-HIGH confidence entry.
- TIMING: Spring/Upthrust entries are IMMEDIATE — enter on the close of the first reversal candle.
OUTPUT: Spring detected (Y/N), Upthrust detected (Y/N), criteria score (0-4), OB confluence, entry candle.

📌 Step 58: Composite Man Analysis — Institutional Intent Reading
JOB: Read the "Composite Man" (aggregate institutional behavior) from price + volume action.
- ACCUMULATION SIGNATURES (Composite Man buying):
  - Declining volume on drops, increasing on rallies within a range
  - Higher lows forming within range (subtle upward drift)
  - Springs with quick recoveries (testing supply)
  - Large bullish candles appearing with volume after quiet periods
- DISTRIBUTION SIGNATURES (Composite Man selling):
  - Increasing volume on rallies that fail to make new highs
  - Lower highs forming within range (subtle downward drift)
  - Upthrusts with quick reversals (testing demand)
  - Large bearish candles appearing after extended bullish grinds
- INTENT SCORE: -5 (strong distribution) to +5 (strong accumulation). 0 = neutral/uncertain.
- OTC CONTEXT: OTC dealers often mimic Composite Man behavior — use the same framework.
OUTPUT: Accumulation/Distribution intent, intent score, supporting evidence, OTC dealer alignment.

📌 Step 59: Wyckoff-SMC Synthesis — Combined Institutional Grade
JOB: Merge Wyckoff analysis with SMC findings for unified institutional view.
- ALIGNMENT SCORING:
  - Wyckoff Phase C (Spring) + SMC Liquidity Sweep + OB confluence = PERFECT INSTITUTIONAL SETUP (grade A+).
  - Wyckoff Phase D + BOS + trend-following OB = STRONG INSTITUTIONAL (grade A).
  - Wyckoff Phase B + range-bound SMC (FVG fill) = MODERATE INSTITUTIONAL (grade B).
  - Wyckoff contradicts SMC = CONFLICT (reduce confidence by 10%, use SMC over Wyckoff for M1).
- FINAL INSTITUTIONAL VERDICT: is smart money likely BUYING, SELLING, or NEUTRAL at current price?
  - This verdict serves as the ULTIMATE directional bias for the signal.
  - If institutional verdict conflicts with technical indicators → reduce confidence but follow institutions.
OUTPUT: Institutional grade (A+/A/B/C/F), verdict (BUYING/SELLING/NEUTRAL), Wyckoff-SMC agreement.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👑 CATEGORY L — FINAL SYNTHESIS (Steps 60-62)
PURPOSE: Combine ALL 59 previous steps into final decisions. NO new analysis — PURE synthesis.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📌 Step 60: 20-Dimension Signal Confluence Count — Weighted Scoring
JOB: Count agreeing dimensions with institutional weights:
  1) Market Regime (Step 6) — WEIGHT 3
  2) EMA Stack (Step 1) — WEIGHT 2
  3) RSI Gradient (Step 7) — WEIGHT 2
  4) MACD Histogram (Step 9) — WEIGHT 2
  5) Stochastic Zone (Step 8) — WEIGHT 1
  6) CCI Position (Step 11) — WEIGHT 1
  7) Volume Confirmation (Steps 13-16) — WEIGHT 2
  8) OBV Direction (Step 14) — WEIGHT 1
  9) Candlestick Pattern (Steps 17-21) — WEIGHT 2
  10) S/R Proximity (Steps 22-25) — WEIGHT 2
  11) BB Position (Step 23) — WEIGHT 1
  12) Price Structure (Step 3) — WEIGHT 2
  13) Backtest Win Rate (Step 41) — WEIGHT 2
  14) Market Condition Bias (Step 44) — WEIGHT 3
  15) Condition Confidence (Step 53) — WEIGHT 2
  16) Order Block Alignment (Step 30) — WEIGHT 3
  17) FVG/Liquidity Direction (Steps 31,35) — WEIGHT 2
  18) BOS/CHoCH Direction (Step 32) — WEIGHT 3
  19) Trap Matrix Clean (Step 38) — WEIGHT 2
  20) Wyckoff Institutional Verdict (Step 59) — WEIGHT 3
- MAX WEIGHTED SCORE = 41 points
- 35-41=ULTRA HIGH(95%+), 29-34=HIGH(85-94%), 23-28=STRONG(75-84%), 17-22=MODERATE(65-74%), 11-16=LOW(55-64%), <11=AVOID
OUTPUT: Weighted score CALL, PUT, favored direction, confidence bracket.

📌 Step 61: 22-Point Anti-Loss Filter Battery — Critical vs Warning
JOB: Apply EACH filter with severity classification:
  ✗ F1 [CRITICAL]: Trend exhaustion (8+ consecutive same color)
  ✗ F2 [WARNING]: RSI extreme without confirmation candle (-3%)
  ✗ F3 [CRITICAL]: Low volume breakout (vol <0.5x avg)
  ✗ F4 [CRITICAL]: Choppy market (Step 52 score ≥4)
  ✗ F5 [WARNING]: Round number blocking signal path (-3%)
  ✗ F6 [CRITICAL]: Triple oscillator divergence AGAINST signal
  ✗ F7 [WARNING]: BB expanding AGAINST signal direction (-3%)
  ✗ F8 [CRITICAL]: Counter-trend signal in strong ADX >35
  ✗ F9 [CRITICAL]: Exhaustion candle (body >5x avg + volume spike)
  ✗ F10 [WARNING]: Price >3x ATR from EMA20 (-3%)
  ✗ F11 [WARNING]: Volume anomaly (>5x without directional body) (-3%)
  ✗ F12 [WARNING]: Inside bar unresolved (-3%)
  ✗ F13 [CRITICAL]: Short AND long trend BOTH opposing signal
  ✗ F14 [WARNING]: Backtest win rate <55% (-3%)
  ✗ F15 [WARNING]: BB 2σ+ extreme without reversal candle (-3%)
  ✗ F16 [CRITICAL]: CHoCH AGAINST signal in last 3 candles
  ✗ F17 [CRITICAL]: Weighted dimension score <17/41
  ✗ F18 [WARNING]: Hollow volume move (-3%)
  ✗ F19 [CRITICAL]: Signal direction AGAINST institutional verdict (Step 59)
  ✗ F20 [CRITICAL]: Active severity-3 trap from Step 38
  ✗ F21 [WARNING]: Signal entering unfilled FVG against direction (-3%)
  ✗ F22 [WARNING]: OTC dealer manipulation pattern active (Step 37) (-5%)
- ANY CRITICAL filter failed → REJECT signal entirely.
- WARNING penalties sum. Below 50% after penalties → REJECT.
OUTPUT: Filters passed (X/22), critical failures, warning penalties, final adjusted confidence.

📌 Step 62: Final Verdict — Generate Elite Precision Signals
JOB: Using ALL Steps 1-61, generate CALL/PUT signals within ${startTime}-${endTime}.
- Each signal MUST demonstrate evidence from ALL 12 CATEGORIES (A through L)
- Apply market condition rules (Steps 44-55)
- Apply SMC validation (Steps 30-34)
- Apply liquidity/trap filters (Steps 35-39)
- Apply Wyckoff institutional verdict (Steps 56-59)
- Apply confidence calibration (Step 53) + choppy filter (Step 52) + anti-loss filter (Step 61)
- Final confidence = weighted dimension score (Step 60) + condition adjustment (Step 53) + SMC bonus + filter penalties (Step 61)
- EXPLOSIVE MOVE BEST-ENTRY: AI-analyzed optimal candle from Step 42 (data-driven, NOT hardcoded middle)
- INSTITUTIONAL PRIORITY: if SMC/Wyckoff gives A+ grade setup, confidence floor = 75% (institutions rarely wrong)
- Each signal: direction, confidence (50-100%), entry_time (HH:MM), reasoning (1000-2000 words covering ALL 12 categories)

═══════════════════════════════════════════════════════════════
📋 DATA FOR ANALYSIS
═══════════════════════════════════════════════════════════════
${pair1Data}
${pair2Data}

═══════════════════════════════════════════════════════════════
📤 OUTPUT FORMAT — STRICT JSON
═══════════════════════════════════════════════════════════════
Return ONLY a valid JSON object with this EXACT structure:
{
  "signals": [
    {
      "pair": "PAIR_NAME",
      "direction": "CALL" or "PUT",
      "confidence": 50-100,
      "entry_time": "HH:MM",
      "reasoning": "1000-2000 word DEEP ANALYSIS covering ALL 12 categories. CatA-TREND: [EMA stack, slope, structure, ADX] | CatB-MOMENTUM: [RSI gradient, MACD, Stochastic, CCI, divergence] | CatC-VOLUME: [volume ratio, OBV, MFI, climax] | CatD-CANDLES: [patterns, body-wick ratios] | CatE-LEVELS: [S/R, BB position, Fibonacci, round numbers] | CatF-VOLATILITY: [ATR regime, BB squeeze, vol cycle, R:R] | CatG-SMC: [order blocks, FVG, BOS/CHoCH, mitigation, breaker] | CatH-LIQUIDITY: [liquidity pools, sweeps, OTC traps, manipulation] | CatI-BACKTEST: [pattern match, win rate, explosive best-entry, mean reversion] | CatJ-MARKET_CONDITION: [condition, calibration, entry method, choppy penalty] | CatK-WYCKOFF: [phase, spring/upthrust, composite man, institutional grade] | CatL-SYNTHESIS: [X/20 dimensions, X/22 filters, institutional verdict, final confidence]",
      "backtest_winrate": 40-100,
      "explosive_potential": "LOW" or "MEDIUM" or "HIGH",
      "dimensions_confirmed": 8-20,
      "key_findings": ["finding1", "finding2"],
      "martingale": "MG1"
    }
  ]
}

IMPORTANT: 
- You MUST return at least 3-5 signals per pair — NEVER return empty signals array
- Each signal MUST have reasoning 1000-2000 words covering ALL 12 CATEGORIES with deep analysis
- Confidence = categories agreeing (12/12=95%, 10/12=83%, 8/12=67%)
- CHOPPY MARKET: If choppy detected, apply -20% penalty. Below 50% → discard signal.
- BEST-ENTRY for explosive moves: evaluate all explosive candidates at full depth, rank them by highest backtest_winrate first, then confidence, then dimensions_confirmed, and pick the single strongest entry
- INSTITUTIONAL OVERRIDE: A+ SMC/Wyckoff setups get confidence floor of 75%
- Return ONLY the JSON — no markdown, no explanation outside JSON
`;
}

// ═══════════════════════════════════════════════════════════
// GEMINI API CALL WITH KEY ROTATION
// ═══════════════════════════════════════════════════════════

async function callGeminiAI(prompt: string, keys: string[], maxRetries: number = 5): Promise<string> {
  const model = 'gemini-2.5-flash';
  
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    const apiKey = getNextKey(keys);
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

    try {
      console.log(`[AI] Attempt ${attempt + 1}/${maxRetries} with key index ${keyIndex}`);
      
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: 0.25,
            topP: 0.95,
            topK: 64,
            maxOutputTokens: 65536,
            responseMimeType: 'text/plain',
            thinkingConfig: {
              thinkingBudget: 24576,
            },
          },
          safetySettings: [
            { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
            { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' },
            { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_NONE' },
            { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_NONE' },
          ],
        }),
        signal: AbortSignal.timeout(300000), // 5 minutes
      });

      if (response.status === 429 || response.status === 402) {
        console.warn(`[AI] Key exhausted (${response.status}), rotating...`);
        await new Promise(r => setTimeout(r, 2000));
        continue;
      }

      if (!response.ok) {
        const errText = await response.text();
        console.error(`[AI] Error ${response.status}: ${errText.slice(0, 200)}`);
        continue;
      }

      const data = await response.json();
      
      // Extract text from response, filtering out thought blocks
      let fullText = '';
      if (data.candidates?.[0]?.content?.parts) {
        for (const part of data.candidates[0].content.parts) {
          if (part.text && !part.thought) {
            fullText += part.text;
          }
        }
      }

      if (!fullText) {
        console.warn('[AI] Empty response, retrying...');
        continue;
      }

      console.log(`[AI] Got response: ${fullText.length} chars`);
      return fullText;
    } catch (err) {
      console.error(`[AI] Attempt ${attempt + 1} failed:`, err);
      if (attempt < maxRetries - 1) {
        await new Promise(r => setTimeout(r, 3000));
      }
    }
  }

  throw new Error('All Gemini API attempts exhausted');
}

// ═══════════════════════════════════════════════════════════
// RESPONSE PARSER — Extract JSON from AI response
// ═══════════════════════════════════════════════════════════

interface AISignal {
  pair: string;
  direction: 'CALL' | 'PUT';
  confidence: number;
  entry_time: string;
  reasoning: string;
  market_overview: string;
  backtest_winrate: number;
  explosive_potential: string;
  statistical_edge: number;
  price_action_grade: string;
  dimensions_confirmed: number;
  anti_loss_filters_passed: number;
  risk_factors: string[];
  key_findings: string[];
  martingale: string;
}

function extractBalancedJson(text: string): string | null {
  const start = text.indexOf('{');
  if (start === -1) return null;
  let depth = 0;
  for (let i = start; i < text.length; i++) {
    if (text[i] === '{') depth++;
    else if (text[i] === '}') {
      depth--;
      if (depth === 0) return text.slice(start, i + 1);
    }
  }
  return null;
}

// ═══════════════════════════════════════════════════════════
// ROBUST 6-LAYER JSON PARSER — RECOVERS EVERY SINGLE SIGNAL
// ═══════════════════════════════════════════════════════════
function parseAIResponse(text: string): AISignal[] {
  const cleanText = text.replace(/```json\s*/g, '').replace(/```\s*/g, '').trim();
  console.log(`[PARSE] Input length: ${cleanText.length} chars`);
  
  // ════════ LAYER 1: Complete balanced JSON extraction ════════
  try {
    const jsonStr = extractBalancedJson(cleanText);
    if (jsonStr) {
      const parsed = JSON.parse(jsonStr);
      if (parsed.signals && Array.isArray(parsed.signals)) {
        const filtered = parsed.signals.filter((s: any) => 
          s.pair && s.direction && s.confidence >= 50 && s.entry_time
        );
        if (filtered.length > 0) {
          console.log(`[PARSE] ✅ Layer 1 SUCCESS: ${filtered.length} signals from balanced JSON`);
          return filtered;
        }
      }
    }
  } catch (e) {
    console.warn('[PARSE] Layer 1 (balanced JSON) failed:', (e as Error).message);
  }

  // ════════ LAYER 2: Direct array match ════════
  try {
    const arrMatch = cleanText.match(/\[\s*\{[\s\S]*\}\s*\]/);
    if (arrMatch) {
      const arr = JSON.parse(arrMatch[0]);
      const filtered = arr.filter((s: any) => s.pair && s.direction && s.confidence >= 50 && s.entry_time);
      if (filtered.length > 0) {
        console.log(`[PARSE] ✅ Layer 2 SUCCESS: ${filtered.length} signals from array match`);
        return filtered;
      }
    }
  } catch (e) {
    console.warn('[PARSE] Layer 2 (array match) failed:', (e as Error).message);
  }

  // ════════ LAYER 3: Smart truncation repair ════════
  try {
    let truncated = cleanText;
    const firstBrace = truncated.indexOf('{');
    if (firstBrace >= 0) {
      truncated = truncated.slice(firstBrace);
      
      // Remove any incomplete trailing string/value
      truncated = truncated
        .replace(/,\s*"[^"]*"?\s*:\s*"[^"]*$/g, '')  // trailing incomplete key-value
        .replace(/,\s*"[^"]*"?\s*:\s*\[?[^\]]*$/g, '') // trailing incomplete array
        .replace(/,\s*"[^"]*"?\s*$/g, '')  // trailing incomplete key
        .replace(/,\s*$/g, '');  // trailing comma
      
      // Count and close unbalanced braces/brackets
      let openBraces = 0, openBrackets = 0;
      let inString = false, escape = false;
      for (const ch of truncated) {
        if (escape) { escape = false; continue; }
        if (ch === '\\') { escape = true; continue; }
        if (ch === '"') { inString = !inString; continue; }
        if (inString) continue;
        if (ch === '{') openBraces++;
        else if (ch === '}') openBraces--;
        else if (ch === '[') openBrackets++;
        else if (ch === ']') openBrackets--;
      }
      
      // Close everything properly
      for (let i = 0; i < openBrackets; i++) truncated += ']';
      for (let i = 0; i < openBraces; i++) truncated += '}';
      
      const parsed = JSON.parse(truncated);
      if (parsed.signals && Array.isArray(parsed.signals)) {
        const filtered = parsed.signals.filter((s: any) => 
          s.pair && s.direction && s.confidence >= 50 && s.entry_time
        );
        if (filtered.length > 0) {
          console.log(`[PARSE] ✅ Layer 3 SUCCESS: ${filtered.length} signals from truncation repair`);
          return filtered;
        }
      }
    }
  } catch (e) {
    console.warn('[PARSE] Layer 3 (truncation repair) failed:', (e as Error).message);
  }

  // ════════ LAYER 4: Individual signal block extraction ════════
  try {
    const signals: AISignal[] = [];
    // Match each complete signal object between {...}
    const signalRegex = /\{\s*"pair"\s*:\s*"[^"]+"\s*,[\s\S]*?"direction"\s*:\s*"(CALL|PUT)"[\s\S]*?"confidence"\s*:\s*\d+[\s\S]*?"entry_time"\s*:\s*"\d{1,2}:\d{2}"[\s\S]*?\}/g;
    let match;
    while ((match = signalRegex.exec(cleanText)) !== null) {
      try {
        // Clean and repair the individual block
        let block = match[0]
          .replace(/,\s*\}/g, '}')
          .replace(/,\s*\]/g, ']');
        
        const parsed = JSON.parse(block);
        if (parsed.pair && parsed.direction && parsed.confidence >= 50 && parsed.entry_time) {
          signals.push({
            pair: parsed.pair,
            direction: parsed.direction,
            confidence: parsed.confidence,
            entry_time: parsed.entry_time,
            reasoning: parsed.reasoning || '',
            market_overview: parsed.market_overview || '',
            backtest_winrate: parsed.backtest_winrate || 0,
            explosive_potential: parsed.explosive_potential || 'LOW',
            statistical_edge: parsed.statistical_edge || 0,
            price_action_grade: parsed.price_action_grade || 'B',
            dimensions_confirmed: parsed.dimensions_confirmed || 10,
            anti_loss_filters_passed: parsed.anti_loss_filters_passed || 18,
            risk_factors: parsed.risk_factors || [],
            key_findings: parsed.key_findings || [],
            martingale: parsed.martingale || 'MG1',
          });
        }
      } catch { /* skip malformed individual block */ }
    }
    if (signals.length > 0) {
      console.log(`[PARSE] ✅ Layer 4 SUCCESS: ${signals.length} signals from individual block extraction`);
      return signals;
    }
  } catch (e) {
    console.warn('[PARSE] Layer 4 (block extraction) failed:', (e as Error).message);
  }

  // ════════ LAYER 5: Progressive field extraction ════════
  try {
    const signals: AISignal[] = [];
    
    // Find all pairs mentioned
    const pairMatches = [...cleanText.matchAll(/"pair"\s*:\s*"([^"]+)"/g)];
    const dirMatches = [...cleanText.matchAll(/"direction"\s*:\s*"(CALL|PUT)"/g)];
    const confMatches = [...cleanText.matchAll(/"confidence"\s*:\s*(\d+)/g)];
    const timeMatches = [...cleanText.matchAll(/"entry_time"\s*:\s*"(\d{1,2}:\d{2})"/g)];
    const reasonMatches = [...cleanText.matchAll(/"reasoning"\s*:\s*"((?:[^"\\]|\\.)*)"/g)];
    const mgMatches = [...cleanText.matchAll(/"martingale"\s*:\s*"([^"]+)"/g)];
    const btwrMatches = [...cleanText.matchAll(/"backtest_winrate"\s*:\s*(\d+)/g)];
    
    const count = Math.min(pairMatches.length, dirMatches.length, confMatches.length, timeMatches.length);
    
    for (let i = 0; i < count; i++) {
      const pair = pairMatches[i]?.[1] || '';
      const dir = dirMatches[i]?.[1] as 'CALL' | 'PUT';
      const conf = parseInt(confMatches[i]?.[1] || '0');
      const time = timeMatches[i]?.[1] || '';
      const reasoning = reasonMatches[i]?.[1] || '';
      const mg = mgMatches[i]?.[1] || 'MG1';
      const btwr = parseInt(btwrMatches[i]?.[1] || '0');
      
      if (pair && dir && conf >= 50 && time) {
        signals.push({
          pair,
          direction: dir,
          confidence: conf,
          entry_time: time,
          reasoning,
          market_overview: '',
          backtest_winrate: btwr,
          explosive_potential: 'LOW',
          statistical_edge: 0,
          price_action_grade: 'B',
          dimensions_confirmed: 10,
          anti_loss_filters_passed: 18,
          risk_factors: [],
          key_findings: [],
          martingale: mg,
        });
      }
    }
    
    if (signals.length > 0) {
      console.log(`[PARSE] ✅ Layer 5 SUCCESS: ${signals.length} signals from progressive field extraction`);
      return signals;
    }
  } catch (e) {
    console.warn('[PARSE] Layer 5 (progressive extraction) failed:', (e as Error).message);
  }

  // ════════ LAYER 6: Deep text mining (last resort) ════════
  console.warn('[PARSE] Layer 6: Deep text mining (emergency recovery)...');
  const signals: AISignal[] = [];
  
  // Split text by likely signal boundaries
  const chunks = cleanText.split(/(?=\{"pair")/);
  
  for (const chunk of chunks) {
    // Extract each field independently with flexible patterns
    const pairMatch = chunk.match(/["\']?pair["\']?\s*[:=]\s*["\']([^"'\s,}]+)/i);
    const dirMatch = chunk.match(/["\']?direction["\']?\s*[:=]\s*["\']?(CALL|PUT)/i);
    const confMatch = chunk.match(/["\']?confidence["\']?\s*[:=]\s*["\']?(\d{2,3})/i);
    const timeMatch = chunk.match(/["\']?entry_time["\']?\s*[:=]\s*["\']?(\d{1,2}:\d{2})/i);
    
    if (pairMatch && dirMatch && confMatch && timeMatch) {
      const pair = pairMatch[1].replace(/_otc$/i, '').replace(/-OTC$/i, '');
      const dir = dirMatch[1].toUpperCase() as 'CALL' | 'PUT';
      const conf = parseInt(confMatch[1]);
      const time = timeMatch[1];
      
      // Extract reasoning if available
      const reasonMatch = chunk.match(/["\']?reasoning["\']?\s*[:=]\s*["\']((?:[^"\'\\]|\\.)*)["\']/i);
      const reasoning = reasonMatch ? reasonMatch[1] : '';
      
      if (conf >= 50) {
        // Avoid duplicates
        const exists = signals.some(s => s.pair === pair && s.entry_time === time);
        if (!exists) {
          signals.push({
            pair,
            direction: dir,
            confidence: conf,
            entry_time: time,
            reasoning,
            market_overview: '',
            backtest_winrate: 0,
            explosive_potential: 'LOW',
            statistical_edge: 0,
            price_action_grade: 'B',
            dimensions_confirmed: 10,
            anti_loss_filters_passed: 18,
            risk_factors: [],
            key_findings: [],
            martingale: 'MG1',
          });
        }
      }
    }
  }
  
  if (signals.length > 0) {
    console.log(`[PARSE] ✅ Layer 6 SUCCESS: ${signals.length} signals from deep text mining`);
  } else {
    console.error('[PARSE] ❌ ALL 6 LAYERS FAILED — No signals recovered');
  }

  return signals;
}

// ═══════════════════════════════════════════════════════════
// SUPABASE CLIENT FOR JOB TRACKING
// ═══════════════════════════════════════════════════════════

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.89.0";

function getSupabaseAdmin() {
  const url = Deno.env.get('SUPABASE_URL')!;
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  return createClient(url, serviceKey);
}

async function updateJob(jobId: string, updates: { progress?: number; status?: string; result?: any; error?: string }) {
  const sb = getSupabaseAdmin();
  const updateData: any = { updated_at: new Date().toISOString() };
  if (updates.progress !== undefined) updateData.progress = updates.progress;
  if (updates.status !== undefined) updateData.status = updates.status;
  if (updates.result !== undefined) updateData.result = updates.result;
  if (updates.error !== undefined) updateData.error = updates.error;
  await sb.from('processing_jobs').update(updateData).eq('id', jobId);
}

// ═══════════════════════════════════════════════════════════
// BACKGROUND PROCESSING FUNCTION
// ═══════════════════════════════════════════════════════════

async function processAnalysis(jobId: string, pairs: string[], startTime: string, endTime: string) {
  try {
    const geminiKeys = getGeminiKeys();
    if (geminiKeys.length === 0) {
      await updateJob(jobId, { status: 'failed', error: 'No API keys configured', progress: 0 });
      return;
    }

    const pair1 = pairs[0];
    const pair2 = pairs.length > 1 ? pairs[1] : null;

    console.log(`🧬 QUANTUM-NEXUS V14 | Job ${jobId} | Analyzing: ${pair1}${pair2 ? ` + ${pair2}` : ''}`);

    // ═══ PHASE 1: FETCH DATA (0% → 20%) ═══
    await updateJob(jobId, { progress: 5, status: 'processing' });
    console.log('📡 Fetching candle data...');

    const fetchPromises: Promise<Candle[]>[] = [
      fetchLiveCandles(pair1),
      fetchBacktestCandles(pair1),
    ];
    if (pair2) {
      fetchPromises.push(fetchLiveCandles(pair2));
      fetchPromises.push(fetchBacktestCandles(pair2));
    }

    const fetchResults = await Promise.all(fetchPromises);
    const live1 = fetchResults[0];
    const backtest1Raw = fetchResults[1];
    const live2 = pair2 ? fetchResults[2] : [];
    const backtest2Raw = pair2 ? fetchResults[3] : [];

    await updateJob(jobId, { progress: 20 });
    console.log(`📊 Data: ${pair1}=${live1.length} live + ${backtest1Raw.length} backtest${pair2 ? ` | ${pair2}=${live2.length} live + ${backtest2Raw.length} backtest` : ''}`);

    if (live1.length < 200) {
      await updateJob(jobId, {
        status: 'completed', progress: 100,
        result: { success: true, signals: [], reason: `Insufficient data for ${pair1}: ${live1.length} candles` },
      });
      return;
    }

    // ═══ PHASE 2: TECHNICAL ANALYSIS (20% → 35%) ═══
    console.log('🔬 Calculating technical indicators...');
    const tech1 = calculateTechnicalSummary(live1);
    if (!tech1) {
      await updateJob(jobId, {
        status: 'completed', progress: 100,
        result: { success: true, signals: [], reason: `Failed to calculate indicators for ${pair1}` },
      });
      return;
    }

    const backtestCandles1 = backtest1Raw.length > live1.length ? backtest1Raw : live1;
    const bt1 = calculateBacktestStats(backtestCandles1);
    const recent1 = formatRecentCandles(live1, 50);

    let tech2: TechnicalSummary | null = null;
    let bt2: BacktestStats | null = null;
    let recent2: string | null = null;

    if (pair2 && live2.length >= 200) {
      tech2 = calculateTechnicalSummary(live2);
      if (tech2) {
        const backtestCandles2 = backtest2Raw.length > live2.length ? backtest2Raw : live2;
        bt2 = calculateBacktestStats(backtestCandles2);
        recent2 = formatRecentCandles(live2, 50);
      }
    }

    await updateJob(jobId, { progress: 35 });

    // ═══ PHASE 3: BUILD PROMPT (35% → 40%) ═══
    console.log('🧠 Building 62-step analysis prompt...');
    const prompt = buildAnalysisPrompt(
      pair1, tech1, bt1, recent1,
      pair2, tech2, bt2, recent2,
      startTime, endTime
    );
    console.log(`📝 Prompt size: ${prompt.length} chars`);
    await updateJob(jobId, { progress: 40 });

    // ═══ PHASE 4: AI ANALYSIS (40% → 90%) ═══
    console.log('🔮 Calling QUANTUM-NEXUS V14 AI...');
    // Update progress periodically during AI call
    const progressTimer = setInterval(async () => {
      try {
        const sb = getSupabaseAdmin();
        const { data } = await sb.from('processing_jobs').select('progress').eq('id', jobId).single();
        if (data && data.progress < 88) {
          await updateJob(jobId, { progress: data.progress + 3 });
        }
      } catch {}
    }, 8000); // Every 8 seconds, increment progress by 3%

    let aiResponse: string;
    try {
      aiResponse = await callGeminiAI(prompt, geminiKeys);
    } finally {
      clearInterval(progressTimer);
    }

    await updateJob(jobId, { progress: 92 });

    // ═══ PHASE 5: PARSE & FINALIZE (90% → 100%) ═══
    console.log('📦 Parsing AI response...');
    console.log(`[AI-RAW] Response preview: ${aiResponse.slice(0, 500)}`);
    const explosiveRank: Record<string, number> = { HIGH: 3, MEDIUM: 2, LOW: 1 };
    const rawSignals = parseAIResponse(aiResponse);

    // ═══ DEDUPLICATION: Remove duplicate signals for same pair+entry_time ═══
    // Keep the signal with higher confidence when duplicates exist
    const dedupMap = new Map<string, typeof rawSignals[0]>();
    for (const sig of rawSignals) {
      const key = `${sig.pair}_${sig.entry_time}`;
      const existing = dedupMap.get(key);
      if (!existing || sig.confidence > existing.confidence) {
        dedupMap.set(key, sig);
      }
    }
    const dedupedSignals = Array.from(dedupMap.values());
    if (rawSignals.length !== dedupedSignals.length) {
      console.log(`[DEDUP] Removed ${rawSignals.length - dedupedSignals.length} duplicate signals (same pair+entry_time)`);
    }

    const signals = dedupedSignals.sort((a, b) => {
      const byBacktest = (b.backtest_winrate || 0) - (a.backtest_winrate || 0);
      if (byBacktest !== 0) return byBacktest;
      const byExplosive = (explosiveRank[String(b.explosive_potential || 'LOW').toUpperCase()] || 0) - (explosiveRank[String(a.explosive_potential || 'LOW').toUpperCase()] || 0);
      if (byExplosive !== 0) return byExplosive;
      const byDimensions = (b.dimensions_confirmed || 0) - (a.dimensions_confirmed || 0);
      if (byDimensions !== 0) return byDimensions;
      return (b.confidence || 0) - (a.confidence || 0);
    });

    console.log(`✅ Analysis complete: ${signals.length} signals`);
    for (const sig of signals) {
      console.log(`  🎯 ${sig.pair} → ${sig.direction} @ ${sig.entry_time} | Confidence: ${sig.confidence}%`);
    }

    await updateJob(jobId, {
      status: 'completed',
      progress: 100,
      result: {
        success: true,
        signals,
        pairsAnalyzed: pair2 ? 2 : 1,
        dataPoints: {
          pair1: { live: live1.length, backtest: backtestCandles1.length },
          pair2: pair2 ? { live: live2.length, backtest: (backtest2Raw.length > live2.length ? backtest2Raw : live2).length } : null,
        },
      },
    });

  } catch (error) {
    console.error('🔥 Background processing error:', error);
    await updateJob(jobId, {
      status: 'failed',
      error: error instanceof Error ? error.message : 'Unknown error',
      progress: 0,
    });
  }
}

// ═══════════════════════════════════════════════════════════
// MAIN HANDLER — Async Job Pattern
// ═══════════════════════════════════════════════════════════

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const action = body.action as string || 'start';

    // ═══ STATUS CHECK ═══
    if (action === 'status') {
      const jobId = body.jobId as string;
      if (!jobId) {
        return new Response(JSON.stringify({ error: 'Missing jobId' }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400,
        });
      }

      const sb = getSupabaseAdmin();
      const { data, error } = await sb.from('processing_jobs').select('*').eq('id', jobId).single();

      if (error || !data) {
        return new Response(JSON.stringify({ error: 'Job not found' }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 404,
        });
      }

      return new Response(JSON.stringify({
        jobId: data.id,
        status: data.status,
        progress: data.progress,
        result: data.result,
        error: data.error,
      }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    // ═══ START NEW JOB ═══
    const pairs = body.pairs as string[];
    const startTime = body.startTime as string || '00:00';
    const endTime = body.endTime as string || '23:59';

    if (!pairs || !Array.isArray(pairs) || pairs.length === 0) {
      return new Response(JSON.stringify({ success: false, error: 'Missing pairs array' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400,
      });
    }

    // Create job record
    const sb = getSupabaseAdmin();
    const { data: job, error: jobError } = await sb.from('processing_jobs').insert({
      status: 'processing',
      progress: 0,
    }).select('id').single();

    if (jobError || !job) {
      console.error('Failed to create job:', jobError);
      return new Response(JSON.stringify({ success: false, error: 'Failed to create job' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500,
      });
    }

    const jobId = job.id;
    console.log(`🚀 Job ${jobId} created for pairs: ${pairs.join(', ')}`);

    // Process in background — return jobId immediately so the HTTP connection doesn't timeout
    // The frontend polls the processing_jobs table for progress updates
    (globalThis as any).EdgeRuntime?.waitUntil?.(processAnalysis(jobId, pairs, startTime, endTime)) 
      || processAnalysis(jobId, pairs, startTime, endTime).catch(err => console.error('Background processing error:', err));

    return new Response(JSON.stringify({
      success: true,
      jobId,
      status: 'processing',
      progress: 0,
    }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });

  } catch (error) {
    console.error('🔥 Future Signal Error:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 });
  }
});
