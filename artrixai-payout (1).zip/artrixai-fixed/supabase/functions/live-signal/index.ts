import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { OTC_API_BASE, extractApiTime, extractApiVolume, parseQuotexCandles } from "../_shared/quotex.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface OandaCandle {
  time: string;
  mid: {
    o: string;
    h: string;
    l: string;
    c: string;
  };
  volume: number;
  complete: boolean;
}

interface OandaCandlesResponse {
  instrument?: string;
  granularity?: string;
  candles?: OandaCandle[];
  errorMessage?: string;
}

// Check if market is OTC (Quotex)
function isOTCMarket(market: string): boolean {
  return market.endsWith('-OTC');
}

// Convert frontend symbol to OANDA format (e.g., EUR/USD -> EUR_USD)
function convertToOandaSymbol(market: string): string {
  return market.replace('/', '_');
}

// Fetch candles from OANDA API (for real market)
async function fetchOandaCandles(symbol: string, granularity: string = 'M1', count: number = 500): Promise<OandaCandle[]> {
  const OANDA_API_KEY = Deno.env.get('OANDA_API_KEY');
  const OANDA_ENDPOINT = Deno.env.get('OANDA_ENDPOINT') || 'https://api-fxpractice.oanda.com/v3';
  
  if (!OANDA_API_KEY) {
    throw new Error('OANDA_API_KEY not configured');
  }
  
  const oandaSymbol = convertToOandaSymbol(symbol);
  const url = `${OANDA_ENDPOINT}/instruments/${oandaSymbol}/candles?granularity=${granularity}&count=${count}`;
  console.log(`Fetching OANDA data from: ${url}`);

  const response = await fetch(url, {
    headers: {
      'Authorization': `Bearer ${OANDA_API_KEY}`,
      'Content-Type': 'application/json',
    }
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`OANDA API error: ${response.status} - ${errorText}`);
    throw new Error(`OANDA API error: ${response.status}`);
  }

  const data: OandaCandlesResponse = await response.json();
  
  if (data.errorMessage) {
    throw new Error(`OANDA error: ${data.errorMessage}`);
  }

  if (!data.candles || data.candles.length === 0) {
    throw new Error('No data received from OANDA API');
  }

  console.log(`OANDA returned ${data.candles.length} candles for ${oandaSymbol}`);
  return data.candles.filter(c => c.complete);
}

// Self-Correction Memory
interface SignalOutcome {
  market: string;
  direction: 'CALL' | 'PUT';
  entryPrice: number;
  exitPrice: number;
  result: 'WIN' | 'LOSS' | 'MTG';
  reason: string;
  timestamp: string;
  setup: string;
  indicators: string[];
  htfBias: string;
  m1Smc: string;
}

const selfCorrectionMemory: Map<string, SignalOutcome[]> = new Map();
const lastTradeResult: Map<string, { result: 'WIN' | 'LOSS'; direction: 'CALL' | 'PUT'; candleTime: string }> = new Map();

function addToSelfCorrection(outcome: SignalOutcome): void {
  const key = outcome.market;
  const existing = selfCorrectionMemory.get(key) || [];
  existing.push(outcome);
  if (existing.length > 50) existing.shift();
  selfCorrectionMemory.set(key, existing);
  console.log(`Self-correction: Added ${outcome.result} for ${outcome.market}. Total: ${existing.length}`);
}

function getSelfCorrectionInsights(market: string): string {
  const outcomes = selfCorrectionMemory.get(market) || [];
  if (outcomes.length === 0) return '';

  const losses = outcomes.filter(o => o.result === 'LOSS');
  if (losses.length === 0) return 'No recent losses to learn from.';

  const lossPatterns: { [key: string]: number } = {};
  const lossSetups: { [key: string]: number } = {};

  losses.slice(-10).forEach(loss => {
    if (loss.reason) {
      lossPatterns[loss.reason] = (lossPatterns[loss.reason] || 0) + 1;
    }
    if (loss.setup) {
      lossSetups[loss.setup] = (lossSetups[loss.setup] || 0) + 1;
    }
  });

  const insights: string[] = [];
  const topPatterns = Object.entries(lossPatterns).sort((a, b) => b[1] - a[1]).slice(0, 3);
  if (topPatterns.length > 0) {
    insights.push(`AVOID PATTERNS: ${topPatterns.map(([p, c]) => `${p}(${c}x)`).join(', ')}`);
  }

  const winRate = ((outcomes.length - losses.length) / outcomes.length * 100).toFixed(1);
  insights.push(`WIN RATE: ${winRate}% (${outcomes.length - losses.length}W/${losses.length}L of ${outcomes.length})`);

  return insights.join(' | ');
}

// Backtest
function backtestSignal(
  candles: OandaCandle[],
  signalDirection: 'CALL' | 'PUT',
  entryIndex: number,
  lookbackPeriods: number = 100
): { winRate: number; totalTests: number; wins: number; losses: number; avgPips: number } {
  if (candles.length < lookbackPeriods + 50) {
    return { winRate: 0, totalTests: 0, wins: 0, losses: 0, avgPips: 0 };
  }

  let wins = 0;
  let losses = 0;
  let totalPips = 0;
  const testPoints: number[] = [];

  const step = Math.floor((candles.length - 100) / lookbackPeriods);
  for (let i = 100; i < candles.length - 1; i += step) {
    if (testPoints.length >= lookbackPeriods) break;
    testPoints.push(i);
  }

  testPoints.forEach(idx => {
    const entryPrice = parseFloat(candles[idx].mid.c);
    const exitPrice = parseFloat(candles[idx + 1].mid.c);
    const priceDiff = exitPrice - entryPrice;
    
    let isWin = false;
    if (signalDirection === 'CALL') {
      isWin = priceDiff > 0;
    } else {
      isWin = priceDiff < 0;
    }

    if (isWin) {
      wins++;
      totalPips += Math.abs(priceDiff);
    } else {
      losses++;
      totalPips -= Math.abs(priceDiff);
    }
  });

  const totalTests = wins + losses;
  const winRate = totalTests > 0 ? (wins / totalTests) * 100 : 0;
  const avgPips = totalTests > 0 ? totalPips / totalTests : 0;

  return { winRate, totalTests, wins, losses, avgPips };
}

// Quotex OTC API
// Store latest payout per market for signal output
const latestPayout: Map<string, number> = new Map();

// Stock OTC pairs require special API format: SYMBOL-OTC -> SYMBOLSTK_otc
const STOCK_OTC_MAP: Record<string, string> = {
  'AXP-OTC': 'AXP_otc',
  'PFE-OTC': 'PFE_otc',
  'INTL-OTC': 'INTL_otc',
  'JNJ-OTC': 'JNJ_otc',
  'MCD-OTC': 'MCD_otc',
  'FB-OTC': 'FB_otc',
  'BA-OTC': 'BA_otc',
  'MSFT-OTC': 'MSFT_otc',
  'USCrude-OTC': 'USCrude_otc',
  'UKBrent-OTC': 'UKBrent_otc',
  'FLOUSD-OTC': 'FLOUSD_otc',
};

async function fetchQuotexOTCCandles(pair: string, count: number = 500): Promise<OandaCandle[]> {
  // Convert pair format: use stock mapping if available, otherwise EURUSD-OTC -> EURUSD_otc
  const apiPair = STOCK_OTC_MAP[pair] || pair.replace('-OTC', '_otc');
  const url = `${OTC_API_BASE}?pair=${encodeURIComponent(apiPair)}&timeframe=M1&count=${count}`;
  console.log(`Fetching Quotex OTC data from: ${url}`);

  const MAX_RETRIES = 3;
  let response: Response | null = null;
  let lastError: Error | null = null;

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Lovable Cloud)',
          'Accept': 'application/json'
        }
      });

      if (response.ok) break; // success

      const status = response.status;
      console.error(`Quotex API HTTP error (attempt ${attempt}/${MAX_RETRIES}): ${status}`);
      await response.text(); // consume body

      if (status >= 500 && attempt < MAX_RETRIES) {
        const delayMs = attempt * 2000; // 2s, 4s
        console.log(`Retrying in ${delayMs}ms...`);
        await new Promise(r => setTimeout(r, delayMs));
        response = null;
        continue;
      }

      lastError = new Error(`Data source temporarily unavailable (${status}). Please try again.`);
    } catch (fetchError) {
      console.error(`Network error (attempt ${attempt}/${MAX_RETRIES}):`, fetchError);
      lastError = new Error('Network error: Unable to connect to data source. Please try again.');
      if (attempt < MAX_RETRIES) {
        await new Promise(r => setTimeout(r, attempt * 2000));
        continue;
      }
    }
  }

  if (!response || !response.ok) {
    throw lastError || new Error('Data source unavailable after retries. Please try again.');
  }

  const raw = await response.text();
  
  // Try to extract JSON even if wrapped in HTML
  let jsonContent = raw.trim();
  
  // If response contains HTML, try to extract JSON from it
  if (raw.includes('<html') || raw.includes('<!DOCTYPE') || raw.startsWith('<')) {
    console.log('Response contains HTML, attempting to extract JSON...');
    const startObj = raw.indexOf('{');
    const endObj = raw.lastIndexOf('}');
    const startArr = raw.indexOf('[');
    const endArr = raw.lastIndexOf(']');
    
    if (startArr !== -1 && endArr !== -1 && endArr > startArr) {
      jsonContent = raw.slice(startArr, endArr + 1);
    } else if (startObj !== -1 && endObj !== -1 && endObj > startObj) {
      jsonContent = raw.slice(startObj, endObj + 1);
    } else {
      console.error('Quotex API returned HTML with no extractable JSON. Response preview:', raw.substring(0, 200));
      throw new Error('Data source returned invalid format. Please try again in a few seconds.');
    }
  }

  // Check for empty response
  if (!jsonContent || jsonContent.length === 0) {
    throw new Error('Data source returned empty response. Please try again.');
  }

  let rows;
  try {
    rows = parseQuotexCandles(jsonContent);
  } catch (parseError) {
    console.error('Failed to parse JSON content:', jsonContent.substring(0, 200));
    throw new Error('Data parsing failed. Please try again.');
  }

  if (!rows || rows.length === 0) {
    throw new Error('No data received from Quotex API');
  }

  // Extract payout from the latest candle (all candles share the same payout for a pair)
  const firstWithPayout = rows.find((c) => typeof c.payout === 'number' && c.payout > 0);
  if (firstWithPayout && typeof firstWithPayout.payout === 'number') {
    latestPayout.set(pair, firstWithPayout.payout);
    console.log(`[Quotex] Payout for ${pair}: ${firstWithPayout.payout}%`);
  }

  // Map to standard format - support both 'time' and 'candle_time' fields
  const mapped = rows.map((c) => {
    const parsedVolume = extractApiVolume(c);
    return {
      time: extractApiTime(c),
      mid: {
        o: String(Number(c.open ?? c.o ?? 0)),
        h: String(Number(c.high ?? c.h ?? 0)),
        l: String(Number(c.low ?? c.l ?? 0)),
        c: String(Number(c.close ?? c.c ?? 0)),
      },
      volume: parsedVolume,
      complete: true,
    };
  });

  const nonZeroVolumeCount = mapped.filter((c) => c.volume > 0).length;
  console.log(`[Quotex] Volume candles for ${pair}: ${nonZeroVolumeCount}/${mapped.length} non-zero (API volume only)`);

  // API returns data in reverse chronological order (newest first)
  // Sort by time ascending (oldest first) to ensure proper chart rendering without gaps
  mapped.sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime());

  return mapped;
}

// OTC chart normalization (visual only)
// Goal: remove artificial "gap up / gap down" artifacts caused by missing/duplicated minute bars.
// Strategy:
// 1) Deduplicate by minute
// 2) Split into segments if a large time jump happens
// 3) Fill small missing gaps with synthetic 1m candles (interpolated)
// 4) Force continuity: open = previous close (OTC should appear continuous)
const OTC_BAR_MS = 60_000;

type BasicOtcCandle = {
  tMs: number;
  open: number;
  high: number;
  low: number;
  close: number;
};

function toMinuteMs(iso: string): number | null {
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return null;
  return Math.floor(t / OTC_BAR_MS) * OTC_BAR_MS;
}

function buildNormalizedOtcChartCandles(
  raw: OandaCandle[],
  desiredCount: number = 50,
  maxFillMissingMinutes: number = 10
): { datetime: string; open: number; high: number; low: number; close: number }[] {
  const base: BasicOtcCandle[] = raw
    .map((c) => {
      const tMs = toMinuteMs(c.time);
      const open = Number(c.mid?.o);
      const high = Number(c.mid?.h);
      const low = Number(c.mid?.l);
      const close = Number(c.mid?.c);
      if (
        tMs === null ||
        !Number.isFinite(open) ||
        !Number.isFinite(high) ||
        !Number.isFinite(low) ||
        !Number.isFinite(close) ||
        open <= 0 ||
        high <= 0 ||
        low <= 0 ||
        close <= 0
      ) {
        return null;
      }
      return { tMs, open, high, low, close };
    })
    .filter((x): x is BasicOtcCandle => x !== null)
    .sort((a, b) => a.tMs - b.tMs);

  if (base.length === 0) return [];

  // Deduplicate by minute (keep latest seen for that minute)
  const dedupMap = new Map<number, BasicOtcCandle>();
  for (const c of base) dedupMap.set(c.tMs, c);
  const uniq = Array.from(dedupMap.values()).sort((a, b) => a.tMs - b.tMs);

  // Segment + fill
  const segments: BasicOtcCandle[][] = [];
  let seg: BasicOtcCandle[] = [];

  for (let i = 0; i < uniq.length; i++) {
    const cur = uniq[i];
    if (seg.length === 0) {
      seg.push(cur);
      continue;
    }

    const prev = seg[seg.length - 1];
    const gapMinutes = Math.round((cur.tMs - prev.tMs) / OTC_BAR_MS);
    const missing = gapMinutes - 1;

    // Big jump -> start a new segment (avoids huge blank spaces on the chart)
    if (missing > maxFillMissingMinutes) {
      segments.push(seg);
      seg = [cur];
      continue;
    }

    // Fill small missing gaps with synthetic candles
    if (missing > 0) {
      const nextOpen = cur.open;
      const prevClose = prev.close;
      let lastClose = prevClose;

      for (let k = 1; k <= missing; k++) {
        const ratio = k / (missing + 1);
        const tMs = prev.tMs + k * OTC_BAR_MS;
        const open = lastClose;
        const close = prevClose + (nextOpen - prevClose) * ratio;
        const high = Math.max(open, close);
        const low = Math.min(open, close);
        seg.push({ tMs, open, high, low, close });
        lastClose = close;
      }
    }

    seg.push(cur);
  }
  if (seg.length) segments.push(seg);

  const lastSeg = segments[segments.length - 1] || [];
  if (lastSeg.length === 0) return [];

  // Force continuity (remove "gap up/down" artifacts visually)
  for (let i = 0; i < lastSeg.length; i++) {
    const c = lastSeg[i];
    // Ensure ranges include open/close
    c.high = Math.max(c.high, c.open, c.close);
    c.low = Math.min(c.low, c.open, c.close);

    if (i === 0) continue;
    const prev = lastSeg[i - 1];
    c.open = prev.close;
    c.high = Math.max(c.high, c.open, c.close);
    c.low = Math.min(c.low, c.open, c.close);
  }

  const window = lastSeg.slice(-desiredCount);
  return window.map((c) => ({
    datetime: new Date(c.tMs).toISOString(),
    open: c.open,
    high: c.high,
    low: c.low,
    close: c.close,
  }));
}

function aggregateCandles(source: OandaCandle[], minutes: number): OandaCandle[] {
  if (!source || source.length === 0) return [];
  const intervalMs = minutes * 60 * 1000;

  const sorted = [...source].sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime());

  const buckets = new Map<number, OandaCandle[]>();
  for (const c of sorted) {
    const t = new Date(c.time).getTime();
    if (Number.isNaN(t)) continue;
    const bucketStart = Math.floor(t / intervalMs) * intervalMs;
    const arr = buckets.get(bucketStart) || [];
    arr.push(c);
    buckets.set(bucketStart, arr);
  }

  const out: OandaCandle[] = [];
  const keys = Array.from(buckets.keys()).sort((a, b) => a - b);
  for (const k of keys) {
    const group = buckets.get(k);
    if (!group || group.length === 0) continue;

    const open = Number(group[0].mid.o);
    const close = Number(group[group.length - 1].mid.c);
    const high = Math.max(...group.map((x) => Number(x.mid.h)));
    const low = Math.min(...group.map((x) => Number(x.mid.l)));
    const volume = group.reduce((sum, x) => sum + (Number(x.volume) || 0), 0);

    out.push({
      time: new Date(k).toISOString(),
      mid: {
        o: String(open),
        h: String(high),
        l: String(low),
        c: String(close),
      },
      volume,
      complete: true,
    });
  }

  return out;
}

// ============= AVOID RULES VALIDATION ENGINE =============
// This engine validates ALL strategies against their specific avoid rules.
// ONLY strategies that PASS their avoid rules are counted as VALID.
// Invalid strategies are 100% EXCLUDED from analysis.

interface MarketConditions {
  adx: number;
  emaAngle: number;
  ema20: number;
  ema50: number;
  ema200: number;
  trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  rsi: number;
  rsi4: number;
  currentPrice: number;
  bodySize: number;
  upperWick: number;
  lowerWick: number;
  range: number;
  avgBody: number;
  isBullishCandle: boolean;
  isBearishCandle: boolean;
  volume: number;
  avgVolume: number;
  volumeRatio: number;
  bbUpper: number;
  bbLower: number;
  bbWidth: number;
  bbExpanding: boolean;
  atr: number;
  atrAvg: number;
  macdHistogram: number;
  stochK: number;
  stochD: number;
  minute: number;
  second: number;
  isNewsTime: boolean;
  support: number;
  resistance: number;
  nearRoundNumber: boolean;
  roundNumberDistance: number;
  consecutiveSameColor: number;
  isMarubozu: boolean;
  isDoji: boolean;
  hasWicks: boolean;
  last10CandlesSameDirection: boolean;
}

interface AvoidRuleResult {
  isValid: boolean;
  blockedReason: string | null;
  passedConditions: string[];
  failedConditions: string[];
}

// Global Salami Trend Rule: Blocks ALL reversal trades during 8-10 consecutive candles
function checkGlobalSalamiTrend(conditions: MarketConditions, signal: 'CALL' | 'PUT'): { blocked: boolean; reason: string } {
  const isReversalSignal = 
    (signal === 'CALL' && conditions.last10CandlesSameDirection && conditions.isBearishCandle) ||
    (signal === 'PUT' && conditions.last10CandlesSameDirection && conditions.isBullishCandle);
  
  if (isReversalSignal && conditions.consecutiveSameColor >= 8) {
    return {
      blocked: true,
      reason: `GLOBAL AVOID: Salami Trend (${conditions.consecutiveSameColor} consecutive candles) - Reversal blocked`
    };
  }
  return { blocked: false, reason: '' };
}

// ============= AVOID RULES DATABASE (Synced from setupAvoidRules.ts) =============
// Setup-specific avoid rules for each strategy - NOT generic category filters

interface SetupAvoidRule {
  setupName: string;
  avoidConditions: { condition: string; check: (c: MarketConditions, sig: 'CALL' | 'PUT') => boolean }[];
}

// 235 Setup Avoid Rules Database (key rules synced)
const SETUP_235_AVOID_RULES: SetupAvoidRule[] = [
  { setupName: "HTF Demand + Hammer", avoidConditions: [
    { condition: "EMA20 is flat (<20° angle) - Hammer needs a trend", check: (c) => Math.abs(c.emaAngle) < 20 }
  ]},
  { setupName: "HTF Demand + Engulfing", avoidConditions: [
    { condition: "Engulfing candle is >3x larger than previous (Exhaustion)", check: (c) => c.bodySize > c.avgBody * 3 }
  ]},
  { setupName: "Morning Star @ HTF", avoidConditions: [
    { condition: "Middle candle is huge Doji with long wicks on both sides", check: (c) => c.isDoji && c.upperWick > c.bodySize && c.lowerWick > c.bodySize }
  ]},
  { setupName: "Sweep Low + Tweezer", avoidConditions: [
    { condition: "Market already formed 5-6 same color candles (Overextended)", check: (c) => c.consecutiveSameColor >= 5 }
  ]},
  { setupName: "1M FVG Tap + Engulfing", avoidConditions: [
    { condition: "Candle body closes fully inside/below the 50% FVG mark", check: (c) => c.bodySize < c.avgBody * 0.5 }
  ]},
  { setupName: "EMA20 + Hammer", avoidConditions: [
    { condition: "EMAs are not parallel (Choppy market indicator)", check: (c) => (c.ema20 > c.ema50) !== (c.ema50 > c.ema200) }
  ]},
  { setupName: "EMA50 + Engulfing", avoidConditions: [
    { condition: "Engulfing is 3x larger than average tiny candles", check: (c) => c.bodySize > c.avgBody * 3 }
  ]},
  { setupName: "VWAP + Engulfing", avoidConditions: [
    { condition: "Volume is lower than previous while body is bigger (Anomaly)", check: (c) => c.volumeRatio < 1 && c.bodySize > c.avgBody }
  ]},
  { setupName: "BB Lower + Hammer", avoidConditions: [
    { condition: "BB is expanding rapidly (Mouth Open = Strong Breakout)", check: (c) => c.bbExpanding }
  ]},
  { setupName: "RSI <20 + Support", avoidConditions: [
    { condition: "RSI is 'Flat' (market has zero bounce intent)", check: (c) => c.rsi > 40 && c.rsi < 60 }
  ]},
  { setupName: "ADX 25-35 + Continue", avoidConditions: [
    { condition: "Round Number (.000) is within 1-2 pips ahead", check: (c) => c.nearRoundNumber && c.roundNumberDistance < 0.0002 }
  ]},
  { setupName: "PSAR Flip + Bullish", avoidConditions: [
    { condition: "Gap UP is more than 3-4 pixels (Algo bypass)", check: (c) => c.range > 0.0003 }
  ]},
  { setupName: "Range Low + Hammer", avoidConditions: [
    { condition: "Range is too narrow (under 4 pips) - just 'Chop'", check: (c) => c.range < 0.0004 }
  ]},
  { setupName: "FVG + EMA20", avoidConditions: [
    { condition: "Candle body closes fully below the FVG 50% zone", check: (c) => c.bodySize < c.avgBody * 0.5 }
  ]},
  { setupName: "StdDev Expansion", avoidConditions: [
    { condition: "Expansion spike is 5x the average body size (Exhaustion)", check: (c) => c.bodySize > c.avgBody * 5 }
  ]},
  { setupName: "Supply OB + Shooting Star", avoidConditions: [
    { condition: "EMA20 is flat (Market needs at least 20° downward angle)", check: (c) => Math.abs(c.emaAngle) < 20 }
  ]},
  { setupName: "Bearish Engulfing", avoidConditions: [
    { condition: "Engulfing body is 3x larger than previous (Exhaustion)", check: (c) => c.bodySize > c.avgBody * 3 }
  ]},
  { setupName: "Marubozu + Pullback", avoidConditions: [
    { condition: "Retrace doesn't happen within the 30s reset window", check: (c) => c.second > 30 }
  ]},
];

// Liquidity Avoid Rules Database (36 setups synced)
const LIQUIDITY_AVOID_RULES: SetupAvoidRule[] = [
  { setupName: "Round Number Vacuum (.000)", avoidConditions: [
    { condition: "Market is Ranging (ADX < 20) - price might stall", check: (c) => c.adx < 20 },
    { condition: "Wick already touched .000 level - the magnet is dead", check: (c) => c.nearRoundNumber && c.roundNumberDistance < 0.0001 }
  ]},
  { setupName: "Half-Number Concrete Wall (.500)", avoidConditions: [
    { condition: "Current candle is a Marubozu (No Wicks) - strong momentum might smash the wall", check: (c) => c.isMarubozu }
  ]},
  { setupName: "Wick-Fill Bait (Long Wick)", avoidConditions: [
    { condition: "EMA50 is sitting inside the wick zone - price might struggle to fill", check: (c) => Math.abs(c.currentPrice - c.ema50) < c.atr * 0.5 }
  ]},
  { setupName: "Failed Wick Fill (Double Trap)", avoidConditions: [
    { condition: "Rejection candle has lower volume than previous - weakness not confirmed", check: (c) => c.volumeRatio < 1 }
  ]},
  { setupName: "Gap-Fill Slingshot", avoidConditions: [
    { condition: "Runaway Gap (> 5 pips) - indicates news/trend strength, NOT a trap", check: (c) => c.range > 0.0005 }
  ]},
  { setupName: "Unfinished Business (1-Pip Tease)", avoidConditions: [
    { condition: "NEXT candle opens with a gap away from support - algo might have reset", check: (c) => c.range > 0.0001 }
  ]},
  { setupName: "EMA 20 Rubber Band", avoidConditions: [
    { condition: "Current candle is a tiny Doji (body < 0.5 pip) - trend pausing, not reversing", check: (c) => c.isDoji && c.bodySize < 0.00005 }
  ]},
  { setupName: "V-Shape Origin Hunt", avoidConditions: [
    { condition: "Round Number (.000) exists between current price and Origin", check: (c) => c.nearRoundNumber }
  ]},
  { setupName: "Turtle Soup (Standard Sweep)", avoidConditions: [
    { condition: "Sweep candle closes in same direction as break (momentum) - not a rejection", check: (c, sig) => (sig === 'CALL' && c.isBullishCandle) || (sig === 'PUT' && c.isBearishCandle) }
  ]},
  { setupName: "The Hollow Bridge (Volume Trap)", avoidConditions: [
    { condition: "Breakout distance > 5 pips - might be real breakout despite low volume", check: (c) => c.range > 0.0005 }
  ]},
  { setupName: "Double Top Inducement (EQH)", avoidConditions: [
    { condition: "Upper wick < 20% of total range - no visible rejection", check: (c) => c.upperWick < c.range * 0.2 }
  ]},
  { setupName: "Inside Bar Pixel Break", avoidConditions: [
    { condition: "Candle closes above mother bar high - valid breakout, not a trap", check: (c) => c.isBullishCandle && c.bodySize > c.avgBody }
  ]},
  { setupName: "News Candle Fade", avoidConditions: [
    { condition: "Body is 10x larger than average - extreme news/trend, do NOT fade", check: (c) => c.bodySize > c.avgBody * 10 }
  ]},
  { setupName: "Trendline Phantom Touch", avoidConditions: [
    { condition: "Rejection candle is a Doji (body < 0.2 pip) - need real body to confirm", check: (c) => c.isDoji }
  ]},
  { setupName: "Session Sweep (Asian Kill Zone)", avoidConditions: [
    { condition: "Volume is lower than average - not a real liquidity sweep event", check: (c) => c.volumeRatio < 1 }
  ]},
  { setupName: "FVG 50% Sniper", avoidConditions: [
    { condition: "Smaller timeframe Order Block exists inside FVG", check: (c) => c.bodySize > c.avgBody * 2 }
  ]},
  { setupName: "Breaker Block (The Flip)", avoidConditions: [
    { condition: "Huge upper wick on reclaim candle (wick > 30% of body) - sellers still active", check: (c) => c.upperWick > c.bodySize * 0.3 }
  ]},
  { setupName: "Volume Imbalance (Gapless Gap)", avoidConditions: [
    { condition: "Candle color moving AWAY from gap - don't chase wrong direction momentum", check: (c, sig) => (sig === 'CALL' && c.isBearishCandle) || (sig === 'PUT' && c.isBullishCandle) }
  ]},
  { setupName: "Opening Price Magnet", avoidConditions: [
    { condition: "Volume is normal (>= 50% of avg) - magnet effect weakened", check: (c) => c.volumeRatio >= 0.5 }
  ]},
  { setupName: "The :00 Hard Reset", avoidConditions: [
    { condition: "Current candle is a Doji (body < 0.1 pip) - no momentum to reverse", check: (c) => c.isDoji && c.bodySize < 0.0001 }
  ]},
  { setupName: "Godzilla Exhaustion", avoidConditions: [
    { condition: "Giant candle BROKE a major Support/Resistance - it's Momentum, NOT Exhaustion", check: (c) => c.currentPrice > c.resistance || c.currentPrice < c.support }
  ]},
  { setupName: "3-Push Staircase", avoidConditions: [
    { condition: "3rd push has HIGHER volume than 2nd push - trend is accelerating, not ending", check: (c) => c.volumeRatio > 1.2 }
  ]},
  { setupName: "Last Second Wick (The Hook)", avoidConditions: [
    { condition: "5S chart does not show a rejection structure - hook not validated", check: (c) => !c.hasWicks }
  ]},
  { setupName: "The Correction Candle", avoidConditions: [
    { condition: "7th candle is small (< avg body) - trend is healthy, don't fade yet", check: (c) => c.bodySize < c.avgBody }
  ]},
  { setupName: "Resistance Liquidity Sweep", avoidConditions: [
    { condition: "Break distance > 5 pips - not a sweep, it's a failed breakout", check: (c) => c.range > 0.0005 },
    { condition: "RSI not overbought (< 65) - exhaustion not confirmed", check: (c) => c.rsi < 65 }
  ]},
  { setupName: "Resistance Valid Breakout", avoidConditions: [
    { condition: "Volume lower than average - fake breakout, needs high volume", check: (c) => c.volumeRatio < 1 },
    { condition: "Upper wick > 30% of body - rejection invalidates breakout", check: (c) => c.upperWick > c.bodySize * 0.3 }
  ]},
  { setupName: "Support Liquidity Sweep", avoidConditions: [
    { condition: "Break distance > 5 pips - not a sweep, it's a failed breakdown", check: (c) => c.range > 0.0005 },
    { condition: "RSI not oversold (> 35) - exhaustion not confirmed", check: (c) => c.rsi > 35 }
  ]},
  { setupName: "Support Valid Breakout", avoidConditions: [
    { condition: "Volume lower than average - fake breakout, needs high volume", check: (c) => c.volumeRatio < 1 },
    { condition: "Lower wick > 30% of body - rejection invalidates breakout", check: (c) => c.lowerWick > c.bodySize * 0.3 }
  ]},
];

// SMC Avoid Rules Database (18 setups synced)
const SMC_AVOID_RULES: SetupAvoidRule[] = [
  { setupName: "Standard FVG", avoidConditions: [
    { condition: "FVG < 2 pips in size - too small for institutional interest", check: (c) => c.range < 0.0002 },
    { condition: "FVG already 50%+ filled immediately - stale gap", check: (c) => c.bodySize < c.avgBody * 0.5 }
  ]},
  { setupName: "Inverted FVG", avoidConditions: [
    { condition: "Breakout body < 60% of candle range - weak breakout structure", check: (c) => c.bodySize < c.range * 0.6 }
  ]},
  { setupName: "Balanced Price Range", avoidConditions: [
    { condition: "BPR < 1 pip wide - insignificant zone", check: (c) => c.range < 0.0001 }
  ]},
  { setupName: "Volume Imbalance", avoidConditions: [
    { condition: "VI > 10 pips - oversized gap, likely news-driven", check: (c) => c.range > 0.001 },
    { condition: "VI already touched by a wick - mitigated zone", check: (c) => c.hasWicks && c.range < 0.0001 }
  ]},
  { setupName: "Turtle Soup", avoidConditions: [
    { condition: "Rejection wick < 80% of sweep depth - weak rejection", check: (c) => Math.max(c.upperWick, c.lowerWick) < c.range * 0.8 }
  ]},
  { setupName: "Standard Order Block", avoidConditions: [
    { condition: "OB touch count > 0 - only trade 1st touch, multiple touches = weak zone", check: (c) => c.consecutiveSameColor > 2 }
  ]},
  { setupName: "Order Block Mean Threshold", avoidConditions: [
    { condition: "Price closed beyond 50% of OB - mean threshold breached, zone failed", check: (c) => c.bodySize > c.avgBody * 1.5 }
  ]},
  { setupName: "Breaker Block", avoidConditions: [
    { condition: "Breaker formed > 15 candles from original sweep - stale zone", check: (c) => c.consecutiveSameColor > 15 },
    { condition: "High volume on break - real breakout, not a trap", check: (c) => c.volumeRatio > 1.5 }
  ]},
  { setupName: "Rejection Block", avoidConditions: [
    { condition: "No visible wick (Marubozu break) - no rejection, just momentum", check: (c) => c.isMarubozu }
  ]},
  { setupName: "Mitigation Block", avoidConditions: [
    { condition: "Return journey touches opposite OB first - order of zones matters", check: (c) => false }
  ]},
  { setupName: "MTF Confluence", avoidConditions: [
    { condition: "Pair correlation < 0.80 - timeframes not aligned, weak confluence", check: (c) => c.adx < 20 }
  ]},
  { setupName: "HTF Wick Entry", avoidConditions: [
    { condition: "1M entry not in top 25% of HTF wick - suboptimal entry location", check: (c) => c.upperWick < c.range * 0.25 && c.lowerWick < c.range * 0.25 }
  ]},
];

// HTF Avoid Rules Database (20 setups synced)
const HTF_AVOID_RULES: SetupAvoidRule[] = [
  { setupName: "Wick-Fill Magnet", avoidConditions: [
    { condition: "1M candle is strong counter-momentum Marubozu", check: (c, sig) => c.isMarubozu && ((sig === 'CALL' && c.isBearishCandle) || (sig === 'PUT' && c.isBullishCandle)) },
    { condition: "Wick < 60% of body size - not significant institutional wick", check: (c) => Math.max(c.upperWick, c.lowerWick) < c.bodySize * 0.6 }
  ]},
  { setupName: "FVG 50% Symmetrizer", avoidConditions: [
    { condition: "Heading UP but RSI > 70 - overbought, don't buy into resistance", check: (c, sig) => sig === 'CALL' && c.rsi > 70 },
    { condition: "Heading DOWN but RSI < 30 - oversold, don't sell into support", check: (c, sig) => sig === 'PUT' && c.rsi < 30 },
    { condition: "15M body < 2x average body - not large enough expansion for FVG", check: (c) => c.bodySize < c.avgBody * 2 }
  ]},
  { setupName: "Round Number Magnet", avoidConditions: [
    { condition: "EMA 200 sits between price and target magnet (.000/.500) - obstacle blocking path", check: (c) => Math.abs(c.currentPrice - c.ema200) < c.atr },
    { condition: "Distance > 3 pips from round number - too far for magnet effect", check: (c) => !c.nearRoundNumber || c.roundNumberDistance > 0.0003 }
  ]},
  { setupName: "OB Mean Threshold", avoidConditions: [
    { condition: "OB has been touched before (touch count > 0) - only trade 1st touch", check: (c) => c.consecutiveSameColor > 3 }
  ]},
  { setupName: "Liquidity Sweep", avoidConditions: [
    { condition: "Close remains OUTSIDE the level - real breakout, not a sweep", check: (c) => c.bodySize > c.avgBody * 2 },
    { condition: "Break distance < 3 pips - insufficient sweep for confirmation", check: (c) => c.range < 0.0003 }
  ]},
  { setupName: "Near-Miss Breakout", avoidConditions: [
    { condition: "Volume > 2x average - high volume will smash the level", check: (c) => c.volumeRatio > 2 },
    { condition: "Distance not in 1-2 pip range - outside near-miss zone", check: (c) => c.range < 0.0001 || c.range > 0.0002 }
  ]},
  { setupName: "Time-Window Reset", avoidConditions: [
    { condition: "1M candle has no wicks (solid Marubozu) - momentum may continue", check: (c) => c.isMarubozu && !c.hasWicks },
    { condition: "Not at :00/:15/:30/:45 minute mark - no algo reset window", check: (c) => ![0, 15, 30, 45].includes(c.minute) }
  ]},
  { setupName: "V-Shape Mirroring", avoidConditions: [
    { condition: "Recovery candles are tiny (< avg body) - weak momentum", check: (c) => c.bodySize < c.avgBody },
    { condition: "No pinbar on 1M chart - missing reversal confirmation", check: (c) => !c.hasWicks }
  ]},
  { setupName: "Color Switching Fatigue", avoidConditions: [
    { condition: "ADX > 30 - strong trend, not fatigue/chop", check: (c) => c.adx > 30 }
  ]},
  { setupName: "HTF RSI Lock", avoidConditions: [
    { condition: "15M RSI not at extreme (not >= 90 or <= 10) - no momentum lock", check: (c) => c.rsi > 10 && c.rsi < 90 }
  ]},
  { setupName: "Vol-Price Divergence", avoidConditions: [
    { condition: "Volume drop < 10% - volume drop not significant enough", check: (c) => c.volumeRatio > 0.9 },
    { condition: "Current body <= previous body - no expansion to create divergence", check: (c) => c.bodySize <= c.avgBody }
  ]},
  { setupName: "BB Outer Walk Exit", avoidConditions: [
    { condition: "ATR > 2x average ATR - parabolic move, do not fade extreme volatility", check: (c) => c.atr > c.atrAvg * 2 }
  ]},
  { setupName: "Godzilla Vacuum", avoidConditions: [
    { condition: "Major S/R level was broken - breakout momentum, not vacuum", check: (c) => c.currentPrice > c.resistance || c.currentPrice < c.support },
    { condition: "Candle has wicks - true Godzilla is Marubozu with zero wicks", check: (c) => c.hasWicks },
    { condition: "Body < 3x average body - not large enough for Godzilla", check: (c) => c.bodySize < c.avgBody * 3 }
  ]},
  { setupName: "Doji Compression Spring", avoidConditions: [
    { condition: "Pre-squeeze direction CALL but price < EMA200 - counter-trend", check: (c, sig) => sig === 'CALL' && c.currentPrice < c.ema200 },
    { condition: "Pre-squeeze direction PUT but price > EMA200 - counter-trend", check: (c, sig) => sig === 'PUT' && c.currentPrice > c.ema200 }
  ]},
  { setupName: "Fractal Symmetry Break", avoidConditions: [
    { condition: "Bullish break but upper wick > body - rejection wick invalidates", check: (c, sig) => sig === 'CALL' && c.upperWick > c.bodySize },
    { condition: "Bearish break but lower wick > body - rejection wick invalidates", check: (c, sig) => sig === 'PUT' && c.lowerWick > c.bodySize }
  ]},
  { setupName: "Session Range Sweep", avoidConditions: [
    { condition: "Within first 5 minutes of London/NY Open - high volatility period", check: (c) => c.minute < 5 },
    { condition: "Sweep < 3 pips beyond session high/low", check: (c) => c.range < 0.0003 }
  ]},
  { setupName: "HTF Inside Bar Trap", avoidConditions: [
    { condition: "Breakout volume < average volume - low volume breakout is fakeout", check: (c) => c.volumeRatio < 1 }
  ]},
  { setupName: "EMA Mean Reversion", avoidConditions: [
    { condition: "News event active - volatility can extend debt to 40+ pips", check: (c) => c.isNewsTime },
    { condition: "Distance from EMA50 < 20 pips - not enough debt accumulated", check: (c) => Math.abs(c.currentPrice - c.ema50) < 0.002 }
  ]},
  { setupName: "Three-Push Exhaustion", avoidConditions: [
    { condition: "3rd push didn't touch round number (> 1 pip away)", check: (c) => !c.nearRoundNumber || c.roundNumberDistance > 0.0001 }
  ]},
  { setupName: "Algorithmic Book Reset", avoidConditions: [
    { condition: "Price > 2 pips from 15M S/R level - not at key level", check: (c) => Math.abs(c.currentPrice - c.support) > 0.0002 && Math.abs(c.currentPrice - c.resistance) > 0.0002 },
    { condition: "Not at :00 minute mark - no hourly algo reset window", check: (c) => c.minute !== 0 }
  ]},
];

// Indicator Avoid Rules Database (36 setups synced)
const INDICATOR_AVOID_RULES: SetupAvoidRule[] = [
  { setupName: "RSI Oversold Reversal", avoidConditions: [
    { condition: "ADX > 30 - strong downtrend, trend too strong for reversal", check: (c) => c.adx > 30 },
    { condition: "Candle is not bullish - need confirmation candle", check: (c) => !c.isBullishCandle }
  ]},
  { setupName: "RSI Overbought Reversal", avoidConditions: [
    { condition: "ADX > 30 - strong uptrend, price will likely glide RSI not reverse", check: (c) => c.adx > 30 },
    { condition: "Candle is not bearish - need confirmation candle", check: (c) => !c.isBearishCandle }
  ]},
  { setupName: "Stochastic Cross Up", avoidConditions: [
    { condition: "Last 5 candles are all red - Salami Trend, ignore the cross", check: (c) => c.consecutiveSameColor >= 5 && c.isBearishCandle },
    { condition: "Stoch K and D not both < 20 - not truly oversold", check: (c) => c.stochK >= 20 || c.stochD >= 20 }
  ]},
  { setupName: "Stochastic Cross Down", avoidConditions: [
    { condition: "Last 5 candles are all green - Salami Trend, ignore the cross", check: (c) => c.consecutiveSameColor >= 5 && c.isBullishCandle },
    { condition: "Stoch K and D not both > 80 - not truly overbought", check: (c) => c.stochK <= 80 || c.stochD <= 80 }
  ]},
  { setupName: "CCI -200 Rejection", avoidConditions: [
    { condition: "CCI still falling (current < previous) - Falling Knife, wait for uptick", check: (c) => c.macdHistogram < 0 },
    { condition: "Candle is not bullish - need confirmation", check: (c) => !c.isBullishCandle }
  ]},
  { setupName: "CCI +200 Rejection", avoidConditions: [
    { condition: "CCI still rising (current > previous) - Rocket Launch, wait for downtick", check: (c) => c.macdHistogram > 0 },
    { condition: "Candle is not bearish - need confirmation", check: (c) => !c.isBearishCandle }
  ]},
  { setupName: "EMA 20 Crossover", avoidConditions: [
    { condition: "EMA20 angle < 15° - flat EMA means ranging market, fake breakout likely", check: (c) => Math.abs(c.emaAngle) < 15 }
  ]},
  { setupName: "EMA 20 Crossunder", avoidConditions: [
    { condition: "EMA20 angle > -15° - flat EMA means ranging market, fake breakdown likely", check: (c) => Math.abs(c.emaAngle) < 15 }
  ]},
  { setupName: "Golden Cross", avoidConditions: [
    { condition: "Price > 5 pips from cross point - overextended, late entry", check: (c) => Math.abs(c.currentPrice - c.ema50) > 0.0005 }
  ]},
  { setupName: "Death Cross", avoidConditions: [
    { condition: "Price > 5 pips from cross point - overextended, late entry", check: (c) => Math.abs(c.currentPrice - c.ema50) > 0.0005 }
  ]},
  { setupName: "Bollinger Band Squeeze Breakout", avoidConditions: [
    { condition: "Volume < 1.5x average - weak breakout, needs volume confirmation", check: (c) => c.volumeRatio < 1.5 },
    { condition: "BB Bandwidth not in squeeze - not a true squeeze breakout", check: (c) => c.bbWidth > 0.0005 }
  ]},
  { setupName: "Parabolic SAR Flip", avoidConditions: [
    { condition: "Gap between current open and previous close > 2 pips - massive gap invalidates flip", check: (c) => c.range > 0.0002 }
  ]},
  { setupName: "MACD Zero Line Cross", avoidConditions: [
    { condition: "Histogram not growing - weak momentum, histogram must be increasing", check: (c) => Math.abs(c.macdHistogram) < 0.00001 }
  ]},
  { setupName: "Williams %R Oversold", avoidConditions: [
    { condition: "Williams %R locked at -100 for 3+ candles - momentum crash, not reversal", check: (c) => c.rsi < 5 && c.consecutiveSameColor >= 3 },
    { condition: "Candle is not bullish - need confirmation", check: (c) => !c.isBullishCandle }
  ]},
  { setupName: "Williams %R Overbought", avoidConditions: [
    { condition: "Williams %R locked at 0 for 3+ candles - momentum pump, not reversal", check: (c) => c.rsi > 95 && c.consecutiveSameColor >= 3 },
    { condition: "Candle is not bearish - need confirmation", check: (c) => !c.isBearishCandle }
  ]},
  { setupName: "ADX Trend Pullback", avoidConditions: [
    { condition: "Close below EMA20 - support broken, pullback failed", check: (c, sig) => sig === 'CALL' && c.currentPrice < c.ema20 },
    { condition: "Close above EMA20 - resistance broken, pullback failed", check: (c, sig) => sig === 'PUT' && c.currentPrice > c.ema20 },
    { condition: "ADX < 25 - trend not strong enough", check: (c) => c.adx < 25 }
  ]},
  { setupName: "Bollinger Band Rejection", avoidConditions: [
    { condition: "Bands are expanding aggressively - do not trade reversal during expansion", check: (c) => c.bbExpanding }
  ]},
  { setupName: "MFI Divergence", avoidConditions: [
    { condition: "Volume not dropping - need declining volume to confirm lack of sellers", check: (c) => c.volumeRatio >= 1 }
  ]},
  { setupName: "Keltner Channel Breakout", avoidConditions: [
    { condition: "RSI > 80 - breakout is late, overbought condition", check: (c, sig) => sig === 'CALL' && c.rsi > 80 },
    { condition: "RSI < 20 - breakdown is late, oversold condition", check: (c, sig) => sig === 'PUT' && c.rsi < 20 }
  ]},
  { setupName: "Donchian Channel Rejection", avoidConditions: [
    { condition: "No lower/upper wick present - must leave rejection wick", check: (c) => !c.hasWicks }
  ]},
  { setupName: "ATR Volatility Explosion", avoidConditions: [
    { condition: "Near resistance level - volatility spike into resistance is risky", check: (c, sig) => sig === 'CALL' && Math.abs(c.currentPrice - c.resistance) < c.atr * 0.3 },
    { condition: "Near support level - volatility spike into support is risky", check: (c, sig) => sig === 'PUT' && Math.abs(c.currentPrice - c.support) < c.atr * 0.3 }
  ]},
  { setupName: "Awesome Oscillator Saucer", avoidConditions: [
    { condition: "AO bars are tiny (< 0.0001) - flat market, no real momentum", check: (c) => c.bodySize < 0.0001 }
  ]},
  { setupName: "Ichimoku Cloud Breakout", avoidConditions: [
    { condition: "Chikou Span not confirming - lagging span must align", check: (c) => c.adx < 20 }
  ]},
  { setupName: "Vortex Indicator Cross", avoidConditions: [
    { condition: "ADX < 20 - trend strength too weak for valid vortex cross", check: (c) => c.adx < 20 }
  ]},
];

// Price Action Avoid Rules Database (27 setups synced)
const PRICE_ACTION_AVOID_RULES: SetupAvoidRule[] = [
  { setupName: "Universal Wick-Fill", avoidConditions: [
    { condition: "RSI4 < 10 or RSI4 > 90 - extreme RSI means reversal likely", check: (c) => (c.rsi4 ?? c.rsi) < 10 || (c.rsi4 ?? c.rsi) > 90 },
    { condition: "Body > 3x average body - news candle, too volatile", check: (c) => c.bodySize > c.avgBody * 3 },
    { condition: "Wick < 60% of body - not significant enough", check: (c) => Math.max(c.upperWick, c.lowerWick) < c.bodySize * 0.6 }
  ]},
  { setupName: "Universal S/R Siphon", avoidConditions: [
    { condition: "Breakout body > 3x average body - real momentum breakout", check: (c) => c.bodySize > c.avgBody * 3 },
    { condition: "Volume >= average volume - confirmed breakout with volume", check: (c) => c.volumeRatio >= 1 }
  ]},
  { setupName: "Universal Jump Gap", avoidConditions: [
    { condition: "Gap >= 5 pips - runaway gap indicating trend continuation", check: (c) => c.range >= 0.0005 },
    { condition: "Gap < 0.5 pip - gap too small to trigger algo gap logic", check: (c) => c.range < 0.00005 }
  ]},
  { setupName: "Universal 3-5 Color Cycle", avoidConditions: [
    { condition: "ADX > 40 - trend too strong to predict cycle end", check: (c) => c.adx > 40 },
    { condition: "RSI not between 25-75 - need confirmation of range-bound market", check: (c) => c.rsi < 25 || c.rsi > 75 }
  ]},
  { setupName: "Universal Round Number Magnet", avoidConditions: [
    { condition: "Body < 0.5 pip - choppy market with tiny candles", check: (c) => c.bodySize < 0.00005 },
    { condition: "Distance > 3 pips from .000/.500 - not close enough", check: (c) => !c.nearRoundNumber || c.roundNumberDistance > 0.0003 }
  ]},
  { setupName: "Universal FVG Symmetrizer", avoidConditions: [
    { condition: "FVG < 2 pips - too small for institutional interest", check: (c) => c.range < 0.0002 },
    { condition: "Already touched/filled more than 60% - stale gap", check: (c) => c.bodySize < c.avgBody * 0.4 }
  ]},
  { setupName: "Universal Doji Reset", avoidConditions: [
    { condition: "Previous candle was Godzilla (>3x average) - too much momentum", check: (c) => c.bodySize > c.avgBody * 3 },
    { condition: "RSI 45-55 - neutral momentum, no reversal signal", check: (c) => c.rsi > 45 && c.rsi < 55 }
  ]},
  { setupName: "Universal Liquidity Sweep", avoidConditions: [
    { condition: "Close above resistance - real breakout, not sweep", check: (c, sig) => sig === 'PUT' && c.currentPrice > c.resistance },
    { condition: "Close below support - real breakdown, not sweep", check: (c, sig) => sig === 'CALL' && c.currentPrice < c.support },
    { condition: "Sweep wick < 60% of sweep distance - weak rejection", check: (c) => Math.max(c.upperWick, c.lowerWick) < c.range * 0.6 }
  ]},
  { setupName: "M-W Exhaustion", avoidConditions: [
    { condition: "No RSI divergence (RSI 40-60) - divergence not confirmed", check: (c) => c.rsi > 40 && c.rsi < 60 }
  ]},
  { setupName: "Godzilla Pattern", avoidConditions: [
    { condition: "Major level broken - it's Momentum, NOT Exhaustion", check: (c) => c.currentPrice > c.resistance * 1.001 || c.currentPrice < c.support * 0.999 }
  ]},
  { setupName: "Ribbon Kiss", avoidConditions: [
    { condition: "EMA crossover blocks ribbon kiss", check: (c) => Math.abs(c.ema20 - c.ema50) < 0.00001 }
  ]},
  { setupName: "Hollow Move", avoidConditions: [
    { condition: "Volume increased - hollow move needs declining volume", check: (c) => c.volumeRatio > 1 }
  ]},
  { setupName: "Micro-Range", avoidConditions: [
    { condition: "Breakout < 2 pips - fake breakout", check: (c) => c.range < 0.0002 }
  ]},
];

// Find matching rule for a setup name
function findMatchingRule(setupName: string, rules: SetupAvoidRule[]): SetupAvoidRule | null {
  const nameLower = setupName.toLowerCase();
  for (const rule of rules) {
    if (nameLower.includes(rule.setupName.toLowerCase()) || rule.setupName.toLowerCase().includes(nameLower)) {
      return rule;
    }
    // Also check partial matches on key words
    const ruleWords = rule.setupName.toLowerCase().split(/[\s+\-_]+/);
    const nameWords = nameLower.split(/[\s+\-_]+/);
    const matchCount = ruleWords.filter(w => nameWords.some(nw => nw.includes(w) || w.includes(nw))).length;
    if (matchCount >= 2) {
      return rule;
    }
  }
  return null;
}

// Validate Strategy Against Avoid Rules - NOW USES SETUP-SPECIFIC RULES
function validateStrategyAgainstAvoidRules(
  category: 'smc' | 'htf' | 'liquidity' | 'indicator' | 'price_action' | 'setup_235',
  setupName: string,
  signal: 'CALL' | 'PUT',
  conditions: MarketConditions
): AvoidRuleResult {
  const result: AvoidRuleResult = {
    isValid: true,
    blockedReason: null,
    passedConditions: [],
    failedConditions: []
  };
  
  // Select the appropriate rules database based on category
  let rulesDb: SetupAvoidRule[] = [];
  switch (category) {
    case 'smc':
      rulesDb = SMC_AVOID_RULES;
      break;
    case 'htf':
      rulesDb = HTF_AVOID_RULES;
      break;
    case 'liquidity':
      rulesDb = LIQUIDITY_AVOID_RULES;
      break;
    case 'indicator':
      rulesDb = INDICATOR_AVOID_RULES;
      break;
    case 'price_action':
      rulesDb = PRICE_ACTION_AVOID_RULES;
      break;
    case 'setup_235':
      rulesDb = SETUP_235_AVOID_RULES;
      break;
  }
  
  // Find matching rule for this setup
  const matchedRule = findMatchingRule(setupName, rulesDb);
  
  if (matchedRule && matchedRule.avoidConditions.length > 0) {
    // Check each avoid condition for this specific setup
    for (const avoidCondition of matchedRule.avoidConditions) {
      const isBlocked = avoidCondition.check(conditions, signal);
      if (isBlocked) {
        result.failedConditions.push(avoidCondition.condition);
        result.isValid = false;
        if (!result.blockedReason) {
          // Format reason with real-time data when applicable
          let reason = avoidCondition.condition;
          if (reason.includes('ADX') && !reason.includes('=')) {
            reason = reason.replace(/ADX [<>] \d+/, `ADX = ${conditions.adx.toFixed(1)}`);
          }
          if (reason.includes('RSI') && !reason.includes('=')) {
            reason = reason.replace(/RSI [<>] \d+/, `RSI = ${conditions.rsi.toFixed(1)}`);
          }
          if (reason.includes('EMA') && reason.includes('angle') && !reason.includes('=')) {
            reason = reason.replace(/\d+°/, `${Math.abs(conditions.emaAngle).toFixed(1)}°`);
          }
          result.blockedReason = reason;
        }
      } else {
        result.passedConditions.push(avoidCondition.condition);
      }
    }
  } else {
    // No specific rule found - pass by default
    result.passedConditions.push(`No specific avoid rules for ${setupName}`);
  }
  
  return result;
}

// Build market conditions from market data for avoid rule validation
function buildMarketConditionsForAvoidRules(marketData: any, currentTime: Date): MarketConditions {
  const body = marketData.priceAction?.lastCandle?.bodySize || 0;
  const range = marketData.priceAction?.lastCandle?.range || 0.0001;
  const avgBody = marketData.volatility?.atr * 0.7 || 0.0001;
  
  return {
    adx: marketData.trend?.adx || 25,
    emaAngle: marketData.trend?.emaSlope || 0,
    ema20: marketData.trend?.ema20 || marketData.currentPrice || 0,
    ema50: marketData.trend?.ema50 || marketData.currentPrice || 0,
    ema200: marketData.trend?.ema200 || marketData.currentPrice || 0,
    trend: marketData.trend?.emaAlignment || 'NEUTRAL',
    rsi: marketData.momentum?.rsi14 || 50,
    rsi4: marketData.momentum?.rsi7 || 50,
    currentPrice: marketData.currentPrice || 0,
    bodySize: body,
    upperWick: range - body > 0 ? (range - body) / 2 : 0,
    lowerWick: range - body > 0 ? (range - body) / 2 : 0,
    range: range,
    avgBody: avgBody,
    isBullishCandle: marketData.priceAction?.lastCandle?.type === 'BULLISH',
    isBearishCandle: marketData.priceAction?.lastCandle?.type === 'BEARISH',
    volume: marketData.volume?.currentVolume || marketData.volume?.obv || 1,
    avgVolume: marketData.volume?.avgVolume20 || 1,
    volumeRatio: marketData.volume?.volumeRatio || 1,
    bbUpper: marketData.volatility?.bollinger?.upper || marketData.currentPrice * 1.01,
    bbLower: marketData.volatility?.bollinger?.lower || marketData.currentPrice * 0.99,
    bbWidth: marketData.volatility?.bollinger?.width || 1,
    bbExpanding: marketData.volatility?.bollinger?.width > 1.5,
    atr: marketData.volatility?.atr || 0.0001,
    atrAvg: marketData.volatility?.atr || 0.0001,
    macdHistogram: marketData.momentum?.macd?.histogram || 0,
    stochK: marketData.momentum?.stochastic?.k || 50,
    stochD: marketData.momentum?.stochastic?.d || 50,
    minute: currentTime.getMinutes(),
    second: currentTime.getSeconds(),
    isNewsTime: false,
    support: marketData.smc?.support || marketData.currentPrice * 0.99,
    resistance: marketData.smc?.resistance || marketData.currentPrice * 1.01,
    nearRoundNumber: (marketData.currentPrice % 0.005) < 0.0003,
    roundNumberDistance: Math.abs(marketData.currentPrice % 0.005),
    consecutiveSameColor: marketData.priceAction?.consecutiveSameColor || 0,
    isMarubozu: body > range * 0.9,
    isDoji: body < range * 0.1,
    hasWicks: body < range * 0.9,
    last10CandlesSameDirection: (marketData.priceAction?.consecutiveSameColor || 0) >= 10
  };
}

// Track blocked strategies for conflict panel
interface BlockedStrategy {
  name: string;
  category: string;
  reason: string;
  signal: 'CALL' | 'PUT';
}

let blockedStrategies: BlockedStrategy[] = [];

// Reset blocked strategies at start of each signal
function resetBlockedStrategies() {
  blockedStrategies = [];
}

// Get blocked strategies for response
function getBlockedStrategies(): BlockedStrategy[] {
  return blockedStrategies;
}

// Get blocked strategy counts by signal direction
function getBlockedStrategyCounts(): { callBlocked: number; putBlocked: number } {
  const callBlocked = blockedStrategies.filter(s => s.signal === 'CALL').length;
  const putBlocked = blockedStrategies.filter(s => s.signal === 'PUT').length;
  return { callBlocked, putBlocked };
}

// Add to blocked strategies with signal direction
function addBlockedStrategy(name: string, category: string, reason: string, signal: 'CALL' | 'PUT') {
  blockedStrategies.push({ name, category, reason, signal });
}

// ============================================================
// 4-PILLAR ROW-LEVEL CATEGORY SYSTEM (from Future Signal)
// ============================================================
// Each row links specific 235 Setup IDs to their EXACT compatible
// SMC, Liquidity, Indicator, and HTF strategies.

interface PillarRow {
  rowName: string;
  setupIds: number[];
  smcIds: number[];
  liquidityTrapIds: number[];
  indicatorIds: number[];
  htfIds: number[];
}

interface Pillar {
  name: string;
  rows: PillarRow[];
}

// ========================
// PILLAR 1: UPTREND DNA (96 CALL setups)
// ========================
const PILLAR_UPTREND: Pillar = {
  name: '🚀 Pillar 1: Up-Trend DNA',
  rows: [
    {
      rowName: 'Bullish FVG & Unicorn',
      setupIds: [5,23,52,63,72,103,114,125,132,144,149,205],
      smcIds: [1,8,17],
      liquidityTrapIds: [1,17,18],
      indicatorIds: [11,18,35,36],
      htfIds: [1,2,13,17],
    },
    {
      rowName: 'IDM, Breaker & Mitigation',
      setupIds: [1,2,21,51,60,101,102,106,118,121,122,129,141,207],
      smcIds: [7,10,11,18],
      liquidityTrapIds: [6,12,20,24],
      indicatorIds: [10,18,25,33],
      htfIds: [4,5,15,18],
    },
    {
      rowName: 'Propulsion & Momentum',
      setupIds: [7,13,14,58,62,69,74,108,110,116,127,145,218],
      smcIds: [12,15],
      liquidityTrapIds: [8,19,22,28],
      indicatorIds: [10,12,20,27],
      htfIds: [8,13,19],
    },
    {
      rowName: 'Fresh OB & Vol Imbalance',
      setupIds: [9,21,53,73,113,134,139,140],
      smcIds: [4,9],
      liquidityTrapIds: [7,19,21,27],
      indicatorIds: [4,9,15,24],
      htfIds: [4,10,17],
    },
    {
      rowName: 'HTF SMT to LTF CHoCH (All CALL)',
      setupIds: [3,8,16,17,18,19,20,24,55,59,61,64,67,68,70,71,75,104,105,107,109,111,112,119,120,123,124,128,130,133,136,138,143,147,148,201,203,211,213,215,220,222,226,228,230,232,234],
      smcIds: [14],
      liquidityTrapIds: [5,15,16,25,29,31],
      indicatorIds: [2,5,31,32,33],
      htfIds: [7,16,20],
    },
  ],
};

// ========================
// PILLAR 2: DOWNTREND DNA (95 PUT setups)
// ========================
const PILLAR_DOWNTREND: Pillar = {
  name: '📂 Pillar 2: Down-Trend DNA',
  rows: [
    {
      rowName: 'Bearish FVG & Bearish Unicorn',
      setupIds: [30,48,77,88,97,153,164,175,182,194,199,206],
      smcIds: [1,8,17],
      liquidityTrapIds: [3,17,18],
      indicatorIds: [13,16,19,36],
      htfIds: [1,2,11,12],
    },
    {
      rowName: 'Bearish Breaker & Mitigation',
      setupIds: [28,33,41,46,152,154,168,179,184,189,190,208,221],
      smcIds: [10,11,18],
      liquidityTrapIds: [20,24,2],
      indicatorIds: [2,5,22,35],
      htfIds: [4,5,15,18],
    },
    {
      rowName: 'Propulsion & Exhaustion',
      setupIds: [32,38,44,83,85,94,98,158,195,219,231,233,235],
      smcIds: [12,15],
      liquidityTrapIds: [8,19,27,33],
      indicatorIds: [13,16,21,29],
      htfIds: [8,13,19],
    },
    {
      rowName: 'Rejection Block & Wick Sniper',
      setupIds: [26,31,43,76,81,87,89,93,95,151,155,156,157,161,163,169,171,172,173,177,178,183,185,186,191,198,202,204,212,214,216,223,227,229],
      smcIds: [13,16],
      liquidityTrapIds: [3,4,23,32],
      indicatorIds: [1,3,7,32],
      htfIds: [1,3,9],
    },
    {
      rowName: 'Bearish SMT / CHoCH',
      setupIds: [27,34,37,39,42,45,78,84,90,91,92,99,100,159,160,162,166,167,170,174,180,188,193,196,197],
      smcIds: [14],
      liquidityTrapIds: [21,25,26,29],
      indicatorIds: [5,6,30,31],
      htfIds: [7,10,16,20],
    },
  ],
};

// ========================
// PILLAR 3: RANGING MARKET DNA (32+ setups)
// ========================
const PILLAR_RANGING: Pillar = {
  name: '↔️ Pillar 3: Ranging Market DNA',
  rows: [
    {
      rowName: 'Turtle Soup Sweep',
      setupIds: [4,29,47,71,80,96,107,115,121,131,181,201,209,210],
      smcIds: [5],
      liquidityTrapIds: [9,16,34],
      indicatorIds: [1,22,26],
      htfIds: [5,16],
    },
    {
      rowName: 'EQH/EQL Inducement',
      setupIds: [12,57,65,82,90,117,142,192,222,223],
      smcIds: [6],
      liquidityTrapIds: [11,2,10],
      indicatorIds: [2,26,30],
      htfIds: [3,6],
    },
    {
      rowName: 'Vol Imbalance & BPR',
      setupIds: [15,22,25,40,49,50,56,61,66,86,91,110,146,150,165,217,224,225],
      smcIds: [3,4],
      liquidityTrapIds: [5,13,21],
      indicatorIds: [2,7,17,34],
      htfIds: [2,14],
    },
  ],
};

// ========================
// PILLAR 4: CHOPPY / SUFFY DNA (12 setups)
// ========================
const PILLAR_CHOPPY: Pillar = {
  name: '🌪️ Pillar 4: Choppy / Suffy Market DNA',
  rows: [
    {
      rowName: 'Extreme Volatility',
      setupIds: [10,11,35,36,54,79,126,135,137,176,185,187],
      smcIds: [3,13,16],
      liquidityTrapIds: [14,25,27],
      indicatorIds: [4,17,31],
      htfIds: [7,9,20],
    },
  ],
};

// Get all setup IDs for a pillar
function getPillarSetupIds(pillar: Pillar): number[] {
  const ids: number[] = [];
  for (const row of pillar.rows) ids.push(...row.setupIds);
  return [...new Set(ids)];
}

// Find which ROW a setup belongs to within a pillar
function findSetupRow(setupId: number, pillar: Pillar): PillarRow | null {
  for (const row of pillar.rows) {
    if (row.setupIds.includes(setupId)) return row;
  }
  return null;
}

// ============= PILLAR CROSS-REFERENCE GATE =============
// Collects all allowed strategy IDs from the active pillar's rows.
// Only strategies whose IDs appear in this set are counted during scoring.
interface PillarAllowedIds {
  smcIds: Set<number>;
  liquidityIds: Set<number>;
  indicatorIds: Set<number>;
  htfIds: Set<number>;
  setupIds: Set<number>;
  pillarName: string;
  lockedDirection: 'CALL' | 'PUT' | null;
}

function buildPillarAllowedIds(pillar: Pillar, lockedDirection: 'CALL' | 'PUT' | null): PillarAllowedIds {
  const smcIds = new Set<number>();
  const liquidityIds = new Set<number>();
  const indicatorIds = new Set<number>();
  const htfIds = new Set<number>();
  const setupIds = new Set<number>();
  
  for (const row of pillar.rows) {
    row.smcIds.forEach(id => smcIds.add(id));
    row.liquidityTrapIds.forEach(id => liquidityIds.add(id));
    row.indicatorIds.forEach(id => indicatorIds.add(id));
    row.htfIds.forEach(id => htfIds.add(id));
    row.setupIds.forEach(id => setupIds.add(id));
  }
  
  console.log(`[PILLAR GATE] ${pillar.name} | Allowed: Setups=${setupIds.size} SMC=${smcIds.size} Liq=${liquidityIds.size} Ind=${indicatorIds.size} HTF=${htfIds.size}`);
  return { smcIds, liquidityIds, indicatorIds, htfIds, setupIds, pillarName: pillar.name, lockedDirection };
}

// ============= PILLAR-FIRST SCANNING HELPERS =============
// These pre-check functions determine if a strategy ID should be scanned AT ALL.
// If the ID is not in the active pillar's allowed set, the detection logic is
// completely SKIPPED — not run and then filtered. This is the Pillar-First architecture.
function shouldScanSmc(id: number, gate?: PillarAllowedIds): boolean {
  if (!gate) return true; // No gate = scan everything
  return gate.smcIds.has(id);
}
function shouldScanLiq(id: number, gate?: PillarAllowedIds): boolean {
  if (!gate) return true;
  return gate.liquidityIds.has(id);
}
function shouldScanInd(id: number, gate?: PillarAllowedIds): boolean {
  if (!gate) return true;
  return gate.indicatorIds.has(id);
}
function shouldScanHtf(id: number, gate?: PillarAllowedIds): boolean {
  if (!gate) return true;
  return gate.htfIds.has(id);
}

// ============================================================
// TREND DETERMINATION ENGINE v3 (PRECISION REBUILD)
// ============================================================
// Uses: Linear Regression slope, Close-sequence momentum, EMA ribbon,
// ADX strength, and multi-window structure for maximum accuracy.

interface TrendResult {
  pillar: Pillar;
  trendName: string;
  confidence: number;
  reasons: string[];
}

interface CandleForTrend {
  open: number;
  high: number;
  low: number;
  close: number;
}

function determineTrend(conditions: MarketConditions, candles: CandleForTrend[]): TrendResult {
  const reasons: string[] = [];

  // LAYER 1: LINEAR REGRESSION SLOPE
  function linRegSlope(data: number[]): number {
    const n = data.length;
    if (n < 2) return 0;
    let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
    for (let i = 0; i < n; i++) {
      sumX += i; sumY += data[i]; sumXY += i * data[i]; sumX2 += i * i;
    }
    return (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  }

  const closes50 = candles.slice(-50).map(c => c.close);
  const closes20 = candles.slice(-20).map(c => c.close);
  const slope50 = linRegSlope(closes50);
  const slope20 = linRegSlope(closes20);

  const avgPrice = closes50.reduce((a, b) => a + b, 0) / closes50.length;
  const normSlope50 = (slope50 / avgPrice) * 10000;
  const normSlope20 = (slope20 / avgPrice) * 10000;

  let lrScore = 0;
  if (Math.abs(normSlope50) > 0.3) lrScore += normSlope50 > 0 ? 1 : -1;
  if (Math.abs(normSlope50) > 0.8) lrScore += normSlope50 > 0 ? 1 : -1;
  if (Math.abs(normSlope20) > 0.5) lrScore += normSlope20 > 0 ? 1 : -1;
  reasons.push(`LR slope: 50c=${normSlope50.toFixed(2)} 20c=${normSlope20.toFixed(2)} → score=${lrScore}`);

  // LAYER 2: CLOSE-SEQUENCE MOMENTUM
  const last30 = candles.slice(-30);
  let higherCloses = 0, lowerCloses = 0;
  for (let i = 1; i < last30.length; i++) {
    if (last30[i].close > last30[i - 1].close) higherCloses++;
    else if (last30[i].close < last30[i - 1].close) lowerCloses++;
  }
  const closeRatio = last30.length > 1 ? (higherCloses - lowerCloses) / (last30.length - 1) : 0;

  let momScore = 0;
  if (closeRatio > 0.15) momScore = 1;
  if (closeRatio > 0.35) momScore = 2;
  if (closeRatio < -0.15) momScore = -1;
  if (closeRatio < -0.35) momScore = -2;
  reasons.push(`Momentum: higher=${higherCloses} lower=${lowerCloses} ratio=${closeRatio.toFixed(2)} → score=${momScore}`);

  // LAYER 3: EMA RIBBON DIRECTION
  let emaScore = 0;
  const p = conditions.currentPrice;
  if (conditions.ema20 > conditions.ema50) emaScore += 1;
  else if (conditions.ema20 < conditions.ema50) emaScore -= 1;
  if (conditions.ema50 > conditions.ema200) emaScore += 1;
  else if (conditions.ema50 < conditions.ema200) emaScore -= 1;
  if (p > conditions.ema20) emaScore += 1;
  else if (p < conditions.ema20) emaScore -= 1;
  reasons.push(`EMA ribbon: score=${emaScore}`);

  // LAYER 4: ADX TREND STRENGTH
  const adxStrong = conditions.adx >= 20;
  const adxModerate = conditions.adx >= 13;
  let adxMultiplier = 1.0;
  if (adxStrong) adxMultiplier = 1.3;
  else if (adxModerate) adxMultiplier = 1.0;
  else adxMultiplier = 0.6;
  reasons.push(`ADX: ${conditions.adx.toFixed(1)} → multiplier=${adxMultiplier}`);

  // LAYER 5: SWING STRUCTURE (5 segments from last 50 candles)
  const structCandles = candles.slice(-50);
  const segCount = 5;
  const segLen = Math.floor(structCandles.length / segCount);
  const segments: CandleForTrend[][] = [];
  for (let i = 0; i < segCount; i++) {
    segments.push(structCandles.slice(i * segLen, (i + 1) * segLen));
  }
  const segHighs = segments.map(s => Math.max(...s.map(c => c.high)));
  const segLows = segments.map(s => Math.min(...s.map(c => c.low)));

  let hhCount = 0, hlCount = 0, lhCount = 0, llCount = 0;
  for (let i = 1; i < segCount; i++) {
    if (segHighs[i] > segHighs[i - 1]) hhCount++; else lhCount++;
    if (segLows[i] > segLows[i - 1]) hlCount++; else llCount++;
  }

  let structScore = 0;
  const bullStruct = hhCount + hlCount;
  const bearStruct = lhCount + llCount;
  if (bullStruct >= 6) structScore = 2;
  else if (bullStruct >= 5) structScore = 1;
  if (bearStruct >= 6) structScore = -2;
  else if (bearStruct >= 5) structScore = -1;
  reasons.push(`Structure: HH=${hhCount} HL=${hlCount} LH=${lhCount} LL=${llCount} → score=${structScore}`);

  // LAYER 6: EMA ANGLE
  let angleScore = 0;
  if (conditions.emaAngle > 15) angleScore = 1;
  else if (conditions.emaAngle < -15) angleScore = -1;
  reasons.push(`EMA angle: ${conditions.emaAngle.toFixed(1)}° → score=${angleScore}`);

  // CHOPPINESS DETECTION
  let switches = 0;
  for (let i = 1; i < last30.length; i++) {
    if ((last30[i].close > last30[i].open) !== (last30[i - 1].close > last30[i - 1].open)) switches++;
  }
  const switchRate = switches / (last30.length - 1);
  const isChoppy = switchRate > 0.75 && conditions.adx < 15;
  if (isChoppy) reasons.push(`⚠ CHOPPY: switch rate ${(switchRate * 100).toFixed(0)}% + ADX ${conditions.adx.toFixed(1)}`);

  // FINAL COMPOSITE SCORE
  const rawComposite = (lrScore * 3) + (momScore * 2) + (emaScore * 2) + (structScore * 1.5) + (angleScore * 1);
  const composite = rawComposite * adxMultiplier;
  const maxScore = 23 * 1.3;
  const normalizedConf = Math.min(100, Math.round((Math.abs(composite) / maxScore) * 100));
  reasons.push(`COMPOSITE: raw=${rawComposite.toFixed(1)} adj=${composite.toFixed(1)} conf=${normalizedConf}%`);

  // DECISION THRESHOLDS
  if (isChoppy && Math.abs(composite) < 8) {
    return { pillar: PILLAR_CHOPPY, trendName: 'CHOPPY', confidence: Math.max(normalizedConf, 40), reasons };
  }
  if (composite >= 6) {
    return { pillar: PILLAR_UPTREND, trendName: 'UPTREND', confidence: Math.max(normalizedConf, 55), reasons };
  }
  if (composite <= -6) {
    return { pillar: PILLAR_DOWNTREND, trendName: 'DOWNTREND', confidence: Math.max(normalizedConf, 55), reasons };
  }
  if (composite >= 3 && (lrScore > 0 || momScore > 0) && (emaScore > 0 || structScore > 0)) {
    return { pillar: PILLAR_UPTREND, trendName: 'UPTREND', confidence: Math.max(normalizedConf, 45), reasons };
  }
  if (composite <= -3 && (lrScore < 0 || momScore < 0) && (emaScore < 0 || structScore < 0)) {
    return { pillar: PILLAR_DOWNTREND, trendName: 'DOWNTREND', confidence: Math.max(normalizedConf, 45), reasons };
  }

  return { pillar: PILLAR_RANGING, trendName: 'RANGING', confidence: Math.max(normalizedConf, 40), reasons };
}

// ============= TECHNICAL INDICATORS =============

function calculateRSI(closes: number[], period: number = 14): number {
  if (closes.length < period + 1) return 50;
  
  let gains = 0;
  let losses = 0;
  
  for (let i = 1; i <= period; i++) {
    const change = closes[i] - closes[i - 1];
    if (change > 0) gains += change;
    else losses -= change;
  }
  
  let avgGain = gains / period;
  let avgLoss = losses / period;
  
  for (let i = period + 1; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1];
    if (change > 0) {
      avgGain = (avgGain * (period - 1) + change) / period;
      avgLoss = (avgLoss * (period - 1)) / period;
    } else {
      avgGain = (avgGain * (period - 1)) / period;
      avgLoss = (avgLoss * (period - 1) - change) / period;
    }
  }
  
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

function calculateSMA(data: number[], period: number): number {
  if (data.length < period) return data[data.length - 1] || 0;
  const slice = data.slice(-period);
  return slice.reduce((a, b) => a + b, 0) / period;
}

function calculateEMA(data: number[], period: number): number[] {
  if (data.length < period) return [data[data.length - 1] || 0];
  
  const ema: number[] = [];
  const multiplier = 2 / (period + 1);
  
  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += data[i];
  }
  ema[period - 1] = sum / period;
  
  for (let i = period; i < data.length; i++) {
    ema[i] = (data[i] - ema[i - 1]) * multiplier + ema[i - 1];
  }
  
  return ema;
}

function calculateMACD(closes: number[]): { macd: number; signal: number; histogram: number } {
  const ema12 = calculateEMA(closes, 12);
  const ema26 = calculateEMA(closes, 26);
  
  if (ema12.length === 0 || ema26.length === 0) {
    return { macd: 0, signal: 0, histogram: 0 };
  }
  
  const macdLine: number[] = [];
  for (let i = 25; i < closes.length; i++) {
    if (ema12[i] !== undefined && ema26[i] !== undefined) {
      macdLine.push(ema12[i] - ema26[i]);
    }
  }
  
  if (macdLine.length < 9) {
    return { macd: 0, signal: 0, histogram: 0 };
  }
  
  const signalLine = calculateEMA(macdLine, 9);
  const lastMacd = macdLine[macdLine.length - 1];
  const lastSignal = signalLine[signalLine.length - 1] || 0;
  
  return {
    macd: lastMacd,
    signal: lastSignal,
    histogram: lastMacd - lastSignal
  };
}

function calculateATR(highs: number[], lows: number[], closes: number[], period: number = 14): number {
  if (highs.length < period + 1) return 0;
  
  const trueRanges: number[] = [];
  
  for (let i = 1; i < highs.length; i++) {
    const tr = Math.max(
      highs[i] - lows[i],
      Math.abs(highs[i] - closes[i - 1]),
      Math.abs(lows[i] - closes[i - 1])
    );
    trueRanges.push(tr);
  }
  
  let atr = trueRanges.slice(0, period).reduce((a, b) => a + b, 0) / period;
  
  for (let i = period; i < trueRanges.length; i++) {
    atr = (atr * (period - 1) + trueRanges[i]) / period;
  }
  
  return atr;
}

function calculateStochastic(highs: number[], lows: number[], closes: number[], period: number = 14): { k: number; d: number } {
  if (closes.length < period) return { k: 50, d: 50 };
  
  const recentHighs = highs.slice(-period);
  const recentLows = lows.slice(-period);
  const highestHigh = Math.max(...recentHighs);
  const lowestLow = Math.min(...recentLows);
  const currentClose = closes[closes.length - 1];
  
  const k = highestHigh === lowestLow ? 50 : ((currentClose - lowestLow) / (highestHigh - lowestLow)) * 100;
  const d = k;
  
  return { k, d };
}

function calculateCCI(highs: number[], lows: number[], closes: number[], period: number = 20): number {
  if (closes.length < period) return 0;
  
  const typicalPrices: number[] = [];
  for (let i = 0; i < closes.length; i++) {
    typicalPrices.push((highs[i] + lows[i] + closes[i]) / 3);
  }
  
  const recentTP = typicalPrices.slice(-period);
  const sma = recentTP.reduce((a, b) => a + b, 0) / period;
  const meanDeviation = recentTP.reduce((acc, tp) => acc + Math.abs(tp - sma), 0) / period;
  
  if (meanDeviation === 0) return 0;
  return (typicalPrices[typicalPrices.length - 1] - sma) / (0.015 * meanDeviation);
}

function calculateBollingerBands(closes: number[], period: number = 20, stdDev: number = 2): { upper: number; middle: number; lower: number; width: number } {
  if (closes.length < period) {
    const price = closes[closes.length - 1];
    return { upper: price, middle: price, lower: price, width: 0 };
  }
  
  const recentCloses = closes.slice(-period);
  const sma = recentCloses.reduce((a, b) => a + b, 0) / period;
  
  const variance = recentCloses.reduce((acc, close) => acc + Math.pow(close - sma, 2), 0) / period;
  const std = Math.sqrt(variance);
  
  const upper = sma + (stdDev * std);
  const lower = sma - (stdDev * std);
  const width = ((upper - lower) / sma) * 100;
  
  return { upper, middle: sma, lower, width };
}

function calculateADX(highs: number[], lows: number[], closes: number[], period: number = 14): number {
  if (highs.length < period + 1) return 25;
  
  const plusDM: number[] = [];
  const minusDM: number[] = [];
  const tr: number[] = [];
  
  for (let i = 1; i < highs.length; i++) {
    const highDiff = highs[i] - highs[i - 1];
    const lowDiff = lows[i - 1] - lows[i];
    
    plusDM.push(highDiff > lowDiff && highDiff > 0 ? highDiff : 0);
    minusDM.push(lowDiff > highDiff && lowDiff > 0 ? lowDiff : 0);
    
    tr.push(Math.max(
      highs[i] - lows[i],
      Math.abs(highs[i] - closes[i - 1]),
      Math.abs(lows[i] - closes[i - 1])
    ));
  }
  
  const smoothedTR = tr.slice(0, period).reduce((a, b) => a + b, 0);
  const smoothedPlusDM = plusDM.slice(0, period).reduce((a, b) => a + b, 0);
  const smoothedMinusDM = minusDM.slice(0, period).reduce((a, b) => a + b, 0);
  
  const plusDI = smoothedTR > 0 ? (smoothedPlusDM / smoothedTR) * 100 : 0;
  const minusDI = smoothedTR > 0 ? (smoothedMinusDM / smoothedTR) * 100 : 0;
  
  const diDiff = Math.abs(plusDI - minusDI);
  const diSum = plusDI + minusDI;
  
  return diSum > 0 ? (diDiff / diSum) * 100 : 25;
}

function calculateOBV(closes: number[], volumes: number[]): { obv: number; trend: string } {
  if (closes.length < 2 || volumes.length < 2) return { obv: 0, trend: 'NEUTRAL' };
  
  let obv = 0;
  for (let i = 1; i < closes.length; i++) {
    if (closes[i] > closes[i - 1]) {
      obv += volumes[i];
    } else if (closes[i] < closes[i - 1]) {
      obv -= volumes[i];
    }
  }
  
  const trend = obv > 0 ? 'BULLISH' : obv < 0 ? 'BEARISH' : 'NEUTRAL';
  return { obv, trend };
}

function calculateVWAP(highs: number[], lows: number[], closes: number[], volumes: number[]): number {
  if (closes.length === 0) return 0;
  
  let cumulativeTPV = 0;
  let cumulativeVolume = 0;
  
  for (let i = 0; i < closes.length; i++) {
    const typicalPrice = (highs[i] + lows[i] + closes[i]) / 3;
    const volume = volumes[i] || 0;
    cumulativeTPV += typicalPrice * volume;
    cumulativeVolume += volume;
  }
  
  return cumulativeVolume > 0 ? cumulativeTPV / cumulativeVolume : closes[closes.length - 1];
}

function calculateIchimoku(highs: number[], lows: number[], closes: number[]): {
  tenkan: number;
  kijun: number;
  senkouA: number;
  senkouB: number;
  chikou: number;
  cloudStatus: 'ABOVE' | 'BELOW' | 'INSIDE';
} {
  const len = closes.length;
  
  const tenkanPeriod = Math.min(9, len);
  const tenkanHigh = Math.max(...highs.slice(-tenkanPeriod));
  const tenkanLow = Math.min(...lows.slice(-tenkanPeriod));
  const tenkan = (tenkanHigh + tenkanLow) / 2;
  
  const kijunPeriod = Math.min(26, len);
  const kijunHigh = Math.max(...highs.slice(-kijunPeriod));
  const kijunLow = Math.min(...lows.slice(-kijunPeriod));
  const kijun = (kijunHigh + kijunLow) / 2;
  
  const senkouA = (tenkan + kijun) / 2;
  
  const senkouBPeriod = Math.min(52, len);
  const senkouBHigh = Math.max(...highs.slice(-senkouBPeriod));
  const senkouBLow = Math.min(...lows.slice(-senkouBPeriod));
  const senkouB = (senkouBHigh + senkouBLow) / 2;
  
  const chikou = closes[len - 1];
  
  const currentPrice = closes[len - 1];
  const cloudTop = Math.max(senkouA, senkouB);
  const cloudBottom = Math.min(senkouA, senkouB);
  
  let cloudStatus: 'ABOVE' | 'BELOW' | 'INSIDE' = 'INSIDE';
  if (currentPrice > cloudTop) cloudStatus = 'ABOVE';
  else if (currentPrice < cloudBottom) cloudStatus = 'BELOW';
  
  return { tenkan, kijun, senkouA, senkouB, chikou, cloudStatus };
}

function calculateVolumeProfile(highs: number[], lows: number[], closes: number[], volumes: number[]): {
  poc: number;
  valueAreaHigh: number;
  valueAreaLow: number;
  pricePosition: 'ABOVE_POC' | 'BELOW_POC' | 'AT_POC';
} {
  if (closes.length < 20) {
    const price = closes[closes.length - 1];
    return { poc: price, valueAreaHigh: price, valueAreaLow: price, pricePosition: 'AT_POC' };
  }
  
  const minPrice = Math.min(...lows.slice(-50));
  const maxPrice = Math.max(...highs.slice(-50));
  const range = maxPrice - minPrice;
  const levels = 20;
  const levelSize = range / levels;
  
  const volumeByLevel: { [key: number]: number } = {};
  
  for (let i = 0; i < closes.length && i < 50; i++) {
    const levelIndex = Math.floor((closes[i] - minPrice) / levelSize);
    const level = minPrice + (levelIndex * levelSize);
    volumeByLevel[level] = (volumeByLevel[level] || 0) + (volumes[i] || 0);
  }
  
  let poc = closes[closes.length - 1];
  let maxVolume = 0;
  for (const [level, volume] of Object.entries(volumeByLevel)) {
    if (volume > maxVolume) {
      maxVolume = volume;
      poc = parseFloat(level);
    }
  }
  
  const totalVolume = Object.values(volumeByLevel).reduce((a, b) => a + b, 0);
  const targetVolume = totalVolume * 0.7;
  
  const sortedLevels = Object.entries(volumeByLevel)
    .map(([level, vol]) => ({ level: parseFloat(level), volume: vol }))
    .sort((a, b) => b.volume - a.volume);
  
  let accumulatedVolume = 0;
  let valueAreaHigh = poc;
  let valueAreaLow = poc;
  
  for (const { level } of sortedLevels) {
    accumulatedVolume += volumeByLevel[level];
    valueAreaHigh = Math.max(valueAreaHigh, level);
    valueAreaLow = Math.min(valueAreaLow, level);
    if (accumulatedVolume >= targetVolume) break;
  }
  
  const currentPrice = closes[closes.length - 1];
  const tolerance = levelSize * 0.5;
  let pricePosition: 'ABOVE_POC' | 'BELOW_POC' | 'AT_POC' = 'AT_POC';
  if (currentPrice > poc + tolerance) pricePosition = 'ABOVE_POC';
  else if (currentPrice < poc - tolerance) pricePosition = 'BELOW_POC';
  
  return { poc, valueAreaHigh, valueAreaLow, pricePosition };
}

function calculateParabolicSAR(highs: number[], lows: number[], closes: number[]): {
  sar: number;
  trend: 'BULLISH' | 'BEARISH';
  reversal: boolean;
} {
  if (closes.length < 5) {
    return { sar: closes[closes.length - 1], trend: 'BULLISH', reversal: false };
  }
  
  const af_start = 0.02;
  const af_increment = 0.02;
  const af_max = 0.2;
  
  let sar = lows[0];
  let ep = highs[0];
  let af = af_start;
  let trend: 'BULLISH' | 'BEARISH' = 'BULLISH';
  
  if (closes[1] > closes[0]) {
    trend = 'BULLISH';
    sar = lows[0];
    ep = highs[1];
  } else {
    trend = 'BEARISH';
    sar = highs[0];
    ep = lows[1];
  }
  
  for (let i = 2; i < closes.length; i++) {
    const prevSAR = sar;
    
    if (trend === 'BULLISH') {
      sar = prevSAR + af * (ep - prevSAR);
      sar = Math.min(sar, lows[i - 1], lows[i - 2]);
      
      if (lows[i] < sar) {
        trend = 'BEARISH';
        sar = ep;
        ep = lows[i];
        af = af_start;
      } else {
        if (highs[i] > ep) {
          ep = highs[i];
          af = Math.min(af + af_increment, af_max);
        }
      }
    } else {
      sar = prevSAR - af * (prevSAR - ep);
      sar = Math.max(sar, highs[i - 1], highs[i - 2]);
      
      if (highs[i] > sar) {
        trend = 'BULLISH';
        sar = ep;
        ep = highs[i];
        af = af_start;
      } else {
        if (lows[i] < ep) {
          ep = lows[i];
          af = Math.min(af + af_increment, af_max);
        }
      }
    }
  }
  
  const currentPrice = closes[closes.length - 1];
  const reversal = trend === 'BULLISH' ? (currentPrice - sar) < (sar * 0.001) : (sar - currentPrice) < (sar * 0.001);
  
  return { sar, trend, reversal };
}

// ============= ADVANCED SMC ANALYSIS (13 Core Modules) =============

const SMC_PIP_SIZE = 0.00010;

// Helper: Calculate body size
function getBodySize(open: number, close: number): number {
  return Math.abs(close - open);
}

// Helper: Calculate upper wick
function getUpperWick(open: number, high: number, close: number): number {
  return high - Math.max(open, close);
}

// Helper: Calculate lower wick  
function getLowerWick(open: number, low: number, close: number): number {
  return Math.min(open, close) - low;
}

// ============= SMC BATCH 1: FVG, iFVG, BPR, Volume Imbalance, Turtle Soup, EQH/EQL =============

// 1. 🟢 FVG (Fair Value Gap) - Magnet Strategy
// Trap: Retailers jump into strong trends; Algo returns to fill imbalance.
function detectFVG_Advanced(highs: number[], lows: number[], closes: number[], i: number): { type: 'CALL' | 'PUT'; zone: [number, number]; logic: string } | null {
  if (i < 2 || i >= highs.length) return null;
  
  const c1High = highs[i - 2];
  const c1Low = lows[i - 2];
  const c3High = highs[i];
  const c3Low = lows[i];
  
  // Bullish FVG (Gap between C1 High and C3 Low)
  if (c3Low > c1High) {
    return { type: 'CALL', zone: [c1High, c3Low], logic: 'Magnet (Fill 50%)' };
  }
  
  // Bearish FVG (Gap between C1 Low and C3 High)
  if (c3High < c1Low) {
    return { type: 'PUT', zone: [c3High, c1Low], logic: 'Magnet (Fill 50%)' };
  }
  
  return null;
}

// 2. 🔴 iFVG (Inverted FVG) - Momentum Strategy
// Trap: Traders wait for reversal; Algo smashes and flips polarity.
function detectIFVG(currentClose: number, activeFVGs: { type: 'CALL' | 'PUT'; zone: [number, number] }[]): { type: 'CALL' | 'PUT'; zone: [number, number]; logic: string } | null {
  for (const fvg of activeFVGs) {
    // Bullish FVG broken downward -> becomes Resistance
    if (fvg.type === 'CALL' && currentClose < fvg.zone[0]) {
      return { type: 'PUT', zone: fvg.zone, logic: 'Polarity Flip (Retest)' };
    }
    // Bearish FVG broken upward -> becomes Support
    if (fvg.type === 'PUT' && currentClose > fvg.zone[1]) {
      return { type: 'CALL', zone: fvg.zone, logic: 'Polarity Flip (Retest)' };
    }
  }
  return null;
}

// 3. ⚡ BPR (Balanced Price Range) - Velocity Strategy
// Trap: Price teleports through overlapping gaps.
function detectBPR(bullishFVG: [number, number] | null, bearishFVG: [number, number] | null): { type: 'MOMENTUM'; zone: [number, number]; logic: string } | null {
  if (!bullishFVG || !bearishFVG) return null;
  
  const overlapTop = Math.min(bullishFVG[1], bearishFVG[1]);
  const overlapBottom = Math.max(bullishFVG[0], bearishFVG[0]);
  
  if (overlapTop > overlapBottom) {
    return { type: 'MOMENTUM', zone: [overlapBottom, overlapTop], logic: 'Vacuum Slingshot' };
  }
  return null;
}

// 4. 👻 Volume Imbalance - Body Gap Strategy
// Trap: Traders ignore gaps if wicks touch; Algo targets Body Fill.
function detectVolumeImbalance(prevClose: number, currOpen: number): { type: 'CALL' | 'PUT'; zone: [number, number]; logic: string } | null {
  if (Math.abs(currOpen - prevClose) > SMC_PIP_SIZE) {
    const direction = currOpen > prevClose ? 'CALL' : 'PUT';
    return { type: direction, zone: [prevClose, currOpen], logic: 'Body Data Fill' };
  }
  return null;
}

// 5. 🐢 Turtle Soup - Liquidity Sweep (Reversal)
// Trap: Breakout traders buy/sell the high/low break.
function detectTurtleSoup(highs: number[], lows: number[], closes: number[], i: number, lookback: number = 20): { type: 'CALL' | 'PUT'; logic: string } | null {
  if (i < lookback) return null;
  
  const currentHigh = highs[i];
  const currentLow = lows[i];
  const currentClose = closes[i];
  
  const oldHigh = Math.max(...highs.slice(i - lookback, i));
  const oldLow = Math.min(...lows.slice(i - lookback, i));
  
  // Bullish Sweep (Sweep Low and Close Back Inside)
  if (currentLow < oldLow && currentClose > oldLow) {
    return { type: 'CALL', logic: 'Liquidity Grab (Stop Hunt)' };
  }
  
  // Bearish Sweep (Sweep High and Close Back Inside)
  if (currentHigh > oldHigh && currentClose < oldHigh) {
    return { type: 'PUT', logic: 'Liquidity Grab (Stop Hunt)' };
  }
  
  return null;
}

// 6. 💰 EQH/EQL (Equal Highs/Lows) - Inducement Strategy
// Trap: Retailers think it's strong S/R; Algo targets these "Cash Pools".
function detectEQH_EQL(highs: number[], lows: number[], i: number, thresholdPips: number = 2): { type: 'TARGET_HIGH' | 'TARGET_LOW'; level: number; logic: string } | null {
  if (i < 10) return null;
  
  const recentHighs = highs.slice(i - 10, i);
  const recentLows = lows.slice(i - 10, i);
  
  for (let idx = 0; idx < recentHighs.length; idx++) {
    for (let jdx = idx + 1; jdx < recentHighs.length; jdx++) {
      if (Math.abs(recentHighs[idx] - recentHighs[jdx]) < thresholdPips * SMC_PIP_SIZE) {
        return { type: 'TARGET_HIGH', level: recentHighs[idx], logic: 'Inducement (Money Pool)' };
      }
      if (Math.abs(recentLows[idx] - recentLows[jdx]) < thresholdPips * SMC_PIP_SIZE) {
        return { type: 'TARGET_LOW', level: recentLows[idx], logic: 'Inducement (Money Pool)' };
      }
    }
  }
  return null;
}

// ============= SMC BATCH 2: IDM, Unicorn, Fresh OB, Breaker Block =============

// 7. 💰 IDM (Inducement Trap) - Extreme Zone Filter
// Algorithm: Trend-er prothom choto pullback-ke algo "Fake Support" banay.
function detectInducement(lows: number[], closes: number[], i: number): { signal: 'CALL'; logic: string } | null {
  if (i < 15) return null;
  
  const currentLow = lows[i];
  const currentClose = closes[i];
  const inducementLow = Math.min(...lows.slice(i - 15, i));
  
  // ALGO TRAP: Price sweeps IDM (Liquidity grab) then targets real extreme zone.
  if (currentLow < inducementLow && currentClose > inducementLow) {
    return { signal: 'CALL', logic: 'IDM Swept: Retailers Trapped. Algo targeting Extreme Order Block.' };
  }
  return null;
}

// 8. 🦄 The Unicorn (Breaker + FVG) - High Confidence
// Algorithm: Breaker Block (broken OB) ebong FVG overlap zone.
function detectUnicorn(
  breakerZone: { low: number; high: number } | null, 
  fvgZone: { type: 'CALL' | 'PUT'; bottom: number; top: number } | null
): { signal: 'CALL' | 'PUT'; logic: string } | null {
  if (!breakerZone || !fvgZone) return null;
  
  const overlap = Math.max(breakerZone.low, fvgZone.bottom) < Math.min(breakerZone.high, fvgZone.top);
  if (overlap) {
    return { signal: fvgZone.type, logic: 'Unicorn: Double Magnet Trap for Breakout Traders. Sureshot Entry.' };
  }
  return null;
}

// 9. 🧠 Fresh Order Block (Memory) - 2nd Touch Trap
// Algorithm: Institutional orders sudhu First Touch-e active thake.
function detectFreshOB(
  currentPrice: number, 
  obZone: { low: number; high: number; side: 'CALL' | 'PUT'; touchCount: number }
): { type: 'CALL' | 'PUT' | 'AVOID'; logic: string } | null {
  // ALGO TRAP: Liquidity builds on multiple touches.
  if (obZone.touchCount > 0) {
    return { type: 'AVOID', logic: 'Liquidity Pool Trap: Multiple touches detected. High Risk.' };
  }
  
  if (obZone.low <= currentPrice && currentPrice <= obZone.high) {
    return { type: obZone.side, logic: 'Institutional Memory: 1st Touch Entry Only.' };
  }
  return null;
}

// 10. ⚡ Breaker Block (BB) - Stop Hunt Fuel
// Algorithm: OB that failed AFTER sweeping liquidity (Stop Hunt).
function detectBreakerBlock(
  currentClose: number, 
  oldOB: { high: number; side: 'CALL' | 'PUT' } | null, 
  liquiditySwept: boolean
): { type: 'CALL'; logic: string } | null {
  if (!oldOB) return null;
  
  // ALGO TRAP: A Bearish OB broken upward after a low sweep.
  if (liquiditySwept && oldOB.side === 'PUT' && currentClose > oldOB.high) {
    return { type: 'CALL', logic: 'Breaker Flip: Stop Hunt confirmed. Price reversing with high momentum.' };
  }
  return null;
}

// ============= SMC BATCH 3: Mitigation, Propulsion, Rejection Block =============

// 11. 🛡️ Mitigation Block (MB) - No-Sweep Exhaustion
// Algorithm: Failure Swing reversal. Price runs out of orders before sweeping.
function detectMitigation(
  currentHigh: number, 
  currentClose: number, 
  lastSwingHigh: number, 
  lastSwingLow: number
): { signal: 'PUT'; logic: string } | null {
  // ALGO TRAP: Price fails to make a Higher High (Exhaustion).
  if (currentHigh < lastSwingHigh && currentClose < lastSwingLow) {
    return { signal: 'PUT', logic: 'Mitigation: Failure Swing detected. Algo is reversing without a hunt.' };
  }
  return null;
}

// 12. 🚀 Propulsion Block (PB) - Momentum Booster
// Algorithm: A high-momentum candle reacting off a Fresh OB.
function detectPropulsion(
  currentLow: number, 
  currentOpen: number, 
  currentClose: number, 
  activeOBZone: { low: number; high: number }
): { signal: 'CONTINUATION'; entryLevel: number; logic: string } | null {
  if (activeOBZone.low <= currentLow && currentLow <= activeOBZone.high) {
    // After touch, identify the 'Propulsion' candle (High Volume/Size)
    if (Math.abs(currentOpen - currentClose) > 2 * SMC_PIP_SIZE) {
      const meanThreshold = (currentOpen + currentClose) / 2;
      return { signal: 'CONTINUATION', entryLevel: meanThreshold, logic: 'Propulsion Block: 50% Mean Threshold is the trap-fill entry.' };
    }
  }
  return null;
}

// 13. 🎯 Rejection Block (RB) - The Wick Hunter
// Algorithm: Hunting liquidity hidden behind long candle wicks.
function detectRejectionBlock(
  prevOpen: number, 
  prevHigh: number, 
  prevLow: number, 
  prevClose: number
): { signal: 'CALL' | 'PUT'; level: number; logic: string } | null {
  const bodySize = Math.abs(prevOpen - prevClose);
  const upperWick = prevHigh - Math.max(prevOpen, prevClose);
  const lowerWick = Math.min(prevOpen, prevClose) - prevLow;
  
  // Bearish: Upper Wick > 2x Body
  if (upperWick > bodySize * 2) {
    const entryZone = prevHigh - upperWick * 0.25; // Entering at 75% of the wick
    return { signal: 'PUT', level: entryZone, logic: 'Rejection Block: Wick Liquidity Grab.' };
  }
  
  // Bullish: Lower Wick > 2x Body
  if (lowerWick > bodySize * 2) {
    const entryZone = prevLow + lowerWick * 0.25;
    return { signal: 'CALL', level: entryZone, logic: 'Rejection Block: Wick Liquidity Grab.' };
  }
  return null;
}

// ============= SMC HTF-LTF COMBOS =============

interface SMTComboResult {
  signal: 'CALL' | 'PUT';
  confidence: string;
  logic: string;
}

// 🔄 HTF SMT to LTF CHoCH
function detectSMTCombo(
  m5Highs: number[], m5Lows: number[], 
  otherM5Highs: number[], otherM5Lows: number[],
  m1High: number, m1Low: number, m1Open: number, m1Close: number,
  prevM1High: number, prevM1Low: number
): SMTComboResult | null {
  if (m5Highs.length < 2 || otherM5Highs.length < 2) return null;
  
  const m5CurrMainHigh = m5Highs[m5Highs.length - 1];
  const m5PrevMainHigh = m5Highs[m5Highs.length - 2];
  const m5CurrOtherHigh = otherM5Highs[otherM5Highs.length - 1];
  const m5PrevOtherHigh = otherM5Highs[otherM5Highs.length - 2];
  
  const m5CurrMainLow = m5Lows[m5Lows.length - 1];
  const m5PrevMainLow = m5Lows[m5Lows.length - 2];
  const m5CurrOtherLow = otherM5Lows[otherM5Lows.length - 1];
  const m5PrevOtherLow = otherM5Lows[otherM5Lows.length - 2];
  
  // SMT Detection: Main pair breaks high, but correlated pair fails
  const bearishSMT = m5CurrMainHigh > m5PrevMainHigh && m5CurrOtherHigh < m5PrevOtherHigh;
  const bullishSMT = m5CurrMainLow < m5PrevMainLow && m5CurrOtherLow > m5PrevOtherLow;
  
  const bodyM1 = Math.abs(m1Open - m1Close);
  
  if (bearishSMT && m1Close < prevM1Low && bodyM1 > SMC_PIP_SIZE) {
    return { signal: 'PUT', confidence: 'HIGH', logic: 'HTF SMT Trap: Correlated Pair Failed to break High. LTF CHoCH Confirmed.' };
  }
  
  if (bullishSMT && m1Close > prevM1High && bodyM1 > SMC_PIP_SIZE) {
    return { signal: 'CALL', confidence: 'HIGH', logic: 'HTF SMT Trap: Correlated Pair Failed to break Low. LTF CHoCH Confirmed.' };
  }
  
  return null;
}

// 🚀 HTF Order Flow to LTF Propulsion
function detectPropulsionCombo(
  m1Low: number, m1High: number, m1Open: number, m1Close: number,
  htfOBZone: { low: number; high: number },
  avgBodyM1: number
): { signal: 'CONTINUATION'; entryLevel: number; targetTP: string; logic: string } | null {
  const inHTFZone = m1Low <= htfOBZone.high && m1High >= htfOBZone.low;
  
  if (inHTFZone) {
    const currBodyM1 = Math.abs(m1Open - m1Close);
    if (currBodyM1 > avgBodyM1 * 2.5) {
      const meanThreshold = (m1Open + m1Close) / 2;
      return {
        signal: 'CONTINUATION',
        entryLevel: meanThreshold,
        targetTP: 'Next HTF High/Low',
        logic: 'Propulsion Block: Large Institutional Displacement from HTF Zone. Retesting 50% Body.'
      };
    }
  }
  return null;
}

// 🎯 HTF Wick Liquidity to LTF Rejection
function detectWickSniper(
  m1Close: number, m1Open: number, m1High: number, m1Low: number,
  htfWickData: { high: number; low: number; midPoint: number }
): { signal: 'CALL' | 'PUT'; confidence: string; logic: string } | null {
  const isInDeepWick = m1Close >= htfWickData.midPoint && m1Close <= htfWickData.high;
  
  if (isInDeepWick) {
    const m1Body = Math.abs(m1Open - m1Close);
    const m1UpperWick = m1High - Math.max(m1Open, m1Close);
    const m1LowerWick = Math.min(m1Open, m1Close) - m1Low;
    
    // Bearish Rejection
    if (m1UpperWick > m1Body * 2) {
      return { signal: 'PUT', confidence: 'EXTREME', logic: 'Wick Sniper: Price hit HTF Liquidity Pool. LTF Rejection Wick Confirmed.' };
    }
    
    // Bullish Rejection
    if (m1LowerWick > m1Body * 2) {
      return { signal: 'CALL', confidence: 'EXTREME', logic: 'Wick Sniper: Price hit HTF Liquidity Pool. LTF Rejection Wick Confirmed.' };
    }
  }
  return null;
}

// 🦄 HTF FVG (CE) to LTF Unicorn
function detectUnicornCombo(
  m1Close: number, m1Volume: number,
  htfFVGZone: { top: number; bottom: number },
  ltfBreakerZone: { low: number; high: number },
  ltfFVGZone: { type: 'CALL' | 'PUT'; bottom: number; top: number },
  avgVol: number
): { signal: 'CALL' | 'PUT'; confidence: string; logic: string } | null {
  const htfCELevel = (htfFVGZone.top + htfFVGZone.bottom) / 2;
  const isHittingHTFCE = Math.abs(m1Close - htfCELevel) < SMC_PIP_SIZE * 1.5;
  
  if (isHittingHTFCE) {
    const unicornOverlap = Math.max(ltfBreakerZone.low, ltfFVGZone.bottom) < Math.min(ltfBreakerZone.high, ltfFVGZone.top);
    
    if (unicornOverlap && m1Volume > avgVol) {
      return {
        signal: ltfFVGZone.type,
        confidence: '98% (Sureshot)',
        logic: 'The Unicorn: HTF 50% FVG Magnet + LTF Breaker/FVG Overlap. Institutional Entry.'
      };
    }
  }
  return null;
}

// 🛡️ HTF Failure Swing to LTF Mitigation
function detectMitigationCombo(
  m1Close: number, m1Open: number, m1PrevClose: number, m1PrevOpen: number,
  htfFailureHigh: number, htfRecentMaxHigh: number,
  ltfStructureLow: number
): { signal: 'PUT'; entryZone: number; logic: string } | null {
  const isHTFExhausted = htfFailureHigh < htfRecentMaxHigh;
  
  if (isHTFExhausted && m1Close < ltfStructureLow) {
    const impulseMove = Math.abs(m1Open - m1Close) > Math.abs(m1PrevOpen - m1PrevClose) * 1.5;
    
    if (impulseMove) {
      return {
        signal: 'PUT',
        entryZone: ltfStructureLow,
        logic: 'Mitigation: HTF Failure Swing (No Hunt) + LTF Structural Displacement. Reversal Imminent.'
      };
    }
  }
  return null;
}

// ============= MAIN SMC ANALYSIS FUNCTIONS (Updated) =============

function findSupportResistanceSMC(highs: number[], lows: number[], closes: number[]): {
  support: number;
  resistance: number;
  orderBlocks: { type: string; level: number }[];
  liquidityZones: { type: string; level: number }[];
} {
  const recentHighs = highs.slice(-100);
  const recentLows = lows.slice(-100);
  const currentPrice = closes[closes.length - 1];
  
  const swingHighs: number[] = [];
  const swingLows: number[] = [];
  
  for (let i = 3; i < recentHighs.length - 3; i++) {
    if (recentHighs[i] > recentHighs[i-1] && recentHighs[i] > recentHighs[i-2] && recentHighs[i] > recentHighs[i-3] &&
        recentHighs[i] > recentHighs[i+1] && recentHighs[i] > recentHighs[i+2]) {
      swingHighs.push(recentHighs[i]);
    }
    if (recentLows[i] < recentLows[i-1] && recentLows[i] < recentLows[i-2] && recentLows[i] < recentLows[i-3] &&
        recentLows[i] < recentLows[i+1] && recentLows[i] < recentLows[i+2]) {
      swingLows.push(recentLows[i]);
    }
  }
  
  const orderBlocks: { type: string; level: number }[] = [];
  for (let i = 10; i < closes.length - 1; i++) {
    if (closes[i] < closes[i-1] && closes[i+1] > closes[i] && closes[i+1] > closes[i-1]) {
      orderBlocks.push({ type: 'BULLISH_OB', level: lows[i] });
    }
    if (closes[i] > closes[i-1] && closes[i+1] < closes[i] && closes[i+1] < closes[i-1]) {
      orderBlocks.push({ type: 'BEARISH_OB', level: highs[i] });
    }
  }
  
  const liquidityZones: { type: string; level: number }[] = [];
  const tolerance = (Math.max(...recentHighs) - Math.min(...recentLows)) * 0.002;
  
  for (let i = 0; i < swingHighs.length; i++) {
    for (let j = i + 1; j < swingHighs.length; j++) {
      if (Math.abs(swingHighs[i] - swingHighs[j]) < tolerance) {
        liquidityZones.push({ type: 'BSL', level: (swingHighs[i] + swingHighs[j]) / 2 });
      }
    }
  }
  
  for (let i = 0; i < swingLows.length; i++) {
    for (let j = i + 1; j < swingLows.length; j++) {
      if (Math.abs(swingLows[i] - swingLows[j]) < tolerance) {
        liquidityZones.push({ type: 'SSL', level: (swingLows[i] + swingLows[j]) / 2 });
      }
    }
  }
  
  const resistanceLevels = swingHighs.filter(h => h > currentPrice).sort((a, b) => a - b);
  const supportLevels = swingLows.filter(l => l < currentPrice).sort((a, b) => b - a);
  
  const resistance = resistanceLevels[0] || Math.max(...recentHighs);
  const support = supportLevels[0] || Math.min(...recentLows);
  
  return { support, resistance, orderBlocks: orderBlocks.slice(-5), liquidityZones: liquidityZones.slice(-5) };
}

function detectMarketStructure(highs: number[], lows: number[], closes: number[]): {
  structure: 'HH_HL' | 'LH_LL' | 'RANGING';
  marketStructure: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  lastBOS: string | null;
  lastCHoCH: string | null;
} {
  if (closes.length < 20) {
    return { structure: 'RANGING', marketStructure: 'NEUTRAL', lastBOS: null, lastCHoCH: null };
  }
  
  const swings: { type: 'high' | 'low'; price: number; index: number }[] = [];
  
  for (let i = 3; i < closes.length - 3; i++) {
    if (highs[i] > highs[i-1] && highs[i] > highs[i-2] && highs[i] > highs[i+1] && highs[i] > highs[i+2]) {
      swings.push({ type: 'high', price: highs[i], index: i });
    }
    if (lows[i] < lows[i-1] && lows[i] < lows[i-2] && lows[i] < lows[i+1] && lows[i] < lows[i+2]) {
      swings.push({ type: 'low', price: lows[i], index: i });
    }
  }
  
  swings.sort((a, b) => a.index - b.index);
  
  const recentSwings = swings.slice(-6);
  let higherHighs = 0;
  let lowerLows = 0;
  let lastBOS: string | null = null;
  const lastCHoCH: string | null = null;
  
  for (let i = 1; i < recentSwings.length; i++) {
    if (recentSwings[i].type === 'high' && recentSwings[i-1]?.type === 'high') {
      if (recentSwings[i].price > recentSwings[i-1].price) higherHighs++;
      else if (recentSwings[i].price < recentSwings[i-1].price) lowerLows++;
    }
    if (recentSwings[i].type === 'low' && recentSwings[i-1]?.type === 'low') {
      if (recentSwings[i].price > recentSwings[i-1].price) higherHighs++;
      else if (recentSwings[i].price < recentSwings[i-1].price) lowerLows++;
    }
  }
  
  const currentPrice = closes[closes.length - 1];
  const lastSwingHigh = recentSwings.filter(s => s.type === 'high').pop();
  const lastSwingLow = recentSwings.filter(s => s.type === 'low').pop();
  
  if (lastSwingHigh && currentPrice > lastSwingHigh.price) {
    lastBOS = 'BULLISH_BOS';
  } else if (lastSwingLow && currentPrice < lastSwingLow.price) {
    lastBOS = 'BEARISH_BOS';
  }
  
  let structure: 'HH_HL' | 'LH_LL' | 'RANGING' = 'RANGING';
  let marketStructure: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = 'NEUTRAL';
  
  if (higherHighs >= 2) {
    structure = 'HH_HL';
    marketStructure = 'BULLISH';
  } else if (lowerLows >= 2) {
    structure = 'LH_LL';
    marketStructure = 'BEARISH';
  }
  
  return { structure, marketStructure, lastBOS, lastCHoCH };
}

function detectFVG(highs: number[], lows: number[]): { type: string; top: number; bottom: number }[] {
  const fvgs: { type: string; top: number; bottom: number }[] = [];
  
  for (let i = 2; i < highs.length; i++) {
    if (lows[i] > highs[i - 2]) {
      fvgs.push({ type: 'BULLISH_FVG', top: lows[i], bottom: highs[i - 2] });
    }
    if (highs[i] < lows[i - 2]) {
      fvgs.push({ type: 'BEARISH_FVG', top: lows[i - 2], bottom: highs[i] });
    }
  }
  
  return fvgs.slice(-5);
}

function calculatePremiumDiscount(highs: number[], lows: number[], closes: number[]): {
  zone: 'PREMIUM' | 'DISCOUNT' | 'EQUILIBRIUM';
  equilibrium: number;
  fibLevels: { [key: string]: number };
} {
  const periodHighs = highs.slice(-50);
  const periodLows = lows.slice(-50);
  
  const highest = Math.max(...periodHighs);
  const lowest = Math.min(...periodLows);
  const range = highest - lowest;
  const equilibrium = lowest + (range * 0.5);
  const currentPrice = closes[closes.length - 1];
  
  const fibLevels = {
    '0': lowest,
    '0.236': lowest + (range * 0.236),
    '0.382': lowest + (range * 0.382),
    '0.5': equilibrium,
    '0.618': lowest + (range * 0.618),
    '0.705': lowest + (range * 0.705),
    '0.786': lowest + (range * 0.786),
    '1': highest
  };
  
  let zone: 'PREMIUM' | 'DISCOUNT' | 'EQUILIBRIUM' = 'EQUILIBRIUM';
  if (currentPrice > equilibrium + (range * 0.1)) zone = 'PREMIUM';
  else if (currentPrice < equilibrium - (range * 0.1)) zone = 'DISCOUNT';
  
  return { zone, equilibrium, fibLevels };
}

// ============= SMC CORE 3 PILLARS FALLBACK =============

interface SMCCorePillarResult {
  signal: 'CALL' | 'PUT' | null;
  logic: string;
  trapType: string;
  confidence: string;
  entry?: number;
}

// --- PILLAR 1: LIQUIDITY TRAP (The Fuel) ---
// Logic: Market sweeps old stops before reversing.
// Trap: Retailers think it's a breakout; Algo closes it back inside.
function detectLiquidityPillar(
  opens: number[], highs: number[], lows: number[], closes: number[], i: number
): SMCCorePillarResult | null {
  if (i < 1) return null;
  
  const currOpen = opens[i];
  const currHigh = highs[i];
  const currLow = lows[i];
  const currClose = closes[i];
  const prevHigh = highs[i - 1];
  const prevLow = lows[i - 1];
  
  // Body and Wick Analysis for Rejection
  const body = Math.abs(currClose - currOpen);
  const upperWick = currHigh - Math.max(currOpen, currClose);
  const lowerWick = Math.min(currOpen, currClose) - currLow;
  
  // TRAP LOGIC: Bullish Sweep (Sweep Low)
  // Price goes below prev low and closes above it with a strong wick.
  if (currLow < prevLow && currClose > prevLow) {
    // Trap Confirmation: Wick must be at least 1.5x the Body
    if (lowerWick > body * 1.5) {
      return {
        signal: 'CALL',
        logic: 'Liquidity Pillar: Lower Sweep Trap Detected',
        trapType: 'Wick Hunt (Stop Loss Captured)',
        confidence: 'High'
      };
    }
  }

  // TRAP LOGIC: Bearish Sweep (Sweep High)
  // Price goes above prev high and closes below it.
  if (currHigh > prevHigh && currClose < prevHigh) {
    if (upperWick > body * 1.5) {
      return {
        signal: 'PUT',
        logic: 'Liquidity Pillar: Upper Sweep Trap Detected',
        trapType: 'Wick Hunt (Stop Loss Captured)',
        confidence: 'High'
      };
    }
  }
  return null;
}

// --- PILLAR 2: IMBALANCE TRAP (The Footprint) ---
// Logic: Price returns to the mid-point (50%) of a large displacement candle.
// Trap: Late trend followers jump in; Algo re-balances the 50% Body first.
function detectImbalancePillar(
  opens: number[], highs: number[], lows: number[], closes: number[], i: number
): SMCCorePillarResult | null {
  if (i < 21) return null;
  
  const currLow = lows[i];
  const currHigh = highs[i];
  const currClose = closes[i];
  const prevOpen = opens[i - 1];
  const prevClose = closes[i - 1];
  
  // Displacement Check: Is the previous candle 'Extra Large'?
  let totalBody = 0;
  for (let j = i - 20; j < i; j++) {
    totalBody += Math.abs(opens[j] - closes[j]);
  }
  const avgBody = totalBody / 20;
  const prevBody = Math.abs(prevOpen - prevClose);
  
  // Logic: If prev body is 2x larger than average, it's a footprint.
  if (prevBody > avgBody * 2) {
    // Calculate Mean Threshold (50% of the body)
    const meanThreshold = (prevOpen + prevClose) / 2;
    
    // TRAP LOGIC: Retest and Rejection at 50%
    // Bullish: Previous was Green, current touches 50% and holds.
    if (prevClose > prevOpen) {
      if (currLow <= (meanThreshold + SMC_PIP_SIZE) && currClose > meanThreshold) {
        return {
          signal: 'CALL',
          logic: 'Imbalance Pillar: 50% Body Re-balance',
          trapType: 'FOMO Trap (Filling Incomplete Orders)',
          confidence: 'Medium',
          entry: meanThreshold
        };
      }
    }
    
    // Bearish: Previous was Red, current touches 50% and holds.
    if (prevClose < prevOpen) {
      if (currHigh >= (meanThreshold - SMC_PIP_SIZE) && currClose < meanThreshold) {
        return {
          signal: 'PUT',
          logic: 'Imbalance Pillar: 50% Body Re-balance',
          trapType: 'FOMO Trap (Filling Incomplete Orders)',
          confidence: 'Medium',
          entry: meanThreshold
        };
      }
    }
  }
  return null;
}

// --- PILLAR 3: MITIGATION SLINGSHOT (The Handover) ---
// Logic: Broken Order Block or Strong Level Retest.
// Trap: Retailers think level is gone; Algo uses it as a Slingshot.
function detectMitigationPillar(
  opens: number[], highs: number[], lows: number[], closes: number[], i: number,
  historicalLevels: number[]
): SMCCorePillarResult | null {
  if (i < 1) return null;
  
  const currHigh = highs[i];
  const currLow = lows[i];
  const currOpen = opens[i];
  const currClose = closes[i];
  const prevBody = Math.abs(opens[i - 1] - closes[i - 1]);
  const currBody = Math.abs(currOpen - currClose);
  
  // Logic: Scanning identified strong broken levels (Wick points)
  for (const level of historicalLevels) {
    // CALL Slingshot: Previous Resistance now Support
    if (Math.abs(currLow - level) < SMC_PIP_SIZE * 2 && currClose > level) {
      // Volatility check: Must have low volatility during retest
      if (currBody < prevBody) {
        return {
          signal: 'CALL',
          logic: 'Mitigation Pillar: Polarity Flip Slingshot',
          trapType: 'Breakout Trap (Power Transfer)',
          confidence: 'High'
        };
      }
    }
    
    // PUT Slingshot: Previous Support now Resistance
    if (Math.abs(currHigh - level) < SMC_PIP_SIZE * 2 && currClose < level) {
      if (currBody < prevBody) {
        return {
          signal: 'PUT',
          logic: 'Mitigation Pillar: Polarity Flip Slingshot',
          trapType: 'Breakout Trap (Power Transfer)',
          confidence: 'High'
        };
      }
    }
  }
  return null;
}

// --- SMC CORE MASTER EXECUTION ENGINE ---
function runSMCCoreFallback(
  opens: number[], highs: number[], lows: number[], closes: number[],
  historicalLevels: number[] = []
): SMCSignalResult {
  const len = closes.length;
  if (len < 3) {
    return { direction: null, confidence: 0, triggers: [], primaryLogic: 'SMC Core Fallback: Insufficient candle data' };
  }

  // Build historical levels from recent swing points (if not provided)
  const levels = historicalLevels.length > 0 ? [...historicalLevels] : [];
  if (levels.length === 0 && closes.length > 30) {
    const start = Math.max(5, closes.length - 60);
    const end = closes.length - 5;
    for (let j = start; j < end; j++) {
      if (
        highs[j] > highs[j - 1] &&
        highs[j] > highs[j - 2] &&
        highs[j] > highs[j + 1] &&
        highs[j] > highs[j + 2]
      ) {
        levels.push(highs[j]);
      }
      if (
        lows[j] < lows[j - 1] &&
        lows[j] < lows[j - 2] &&
        lows[j] < lows[j + 1] &&
        lows[j] < lows[j + 2]
      ) {
        levels.push(lows[j]);
      }
    }
  }

  // Scan last N candles so fallback doesn't miss a near-recent trap
  const lookbackBars = Math.min(12, len);

  let best: {
    maxScore: number;
    callScore: number;
    putScore: number;
    triggers: string[];
    primaryLogic: string;
  } | null = null;

  for (let offset = 0; offset < lookbackBars; offset++) {
    const i = len - 1 - offset;
    if (i < 2) break;

    const triggers: string[] = [];
    let callScore = 0;
    let putScore = 0;

    // Pillar 1: Liquidity
    const sweep = detectLiquidityPillar(opens, highs, lows, closes, i);
    if (sweep) {
      if (sweep.signal === 'CALL') callScore += 2;
      else if (sweep.signal === 'PUT') putScore += 2;
      triggers.push(`${sweep.logic} [${sweep.trapType}]`);
    }

    // Pillar 2: Imbalance
    const rebalance = detectImbalancePillar(opens, highs, lows, closes, i);
    if (rebalance) {
      if (rebalance.signal === 'CALL') callScore += 1.5;
      else if (rebalance.signal === 'PUT') putScore += 1.5;
      triggers.push(`${rebalance.logic} [${rebalance.trapType}]`);
    }

    // Pillar 3: Mitigation
    const mitigate = detectMitigationPillar(opens, highs, lows, closes, i, levels);
    if (mitigate) {
      if (mitigate.signal === 'CALL') callScore += 1.5;
      else if (mitigate.signal === 'PUT') putScore += 1.5;
      triggers.push(`${mitigate.logic} [${mitigate.trapType}]`);
    }

    const maxScore = Math.max(callScore, putScore);
    if (maxScore <= 0) continue;

    const primaryLogic = triggers.length > 0 ? triggers[0] : 'No SMC Core triggers detected';
    if (!best || maxScore > best.maxScore) {
      best = { maxScore, callScore, putScore, triggers, primaryLogic };
    }
  }

  if (!best) {
    return {
      direction: null,
      confidence: 0,
      triggers: [],
      primaryLogic: 'SMC Core Fallback: No SMC Core triggers detected',
    };
  }

  const direction = best.callScore > best.putScore ? 'CALL' : best.putScore > best.callScore ? 'PUT' : null;
  const confidence = best.maxScore * 20; // Scale to percentage

  return {
    direction,
    confidence: Math.min(confidence, 100),
    triggers: best.triggers.map(t => `[SMC Core] ${t}`),
    primaryLogic: `SMC Core Fallback: ${best.primaryLogic}`
  };
}

// ============= NEW 18 SMC SETUP DATABASE =============
// Batch 1: FVG, iFVG, BPR, Volume Imbalance, Turtle Soup, EQH/EQL
// Batch 2: IDM, Unicorn, Fresh OB, Breaker Block
// Batch 3: Mitigation Block, Propulsion Block, Rejection Block
// MTF: SMT to CHoCH, Order Flow to Propulsion, Wick Sniper, Unicorn Combo, Mitigation Combo

const SMC_SETUP_PIP = 0.00010;

interface SMCSetupResult {
  signal: 'CALL' | 'PUT' | null;
  logic: string;
  confidence: 'HIGH' | 'MEDIUM' | 'LOW' | 'EXTREME';
  setupName: string;
}

// ====== BATCH 1 (6 Setups) ======

// 1. FVG (Fair Value Gap) - Magnet Strategy
function smc_FVG(highs: number[], lows: number[], i: number): SMCSetupResult | null {
  if (i < 2) return null;
  const c1High = highs[i - 2], c3Low = lows[i];
  const c1Low = lows[i - 2], c3High = highs[i];
  
  // Bullish FVG (Gap between C1 High and C3 Low)
  if (c3Low > c1High) {
    return { signal: 'CALL', logic: 'Magnet (Fill 50%)', confidence: 'MEDIUM', setupName: 'FVG Bullish' };
  }
  // Bearish FVG (Gap between C1 Low and C3 High)
  if (c3High < c1Low) {
    return { signal: 'PUT', logic: 'Magnet (Fill 50%)', confidence: 'MEDIUM', setupName: 'FVG Bearish' };
  }
  return null;
}

// 2. iFVG (Inverted FVG) - Momentum Strategy (Polarity Flip)
function smc_iFVG(closes: number[], activeFvgs: { type: 'CALL' | 'PUT'; zoneBottom: number; zoneTop: number }[], i: number): SMCSetupResult | null {
  if (activeFvgs.length === 0) return null;
  const currentClose = closes[i];
  
  for (const fvg of activeFvgs) {
    // Bullish FVG broken downward -> becomes Resistance
    if (fvg.type === 'CALL' && currentClose < fvg.zoneBottom) {
      return { signal: 'PUT', logic: 'Polarity Flip (Retest)', confidence: 'HIGH', setupName: 'iFVG Bearish' };
    }
    // Bearish FVG broken upward -> becomes Support
    if (fvg.type === 'PUT' && currentClose > fvg.zoneTop) {
      return { signal: 'CALL', logic: 'Polarity Flip (Retest)', confidence: 'HIGH', setupName: 'iFVG Bullish' };
    }
  }
  return null;
}

// 3. BPR (Balanced Price Range) - Velocity Strategy
function smc_BPR(highs: number[], lows: number[], i: number): SMCSetupResult | null {
  if (i < 4) return null;
  
  // Look for overlapping bullish and bearish FVGs in recent candles
  let bullishFvg: { top: number; bottom: number } | null = null;
  let bearishFvg: { top: number; bottom: number } | null = null;
  
  for (let j = i - 3; j <= i - 1; j++) {
    if (j < 2) continue;
    const c1High = highs[j - 2], c3Low = lows[j];
    const c1Low = lows[j - 2], c3High = highs[j];
    
    if (c3Low > c1High && !bullishFvg) bullishFvg = { bottom: c1High, top: c3Low };
    if (c3High < c1Low && !bearishFvg) bearishFvg = { bottom: c3High, top: c1Low };
  }
  
  if (bullishFvg && bearishFvg) {
    const overlapTop = Math.min(bullishFvg.top, bearishFvg.top);
    const overlapBottom = Math.max(bullishFvg.bottom, bearishFvg.bottom);
    
    if (overlapTop > overlapBottom) {
      return { signal: 'CALL', logic: 'Vacuum Slingshot', confidence: 'HIGH', setupName: 'BPR Overlap' };
    }
  }
  return null;
}

// 4. Volume Imbalance - Body Gap Strategy
function smc_VolumeImbalance(opens: number[], closes: number[], i: number): SMCSetupResult | null {
  if (i < 1) return null;
  const prevClose = closes[i - 1];
  const currOpen = opens[i];
  
  if (Math.abs(currOpen - prevClose) > SMC_SETUP_PIP) {
    const direction: 'CALL' | 'PUT' = currOpen > prevClose ? 'CALL' : 'PUT';
    return { signal: direction, logic: 'Body Data Fill', confidence: 'LOW', setupName: 'Volume Imbalance' };
  }
  return null;
}

// 5. Turtle Soup - Liquidity Sweep (Reversal)
function smc_TurtleSoup(highs: number[], lows: number[], closes: number[], i: number, lookback: number = 20): SMCSetupResult | null {
  if (i < lookback) return null;
  
  const currHigh = highs[i], currLow = lows[i], currClose = closes[i];
  let oldHigh = highs[i - lookback];
  let oldLow = lows[i - lookback];
  
  for (let j = i - lookback; j < i; j++) {
    if (highs[j] > oldHigh) oldHigh = highs[j];
    if (lows[j] < oldLow) oldLow = lows[j];
  }
  
  // Bullish Sweep (Sweep Low and Close Back Inside)
  if (currLow < oldLow && currClose > oldLow) {
    return { signal: 'CALL', logic: 'Liquidity Grab (Stop Hunt)', confidence: 'HIGH', setupName: 'Turtle Soup Bullish' };
  }
  // Bearish Sweep (Sweep High and Close Back Inside)
  if (currHigh > oldHigh && currClose < oldHigh) {
    return { signal: 'PUT', logic: 'Liquidity Grab (Stop Hunt)', confidence: 'HIGH', setupName: 'Turtle Soup Bearish' };
  }
  return null;
}

// 6. EQH/EQL (Equal Highs/Lows) - Inducement Strategy
function smc_EQH_EQL(highs: number[], lows: number[], i: number, thresholdPips: number = 2): SMCSetupResult | null {
  if (i < 10) return null;
  
  const recentHighs = highs.slice(i - 10, i);
  const recentLows = lows.slice(i - 10, i);
  
  for (let idx = 0; idx < recentHighs.length; idx++) {
    for (let jdx = idx + 1; jdx < recentHighs.length; jdx++) {
      if (Math.abs(recentHighs[idx] - recentHighs[jdx]) < thresholdPips * SMC_SETUP_PIP) {
        return { signal: 'PUT', logic: 'Inducement (Money Pool)', confidence: 'MEDIUM', setupName: 'EQH Target' };
      }
      if (Math.abs(recentLows[idx] - recentLows[jdx]) < thresholdPips * SMC_SETUP_PIP) {
        return { signal: 'CALL', logic: 'Inducement (Money Pool)', confidence: 'MEDIUM', setupName: 'EQL Target' };
      }
    }
  }
  return null;
}

// ====== BATCH 2 (4 Setups) ======

// 7. IDM (Inducement Trap) - Extreme Zone Filter
function smc_IDM(lows: number[], closes: number[], i: number): SMCSetupResult | null {
  if (i < 15) return null;
  
  let inducementLow = lows[i - 15];
  for (let j = i - 15; j < i; j++) {
    if (lows[j] < inducementLow) inducementLow = lows[j];
  }
  
  const currLow = lows[i], currClose = closes[i];
  
  // ALGO TRAP: Price sweeps IDM then targets real extreme zone
  if (currLow < inducementLow && currClose > inducementLow) {
    return { signal: 'CALL', logic: 'IDM Swept: Retailers Trapped. Algo targeting Extreme OB.', confidence: 'HIGH', setupName: 'IDM Trap' };
  }
  return null;
}

// 8. The Unicorn (Breaker + FVG) - High Confidence
function smc_Unicorn(highs: number[], lows: number[], closes: number[], i: number): SMCSetupResult | null {
  if (i < 5) return null;
  
  // Find Breaker Zone (broken OB)
  let breakerZone: { low: number; high: number; side: 'CALL' | 'PUT' } | null = null;
  for (let j = i - 4; j < i - 1; j++) {
    if (j < 1) continue;
    // Bearish OB broken upward
    if (closes[j] < closes[j - 1] && closes[j + 1] > closes[j - 1]) {
      breakerZone = { low: lows[j], high: highs[j], side: 'CALL' };
    }
    // Bullish OB broken downward
    if (closes[j] > closes[j - 1] && closes[j + 1] < closes[j - 1]) {
      breakerZone = { low: lows[j], high: highs[j], side: 'PUT' };
    }
  }
  
  // Find FVG Zone
  let fvgZone: { bottom: number; top: number; type: 'CALL' | 'PUT' } | null = null;
  if (i >= 2) {
    const c1High = highs[i - 2], c3Low = lows[i];
    const c1Low = lows[i - 2], c3High = highs[i];
    if (c3Low > c1High) fvgZone = { bottom: c1High, top: c3Low, type: 'CALL' };
    else if (c3High < c1Low) fvgZone = { bottom: c3High, top: c1Low, type: 'PUT' };
  }
  
  // Check overlap
  if (breakerZone && fvgZone) {
    const overlap = Math.max(breakerZone.low, fvgZone.bottom) < Math.min(breakerZone.high, fvgZone.top);
    if (overlap) {
      return { signal: fvgZone.type, logic: 'Unicorn: Double Magnet Trap. Sureshot Entry.', confidence: 'EXTREME', setupName: 'The Unicorn' };
    }
  }
  return null;
}

// 9. Fresh Order Block (Memory) - 2nd Touch Trap
function smc_FreshOB(opens: number[], highs: number[], lows: number[], closes: number[], i: number): SMCSetupResult | null {
  if (i < 10) return null;
  
  // Find OB zones and track touches
  const obZones: { low: number; high: number; side: 'CALL' | 'PUT'; touchCount: number }[] = [];
  
  for (let j = i - 9; j < i - 2; j++) {
    if (j < 1) continue;
    // Bullish OB: Down candle followed by break above
    if (closes[j] < opens[j] && closes[j + 1] > highs[j]) {
      let touches = 0;
      for (let k = j + 2; k < i; k++) {
        if (lows[k] <= highs[j] && lows[k] >= lows[j]) touches++;
      }
      obZones.push({ low: lows[j], high: highs[j], side: 'CALL', touchCount: touches });
    }
    // Bearish OB: Up candle followed by break below
    if (closes[j] > opens[j] && closes[j + 1] < lows[j]) {
      let touches = 0;
      for (let k = j + 2; k < i; k++) {
        if (highs[k] >= lows[j] && highs[k] <= highs[j]) touches++;
      }
      obZones.push({ low: lows[j], high: highs[j], side: 'PUT', touchCount: touches });
    }
  }
  
  // Only trade 1st touch (fresh)
  const currClose = closes[i], currLow = lows[i], currHigh = highs[i];
  for (const ob of obZones) {
    if (ob.touchCount > 0) continue; // Avoid multi-touch = liquidity trap
    
    if (ob.side === 'CALL' && currLow <= ob.high && currLow >= ob.low) {
      return { signal: 'CALL', logic: 'Institutional Memory: 1st Touch Entry Only.', confidence: 'HIGH', setupName: 'Fresh OB Bullish' };
    }
    if (ob.side === 'PUT' && currHigh >= ob.low && currHigh <= ob.high) {
      return { signal: 'PUT', logic: 'Institutional Memory: 1st Touch Entry Only.', confidence: 'HIGH', setupName: 'Fresh OB Bearish' };
    }
  }
  return null;
}

// 10. Breaker Block (BB) - Stop Hunt Fuel
function smc_BreakerBlock(opens: number[], highs: number[], lows: number[], closes: number[], i: number): SMCSetupResult | null {
  if (i < 5) return null;
  
  // Check for liquidity sweep and OB failure
  const currClose = closes[i];
  
  for (let j = i - 4; j < i - 1; j++) {
    if (j < 1) continue;
    
    // Bearish OB that failed after low sweep -> CALL
    if (closes[j] < opens[j]) { // Was a bearish candle (potential OB)
      const obHigh = highs[j];
      // Check if price swept lows before breaking OB
      let liquiditySwept = false;
      for (let k = j + 1; k < i; k++) {
        if (lows[k] < lows[j - 1]) liquiditySwept = true;
      }
      if (liquiditySwept && currClose > obHigh) {
        return { signal: 'CALL', logic: 'Breaker Flip: Stop Hunt confirmed. Price reversing.', confidence: 'HIGH', setupName: 'Breaker Block Bullish' };
      }
    }
    
    // Bullish OB that failed after high sweep -> PUT
    if (closes[j] > opens[j]) {
      const obLow = lows[j];
      let liquiditySwept = false;
      for (let k = j + 1; k < i; k++) {
        if (highs[k] > highs[j - 1]) liquiditySwept = true;
      }
      if (liquiditySwept && currClose < obLow) {
        return { signal: 'PUT', logic: 'Breaker Flip: Stop Hunt confirmed. Price reversing.', confidence: 'HIGH', setupName: 'Breaker Block Bearish' };
      }
    }
  }
  return null;
}

// ====== BATCH 3 (3 Setups) ======

// 11. Mitigation Block (MB) - No-Sweep Exhaustion
function smc_MitigationBlock(highs: number[], lows: number[], closes: number[], i: number): SMCSetupResult | null {
  if (i < 10) return null;
  
  // Find last swing high and low
  let lastSwingHigh = highs[i - 5];
  let lastSwingLow = lows[i - 5];
  for (let j = i - 10; j < i - 3; j++) {
    if (highs[j] > lastSwingHigh) lastSwingHigh = highs[j];
    if (lows[j] < lastSwingLow) lastSwingLow = lows[j];
  }
  
  const currHigh = highs[i], currClose = closes[i];
  
  // Failure Swing: Price fails to make Higher High (Exhaustion)
  if (currHigh < lastSwingHigh && currClose < lastSwingLow) {
    return { signal: 'PUT', logic: 'Mitigation: Failure Swing detected. Algo reversing without hunt.', confidence: 'HIGH', setupName: 'Mitigation Block Bearish' };
  }
  
  // Bullish version
  const currLow = lows[i];
  if (currLow > lastSwingLow && currClose > lastSwingHigh) {
    return { signal: 'CALL', logic: 'Mitigation: Failure Swing detected. Algo reversing without hunt.', confidence: 'HIGH', setupName: 'Mitigation Block Bullish' };
  }
  return null;
}

// 12. Propulsion Block (PB) - Momentum Booster
function smc_PropulsionBlock(opens: number[], highs: number[], lows: number[], closes: number[], i: number): SMCSetupResult | null {
  if (i < 10) return null;
  
  // Find Fresh OB Zone
  let activeOB: { low: number; high: number; side: 'CALL' | 'PUT' } | null = null;
  for (let j = i - 8; j < i - 2; j++) {
    if (j < 1) continue;
    if (closes[j] < opens[j] && closes[j + 1] > highs[j]) {
      activeOB = { low: lows[j], high: highs[j], side: 'CALL' };
    }
    if (closes[j] > opens[j] && closes[j + 1] < lows[j]) {
      activeOB = { low: lows[j], high: highs[j], side: 'PUT' };
    }
  }
  
  if (!activeOB) return null;
  
  const currOpen = opens[i], currClose = closes[i], currLow = lows[i], currHigh = highs[i];
  
  // Check if current candle is in OB zone and is high-momentum
  const inZone = (currLow <= activeOB.high && currHigh >= activeOB.low);
  const bodySize = Math.abs(currOpen - currClose);
  
  if (inZone && bodySize > 2 * SMC_SETUP_PIP) {
    const meanThreshold = (currOpen + currClose) / 2;
    return { signal: activeOB.side, logic: `Propulsion Block: 50% Mean Threshold trap-fill at ${meanThreshold.toFixed(5)}`, confidence: 'MEDIUM', setupName: 'Propulsion Block' };
  }
  return null;
}

// 13. Rejection Block (RB) - The Wick Hunter
function smc_RejectionBlock(opens: number[], highs: number[], lows: number[], closes: number[], i: number): SMCSetupResult | null {
  if (i < 1) return null;
  
  const prevOpen = opens[i - 1], prevHigh = highs[i - 1], prevLow = lows[i - 1], prevClose = closes[i - 1];
  const bodySize = Math.abs(prevOpen - prevClose);
  const upperWick = prevHigh - Math.max(prevOpen, prevClose);
  const lowerWick = Math.min(prevOpen, prevClose) - prevLow;
  
  // Bearish: Upper Wick > 2x Body
  if (upperWick > bodySize * 2) {
    return { signal: 'PUT', logic: 'Rejection Block: Wick Liquidity Grab.', confidence: 'HIGH', setupName: 'Rejection Block Bearish' };
  }
  
  // Bullish: Lower Wick > 2x Body
  if (lowerWick > bodySize * 2) {
    return { signal: 'CALL', logic: 'Rejection Block: Wick Liquidity Grab.', confidence: 'HIGH', setupName: 'Rejection Block Bullish' };
  }
  return null;
}

// ====== MTF SETUPS (5 Setups using M5 data simulation) ======

// 14. HTF SMT to LTF CHoCH
function smc_SMT_CHoCH(m1Highs: number[], m1Lows: number[], m1Closes: number[], m5Highs: number[], m5Lows: number[], i: number): SMCSetupResult | null {
  if (i < 2 || m5Highs.length < 2) return null;
  
  const m5Len = m5Highs.length;
  const m5CurrHigh = m5Highs[m5Len - 1], m5PrevHigh = m5Highs[m5Len - 2];
  const m5CurrLow = m5Lows[m5Len - 1], m5PrevLow = m5Lows[m5Len - 2];
  
  // SMT: Main pair breaks high but correlated fails (simulate with 5M divergence)
  const bearishSMT = m5CurrHigh > m5PrevHigh && m1Closes[i] < m1Closes[i - 1];
  const bullishSMT = m5CurrLow < m5PrevLow && m1Closes[i] > m1Closes[i - 1];
  
  const m1Body = Math.abs(m1Closes[i] - m1Closes[i - 1]);
  
  if (bearishSMT && m1Body > SMC_SETUP_PIP) {
    return { signal: 'PUT', logic: 'HTF SMT Trap: LTF CHoCH Confirmed.', confidence: 'HIGH', setupName: 'SMT to CHoCH Bearish' };
  }
  if (bullishSMT && m1Body > SMC_SETUP_PIP) {
    return { signal: 'CALL', logic: 'HTF SMT Trap: LTF CHoCH Confirmed.', confidence: 'HIGH', setupName: 'SMT to CHoCH Bullish' };
  }
  return null;
}

// 15. HTF Order Flow to LTF Propulsion
function smc_HTF_Propulsion(m1Opens: number[], m1Highs: number[], m1Lows: number[], m1Closes: number[], m5Opens: number[], m5Closes: number[], i: number): SMCSetupResult | null {
  if (i < 20 || m5Opens.length < 2) return null;
  
  // HTF OB Zone from 5M
  const m5Len = m5Opens.length;
  let htfOBZone: { low: number; high: number; side: 'CALL' | 'PUT' } | null = null;
  
  if (m5Closes[m5Len - 1] > m5Opens[m5Len - 1]) {
    htfOBZone = { low: Math.min(m5Opens[m5Len - 1], m5Closes[m5Len - 1]), high: Math.max(m5Opens[m5Len - 1], m5Closes[m5Len - 1]), side: 'CALL' };
  } else {
    htfOBZone = { low: Math.min(m5Opens[m5Len - 1], m5Closes[m5Len - 1]), high: Math.max(m5Opens[m5Len - 1], m5Closes[m5Len - 1]), side: 'PUT' };
  }
  
  // Check if M1 is reacting in HTF zone
  const inZone = m1Lows[i] <= htfOBZone.high && m1Highs[i] >= htfOBZone.low;
  
  // Check for large displacement candle (2.5x avg body)
  let avgBody = 0;
  for (let j = i - 20; j < i; j++) avgBody += Math.abs(m1Opens[j] - m1Closes[j]);
  avgBody /= 20;
  const currBody = Math.abs(m1Opens[i] - m1Closes[i]);
  
  if (inZone && currBody > avgBody * 2.5) {
    return { signal: htfOBZone.side, logic: 'Propulsion Block: Institutional Displacement from HTF Zone.', confidence: 'HIGH', setupName: 'HTF Order Flow Propulsion' };
  }
  return null;
}

// 16. HTF Wick Liquidity to LTF Rejection (Wick Sniper)
function smc_WickSniper(m1Opens: number[], m1Highs: number[], m1Lows: number[], m1Closes: number[], m5Highs: number[], m5Lows: number[], m5Opens: number[], m5Closes: number[], i: number): SMCSetupResult | null {
  if (i < 1 || m5Highs.length < 1) return null;
  
  const m5Len = m5Highs.length;
  const m5High = m5Highs[m5Len - 1], m5Low = m5Lows[m5Len - 1];
  const m5Open = m5Opens[m5Len - 1], m5Close = m5Closes[m5Len - 1];
  const m5MidPoint = (m5High + m5Low) / 2;
  
  const m1Close = m1Closes[i], m1Open = m1Opens[i], m1High = m1Highs[i], m1Low = m1Lows[i];
  
  // Price in deep wick zone (top 50%)
  const inDeepWick = m1Close >= m5MidPoint && m1Close <= m5High;
  
  if (inDeepWick) {
    const m1Body = Math.abs(m1Open - m1Close);
    const m1UpperWick = m1High - Math.max(m1Open, m1Close);
    const m1LowerWick = Math.min(m1Open, m1Close) - m1Low;
    
    // Bearish Rejection
    if (m1UpperWick > m1Body * 2) {
      return { signal: 'PUT', logic: 'Wick Sniper: HTF Liquidity Pool + LTF Rejection.', confidence: 'EXTREME', setupName: 'Wick Sniper Bearish' };
    }
    // Bullish Rejection
    if (m1LowerWick > m1Body * 2) {
      return { signal: 'CALL', logic: 'Wick Sniper: HTF Liquidity Pool + LTF Rejection.', confidence: 'EXTREME', setupName: 'Wick Sniper Bullish' };
    }
  }
  return null;
}

// 17. HTF FVG (CE) to LTF Unicorn (High Precision Confluence)
function smc_UnicornCombo(m1Opens: number[], m1Highs: number[], m1Lows: number[], m1Closes: number[], m5Highs: number[], m5Lows: number[], i: number): SMCSetupResult | null {
  if (i < 5 || m5Highs.length < 3) return null;
  
  // HTF FVG CE Level (50%)
  const m5Len = m5Highs.length;
  let htfFvgCE: number | null = null;
  let htfFvgType: 'CALL' | 'PUT' | null = null;
  
  if (m5Lows[m5Len - 1] > m5Highs[m5Len - 3]) {
    htfFvgCE = (m5Highs[m5Len - 3] + m5Lows[m5Len - 1]) / 2;
    htfFvgType = 'CALL';
  } else if (m5Highs[m5Len - 1] < m5Lows[m5Len - 3]) {
    htfFvgCE = (m5Lows[m5Len - 3] + m5Highs[m5Len - 1]) / 2;
    htfFvgType = 'PUT';
  }
  
  if (!htfFvgCE || !htfFvgType) return null;
  
  // Check if M1 is hitting HTF CE
  const isHittingCE = Math.abs(m1Closes[i] - htfFvgCE) < SMC_SETUP_PIP * 1.5;
  
  if (isHittingCE) {
    // Check for LTF Unicorn (Breaker + FVG overlap)
    const unicorn = smc_Unicorn(m1Highs, m1Lows, m1Closes, i);
    if (unicorn) {
      return { signal: htfFvgType, logic: 'The Unicorn: HTF 50% FVG Magnet + LTF Breaker/FVG Overlap.', confidence: 'EXTREME', setupName: 'Unicorn Combo' };
    }
  }
  return null;
}

// 18. HTF Failure Swing to LTF Mitigation
function smc_MitigationCombo(m1Opens: number[], m1Highs: number[], m1Lows: number[], m1Closes: number[], m5Highs: number[], m5Lows: number[], i: number): SMCSetupResult | null {
  if (i < 5 || m5Highs.length < 5) return null;
  
  const m5Len = m5Highs.length;
  
  // HTF Exhaustion: Current 5M high is lower than previous 5M highs
  let maxM5High = m5Highs[m5Len - 5];
  for (let j = m5Len - 5; j < m5Len - 1; j++) {
    if (m5Highs[j] > maxM5High) maxM5High = m5Highs[j];
  }
  const htfExhausted = m5Highs[m5Len - 1] < maxM5High;
  
  if (htfExhausted) {
    // LTF structural low
    let ltfStructureLow = m1Lows[i - 3];
    for (let j = i - 5; j < i - 1; j++) {
      if (m1Lows[j] < ltfStructureLow) ltfStructureLow = m1Lows[j];
    }
    
    // Check for impulsive break
    const currBody = Math.abs(m1Opens[i] - m1Closes[i]);
    const prevBody = Math.abs(m1Opens[i - 1] - m1Closes[i - 1]);
    const impulsiveMove = currBody > prevBody * 1.5;
    
    if (m1Closes[i] < ltfStructureLow && impulsiveMove) {
      return { signal: 'PUT', logic: 'Mitigation: HTF Failure Swing + LTF Structural Displacement.', confidence: 'HIGH', setupName: 'Mitigation Combo' };
    }
  }
  return null;
}

// ============= COMPREHENSIVE SMC SIGNAL SCANNER (NEW 18 SETUPS) =============

interface SMCSignalResult {
  direction: 'CALL' | 'PUT' | null;
  confidence: number;
  triggers: string[];
  primaryLogic: string;
}

function runAdvancedSMCAnalysis(
  opens: number[], highs: number[], lows: number[], closes: number[], 
  volumes: number[],
  m5Opens?: number[], m5Highs?: number[], m5Lows?: number[], m5Closes?: number[],
  pillarGate?: PillarAllowedIds
): SMCSignalResult {
  const i = closes.length - 1;
  const triggers: string[] = [];
  let callScore = 0;
  let putScore = 0;
  let matchCount = 0;
  
  // Build active FVGs for iFVG detection
  const activeFvgs: { type: 'CALL' | 'PUT'; zoneBottom: number; zoneTop: number }[] = [];
  for (let j = Math.max(2, i - 20); j < i; j++) {
    if (lows[j] > highs[j - 2]) {
      activeFvgs.push({ type: 'CALL', zoneBottom: highs[j - 2], zoneTop: lows[j] });
    }
    if (highs[j] < lows[j - 2]) {
      activeFvgs.push({ type: 'PUT', zoneBottom: highs[j], zoneTop: lows[j - 2] });
    }
  }
  
  // ====== RUN ONLY PILLAR-COMPATIBLE SETUPS (Pillar-First Architecture) ======
  let pillarSkippedSmc = 0;
  
  // BATCH 1 (6)
  const fvg = shouldScanSmc(1, pillarGate) ? smc_FVG(highs, lows, i) : (pillarSkippedSmc++, null);
  if (fvg) { matchCount++; if (fvg.signal === 'CALL') callScore += 1; else putScore += 1; triggers.push(`[${fvg.setupName}] ${fvg.logic}`); }
  
  const ifvg = shouldScanSmc(2, pillarGate) ? smc_iFVG(closes, activeFvgs, i) : (pillarSkippedSmc++, null);
  if (ifvg) { matchCount++; if (ifvg.signal === 'CALL') callScore += 1.5; else putScore += 1.5; triggers.push(`[${ifvg.setupName}] ${ifvg.logic}`); }
  
  const bpr = shouldScanSmc(3, pillarGate) ? smc_BPR(highs, lows, i) : (pillarSkippedSmc++, null);
  if (bpr) { matchCount++; if (bpr.signal === 'CALL') callScore += 1.5; else putScore += 1.5; triggers.push(`[${bpr.setupName}] ${bpr.logic}`); }
  
  const volImb = shouldScanSmc(4, pillarGate) ? smc_VolumeImbalance(opens, closes, i) : (pillarSkippedSmc++, null);
  if (volImb) { matchCount++; if (volImb.signal === 'CALL') callScore += 0.5; else putScore += 0.5; triggers.push(`[${volImb.setupName}] ${volImb.logic}`); }
  
  const turtle = shouldScanSmc(5, pillarGate) ? smc_TurtleSoup(highs, lows, closes, i) : (pillarSkippedSmc++, null);
  if (turtle) { matchCount++; if (turtle.signal === 'CALL') callScore += 2; else putScore += 2; triggers.push(`[${turtle.setupName}] ${turtle.logic}`); }
  
  const eqhEql = shouldScanSmc(6, pillarGate) ? smc_EQH_EQL(highs, lows, i) : (pillarSkippedSmc++, null);
  if (eqhEql) { matchCount++; if (eqhEql.signal === 'CALL') callScore += 1; else putScore += 1; triggers.push(`[${eqhEql.setupName}] ${eqhEql.logic}`); }
  
  // BATCH 2 (4)
  const idm = shouldScanSmc(7, pillarGate) ? smc_IDM(lows, closes, i) : (pillarSkippedSmc++, null);
  if (idm) { matchCount++; if (idm.signal === 'CALL') callScore += 1.5; else putScore += 1.5; triggers.push(`[${idm.setupName}] ${idm.logic}`); }
  
  const unicorn = shouldScanSmc(8, pillarGate) ? smc_Unicorn(highs, lows, closes, i) : (pillarSkippedSmc++, null);
  if (unicorn) { matchCount++; if (unicorn.signal === 'CALL') callScore += 3; else putScore += 3; triggers.push(`[${unicorn.setupName}] ${unicorn.logic}`); }
  
  const freshOB = shouldScanSmc(9, pillarGate) ? smc_FreshOB(opens, highs, lows, closes, i) : (pillarSkippedSmc++, null);
  if (freshOB) { matchCount++; if (freshOB.signal === 'CALL') callScore += 1.5; else putScore += 1.5; triggers.push(`[${freshOB.setupName}] ${freshOB.logic}`); }
  
  const breaker = shouldScanSmc(10, pillarGate) ? smc_BreakerBlock(opens, highs, lows, closes, i) : (pillarSkippedSmc++, null);
  if (breaker) { matchCount++; if (breaker.signal === 'CALL') callScore += 2; else putScore += 2; triggers.push(`[${breaker.setupName}] ${breaker.logic}`); }
  
  // BATCH 3 (3)
  const mitigation = shouldScanSmc(11, pillarGate) ? smc_MitigationBlock(highs, lows, closes, i) : (pillarSkippedSmc++, null);
  if (mitigation) { matchCount++; if (mitigation.signal === 'CALL') callScore += 1.5; else putScore += 1.5; triggers.push(`[${mitigation.setupName}] ${mitigation.logic}`); }
  
  const propulsion = shouldScanSmc(12, pillarGate) ? smc_PropulsionBlock(opens, highs, lows, closes, i) : (pillarSkippedSmc++, null);
  if (propulsion) { matchCount++; if (propulsion.signal === 'CALL') callScore += 1; else putScore += 1; triggers.push(`[${propulsion.setupName}] ${propulsion.logic}`); }
  
  const rejection = shouldScanSmc(13, pillarGate) ? smc_RejectionBlock(opens, highs, lows, closes, i) : (pillarSkippedSmc++, null);
  if (rejection) { matchCount++; if (rejection.signal === 'CALL') callScore += 1.5; else putScore += 1.5; triggers.push(`[${rejection.setupName}] ${rejection.logic}`); }
  
  // MTF SETUPS (5) - Only if M5 data is available
  if (m5Opens && m5Highs && m5Lows && m5Closes && m5Opens.length > 0) {
    const smtChoch = shouldScanSmc(14, pillarGate) ? smc_SMT_CHoCH(highs, lows, closes, m5Highs, m5Lows, i) : (pillarSkippedSmc++, null);
    if (smtChoch) { matchCount++; if (smtChoch.signal === 'CALL') callScore += 2; else putScore += 2; triggers.push(`[${smtChoch.setupName}] ${smtChoch.logic}`); }
    
    const htfProp = shouldScanSmc(15, pillarGate) ? smc_HTF_Propulsion(opens, highs, lows, closes, m5Opens, m5Closes, i) : (pillarSkippedSmc++, null);
    if (htfProp) { matchCount++; if (htfProp.signal === 'CALL') callScore += 2; else putScore += 2; triggers.push(`[${htfProp.setupName}] ${htfProp.logic}`); }
    
    const wickSniper = shouldScanSmc(16, pillarGate) ? smc_WickSniper(opens, highs, lows, closes, m5Highs, m5Lows, m5Opens, m5Closes, i) : (pillarSkippedSmc++, null);
    if (wickSniper) { matchCount++; if (wickSniper.signal === 'CALL') callScore += 3; else putScore += 3; triggers.push(`[${wickSniper.setupName}] ${wickSniper.logic}`); }
    
    const unicornCombo = shouldScanSmc(17, pillarGate) ? smc_UnicornCombo(opens, highs, lows, closes, m5Highs, m5Lows, i) : (pillarSkippedSmc++, null);
    if (unicornCombo) { matchCount++; if (unicornCombo.signal === 'CALL') callScore += 3; else putScore += 3; triggers.push(`[${unicornCombo.setupName}] ${unicornCombo.logic}`); }
    
    const mitigationCombo = shouldScanSmc(18, pillarGate) ? smc_MitigationCombo(opens, highs, lows, closes, m5Highs, m5Lows, i) : (pillarSkippedSmc++, null);
    if (mitigationCombo) { matchCount++; if (mitigationCombo.signal === 'CALL') callScore += 2; else putScore += 2; triggers.push(`[${mitigationCombo.setupName}] ${mitigationCombo.logic}`); }
  }
  
  if (pillarSkippedSmc > 0) {
    console.log(`[PILLAR-FIRST SMC] Skipped ${pillarSkippedSmc} non-pillar SMC setups (never scanned)`);
  }
  
  // Calculate direction and confidence
  let direction: 'CALL' | 'PUT' | null = callScore > putScore ? 'CALL' : putScore > callScore ? 'PUT' : null;
  let confidence = Math.max(callScore, putScore) * 12;
  let primaryLogic = triggers.length > 0 ? triggers[0] : 'No SMC triggers detected';
  let finalTriggers = [...triggers];
  
  console.log(`SMC 18-Setup Scanner: ${matchCount} matches, CALL=${callScore.toFixed(1)}, PUT=${putScore.toFixed(1)}`);
  
  // ============= SMC CORE FALLBACK: If no setup match, use 3 Core Pillars =============
  if (matchCount === 0 || direction === null || confidence < 15) {
    console.log('SMC 3-Pillar Fallback activated: No primary SMC setup found');
    const coreFallback = runSMCCoreFallback(opens, highs, lows, closes);
    
    if (coreFallback.direction) {
      direction = coreFallback.direction;
      confidence = coreFallback.confidence;
      primaryLogic = coreFallback.primaryLogic;
      finalTriggers = [...triggers, ...coreFallback.triggers];
      console.log(`SMC 3-Pillar Fallback Result: ${direction} @ ${confidence}% - ${primaryLogic}`);
    }
  }
  
  return { direction, confidence: Math.min(confidence, 100), triggers: finalTriggers, primaryLogic };
}

// ============= PATTERN DETECTION =============

function detectCandlePatterns(opens: number[], highs: number[], lows: number[], closes: number[]): string[] {
  const patterns: string[] = [];
  const len = closes.length;
  if (len < 5) return patterns;
  
  const lastOpen = opens[len - 1];
  const lastHigh = highs[len - 1];
  const lastLow = lows[len - 1];
  const lastClose = closes[len - 1];
  const body = Math.abs(lastClose - lastOpen);
  const range = lastHigh - lastLow;
  const upperWick = lastHigh - Math.max(lastOpen, lastClose);
  const lowerWick = Math.min(lastOpen, lastClose) - lastLow;
  
  // Doji
  if (body < range * 0.1 && range > 0) {
    if (upperWick > body * 2 && lowerWick < body) {
      patterns.push('GRAVESTONE_DOJI');
    } else if (lowerWick > body * 2 && upperWick < body) {
      patterns.push('DRAGONFLY_DOJI');
    } else {
      patterns.push('DOJI');
    }
  }
  
  // Hammer/Shooting Star
  if (lowerWick > body * 2 && upperWick < body * 0.3 && body > 0) {
    patterns.push('HAMMER');
  }
  if (upperWick > body * 2 && lowerWick < body * 0.3 && body > 0) {
    patterns.push('SHOOTING_STAR');
  }
  
  // Engulfing
  if (len >= 2) {
    const prevOpen = opens[len - 2];
    const prevClose = closes[len - 2];
    const prevBody = Math.abs(prevClose - prevOpen);
    
    if (lastClose > lastOpen && prevClose < prevOpen && lastOpen < prevClose && lastClose > prevOpen && body > prevBody) {
      patterns.push('BULLISH_ENGULFING');
    }
    if (lastClose < lastOpen && prevClose > prevOpen && lastOpen > prevClose && lastClose < prevOpen && body > prevBody) {
      patterns.push('BEARISH_ENGULFING');
    }
  }
  
  // Pin Bar
  if (lowerWick > body * 2.5 && upperWick < range * 0.2) {
    patterns.push('BULLISH_PIN_BAR');
  }
  if (upperWick > body * 2.5 && lowerWick < range * 0.2) {
    patterns.push('BEARISH_PIN_BAR');
  }
  
  // Marubozu
  if (body > range * 0.9 && range > 0) {
    if (lastClose > lastOpen) {
      patterns.push('BULLISH_MARUBOZU');
    } else {
      patterns.push('BEARISH_MARUBOZU');
    }
  }
  
  // Three consecutive same direction
  if (len >= 3) {
    const allBullish = closes[len-1] > opens[len-1] && closes[len-2] > opens[len-2] && closes[len-3] > opens[len-3];
    const allBearish = closes[len-1] < opens[len-1] && closes[len-2] < opens[len-2] && closes[len-3] < opens[len-3];
    
    if (allBullish) patterns.push('THREE_WHITE_SOLDIERS');
    if (allBearish) patterns.push('THREE_BLACK_CROWS');
  }
  
  return patterns;
}

// ============= BUILD MARKET DATA =============

function buildMarketDataForAI(candles: OandaCandle[], symbol: string) {
  const opens = candles.map(c => parseFloat(c.mid.o));
  const highs = candles.map(c => parseFloat(c.mid.h));
  const lows = candles.map(c => parseFloat(c.mid.l));
  const closes = candles.map(c => parseFloat(c.mid.c));
  const volumes = candles.map(c => Number.isFinite(c.volume) ? c.volume : 0);
  const currentPrice = closes[closes.length - 1];
  
  const ema20 = calculateEMA(closes, 20);
  const ema50 = calculateEMA(closes, 50);
  const ema200 = calculateEMA(closes, 200);
  
  const lastEma20 = ema20[ema20.length - 1] || currentPrice;
  const lastEma50 = ema50[ema50.length - 1] || currentPrice;
  const lastEma200 = ema200[ema200.length - 1] || currentPrice;
  
  const rsi14 = calculateRSI(closes, 14);
  const rsi7 = calculateRSI(closes, 7);
  const macd = calculateMACD(closes);
  const stochastic = calculateStochastic(highs, lows, closes, 14);
  const cci = calculateCCI(highs, lows, closes, 20);
  const atr = calculateATR(highs, lows, closes, 14);
  const bollinger = calculateBollingerBands(closes, 20, 2);
  const adx = calculateADX(highs, lows, closes, 14);
  const obv = calculateOBV(closes, volumes);
  const vwap = calculateVWAP(highs, lows, closes, volumes);
  const ichimoku = calculateIchimoku(highs, lows, closes);
  const volumeProfile = calculateVolumeProfile(highs, lows, closes, volumes);
  const parabolicSAR = calculateParabolicSAR(highs, lows, closes);
  const patterns = detectCandlePatterns(opens, highs, lows, closes);
  const marketStructure = detectMarketStructure(highs, lows, closes);
  const srLevels = findSupportResistanceSMC(highs, lows, closes);
  const fvgs = detectFVG(highs, lows);
  const premiumDiscount = calculatePremiumDiscount(highs, lows, closes);
  
  // ============= EMA SLOPE (ANGLE) CALCULATION =============
  let emaSlope = 0;
  if (ema20.length >= 5) {
    const recentEma = ema20.slice(-5);
    const slopeRaw = (recentEma[recentEma.length - 1] - recentEma[0]) / (recentEma.length - 1);
    emaSlope = (slopeRaw / (currentPrice || 1)) * 10000; // Normalized degrees-like value
  }
  
  // ============= NEAR ORDER BLOCK DETECTION =============
  let nearDemandOB = false;
  let nearSupplyOB = false;
  const obTolerance = atr * 1.5;
  for (const ob of srLevels.orderBlocks) {
    if (ob.type === 'BULLISH_OB' && Math.abs(currentPrice - ob.level) <= obTolerance) {
      nearDemandOB = true;
    }
    if (ob.type === 'BEARISH_OB' && Math.abs(currentPrice - ob.level) <= obTolerance) {
      nearSupplyOB = true;
    }
  }
  
  // ============= FVG TYPE FLAGS =============
  const hasBullishFVG = fvgs.some(f => f.type === 'BULLISH_FVG');
  const hasBearishFVG = fvgs.some(f => f.type === 'BEARISH_FVG');
  
  // ============= LIQUIDITY SWEEP DETECTION =============
  let hasLiquiditySweepFlag = false;
  let lastLiquiditySweep: 'SSL' | 'BSL' | null = null;
  if (closes.length >= 20) {
    const recent20Highs = highs.slice(-20, -1);
    const recent20Lows = lows.slice(-20, -1);
    const swingH = Math.max(...recent20Highs);
    const swingL = Math.min(...recent20Lows);
    const lastHigh = highs[highs.length - 1];
    const lastLow = lows[lows.length - 1];
    const lastClose = closes[closes.length - 1];
    // BSL sweep: current high broke swing high but closed back below
    if (lastHigh > swingH && lastClose < swingH) {
      hasLiquiditySweepFlag = true;
      lastLiquiditySweep = 'BSL';
    }
    // SSL sweep: current low broke swing low but closed back above
    if (lastLow < swingL && lastClose > swingL) {
      hasLiquiditySweepFlag = true;
      lastLiquiditySweep = 'SSL';
    }
  }
  
  // ============= VOLUME METRICS =============
  const rawVolumes = volumes;
  const avgVolume20 = volumes.length >= 20 ? volumes.slice(-20).reduce((a, b) => a + b, 0) / 20 : 1;
  const currentVolume = volumes[volumes.length - 1] || 0;
  const volumeRatio = avgVolume20 > 0 ? currentVolume / avgVolume20 : 1;
  const isVolumeSpike = volumeRatio > 2.0;
  const isVolumeDry = volumeRatio < 0.3;
  
  // Volume-Price Divergence Detection
  const lastCandle = closes[closes.length - 1] > opens[opens.length - 1] ? 'BULLISH' : 'BEARISH';
  const volPriceDivergence = (lastCandle === 'BULLISH' && obv.trend === 'BEARISH') ||
                             (lastCandle === 'BEARISH' && obv.trend === 'BULLISH');
  
  // Consecutive same color count
  let consecutiveSameColor = 0;
  const lastDir = closes[closes.length - 1] > opens[opens.length - 1];
  for (let ci = closes.length - 2; ci >= 0; ci--) {
    if ((closes[ci] > opens[ci]) === lastDir) consecutiveSameColor++;
    else break;
  }
  
  let emaAlignment: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = 'NEUTRAL';
  if (lastEma20 > lastEma50 && lastEma50 > lastEma200) emaAlignment = 'BULLISH';
  else if (lastEma20 < lastEma50 && lastEma50 < lastEma200) emaAlignment = 'BEARISH';
  
  let rsiZone: 'OVERSOLD' | 'OVERBOUGHT' | 'NEUTRAL' = 'NEUTRAL';
  if (rsi14 < 30) rsiZone = 'OVERSOLD';
  else if (rsi14 > 70) rsiZone = 'OVERBOUGHT';
  
  let bollingerPosition: 'UPPER_BAND' | 'LOWER_BAND' | 'MIDDLE' = 'MIDDLE';
  if (currentPrice >= bollinger.upper) bollingerPosition = 'UPPER_BAND';
  else if (currentPrice <= bollinger.lower) bollingerPosition = 'LOWER_BAND';
  
  const tkCross = ichimoku.tenkan > ichimoku.kijun ? 'BULLISH' : ichimoku.tenkan < ichimoku.kijun ? 'BEARISH' : 'NEUTRAL';
  
  return {
    symbol,
    currentPrice,
    // Raw series kept for internal scoring engines (not sent to client)
    raw: { opens, highs, lows, closes, volumes, times: candles.map(c => c.time) },
    trend: {
      ema20: lastEma20,
      ema50: lastEma50,
      ema200: lastEma200,
      emaAlignment,
      emaSlope,
      priceVsEMA20: currentPrice > lastEma20 ? 'ABOVE' : 'BELOW',
      priceVsEMA50: currentPrice > lastEma50 ? 'ABOVE' : 'BELOW',
      adx,
      trendStrength: adx > 25 ? 'STRONG' : adx < 20 ? 'WEAK' : 'MODERATE',
    },
    momentum: {
      rsi14,
      rsi7,
      rsiZone,
      rsiDivergence: 'NONE' as string,
      macd: {
        macd: macd.macd,
        signal: macd.signal,
        histogram: macd.histogram,
        crossover: macd.histogram > 0 ? 'BULLISH' : 'BEARISH',
      },
      stochastic: {
        k: stochastic.k,
        d: stochastic.d,
        zone: stochastic.k < 20 ? 'OVERSOLD' : stochastic.k > 80 ? 'OVERBOUGHT' : 'NEUTRAL'
      },
      cci
    },
    volatility: {
      atr,
      bollinger: {
        upper: bollinger.upper,
        middle: bollinger.middle,
        lower: bollinger.lower,
        width: bollinger.width,
        position: bollingerPosition
      }
    },
    volume: {
      obv: obv.obv,
      obvTrend: obv.trend,
      vwap,
      priceVsVWAP: currentPrice > vwap ? 'ABOVE' : 'BELOW',
      volumeProfile,
      currentVolume,
      avgVolume20,
      volumeRatio,
      isVolumeSpike,
      isVolumeDry,
      volPriceDivergence,
    },
    ichimoku: {
      tenkan: ichimoku.tenkan,
      kijun: ichimoku.kijun,
      senkouA: ichimoku.senkouA,
      senkouB: ichimoku.senkouB,
      cloudStatus: ichimoku.cloudStatus,
      tkCross
    },
    parabolicSAR: {
      sar: parabolicSAR.sar,
      trend: parabolicSAR.trend,
      reversal: parabolicSAR.reversal
    },
    smc: {
      marketStructure: marketStructure.marketStructure,
      structure: marketStructure.structure,
      lastBOS: marketStructure.lastBOS,
      lastCHoCH: marketStructure.lastCHoCH,
      support: srLevels.support,
      resistance: srLevels.resistance,
      orderBlocks: srLevels.orderBlocks.slice(-3),
      liquidityZones: srLevels.liquidityZones.slice(-3),
      fvgs: fvgs.slice(-3),
      premiumDiscount: premiumDiscount.zone,
      equilibrium: premiumDiscount.equilibrium,
      nearDemandOB,
      nearSupplyOB,
      hasBullishFVG,
      hasBearishFVG,
      hasLiquiditySweep: hasLiquiditySweepFlag,
      lastLiquiditySweep,
      fibOTE: {
        '0.618': premiumDiscount.fibLevels['0.618'],
        '0.705': premiumDiscount.fibLevels['0.705'],
        '0.786': premiumDiscount.fibLevels['0.786']
      }
    },
    priceAction: {
      patterns,
      consecutiveSameColor,
      lastCandle: {
        type: closes[closes.length - 1] > opens[opens.length - 1] ? 'BULLISH' : 'BEARISH',
        bodySize: Math.abs(closes[closes.length - 1] - opens[opens.length - 1]),
        range: highs[highs.length - 1] - lows[lows.length - 1]
      }
    },
    levels: {
      support: srLevels.support,
      resistance: srLevels.resistance,
      fibLevels: premiumDiscount.fibLevels
    }
  };
}

// ============= NEW 235 SETUP DATABASE (UPDATED UNIVERSAL OTC ALGORITHMIC SYSTEM) =============

interface TrapSetup {
  id: number;
  name: string;
  direction: 'CALL' | 'PUT';
  trapType: string;
  checkLogic: (data: ReturnType<typeof buildMarketDataForAI>, candles?: OandaCandle[]) => boolean;
}

// Helper functions for setup detection
function isHammer(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.priceAction.patterns.includes('HAMMER');
}
function isShootingStar(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.priceAction.patterns.includes('SHOOTING_STAR');
}
function isBullishEngulfing(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.priceAction.patterns.includes('BULLISH_ENGULFING');
}
function isBearishEngulfing(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.priceAction.patterns.includes('BEARISH_ENGULFING');
}
function isDoji(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.priceAction.patterns.includes('DOJI') || d.priceAction.patterns.includes('DRAGONFLY_DOJI') || d.priceAction.patterns.includes('GRAVESTONE_DOJI');
}
function isMorningStar(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.priceAction.patterns.includes('HAMMER') && d.smc.premiumDiscount === 'DISCOUNT';
}
function isEveningStar(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.priceAction.patterns.includes('SHOOTING_STAR') && d.smc.premiumDiscount === 'PREMIUM';
}
function isBullishMarubozu(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.priceAction.patterns.includes('BULLISH_MARUBOZU');
}
function isBearishMarubozu(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.priceAction.patterns.includes('BEARISH_MARUBOZU');
}
function isThreeWhiteSoldiers(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.priceAction.patterns.includes('THREE_WHITE_SOLDIERS');
}
function isThreeBlackCrows(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.priceAction.patterns.includes('THREE_BLACK_CROWS');
}
function isBullishPinBar(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.priceAction.patterns.includes('BULLISH_PIN_BAR');
}
function isBearishPinBar(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.priceAction.patterns.includes('BEARISH_PIN_BAR');
}
function isAtDemand(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.smc.premiumDiscount === 'DISCOUNT' || d.smc.orderBlocks.some(ob => ob.type === 'BULLISH_OB');
}
function isAtSupply(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.smc.premiumDiscount === 'PREMIUM' || d.smc.orderBlocks.some(ob => ob.type === 'BEARISH_OB');
}
function isAtSupport(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  const tolerance = d.currentPrice * 0.002;
  return Math.abs(d.currentPrice - d.smc.support) <= tolerance;
}
function isAtResistance(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  const tolerance = d.currentPrice * 0.002;
  return Math.abs(d.currentPrice - d.smc.resistance) <= tolerance;
}
function isNearRoundNumber(price: number, type?: string): boolean {
  const str = price.toFixed(5);
  if (type === '000') return str.endsWith('000') || str.includes('.000');
  if (type === '500') return str.includes('.500') || str.includes('500');
  return str.includes('.000') || str.includes('.500') || str.endsWith('00');
}
function hasFVG(d: ReturnType<typeof buildMarketDataForAI>, type: 'BULLISH' | 'BEARISH'): boolean {
  return d.smc.fvgs.some(f => f.type === `${type}_FVG`);
}
function hasLiquiditySweep(d: ReturnType<typeof buildMarketDataForAI>, type: 'SSL' | 'BSL'): boolean {
  return d.smc.liquidityZones.some(l => l.type === type);
}
function isAtEMA(d: ReturnType<typeof buildMarketDataForAI>, ema: 20 | 50 | 200): boolean {
  const emaVal = ema === 20 ? d.trend.ema20 : ema === 50 ? d.trend.ema50 : d.trend.ema200;
  const tolerance = d.volatility.atr * 0.5;
  return Math.abs(d.currentPrice - emaVal) <= tolerance;
}
function isAtBBLower(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.volatility.bollinger.position === 'LOWER_BAND';
}
function isAtBBUpper(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.volatility.bollinger.position === 'UPPER_BAND';
}
function isAtVWAP(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  const tolerance = d.volatility.atr * 0.3;
  return Math.abs(d.currentPrice - d.volume.vwap) <= tolerance;
}
function isBullish(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.priceAction.lastCandle.type === 'BULLISH';
}
function isBearish(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.priceAction.lastCandle.type === 'BEARISH';
}
function isStrongTrend(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.trend.adx > 25;
}
function isBBSqueeze(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.volatility.bollinger.width < 2;
}
function isVolumeSpike(d: ReturnType<typeof buildMarketDataForAI>): boolean {
  return d.volume.obvTrend === 'BULLISH' || d.volume.obvTrend === 'BEARISH';
}

const MASTER_235_SETUPS: TrapSetup[] = [
  // ============= SETUPS 1-50 (CALL & PUT BASICS) =============
  // 1 🟢 CALL: HTF Demand + Hammer (Trap 12)
  { id: 1, name: 'HTF Demand + Hammer', direction: 'CALL', trapType: 'Trap 12: Stop Hunt', checkLogic: (d) => isAtDemand(d) && isHammer(d) && d.smc.premiumDiscount === 'DISCOUNT' },
  // 2 🟢 CALL: HTF Demand + Engulfing (Trap 2)
  { id: 2, name: 'HTF Demand + Engulfing', direction: 'CALL', trapType: 'Trap 2: S/R Siphon', checkLogic: (d) => isAtDemand(d) && isBullishEngulfing(d) },
  // 3 🟢 CALL: Morning Star @ HTF (Trap 19)
  { id: 3, name: 'Morning Star @ HTF', direction: 'CALL', trapType: 'Trap 19: Volatility Snap', checkLogic: (d) => isMorningStar(d) && d.smc.premiumDiscount === 'DISCOUNT' },
  // 4 🟢 CALL: Sweep Low + Tweezer (Trap 24)
  { id: 4, name: 'Sweep Low + Tweezer', direction: 'CALL', trapType: 'Trap 24: Round Magnet', checkLogic: (d) => hasLiquiditySweep(d, 'SSL') && isNearRoundNumber(d.currentPrice, '000') },
  // 5 🟢 CALL: 1M FVG Tap + Engulfing (Trap 6)
  { id: 5, name: 'FVG Tap + Engulfing', direction: 'CALL', trapType: 'Trap 6: Symmetrizer', checkLogic: (d) => hasFVG(d, 'BULLISH') && isBullishEngulfing(d) },
  // 6 🟢 CALL: EMA20 + Hammer (Trap 22)
  { id: 6, name: 'EMA20 + Hammer', direction: 'CALL', trapType: 'Trap 22: Ribbon Kiss', checkLogic: (d) => isAtEMA(d, 20) && isHammer(d) && d.trend.emaAlignment === 'BULLISH' },
  // 7 🟢 CALL: EMA50 + Engulfing (Trap 14)
  { id: 7, name: 'EMA50 + Engulfing', direction: 'CALL', trapType: 'Trap 14: Vacuum Effect', checkLogic: (d) => isAtEMA(d, 50) && isBullishEngulfing(d) },
  // 8 🟢 CALL: EMA200 + Engulfing (Trap 25)
  { id: 8, name: 'EMA200 + Engulfing', direction: 'CALL', trapType: 'Trap 25: Time Window', checkLogic: (d) => isAtEMA(d, 200) && isBullishEngulfing(d) },
  // 9 🟢 CALL: VWAP + Engulfing (Trap 9)
  { id: 9, name: 'VWAP + Engulfing', direction: 'CALL', trapType: 'Trap 9: VWAP Deviation', checkLogic: (d) => isAtVWAP(d) && isBullishEngulfing(d) && d.volume.obvTrend === 'BULLISH' },
  // 10 🟢 CALL: BB Lower + Hammer (Trap 11)
  { id: 10, name: 'BB Lower + Hammer', direction: 'CALL', trapType: 'Trap 11: Bollinger Blast', checkLogic: (d) => isAtBBLower(d) && isHammer(d) },
  // 11 🟢 CALL: RSI <20 + Support (Trap 10)
  { id: 11, name: 'RSI Oversold + Support', direction: 'CALL', trapType: 'Trap 10: Algo Trending', checkLogic: (d) => d.momentum.rsi14 < 20 && isAtSupport(d) },
  // 12 🟢 CALL: Stochastic + Bullish (Trap 21)
  { id: 12, name: 'Stochastic Oversold + Bullish', direction: 'CALL', trapType: 'Trap 21: Compression', checkLogic: (d) => d.momentum.stochastic.k < 20 && isBullish(d) },
  // 13 🟢 CALL: ADX 25-35 + Continue (Trap 4)
  { id: 13, name: 'ADX Trending + Bullish Continue', direction: 'CALL', trapType: 'Trap 4: Color Cycle', checkLogic: (d) => d.trend.adx >= 25 && d.trend.adx <= 35 && isBullish(d) && d.trend.emaAlignment === 'BULLISH' },
  // 14 🟢 CALL: OBV Rising + Engulfing (Trap 27)
  { id: 14, name: 'OBV Rising + Engulfing', direction: 'CALL', trapType: 'Trap 27: Vol Divergence', checkLogic: (d) => d.volume.obvTrend === 'BULLISH' && isBullishEngulfing(d) },
  // 15 🟢 CALL: MFI Oversold + Hammer (Trap 5)
  { id: 15, name: 'MFI Oversold + Hammer', direction: 'CALL', trapType: 'Trap 5: Round Magnet', checkLogic: (d) => d.momentum.rsi14 < 30 && isHammer(d) && isNearRoundNumber(d.currentPrice, '500') },
  // 16 🟢 CALL: Inside 3 Up @ Demand (Trap 18)
  { id: 16, name: 'Inside 3 Up @ Demand', direction: 'CALL', trapType: 'Trap 18: Symmetry Break', checkLogic: (d) => isAtDemand(d) && d.smc.structure === 'HH_HL' },
  // 17 🟢 CALL: 3 Soldiers @ Sweep (Trap 13)
  { id: 17, name: '3 White Soldiers', direction: 'CALL', trapType: 'Trap 13: Invalidated Rej', checkLogic: (d) => isThreeWhiteSoldiers(d) },
  // 18 🟢 CALL: Marubozu + Pullback (Trap 1)
  { id: 18, name: 'Marubozu + Pullback', direction: 'CALL', trapType: 'Trap 1: Wick Fill', checkLogic: (d) => isBullishMarubozu(d) },
  // 19 🟢 CALL: Rising 3 Methods (Trap 21)
  { id: 19, name: 'Rising 3 Methods', direction: 'CALL', trapType: 'Trap 21: Compression', checkLogic: (d) => d.trend.emaAlignment === 'BULLISH' && d.priceAction.patterns.length >= 2 },
  // 20 🟢 CALL: PSAR Flip + Bullish (Trap 17)
  { id: 20, name: 'PSAR Flip Bullish', direction: 'CALL', trapType: 'Trap 17: Micro-Gap', checkLogic: (d) => d.parabolicSAR.trend === 'BULLISH' && isBullish(d) },
  // 21 🟢 CALL: VWAP + EMA20 (Trap 20)
  { id: 21, name: 'VWAP + EMA20 Support', direction: 'CALL', trapType: 'Trap 20: Near-Miss', checkLogic: (d) => isAtVWAP(d) && isAtEMA(d, 20) },
  // 22 🟢 CALL: Range Low + Hammer (Trap 26)
  { id: 22, name: 'Range Low + Hammer', direction: 'CALL', trapType: 'Trap 26: Micro-Range', checkLogic: (d) => d.smc.premiumDiscount === 'DISCOUNT' && isHammer(d) },
  // 23 🟢 CALL: FVG + EMA20 (Trap 6)
  { id: 23, name: 'FVG + EMA20', direction: 'CALL', trapType: 'Trap 6: Symmetrizer', checkLogic: (d) => hasFVG(d, 'BULLISH') && isAtEMA(d, 20) },
  // 24 🟢 CALL: StdDev Expansion (Trap 16)
  { id: 24, name: 'StdDev Expansion Bullish', direction: 'CALL', trapType: 'Trap 16: Escalator Exit', checkLogic: (d) => d.volatility.bollinger.width > 3 && isBullish(d) },
  // 25 🟢 CALL: HTF Range Floor (Trap 15)
  { id: 25, name: 'HTF Range Floor', direction: 'CALL', trapType: 'Trap 15: Switching Fatigue', checkLogic: (d) => d.smc.premiumDiscount === 'DISCOUNT' && d.priceAction.patterns.length > 0 },
  
  // ============= SETUPS 26-50 (PUT BASICS) =============
  // 26 🔴 PUT: Supply OB + Shooting Star (Trap 12)
  { id: 26, name: 'Supply OB + Shooting Star', direction: 'PUT', trapType: 'Trap 12: Stop Hunt', checkLogic: (d) => isAtSupply(d) && isShootingStar(d) },
  // 27 🔴 PUT: Evening Star @ HTF (Trap 19)
  { id: 27, name: 'Evening Star @ HTF', direction: 'PUT', trapType: 'Trap 19: Volatility Snap', checkLogic: (d) => isEveningStar(d) && isAtBBUpper(d) },
  // 28 🔴 PUT: Bearish Engulfing (Trap 2)
  { id: 28, name: 'Bearish Engulfing @ Resistance', direction: 'PUT', trapType: 'Trap 2: S/R Siphon', checkLogic: (d) => isBearishEngulfing(d) && isAtResistance(d) },
  // 29 🔴 PUT: Sweep High + Tweezer (Trap 24)
  { id: 29, name: 'Sweep High + Tweezer', direction: 'PUT', trapType: 'Trap 24: Round Magnet', checkLogic: (d) => hasLiquiditySweep(d, 'BSL') && isNearRoundNumber(d.currentPrice, '000') },
  // 30 🔴 PUT: FVG Tap + Engulfing (Trap 6)
  { id: 30, name: 'Bearish FVG Tap + Engulfing', direction: 'PUT', trapType: 'Trap 6: Symmetrizer', checkLogic: (d) => hasFVG(d, 'BEARISH') && isBearishEngulfing(d) },
  // 31 🔴 PUT: EMA20 + Shooting Star (Trap 1)
  { id: 31, name: 'EMA20 + Shooting Star', direction: 'PUT', trapType: 'Trap 1: Wick Fill', checkLogic: (d) => isAtEMA(d, 20) && isShootingStar(d) },
  // 32 🔴 PUT: EMA50 + Engulfing (Trap 14)
  { id: 32, name: 'EMA50 + Bearish Engulfing', direction: 'PUT', trapType: 'Trap 14: Vacuum Effect', checkLogic: (d) => isAtEMA(d, 50) && isBearishEngulfing(d) },
  // 33 🔴 PUT: EMA200 + Engulfing (Trap 25)
  { id: 33, name: 'EMA200 + Bearish Engulfing', direction: 'PUT', trapType: 'Trap 25: Time Window', checkLogic: (d) => isAtEMA(d, 200) && isBearishEngulfing(d) },
  // 34 🔴 PUT: VWAP + Engulfing (Trap 9)
  { id: 34, name: 'VWAP + Bearish Engulfing', direction: 'PUT', trapType: 'Trap 9: VWAP Deviation', checkLogic: (d) => isAtVWAP(d) && isBearishEngulfing(d) },
  // 35 🔴 PUT: BB Upper + Star (Trap 11)
  { id: 35, name: 'BB Upper + Shooting Star', direction: 'PUT', trapType: 'Trap 11: Bollinger Blast', checkLogic: (d) => isAtBBUpper(d) && isShootingStar(d) },
  // 36 🔴 PUT: RSI >80 + Resistance (Trap 10)
  { id: 36, name: 'RSI Overbought + Resistance', direction: 'PUT', trapType: 'Trap 10: Algo Trending', checkLogic: (d) => d.momentum.rsi14 > 80 && isAtResistance(d) },
  // 37 🔴 PUT: Stochastic + Bearish (Trap 21)
  { id: 37, name: 'Stochastic Overbought + Bearish', direction: 'PUT', trapType: 'Trap 21: Compression', checkLogic: (d) => d.momentum.stochastic.k > 80 && isBearish(d) },
  // 38 🔴 PUT: ADX 25-35 + Continue (Trap 4)
  { id: 38, name: 'ADX Trending + Bearish Continue', direction: 'PUT', trapType: 'Trap 4: Color Cycle', checkLogic: (d) => d.trend.adx >= 25 && d.trend.adx <= 35 && isBearish(d) && d.trend.emaAlignment === 'BEARISH' },
  // 39 🔴 PUT: OBV Falling + Engulfing (Trap 27)
  { id: 39, name: 'OBV Falling + Engulfing', direction: 'PUT', trapType: 'Trap 27: Hollow Move', checkLogic: (d) => d.volume.obvTrend === 'BEARISH' && isBearishEngulfing(d) },
  // 40 🔴 PUT: MFI Overbought + Star (Trap 5)
  { id: 40, name: 'MFI Overbought + Star', direction: 'PUT', trapType: 'Trap 5: Round Magnet', checkLogic: (d) => d.momentum.rsi14 > 70 && isShootingStar(d) && isNearRoundNumber(d.currentPrice, '500') },
  // 41 🔴 PUT: Inside 3 Down @ Supply (Trap 18)
  { id: 41, name: 'Inside 3 Down @ Supply', direction: 'PUT', trapType: 'Trap 18: Symmetry Break', checkLogic: (d) => isAtSupply(d) && d.smc.structure === 'LH_LL' },
  // 42 🔴 PUT: 3 Crows After Sweep (Trap 13)
  { id: 42, name: '3 Black Crows', direction: 'PUT', trapType: 'Trap 13: Invalidated Rej', checkLogic: (d) => isThreeBlackCrows(d) },
  // 43 🔴 PUT: Marubozu + Pullback (Trap 1)
  { id: 43, name: 'Bearish Marubozu + Pullback', direction: 'PUT', trapType: 'Trap 1: Wick Fill', checkLogic: (d) => isBearishMarubozu(d) },
  // 44 🔴 PUT: Falling 3 Methods (Trap 21)
  { id: 44, name: 'Falling 3 Methods', direction: 'PUT', trapType: 'Trap 21: Compression', checkLogic: (d) => d.trend.emaAlignment === 'BEARISH' && d.priceAction.patterns.length >= 2 },
  // 45 🔴 PUT: PSAR Flip + Bearish (Trap 17)
  { id: 45, name: 'PSAR Flip Bearish', direction: 'PUT', trapType: 'Trap 17: Micro-Gap', checkLogic: (d) => d.parabolicSAR.trend === 'BEARISH' && isBearish(d) },
  // 46 🔴 PUT: VWAP + EMA20 Resistance (Trap 20)
  { id: 46, name: 'VWAP + EMA20 Resistance', direction: 'PUT', trapType: 'Trap 20: Near-Miss', checkLogic: (d) => isAtVWAP(d) && isAtEMA(d, 20) && isBearish(d) },
  // 47 🔴 PUT: Liquidity Grab @ High (Trap 23)
  { id: 47, name: 'Liquidity Grab High', direction: 'PUT', trapType: 'Trap 23: Round Flush', checkLogic: (d) => hasLiquiditySweep(d, 'BSL') && isNearRoundNumber(d.currentPrice, '000') },
  // 48 🔴 PUT: FVG + EMA20 (Trap 6)
  { id: 48, name: 'Bearish FVG + EMA20', direction: 'PUT', trapType: 'Trap 6: Symmetrizer', checkLogic: (d) => hasFVG(d, 'BEARISH') && isAtEMA(d, 20) },
  // 49 🔴 PUT: StdDev Expansion Bearish (Trap 16)
  { id: 49, name: 'StdDev Expansion Bearish', direction: 'PUT', trapType: 'Trap 16: Godzilla Candle', checkLogic: (d) => d.volatility.bollinger.width > 3 && isBearish(d) },
  // 50 🔴 PUT: HTF Range High (Trap 15)
  { id: 50, name: 'HTF Range Ceiling', direction: 'PUT', trapType: 'Trap 15: Switching Fatigue', checkLogic: (d) => d.smc.premiumDiscount === 'PREMIUM' && d.priceAction.patterns.length > 0 },

  // ============= SETUPS 51-100 (ADVANCED) =============
  // 51 🟢 CALL: HTF Demand + Inverted Hammer (Trap 6)
  { id: 51, name: 'Demand + Inverted Hammer', direction: 'CALL', trapType: 'Trap 6: Hammer Fail', checkLogic: (d) => isAtDemand(d) && d.priceAction.patterns.includes('DRAGONFLY_DOJI') },
  // 52 🟢 CALL: FVG + Morning Star Combo (Trap 6)
  { id: 52, name: 'FVG + Morning Star', direction: 'CALL', trapType: 'Trap 6: Symmetrizer', checkLogic: (d) => isMorningStar(d) && hasFVG(d, 'BULLISH') },
  // 53 🟢 CALL: EMA20 + EMA50 Support (Trap 22)
  { id: 53, name: 'EMA20 + EMA50 Ribbon Support', direction: 'CALL', trapType: 'Trap 22: Ribbon Kiss', checkLogic: (d) => isAtEMA(d, 20) && isAtEMA(d, 50) && d.trend.emaAlignment === 'BULLISH' },
  // 54 🟢 CALL: VWAP + BB Lower (Trap 11)
  { id: 54, name: 'VWAP + BB Lower', direction: 'CALL', trapType: 'Trap 11: Mean Reversion', checkLogic: (d) => isAtBBLower(d) && isAtVWAP(d) },
  // 55 🟢 CALL: Liquidity Sweep + Marubozu (Trap 2)
  { id: 55, name: 'Liquidity Sweep + Marubozu', direction: 'CALL', trapType: 'Trap 2: S/R Siphon', checkLogic: (d) => isBullishMarubozu(d) && hasLiquiditySweep(d, 'SSL') },
  // 56 🟢 CALL: RSI Divergence + Hammer (Trap 10)
  { id: 56, name: 'RSI Divergence + Hammer', direction: 'CALL', trapType: 'Trap 10: Algo Trending', checkLogic: (d) => d.momentum.rsi14 < 35 && isHammer(d) && isNearRoundNumber(d.currentPrice, '000') },
  // 57 🟢 CALL: Stochastic Reset + Engulfing (Trap 21)
  { id: 57, name: 'Stochastic Reset + Engulfing', direction: 'CALL', trapType: 'Trap 21: Compression', checkLogic: (d) => isBullishEngulfing(d) && d.momentum.stochastic.k < 20 },
  // 58 🟢 CALL: ADX Rising + Bullish Break (Trap 14)
  { id: 58, name: 'ADX Rising + Bullish Break', direction: 'CALL', trapType: 'Trap 14: Vacuum Expansion', checkLogic: (d) => d.trend.adx > 25 && d.smc.lastBOS === 'BULLISH_BOS' },
  // 59 🟢 CALL: OBV Breakout + Engulfing (Trap 27)
  { id: 59, name: 'OBV Breakout + Engulfing', direction: 'CALL', trapType: 'Trap 27: Vol Divergence', checkLogic: (d) => d.volume.obvTrend === 'BULLISH' && isBullishEngulfing(d) },
  // 60 🟢 CALL: MFI Rising + Demand (Trap 5)
  { id: 60, name: 'MFI Rising + Demand', direction: 'CALL', trapType: 'Trap 5: Round Magnet', checkLogic: (d) => d.momentum.rsi14 < 40 && isAtDemand(d) },
  // 61 🟢 CALL: Inside Bar Liquidity Grab (Trap 26)
  { id: 61, name: 'Inside Bar Liquidity Grab', direction: 'CALL', trapType: 'Trap 26: Micro-Range', checkLogic: (d) => d.smc.premiumDiscount === 'DISCOUNT' && isBullish(d) },
  // 62 🟢 CALL: 3 Pushes Down + Hammer (Trap 16)
  { id: 62, name: '3 Pushes Down + Hammer', direction: 'CALL', trapType: 'Trap 16: Escalator Exit', checkLogic: (d) => isHammer(d) && d.smc.structure === 'LH_LL' && isVolumeSpike(d) },
  // 63 🟢 CALL: EMA200 + FVG Overlap (Trap 8)
  { id: 63, name: 'EMA200 + FVG Overlap', direction: 'CALL', trapType: 'Trap 8: Institutional Reset', checkLogic: (d) => isAtEMA(d, 200) && hasFVG(d, 'BULLISH') },
  // 64 🟢 CALL: VWAP Reclaim + Bullish (Trap 17)
  { id: 64, name: 'VWAP Reclaim + Bullish', direction: 'CALL', trapType: 'Trap 17: Micro-Gap', checkLogic: (d) => d.volume.priceVsVWAP === 'ABOVE' && isBullish(d) },
  // 65 🟢 CALL: StdDev Compression (Trap 21)
  { id: 65, name: 'StdDev Compression Breakout', direction: 'CALL', trapType: 'Trap 21: Spring Release', checkLogic: (d) => isBBSqueeze(d) && isBullish(d) },
  // 66 🟢 CALL: HTF Range Low + Morning Star (Trap 15)
  { id: 66, name: 'Range Low + Morning Star', direction: 'CALL', trapType: 'Trap 15: Switching Fatigue', checkLogic: (d) => d.smc.premiumDiscount === 'DISCOUNT' && isMorningStar(d) },
  // 67 🟢 CALL: Bullish Engulfing After Doji (Trap 7)
  { id: 67, name: 'Engulfing After Doji', direction: 'CALL', trapType: 'Trap 7: Doji Reset', checkLogic: (d) => isDoji(d) || isBullishEngulfing(d) },
  // 68 🟢 CALL: Rising Channel + Hammer (Trap 20)
  { id: 68, name: 'Rising Channel + Hammer', direction: 'CALL', trapType: 'Trap 20: Near-Miss', checkLogic: (d) => d.trend.emaAlignment === 'BULLISH' && isHammer(d) },
  // 69 🟢 CALL: PSAR Stair-Step + Bullish (Trap 4)
  { id: 69, name: 'PSAR Stair-Step Bullish', direction: 'CALL', trapType: 'Trap 4: Color Cycle', checkLogic: (d) => d.parabolicSAR.trend === 'BULLISH' && isBullish(d) },
  // 70 🟢 CALL: EMA50 Retest + Strong Close (Trap 25)
  { id: 70, name: 'EMA50 Retest + Strong Close', direction: 'CALL', trapType: 'Trap 25: Time Window', checkLogic: (d) => isAtEMA(d, 50) && isBullish(d) },
  // 71 🟢 CALL: Asia/OTC Low Sweep (Trap 12)
  { id: 71, name: 'Session Low Sweep', direction: 'CALL', trapType: 'Trap 12: Stop Hunt', checkLogic: (d) => hasLiquiditySweep(d, 'SSL') && isBullish(d) },
  // 72 🟢 CALL: FVG Partial Fill + Continue (Trap 1)
  { id: 72, name: 'FVG Partial Fill', direction: 'CALL', trapType: 'Trap 1: Wick Fill', checkLogic: (d) => hasFVG(d, 'BULLISH') && isBullish(d) },
  // 73 🟢 CALL: VWAP + EMA200 Stack (Trap 5)
  { id: 73, name: 'VWAP + EMA200 Stack', direction: 'CALL', trapType: 'Trap 5: Heavy Gravity', checkLogic: (d) => isAtVWAP(d) && isAtEMA(d, 200) && isNearRoundNumber(d.currentPrice) },
  // 74 🟢 CALL: OBV Higher Low + Engulfing (Trap 9)
  { id: 74, name: 'OBV Higher Low + Engulfing', direction: 'CALL', trapType: 'Trap 9: VWAP Deviation', checkLogic: (d) => d.volume.obvTrend === 'BULLISH' && isBullishEngulfing(d) },
  // 75 🟢 CALL: BB Walk (Lower to Mid) (Trap 4)
  { id: 75, name: 'BB Walk Lower to Mid', direction: 'CALL', trapType: 'Trap 4: Odd Cycle', checkLogic: (d) => d.volatility.bollinger.position === 'LOWER_BAND' && isBullish(d) },
  
  // ============= SETUPS 76-100 (ADVANCED PUTS) =============
  // 76 🔴 PUT: HTF Supply + Inverted Hammer (Trap 6)
  { id: 76, name: 'Supply + Inverted Hammer', direction: 'PUT', trapType: 'Trap 6: Wick Target', checkLogic: (d) => isAtSupply(d) && d.priceAction.patterns.includes('GRAVESTONE_DOJI') },
  // 77 🔴 PUT: FVG + Evening Star (Trap 6)
  { id: 77, name: 'FVG + Evening Star', direction: 'PUT', trapType: 'Trap 6: Symmetrizer', checkLogic: (d) => isEveningStar(d) && hasFVG(d, 'BEARISH') },
  // 78 🔴 PUT: EMA20 + EMA50 Resistance (Trap 22)
  { id: 78, name: 'EMA20 + EMA50 Resistance', direction: 'PUT', trapType: 'Trap 22: Ribbon Kiss', checkLogic: (d) => isAtEMA(d, 50) && isShootingStar(d) },
  // 79 🔴 PUT: VWAP + BB Upper (Trap 11)
  { id: 79, name: 'VWAP + BB Upper', direction: 'PUT', trapType: 'Trap 11: Bollinger Blast', checkLogic: (d) => isAtBBUpper(d) && isAtVWAP(d) },
  // 80 🔴 PUT: Liquidity Sweep High (Trap 2)
  { id: 80, name: 'Liquidity Sweep High', direction: 'PUT', trapType: 'Trap 2: S/R Siphon', checkLogic: (d) => hasLiquiditySweep(d, 'BSL') && isNearRoundNumber(d.currentPrice, '000') },
  // 81 🔴 PUT: RSI Divergence + Star (Trap 10)
  { id: 81, name: 'RSI Divergence + Star', direction: 'PUT', trapType: 'Trap 10: Exhaustion', checkLogic: (d) => d.momentum.rsi14 > 65 && isShootingStar(d) },
  // 82 🔴 PUT: Stochastic Reset + Engulfing (Trap 21)
  { id: 82, name: 'Stochastic Reset + Bear Engulfing', direction: 'PUT', trapType: 'Trap 21: Doji Spring', checkLogic: (d) => d.momentum.stochastic.k > 80 && isBearishEngulfing(d) },
  // 83 🔴 PUT: ADX Rising + Bearish Break (Trap 14)
  { id: 83, name: 'ADX Rising + Bearish Break', direction: 'PUT', trapType: 'Trap 14: Vacuum Effect', checkLogic: (d) => d.trend.adx > 25 && d.smc.lastBOS === 'BEARISH_BOS' },
  // 84 🔴 PUT: OBV Breakdown + Engulfing (Trap 27)
  { id: 84, name: 'OBV Breakdown + Engulfing', direction: 'PUT', trapType: 'Trap 27: Hollow Move', checkLogic: (d) => d.volume.obvTrend === 'BEARISH' && isBearishEngulfing(d) },
  // 85 🔴 PUT: MFI Falling + Supply (Trap 25)
  { id: 85, name: 'MFI Falling + Supply', direction: 'PUT', trapType: 'Trap 25: Time Reset', checkLogic: (d) => d.momentum.rsi14 > 60 && isAtSupply(d) },
  // 86 🔴 PUT: Inside Bar Grab + Down (Trap 26)
  { id: 86, name: 'Inside Bar Grab Down', direction: 'PUT', trapType: 'Trap 26: Micro-Range', checkLogic: (d) => d.smc.premiumDiscount === 'PREMIUM' && isBearish(d) },
  // 87 🔴 PUT: 3 Pushes Up + Star (Trap 16)
  { id: 87, name: '3 Pushes Up + Star', direction: 'PUT', trapType: 'Trap 16: Exhaustion', checkLogic: (d) => isShootingStar(d) && d.smc.structure === 'HH_HL' && isAtBBUpper(d) },
  // 88 🔴 PUT: EMA200 + FVG Overlap (Trap 8)
  { id: 88, name: 'EMA200 + Bearish FVG', direction: 'PUT', trapType: 'Trap 8: Fib 78.6', checkLogic: (d) => isAtEMA(d, 200) && hasFVG(d, 'BEARISH') },
  // 89 🔴 PUT: VWAP Loss + Bearish (Trap 17)
  { id: 89, name: 'VWAP Loss + Bearish', direction: 'PUT', trapType: 'Trap 17: Micro-Gap', checkLogic: (d) => d.volume.priceVsVWAP === 'BELOW' && isBearish(d) },
  // 90 🔴 PUT: StdDev Compression Bearish (Trap 21)
  { id: 90, name: 'StdDev Compression Bearish', direction: 'PUT', trapType: 'Trap 21: Spring', checkLogic: (d) => isBBSqueeze(d) && isBearish(d) },
  // 91 🔴 PUT: HTF Range High + Evening Star (Trap 19)
  { id: 91, name: 'Range High + Evening Star', direction: 'PUT', trapType: 'Trap 19: Volatility Snap', checkLogic: (d) => d.smc.premiumDiscount === 'PREMIUM' && isEveningStar(d) },
  // 92 🔴 PUT: Bearish Engulfing After Doji (Trap 7)
  { id: 92, name: 'Bear Engulfing After Doji', direction: 'PUT', trapType: 'Trap 7: Continuation Doji', checkLogic: (d) => isDoji(d) || isBearishEngulfing(d) },
  // 93 🔴 PUT: Falling Channel + Star (Trap 20)
  { id: 93, name: 'Falling Channel + Star', direction: 'PUT', trapType: 'Trap 20: Near-Miss', checkLogic: (d) => d.trend.emaAlignment === 'BEARISH' && isShootingStar(d) },
  // 94 🔴 PUT: PSAR Stair-Step + Bearish (Trap 4)
  { id: 94, name: 'PSAR Stair-Step Bearish', direction: 'PUT', trapType: 'Trap 4: Momentum Cycle', checkLogic: (d) => d.parabolicSAR.trend === 'BEARISH' && isBearish(d) },
  // 95 🔴 PUT: EMA50 Retest + Shooting Star (Trap 1)
  { id: 95, name: 'EMA50 Retest + Star', direction: 'PUT', trapType: 'Trap 1: Wick Fill', checkLogic: (d) => isAtEMA(d, 50) && isShootingStar(d) },
  // 96 🔴 PUT: Asia/OTC High Sweep (Trap 12)
  { id: 96, name: 'Session High Sweep', direction: 'PUT', trapType: 'Trap 12: Stop Hunt', checkLogic: (d) => hasLiquiditySweep(d, 'BSL') && isNearRoundNumber(d.currentPrice, '500') },
  // 97 🔴 PUT: FVG Partial Fill + Continue (Trap 13)
  { id: 97, name: 'Bearish FVG Partial Fill', direction: 'PUT', trapType: 'Trap 13: Invalidated Rej', checkLogic: (d) => hasFVG(d, 'BEARISH') && isBearish(d) },
  // 98 🔴 PUT: VWAP + EMA200 Stack (Trap 5)
  { id: 98, name: 'VWAP + EMA200 Ceiling', direction: 'PUT', trapType: 'Trap 5: Institutional Ceiling', checkLogic: (d) => isAtVWAP(d) && isAtEMA(d, 200) && isVolumeSpike(d) },
  // 99 🔴 PUT: OBV Lower High + Engulfing (Trap 9)
  { id: 99, name: 'OBV Lower High + Engulfing', direction: 'PUT', trapType: 'Trap 9: Static Volume', checkLogic: (d) => d.volume.obvTrend === 'BEARISH' && isBearishEngulfing(d) },
  // 100 🔴 PUT: BB Walk (Upper to Mid) (Trap 15)
  { id: 100, name: 'BB Walk Upper to Mid', direction: 'PUT', trapType: 'Trap 15: Color Fatigue', checkLogic: (d) => d.volatility.bollinger.position === 'UPPER_BAND' && isBearish(d) },

  // ============= SETUPS 101-150 (ELITE TIER) =============
  // 101 🟢 CALL: HTF Demand + Long Rej Wick (Trap 12)
  { id: 101, name: 'Demand + Long Rejection Wick', direction: 'CALL', trapType: 'Trap 12: Stop Hunt', checkLogic: (d) => isAtDemand(d) && isBullishPinBar(d) && isBullish(d) },
  // 102 🟢 CALL: Demand OB + Doji → Engulfing (Trap 7)
  { id: 102, name: 'Demand OB + Doji Engulfing', direction: 'CALL', trapType: 'Trap 7: Binary Reset', checkLogic: (d) => isAtDemand(d) && isDoji(d) && isBullishEngulfing(d) },
  // 103 🟢 CALL: FVG + Tweezer Bottom (Trap 6)
  { id: 103, name: 'FVG + Tweezer Bottom', direction: 'CALL', trapType: 'Trap 6: Symmetrizer', checkLogic: (d) => hasFVG(d, 'BULLISH') && isAtSupport(d) },
  // 104 🟢 CALL: EMA20 Trend + Inside Bar Up (Trap 21)
  { id: 104, name: 'EMA20 Trend + Inside Bar Up', direction: 'CALL', trapType: 'Trap 21: Compression', checkLogic: (d) => d.trend.priceVsEMA20 === 'ABOVE' && isBullish(d) },
  // 105 🟢 CALL: VWAP Rising + Hammer (Trap 9)
  { id: 105, name: 'VWAP Rising + Hammer', direction: 'CALL', trapType: 'Trap 9: VWAP Deviation', checkLogic: (d) => d.volume.priceVsVWAP === 'ABOVE' && isHammer(d) },
  // 106 🟢 CALL: EMA50 + Morning Star (Trap 22)
  { id: 106, name: 'EMA50 + Morning Star', direction: 'CALL', trapType: 'Trap 22: Ribbon Kiss', checkLogic: (d) => isMorningStar(d) && isAtEMA(d, 50) },
  // 107 🟢 CALL: EMA200 + Sweep + Hammer (Trap 23)
  { id: 107, name: 'EMA200 + Sweep + Hammer', direction: 'CALL', trapType: 'Trap 23: Round Flush', checkLogic: (d) => isAtEMA(d, 200) && isHammer(d) && isNearRoundNumber(d.currentPrice, '000') },
  // 108 🟢 CALL: BB Squeeze + Bullish Expansion (Trap 14)
  { id: 108, name: 'BB Squeeze + Bullish Expansion', direction: 'CALL', trapType: 'Trap 14: Vacuum Effect', checkLogic: (d) => isBBSqueeze(d) && isBullish(d) },
  // 109 🟢 CALL: RSI Mid-Zone Rejection (Trap 10)
  { id: 109, name: 'RSI Mid-Zone Hook Up', direction: 'CALL', trapType: 'Trap 10: Algo Trending', checkLogic: (d) => d.momentum.rsi14 >= 45 && d.momentum.rsi14 <= 55 && isBullish(d) },
  // 110 🟢 CALL: OBV Flat → Sudden Spike (Trap 27)
  { id: 110, name: 'OBV Flat to Spike', direction: 'CALL', trapType: 'Trap 27: Vol Divergence', checkLogic: (d) => d.volume.obvTrend === 'BULLISH' && isBullish(d) },
  // 111 🟢 CALL: MFI Reset + Hammer (Trap 16)
  { id: 111, name: 'MFI Reset + Hammer', direction: 'CALL', trapType: 'Trap 16: Escalator Exit', checkLogic: (d) => d.momentum.rsi14 <= 20 && isHammer(d) },
  // 112 🟢 CALL: ADX > 25 + Continuation (Trap 4)
  { id: 112, name: 'ADX Strong + 4th Green', direction: 'CALL', trapType: 'Trap 4: Color Cycle', checkLogic: (d) => d.trend.adx > 25 && isBullish(d) && d.trend.emaAlignment === 'BULLISH' },
  // 113 🟢 CALL: VWAP + EMA50 + Demand Stack (Trap 5)
  { id: 113, name: 'Triple Stack Demand', direction: 'CALL', trapType: 'Trap 5: Heavy Gravity', checkLogic: (d) => isAtVWAP(d) && isAtEMA(d, 50) && isAtDemand(d) && isNearRoundNumber(d.currentPrice, '500') },
  // 114 🟢 CALL: FVG Edge Tap + Strong Close (Trap 13)
  { id: 114, name: 'FVG Edge Tap + Strong Close', direction: 'CALL', trapType: 'Trap 13: Invalidated Rejection', checkLogic: (d) => hasFVG(d, 'BULLISH') && isBullishEngulfing(d) },
  // 115 🟢 CALL: Range Low Fakeout + Marubozu (Trap 26)
  { id: 115, name: 'Range Low Fakeout + Marubozu', direction: 'CALL', trapType: 'Trap 26: Micro-Range', checkLogic: (d) => d.smc.premiumDiscount === 'DISCOUNT' && isBullishMarubozu(d) },
  // 116 🟢 CALL: Engulfing After 2 Small Reds (Trap 15)
  { id: 116, name: 'Engulfing After 2 Small Reds', direction: 'CALL', trapType: 'Trap 15: Switching Fatigue', checkLogic: (d) => isBullish(d) && isBullishEngulfing(d) },
  // 117 🟢 CALL: 3 Inside Bars + Break Up (Trap 21)
  { id: 117, name: '3 Inside Bars Break Up', direction: 'CALL', trapType: 'Trap 21: Spring Release', checkLogic: (d) => isBullish(d) && d.smc.structure === 'HH_HL' },
  // 118 🟢 CALL: Rising Wedge Fake Breakdown (Trap 2)
  { id: 118, name: 'Wedge Fake Breakdown', direction: 'CALL', trapType: 'Trap 2: S/R Siphon', checkLogic: (d) => isBullishEngulfing(d) && hasLiquiditySweep(d, 'SSL') },
  // 119 🟢 CALL: EMA20 Reclaim + Strong Close (Trap 17)
  { id: 119, name: 'EMA20 Reclaim + Gap Up', direction: 'CALL', trapType: 'Trap 17: Micro-Gap', checkLogic: (d) => d.trend.priceVsEMA20 === 'ABOVE' && isBullish(d) },
  // 120 🟢 CALL: VWAP Reclaim + Doji Reset (Trap 7)
  { id: 120, name: 'VWAP Reclaim + Doji', direction: 'CALL', trapType: 'Trap 7: Doji Reset', checkLogic: (d) => d.volume.priceVsVWAP === 'ABOVE' && isDoji(d) },
  // 121 🟢 CALL: Prev Day Low Sweep + Hammer (Trap 12)
  { id: 121, name: 'PDL Sweep + Hammer', direction: 'CALL', trapType: 'Trap 12: Stop Hunt', checkLogic: (d) => hasLiquiditySweep(d, 'SSL') && isHammer(d) },
  // 122 🟢 CALL: HTF Demand + Inv. Hammer Conf (Trap 6)
  { id: 122, name: 'Demand + Inv Hammer Conf', direction: 'CALL', trapType: 'Trap 6: Wick Magnet', checkLogic: (d) => isAtDemand(d) && isBullish(d) },
  // 123 🟢 CALL: BB Lower Walk → Mid (Trap 11)
  { id: 123, name: 'BB Lower Walk to Mid', direction: 'CALL', trapType: 'Trap 11: Mean Reversion', checkLogic: (d) => isAtBBLower(d) && isVolumeSpike(d) },
  // 124 🟢 CALL: OBV Higher Low + Bullish (Trap 9)
  { id: 124, name: 'OBV Higher Low', direction: 'CALL', trapType: 'Trap 9: VWAP Deviation', checkLogic: (d) => d.volume.obvTrend === 'BULLISH' && isBullish(d) },
  // 125 🟢 CALL: EMA50 + FVG Overlap (Trap 8)
  { id: 125, name: 'EMA50 + FVG Perfect Align', direction: 'CALL', trapType: 'Trap 8: Institutional Reset', checkLogic: (d) => isAtEMA(d, 50) && hasFVG(d, 'BULLISH') },
  // 126 🟢 CALL: RSI Bullish Divergence (Trap 10)
  { id: 126, name: 'RSI Bullish Divergence', direction: 'CALL', trapType: 'Trap 10: Exhaustion', checkLogic: (d) => d.momentum.rsi14 < 20 && isBullish(d) },
  // 127 🟢 CALL: ADX Rising + Marubozu (Trap 14)
  { id: 127, name: 'ADX Rising + Marubozu', direction: 'CALL', trapType: 'Trap 14: Vacuum Effect', checkLogic: (d) => d.trend.adx > 25 && isBullishMarubozu(d) },
  // 128 🟢 CALL: PSAR Support + Bullish (Trap 4)
  { id: 128, name: 'PSAR Support 3rd Candle', direction: 'CALL', trapType: 'Trap 4: Odd Cycle', checkLogic: (d) => d.parabolicSAR.trend === 'BULLISH' && isBullish(d) },
  // 129 🟢 CALL: Demand OB + Inside 3 Up (Trap 18)
  { id: 129, name: 'Demand OB + Inside 3 Up', direction: 'CALL', trapType: 'Trap 18: Symmetry Break', checkLogic: (d) => isAtDemand(d) && d.smc.structure === 'HH_HL' },
  // 130 🟢 CALL: VWAP Pullback + Engulfing (Trap 20)
  { id: 130, name: 'VWAP Near-Miss + Engulfing', direction: 'CALL', trapType: 'Trap 20: Near-Miss', checkLogic: (d) => isAtVWAP(d) && isBullishEngulfing(d) },
  // 131 🟢 CALL: EMA200 + Range Low (Trap 23)
  { id: 131, name: 'EMA200 + Range Low', direction: 'CALL', trapType: 'Trap 23: Round Flush', checkLogic: (d) => isAtEMA(d, 200) && d.smc.premiumDiscount === 'DISCOUNT' && isNearRoundNumber(d.currentPrice, '000') },
  // 132 🟢 CALL: FVG Partial Fill + Hammer (Trap 6)
  { id: 132, name: 'FVG 50% Fill + Hammer', direction: 'CALL', trapType: 'Trap 6: Symmetrizer', checkLogic: (d) => isHammer(d) && hasFVG(d, 'BULLISH') },
  // 133 🟢 CALL: Liquidity Sweep + Morning Star (Trap 12)
  { id: 133, name: 'SSL Sweep + Morning Star', direction: 'CALL', trapType: 'Trap 12: Stop Hunt', checkLogic: (d) => isMorningStar(d) && hasLiquiditySweep(d, 'SSL') },
  // 134 🟢 CALL: EMA20/50 Compression Break (Trap 21)
  { id: 134, name: 'EMA Squeeze Break Up', direction: 'CALL', trapType: 'Trap 21: Spring', checkLogic: (d) => isBullish(d) && d.trend.priceVsEMA20 === 'ABOVE' && d.trend.priceVsEMA50 === 'ABOVE' },
  // 135 🟢 CALL: StdDev Spike + Bullish (Trap 19)
  { id: 135, name: 'StdDev Spike at BB Lower', direction: 'CALL', trapType: 'Trap 19: Volatility Snap', checkLogic: (d) => isAtBBLower(d) && isNearRoundNumber(d.currentPrice) },
  // 136 🟢 CALL: OBV Break + Continuation (Trap 27)
  { id: 136, name: 'OBV Break Resistance', direction: 'CALL', trapType: 'Trap 27: Hollow Move', checkLogic: (d) => d.volume.obvTrend === 'BULLISH' && isBullish(d) },
  // 137 🟢 CALL: BB Mean Reversion Buy (Trap 11)
  { id: 137, name: 'BB 100% Outside Lower', direction: 'CALL', trapType: 'Trap 11: Bollinger Blast', checkLogic: (d) => isAtBBLower(d) },
  // 138 🟢 CALL: RSI Reset + Inside Bar (Trap 7)
  { id: 138, name: 'RSI 50 + Inside Bar Up', direction: 'CALL', trapType: 'Trap 7: Binary Reset', checkLogic: (d) => d.momentum.rsi14 >= 48 && d.momentum.rsi14 <= 52 && isBullish(d) },
  // 139 🟢 CALL: VWAP + EMA200 Golden Cross (Trap 5)
  { id: 139, name: 'VWAP + EMA200 Cross', direction: 'CALL', trapType: 'Trap 5: Institutional Reset', checkLogic: (d) => isAtVWAP(d) && isAtEMA(d, 200) },
  // 140 🟢 CALL: Demand OB + Strong Close (Trap 13)
  { id: 140, name: 'Demand OB Marubozu', direction: 'CALL', trapType: 'Trap 13: Invalidated Rejection', checkLogic: (d) => isAtDemand(d) && isBullishMarubozu(d) },
  // 141 🟢 CALL: HTF Pullback + Hammer (Trap 25)
  { id: 141, name: 'HTF Pullback + Hammer at :00', direction: 'CALL', trapType: 'Trap 25: Time Window', checkLogic: (d) => isAtDemand(d) && isHammer(d) },
  // 142 🟢 CALL: Range Low + Doji → Break (Trap 26)
  { id: 142, name: 'Range Low Doji Break', direction: 'CALL', trapType: 'Trap 26: Micro-Range', checkLogic: (d) => d.smc.premiumDiscount === 'DISCOUNT' && isDoji(d) },
  // 143 🟢 CALL: EMA50 Retest 2nd Touch (Trap 22)
  { id: 143, name: 'EMA50 2nd Touch', direction: 'CALL', trapType: 'Trap 22: Ribbon Kiss', checkLogic: (d) => isAtEMA(d, 50) && d.trend.emaAlignment === 'BULLISH' },
  // 144 🟢 CALL: FVG + Sweep Combo (Trap 2)
  { id: 144, name: 'FVG + SSL Sweep', direction: 'CALL', trapType: 'Trap 2: S/R Siphon', checkLogic: (d) => hasLiquiditySweep(d, 'SSL') && hasFVG(d, 'BULLISH') },
  // 145 🟢 CALL: VWAP Rising + Marubozu (Trap 14)
  { id: 145, name: 'VWAP Rising + Marubozu', direction: 'CALL', trapType: 'Trap 14: Vacuum Expansion', checkLogic: (d) => d.volume.priceVsVWAP === 'ABOVE' && isBullishMarubozu(d) && isVolumeSpike(d) },
  // 146 🟢 CALL: OBV Flat → Sudden Rise (Trap 9)
  { id: 146, name: 'OBV Doji Spike', direction: 'CALL', trapType: 'Trap 9: VWAP Deviation', checkLogic: (d) => isDoji(d) && d.volume.obvTrend === 'BULLISH' },
  // 147 🟢 CALL: ADX Stable Continue (Trap 4)
  { id: 147, name: 'ADX 30 Every 2nd Green', direction: 'CALL', trapType: 'Trap 4: Momentum Trap', checkLogic: (d) => d.trend.adx >= 28 && d.trend.adx <= 32 && isBullish(d) },
  // 148 🟢 CALL: BB Expansion + Demand (Trap 21)
  { id: 148, name: 'BB Expansion at Demand', direction: 'CALL', trapType: 'Trap 21: Expansion', checkLogic: (d) => d.volatility.bollinger.width > 3 && isAtDemand(d) },
  // 149 🟢 CALL: EMA200 + Morning Star Fib (Trap 8)
  { id: 149, name: 'EMA200 Morning Star 78.6', direction: 'CALL', trapType: 'Trap 8: Fib 78.6', checkLogic: (d) => isAtEMA(d, 200) && isMorningStar(d) },
  // 150 🟢 CALL: HTF Range + Vol Spike (Trap 16)
  { id: 150, name: 'Range Low Vol Spike', direction: 'CALL', trapType: 'Trap 16: Godzilla Candle', checkLogic: (d) => d.smc.premiumDiscount === 'DISCOUNT' && isVolumeSpike(d) },

  // ============= SETUPS 151-200 (ELITE PUTS) =============
  // 151 🔴 PUT: HTF Supply + Long Upper Wick (Trap 1)
  { id: 151, name: 'Supply + Long Upper Wick', direction: 'PUT', trapType: 'Trap 1: Wick-Fill', checkLogic: (d) => isAtSupply(d) && isBearishPinBar(d) && isBearish(d) },
  // 152 🔴 PUT: Supply OB + Doji → Engulfing (Trap 7)
  { id: 152, name: 'Supply OB Doji Engulfing', direction: 'PUT', trapType: 'Trap 7: Binary Reset', checkLogic: (d) => isAtSupply(d) && isDoji(d) && isBearishEngulfing(d) },
  // 153 🔴 PUT: FVG + Tweezer Top (Trap 6)
  { id: 153, name: 'FVG + Tweezer Top', direction: 'PUT', trapType: 'Trap 6: Symmetrizer', checkLogic: (d) => hasFVG(d, 'BEARISH') && isAtResistance(d) },
  // 154 🔴 PUT: EMA20 Trend + Inside Bar Down (Trap 21)
  { id: 154, name: 'EMA20 Trend + Inside Bar Down', direction: 'PUT', trapType: 'Trap 21: Compression', checkLogic: (d) => d.trend.priceVsEMA20 === 'BELOW' && isBearish(d) },
  // 155 🔴 PUT: VWAP Falling + Shooting Star (Trap 9)
  { id: 155, name: 'VWAP Falling + Star', direction: 'PUT', trapType: 'Trap 9: VWAP Deviation', checkLogic: (d) => d.volume.priceVsVWAP === 'BELOW' && isShootingStar(d) },
  // 156 🔴 PUT: EMA50 + Evening Star (Trap 22)
  { id: 156, name: 'EMA50 + Evening Star', direction: 'PUT', trapType: 'Trap 22: Ribbon Kiss', checkLogic: (d) => isEveningStar(d) && isAtEMA(d, 50) },
  // 157 🔴 PUT: EMA200 + Sweep + Star (Trap 23)
  { id: 157, name: 'EMA200 + Sweep + Star', direction: 'PUT', trapType: 'Trap 23: Round Flush', checkLogic: (d) => isAtEMA(d, 200) && isShootingStar(d) && isNearRoundNumber(d.currentPrice, '000') },
  // 158 🔴 PUT: BB Squeeze + Bearish Expansion (Trap 14)
  { id: 158, name: 'BB Squeeze + Bearish Expansion', direction: 'PUT', trapType: 'Trap 14: Vacuum Effect', checkLogic: (d) => isBBSqueeze(d) && isBearish(d) },
  // 159 🔴 PUT: RSI Mid-Zone Rejection Down (Trap 10)
  { id: 159, name: 'RSI Mid-Zone Hook Down', direction: 'PUT', trapType: 'Trap 10: Algo Trending', checkLogic: (d) => d.momentum.rsi14 >= 45 && d.momentum.rsi14 <= 55 && isBearish(d) },
  // 160 🔴 PUT: OBV Flat → Sudden Drop (Trap 27)
  { id: 160, name: 'OBV Flat to Drop', direction: 'PUT', trapType: 'Trap 27: Vol Divergence', checkLogic: (d) => d.volume.obvTrend === 'BEARISH' && isBearish(d) },
  // 161 🔴 PUT: MFI Reset + Star (Trap 16)
  { id: 161, name: 'MFI 80 + Star', direction: 'PUT', trapType: 'Trap 16: Escalator Exit', checkLogic: (d) => d.momentum.rsi14 >= 80 && isShootingStar(d) },
  // 162 🔴 PUT: ADX > 25 + 4th Red (Trap 4)
  { id: 162, name: 'ADX Strong + 4th Red', direction: 'PUT', trapType: 'Trap 4: Color Cycle', checkLogic: (d) => d.trend.adx > 25 && isBearish(d) && d.trend.emaAlignment === 'BEARISH' },
  // 163 🔴 PUT: VWAP + EMA50 + Supply Stack (Trap 5)
  { id: 163, name: 'Triple Stack Supply', direction: 'PUT', trapType: 'Trap 5: Heavy Gravity', checkLogic: (d) => isAtVWAP(d) && isAtEMA(d, 50) && isAtSupply(d) && isNearRoundNumber(d.currentPrice, '500') },
  // 164 🔴 PUT: FVG Edge Tap + Strong Close (Trap 13)
  { id: 164, name: 'Bearish FVG Edge Engulf', direction: 'PUT', trapType: 'Trap 13: Invalidated Rejection', checkLogic: (d) => hasFVG(d, 'BEARISH') && isBearishEngulfing(d) },
  // 165 🔴 PUT: Range High Fakeout + Marubozu (Trap 26)
  { id: 165, name: 'Range High Fakeout + Marubozu', direction: 'PUT', trapType: 'Trap 26: Micro-Range', checkLogic: (d) => d.smc.premiumDiscount === 'PREMIUM' && isBearishMarubozu(d) },
  // 166 🔴 PUT: Engulfing After 2 Small Greens (Trap 15)
  { id: 166, name: 'Engulfing After 2 Small Greens', direction: 'PUT', trapType: 'Trap 15: Switching Fatigue', checkLogic: (d) => isBearish(d) && isBearishEngulfing(d) },
  // 167 🔴 PUT: 3 Inside Bars + Break Down (Trap 21)
  { id: 167, name: '3 Inside Bars Break Down', direction: 'PUT', trapType: 'Trap 21: Spring Release', checkLogic: (d) => isBearish(d) && d.smc.structure === 'LH_LL' },
  // 168 🔴 PUT: Falling Wedge Fake Breakout (Trap 2)
  { id: 168, name: 'Wedge Fake Breakout', direction: 'PUT', trapType: 'Trap 2: S/R Siphon', checkLogic: (d) => isBearishEngulfing(d) && hasLiquiditySweep(d, 'BSL') },
  // 169 🔴 PUT: EMA20 Loss + Strong Close (Trap 17)
  { id: 169, name: 'EMA20 Loss + Gap Down', direction: 'PUT', trapType: 'Trap 17: Micro-Gap', checkLogic: (d) => d.trend.priceVsEMA20 === 'BELOW' && isBearish(d) },
  // 170 🔴 PUT: VWAP Loss + Doji Continuation (Trap 7)
  { id: 170, name: 'VWAP Loss + Doji', direction: 'PUT', trapType: 'Trap 7: Doji Reset', checkLogic: (d) => d.volume.priceVsVWAP === 'BELOW' && isDoji(d) },
  // 171 🔴 PUT: Prev Day High Sweep + Star (Trap 12)
  { id: 171, name: 'PDH Sweep + Star', direction: 'PUT', trapType: 'Trap 12: Stop Hunt', checkLogic: (d) => hasLiquiditySweep(d, 'BSL') && isShootingStar(d) },
  // 172 🔴 PUT: HTF Supply + Hammer Conf (Trap 6)
  { id: 172, name: 'Supply + Hammer Wick Fill', direction: 'PUT', trapType: 'Trap 6: Wick Magnet', checkLogic: (d) => isAtSupply(d) && isBearish(d) },
  // 173 🔴 PUT: BB Upper Walk → Mid (Trap 11)
  { id: 173, name: 'BB Upper Walk to Mid', direction: 'PUT', trapType: 'Trap 11: Mean Reversion', checkLogic: (d) => isAtBBUpper(d) && isVolumeSpike(d) },
  // 174 🔴 PUT: OBV Lower High + Bearish (Trap 9)
  { id: 174, name: 'OBV Double Top Divergence', direction: 'PUT', trapType: 'Trap 9: VWAP Deviation', checkLogic: (d) => d.volume.obvTrend === 'BEARISH' && isBearish(d) },
  // 175 🔴 PUT: EMA50 + FVG Overlap (Trap 8)
  { id: 175, name: 'EMA50 + Bearish FVG Align', direction: 'PUT', trapType: 'Trap 8: Inst. Reset', checkLogic: (d) => isAtEMA(d, 50) && hasFVG(d, 'BEARISH') },
  // 176 🔴 PUT: RSI Bearish Divergence (Trap 10)
  { id: 176, name: 'RSI Bearish Divergence', direction: 'PUT', trapType: 'Trap 10: Exhaustion', checkLogic: (d) => d.momentum.rsi14 > 80 && isBearish(d) },
  // 177 🔴 PUT: ADX Rising + Marubozu (Trap 14)
  { id: 177, name: 'ADX Rising + Bear Marubozu', direction: 'PUT', trapType: 'Trap 14: Vacuum Effect', checkLogic: (d) => d.trend.adx > 25 && isBearishMarubozu(d) },
  // 178 🔴 PUT: PSAR Resistance + Bearish (Trap 4)
  { id: 178, name: 'PSAR Resistance 3rd Candle', direction: 'PUT', trapType: 'Trap 4: Odd Cycle', checkLogic: (d) => d.parabolicSAR.trend === 'BEARISH' && isBearish(d) },
  // 179 🔴 PUT: Supply OB + Inside 3 Down (Trap 18)
  { id: 179, name: 'Supply OB + Inside 3 Down', direction: 'PUT', trapType: 'Trap 18: Symmetry Break', checkLogic: (d) => isAtSupply(d) && d.smc.structure === 'LH_LL' },
  // 180 🔴 PUT: VWAP Pullback + Engulfing (Trap 20)
  { id: 180, name: 'VWAP Near-Miss + Bear Engulf', direction: 'PUT', trapType: 'Trap 20: Near-Miss', checkLogic: (d) => isAtVWAP(d) && isBearishEngulfing(d) },
  // 181 🔴 PUT: EMA200 + Range High (Trap 23)
  { id: 181, name: 'EMA200 + Range High', direction: 'PUT', trapType: 'Trap 23: Round Flush', checkLogic: (d) => isAtEMA(d, 200) && d.smc.premiumDiscount === 'PREMIUM' && isNearRoundNumber(d.currentPrice, '000') },
  // 182 🔴 PUT: FVG Partial Fill + Star (Trap 6)
  { id: 182, name: 'FVG 50% Fill + Star', direction: 'PUT', trapType: 'Trap 6: Symmetrizer', checkLogic: (d) => isShootingStar(d) && hasFVG(d, 'BEARISH') },
  // 183 🔴 PUT: Liquidity Sweep + Evening Star (Trap 12)
  { id: 183, name: 'BSL Sweep + Evening Star', direction: 'PUT', trapType: 'Trap 12: Stop Hunt', checkLogic: (d) => isEveningStar(d) && hasLiquiditySweep(d, 'BSL') },
  // 184 🔴 PUT: EMA20/50 Compression Break (Trap 21)
  { id: 184, name: 'EMA Squeeze Break Down', direction: 'PUT', trapType: 'Trap 21: Spring', checkLogic: (d) => isBearish(d) && d.trend.priceVsEMA20 === 'BELOW' && d.trend.priceVsEMA50 === 'BELOW' },
  // 185 🔴 PUT: StdDev Spike + Bearish (Trap 19)
  { id: 185, name: 'StdDev Spike at BB Upper', direction: 'PUT', trapType: 'Trap 19: Volatility Snap', checkLogic: (d) => isAtBBUpper(d) && isNearRoundNumber(d.currentPrice) },
  // 186 🔴 PUT: OBV Break + Continuation (Trap 27)
  { id: 186, name: 'OBV Break Support', direction: 'PUT', trapType: 'Trap 27: Hollow Move', checkLogic: (d) => d.volume.obvTrend === 'BEARISH' && isBearish(d) },
  // 187 🔴 PUT: BB Mean Reversion Sell (Trap 11)
  { id: 187, name: 'BB 100% Outside Upper', direction: 'PUT', trapType: 'Trap 11: Bollinger Blast', checkLogic: (d) => isAtBBUpper(d) },
  // 188 🔴 PUT: RSI Reset + Inside Bar Down (Trap 7)
  { id: 188, name: 'RSI 50 + Inside Bar Down', direction: 'PUT', trapType: 'Trap 7: Binary Reset', checkLogic: (d) => d.momentum.rsi14 >= 48 && d.momentum.rsi14 <= 52 && isBearish(d) },
  // 189 🔴 PUT: VWAP + EMA200 Death Cross (Trap 5)
  { id: 189, name: 'VWAP + EMA200 Death Cross', direction: 'PUT', trapType: 'Trap 5: Inst. Reset', checkLogic: (d) => isAtVWAP(d) && isAtEMA(d, 200) && isBearish(d) },
  // 190 🔴 PUT: Supply OB + Strong Close (Trap 13)
  { id: 190, name: 'Supply OB Marubozu', direction: 'PUT', trapType: 'Trap 13: Inv. Rejection', checkLogic: (d) => isAtSupply(d) && isBearishMarubozu(d) },
  // 191 🔴 PUT: HTF Pullback + Star (Trap 25)
  { id: 191, name: 'HTF Pullback + Star at :00', direction: 'PUT', trapType: 'Trap 25: Time Window', checkLogic: (d) => isAtSupply(d) && isShootingStar(d) },
  // 192 🔴 PUT: Range High + Doji → Break (Trap 26)
  { id: 192, name: 'Range High Doji Break', direction: 'PUT', trapType: 'Trap 26: Micro-Range', checkLogic: (d) => d.smc.premiumDiscount === 'PREMIUM' && isDoji(d) },
  // 193 🔴 PUT: EMA50 Retest 2nd Touch (Trap 22)
  { id: 193, name: 'EMA50 2nd Touch Reject', direction: 'PUT', trapType: 'Trap 22: Ribbon Kiss', checkLogic: (d) => isAtEMA(d, 50) && d.trend.emaAlignment === 'BEARISH' },
  // 194 🔴 PUT: FVG + Sweep Combo (Trap 2)
  { id: 194, name: 'FVG + BSL Sweep', direction: 'PUT', trapType: 'Trap 2: S/R Siphon', checkLogic: (d) => hasLiquiditySweep(d, 'BSL') && hasFVG(d, 'BEARISH') },
  // 195 🔴 PUT: VWAP Falling + Marubozu (Trap 14)
  { id: 195, name: 'VWAP Falling + Marubozu', direction: 'PUT', trapType: 'Trap 14: Vacuum Expansion', checkLogic: (d) => d.volume.priceVsVWAP === 'BELOW' && isBearishMarubozu(d) && isVolumeSpike(d) },
  // 196 🔴 PUT: OBV Flat → Sudden Drop (Trap 9)
  { id: 196, name: 'OBV Doji Drop', direction: 'PUT', trapType: 'Trap 9: VWAP Deviation', checkLogic: (d) => isDoji(d) && d.volume.obvTrend === 'BEARISH' },
  // 197 🔴 PUT: ADX Stable Continue (Trap 4)
  { id: 197, name: 'ADX 30 Every 2nd Red', direction: 'PUT', trapType: 'Trap 4: Momentum Trap', checkLogic: (d) => d.trend.adx >= 28 && d.trend.adx <= 32 && isBearish(d) },
  // 198 🔴 PUT: BB Expansion + Supply (Trap 21)
  { id: 198, name: 'BB Expansion at Supply', direction: 'PUT', trapType: 'Trap 21: Expansion', checkLogic: (d) => d.volatility.bollinger.width > 3 && isAtSupply(d) },
  // 199 🔴 PUT: EMA200 + Evening Star Fib (Trap 8)
  { id: 199, name: 'EMA200 Evening Star 78.6', direction: 'PUT', trapType: 'Trap 8: Fib 78.6', checkLogic: (d) => isAtEMA(d, 200) && isEveningStar(d) },
  // 200 🔴 PUT: HTF Range + Vol Spike (Trap 16)
  { id: 200, name: 'Range High Vol Spike', direction: 'PUT', trapType: 'Trap 16: Godzilla Candle', checkLogic: (d) => d.smc.premiumDiscount === 'PREMIUM' && isVolumeSpike(d) },

  // ============= SETUPS 201-235 (MASTER TIER) =============
  // 201 🟢 CALL: Liquidity Sweep + HTF Demand + Hammer (Trap 12)
  { id: 201, name: 'Session Low Sweep + Demand + Hammer', direction: 'CALL', trapType: 'Trap 12: Master Hunt', checkLogic: (d) => isAtDemand(d) && isHammer(d) && hasLiquiditySweep(d, 'SSL') },
  // 202 🔴 PUT: Liquidity Sweep + HTF Supply + Shooting Star (Trap 12)
  { id: 202, name: 'Session High Sweep + Supply + Star', direction: 'PUT', trapType: 'Trap 12: Master Hunt', checkLogic: (d) => isAtSupply(d) && isShootingStar(d) && hasLiquiditySweep(d, 'BSL') },
  // 203 🟢 CALL: EMA200 Rejection + Hammer (Trap 1)
  { id: 203, name: 'EMA200 Rejection + Hammer', direction: 'CALL', trapType: 'Trap 1: Wick Paint', checkLogic: (d) => isAtEMA(d, 200) && isHammer(d) },
  // 204 🔴 PUT: EMA200 Rejection + Shooting Star (Trap 1)
  { id: 204, name: 'EMA200 Rejection + Star', direction: 'PUT', trapType: 'Trap 1: Wick Fill', checkLogic: (d) => isAtEMA(d, 200) && isShootingStar(d) },
  // 205 🟢 CALL: FVG Tap + Strong Bullish Close (Trap 6)
  { id: 205, name: 'FVG 50% Mitigation + Bullish', direction: 'CALL', trapType: 'Trap 6: Mitigation', checkLogic: (d) => hasFVG(d, 'BULLISH') && isBullish(d) },
  // 206 🔴 PUT: FVG Tap + Strong Bearish Close (Trap 6)
  { id: 206, name: 'FVG 50% Mitigation + Bearish', direction: 'PUT', trapType: 'Trap 6: Mitigation', checkLogic: (d) => hasFVG(d, 'BEARISH') && isBearish(d) },
  // 207 🟢 CALL: HTF Order Block + Engulfing (Trap 2)
  { id: 207, name: 'Demand OB Fake Breakdown + Engulf', direction: 'CALL', trapType: 'Trap 2: OB Siphon', checkLogic: (d) => isAtDemand(d) && isBullishEngulfing(d) && hasLiquiditySweep(d, 'SSL') },
  // 208 🔴 PUT: HTF Order Block + Engulfing (Trap 2)
  { id: 208, name: 'Supply OB Fake Breakout + Engulf', direction: 'PUT', trapType: 'Trap 2: OB Siphon', checkLogic: (d) => isAtSupply(d) && isBearishEngulfing(d) && hasLiquiditySweep(d, 'BSL') },
  // 209 🟢 CALL: Range Low Fakeout + Marubozu (Trap 26)
  { id: 209, name: 'Range Low 2-Pip Fakeout + Marubozu', direction: 'CALL', trapType: 'Trap 26: Precision Range', checkLogic: (d) => d.smc.premiumDiscount === 'DISCOUNT' && isBullishMarubozu(d) },
  // 210 🔴 PUT: Range High Fakeout + Marubozu (Trap 26)
  { id: 210, name: 'Range High 2-Pip Fakeout + Marubozu', direction: 'PUT', trapType: 'Trap 26: Precision Range', checkLogic: (d) => d.smc.premiumDiscount === 'PREMIUM' && isBearishMarubozu(d) },
  // 211 🟢 CALL: Doji at Support + Green Conf. (Trap 7)
  { id: 211, name: 'Support Doji + Green Break', direction: 'CALL', trapType: 'Trap 7: Balance Break', checkLogic: (d) => isAtSupport(d) && isDoji(d) && isBullish(d) },
  // 212 🔴 PUT: Doji at Resistance + Red Conf. (Trap 7)
  { id: 212, name: 'Resistance Doji + Red Break', direction: 'PUT', trapType: 'Trap 7: Balance Break', checkLogic: (d) => isAtResistance(d) && isDoji(d) && isBearish(d) },
  // 213 🟢 CALL: Hammer at Support Wick Fill (Trap 6)
  { id: 213, name: 'Support Hammer Wick Fill', direction: 'CALL', trapType: 'Trap 6: Wick Fill', checkLogic: (d) => isAtSupport(d) && isHammer(d) },
  // 214 🔴 PUT: Hanging Man at Resistance (Trap 12)
  { id: 214, name: 'Resistance Hanging Man Trap', direction: 'PUT', trapType: 'Trap 12: Trap Confirm', checkLogic: (d) => isAtResistance(d) && isHammer(d) && isBearish(d) },
  // 215 🟢 CALL: Inverted Hammer at Support (Trap 6)
  { id: 215, name: 'Support Inv Hammer Wick Fill', direction: 'CALL', trapType: 'Trap 6: Wick Fill', checkLogic: (d) => isAtSupport(d) && d.priceAction.patterns.includes('DRAGONFLY_DOJI') },
  // 216 🔴 PUT: Shooting Star at Resistance (Trap 1)
  { id: 216, name: 'Resistance Star 60% Wick', direction: 'PUT', trapType: 'Trap 1: High Accuracy', checkLogic: (d) => isAtResistance(d) && isShootingStar(d) },
  // 217 CONFIRM: Spinning Top (Trap 15)
  { id: 217, name: 'Spinning Top Break', direction: 'CALL', trapType: 'Trap 15: Wait Confirm', checkLogic: (d) => isBullish(d) && d.priceAction.patterns.length > 0 },
  // 218 🟢 CALL: Green Marubozu Trend (Trap 14)
  { id: 218, name: 'Green Marubozu No Wicks', direction: 'CALL', trapType: 'Trap 14: Pure Momentum', checkLogic: (d) => isBullishMarubozu(d) },
  // 219 🔴 PUT: Red Marubozu Trend (Trap 14)
  { id: 219, name: 'Red Marubozu No Wicks', direction: 'PUT', trapType: 'Trap 14: Pure Momentum', checkLogic: (d) => isBearishMarubozu(d) },
  // 220 🟢 CALL: Bullish Engulfing + Support (Trap 2)
  { id: 220, name: 'Engulfing Reclaim Support', direction: 'CALL', trapType: 'Trap 2: Level Reclaim', checkLogic: (d) => isBullishEngulfing(d) && isAtSupport(d) },
  // 221 🔴 PUT: Bearish Engulfing + Resistance (Trap 2)
  { id: 221, name: 'Engulfing Reject Resistance', direction: 'PUT', trapType: 'Trap 2: Level Reject', checkLogic: (d) => isBearishEngulfing(d) && isAtResistance(d) },
  // 222 🟢 CALL: Tweezer Bottom Round Number (Trap 24)
  { id: 222, name: 'Tweezer Bottom .000/.500', direction: 'CALL', trapType: 'Trap 24: Round Magnet', checkLogic: (d) => isAtSupport(d) && isNearRoundNumber(d.currentPrice) },
  // 223 🔴 PUT: Tweezer Top Round Number (Trap 24)
  { id: 223, name: 'Tweezer Top .000/.500', direction: 'PUT', trapType: 'Trap 24: Round Magnet', checkLogic: (d) => isAtResistance(d) && isNearRoundNumber(d.currentPrice) },
  // 224 CONFIRM: Harami Micro Gap (Trap 17)
  { id: 224, name: 'Harami Micro Gap Trade', direction: 'CALL', trapType: 'Trap 17: Gap Trade', checkLogic: (d) => isBullish(d) },
  // 225 CONFIRM: Harami Cross Expansion (Trap 21)
  { id: 225, name: 'Harami Cross Expansion', direction: 'CALL', trapType: 'Trap 21: Doji Expand', checkLogic: (d) => isDoji(d) },
  // 226 🟢 CALL: Piercing Line (Trap 13)
  { id: 226, name: 'Piercing Line 50% Close', direction: 'CALL', trapType: 'Trap 13: Midline Pierce', checkLogic: (d) => isBullish(d) && d.priceAction.patterns.length > 0 },
  // 227 🔴 PUT: Dark Cloud Cover (Trap 13)
  { id: 227, name: 'Dark Cloud 50% Close', direction: 'PUT', trapType: 'Trap 13: Midline Pierce', checkLogic: (d) => isBearish(d) && d.priceAction.patterns.length > 0 },
  // 228 🟢 CALL: Morning Star + BB Pierce (Trap 19)
  { id: 228, name: 'Morning Star BB Pierce', direction: 'CALL', trapType: 'Trap 19: BB Snap', checkLogic: (d) => isMorningStar(d) && isAtBBLower(d) },
  // 229 🔴 PUT: Evening Star + BB Pierce (Trap 19)
  { id: 229, name: 'Evening Star BB Pierce', direction: 'PUT', trapType: 'Trap 19: BB Snap', checkLogic: (d) => isEveningStar(d) && isAtBBUpper(d) },
  // 230 🟢 CALL: Three White Soldiers 4th Candle (Trap 4)
  { id: 230, name: '3 Soldiers + 4th Continue', direction: 'CALL', trapType: 'Trap 4: Color Continue', checkLogic: (d) => isThreeWhiteSoldiers(d) && d.momentum.rsi14 <= 90 },
  // 231 🔴 PUT: Three Black Crows 4th Candle (Trap 4)
  { id: 231, name: '3 Crows + 4th Continue', direction: 'PUT', trapType: 'Trap 4: Color Continue', checkLogic: (d) => isThreeBlackCrows(d) && d.momentum.rsi14 >= 10 },
  // 232 🟢 CALL: Inside Three Up (Trap 18)
  { id: 232, name: 'Inside Three Up Sequence Break', direction: 'CALL', trapType: 'Trap 18: Sequence Break', checkLogic: (d) => d.smc.structure === 'HH_HL' && isBullish(d) },
  // 233 🔴 PUT: Inside Three Down (Trap 18)
  { id: 233, name: 'Inside Three Down Sequence Break', direction: 'PUT', trapType: 'Trap 18: Sequence Break', checkLogic: (d) => d.smc.structure === 'LH_LL' && isBearish(d) },
  // 234 🟢 CALL: Rising Three Methods (Trap 21)
  { id: 234, name: 'Rising 3 Methods Doji Mid', direction: 'CALL', trapType: 'Trap 21: Doji Continue', checkLogic: (d) => d.trend.emaAlignment === 'BULLISH' && isDoji(d) },
  // 235 🔴 PUT: Falling Three Methods (Trap 21)
  { id: 235, name: 'Falling 3 Methods Doji Mid', direction: 'PUT', trapType: 'Trap 21: Doji Continue', checkLogic: (d) => d.trend.emaAlignment === 'BEARISH' && isDoji(d) },
];

// ============= NEW 7-CATEGORY SCORING SYSTEM =============
// MINIMUM REQUIREMENTS DISABLED - Bot now generates signals freely
// All category minimums set to 0 for unrestricted signal generation

const CATEGORY_MIN_REQUIREMENTS = {
  SMC: 0,
  LIQUIDITY: 0,
  INDICATORS: 0,
  SETUPS_235: 0,
  HTF: 0,
};

// Pip sizing must adapt across markets (OTC/forex/indices-like price scales).
// This is intentionally simple and deterministic.
function getDynamicPipSize(currentPrice: number): number {
  const abs = Math.abs(currentPrice);
  if (abs >= 100) return 0.01;
  if (abs >= 10) return 0.001;
  if (abs >= 1) return 0.0001;
  if (abs >= 0.1) return 0.00001;
  return 0.000001;
}

interface CategoryScore {
  name: string;
  score: number;
  factors: string[];
  minRequired?: number;
  fallbackUsed?: boolean;
}

function calculateNew7CategoryScore(
  marketData: ReturnType<typeof buildMarketDataForAI>,
  marketDataH1: ReturnType<typeof buildMarketDataForAI> | null,
  marketDataM15: ReturnType<typeof buildMarketDataForAI> | null,
  marketDataM5: ReturnType<typeof buildMarketDataForAI> | null,
  direction: 'CALL' | 'PUT',
  marketConditions?: MarketConditions,
  pillarGate?: PillarAllowedIds
): { totalScore: number; categories: CategoryScore[]; matchedSetups: TrapSetup[]; allCategoriesMet: boolean; failedCategories: string[] } {
  
  const categories: CategoryScore[] = [];
  
  // ============= AVOID RULES VALIDATION TRACKING =============
  let totalBlockedStrategies = 0;
  let totalValidStrategies = 0;
  
  // ============= PILLAR CROSS-REFERENCE GATE TRACKING =============
  let pillarGatedSmc = 0;
  let pillarGatedLiq = 0;
  let pillarGatedInd = 0;
  let pillarGatedHtf = 0;
  // PILLAR-FIRST: Track strategies whose detection logic was completely skipped
  let pillarSkippedLiq = 0;
  let pillarSkippedInd = 0;
  let pillarSkippedHtf = 0;
  
  // ============= 1. SMC (NEW 18 SETUP DATABASE) =============
  // MINIMUM REQUIREMENT: 4 POINTS
  // Uses the new 18 SMC setups with 3-pillar fallback
  // First setup match = 1 point, each extra = 0.5 point
  // IMPORTANT: If score < 4, activate 3 Core Pillars Fallback to complete remaining points
  const smcFactors: string[] = [];
  let smcScore = 0;
  let smcFallbackUsed = false;

  const raw = (marketData as any).raw as
    | { opens: number[]; highs: number[]; lows: number[]; closes: number[]; volumes: number[] }
    | undefined;

  if (raw && raw.closes.length >= 30) {
    // Use last 200 candles for analysis as per requirement
    const window = Math.min(200, raw.closes.length);
    const start = raw.closes.length - window;
    const smcOpens = raw.opens.slice(start);
    const smcHighs = raw.highs.slice(start);
    const smcLows = raw.lows.slice(start);
    const smcCloses = raw.closes.slice(start);
    const smcVolumes = raw.volumes.slice(start);

    // Run the new 18 SMC setup analysis (includes internal 3-pillar fallback when no match)
    const smcResult = runAdvancedSMCAnalysis(smcOpens, smcHighs, smcLows, smcCloses, smcVolumes, undefined, undefined, undefined, undefined, pillarGate);

    // ============= VALIDATE SMC TRIGGERS AGAINST AVOID RULES + PILLAR GATE =============
    // Only count triggers that PASS both avoid rules AND pillar cross-reference gate
    let validSmcTriggers: string[] = [];
    let blockedSmcTriggers: string[] = [];
    
    // SMC Setup Name → ID mapping for pillar cross-reference
    const SMC_NAME_TO_ID: Record<string, number> = {
      'Standard FVG': 1, 'FVG': 1, 'Inverted FVG': 2, 'iFVG': 2, 'Balanced Price Range': 3, 'BPR': 3,
      'Volume Imbalance': 4, 'Turtle Soup': 5, 'EQH/EQL': 6, 'EQH_EQL': 6,
      'IDM': 7, 'Unicorn': 8, 'Fresh Order Block': 9, 'FreshOB': 9,
      'Breaker Block': 10, 'BreakerBlock': 10, 'Mitigation Block': 11, 'MitigationBlock': 11,
      'Propulsion Block': 12, 'PropulsionBlock': 12, 'Rejection Block': 13, 'RejectionBlock': 13,
      'SMT CHoCH': 14, 'SMT_CHoCH': 14, 'HTF Propulsion': 15, 'HTF_Propulsion': 15,
      'Wick Sniper': 16, 'WickSniper': 16, 'Unicorn Combo': 17, 'UnicornCombo': 17,
      'Mitigation Combo': 18, 'MitigationCombo': 18,
    };
    
    if (smcResult.direction === direction && smcResult.triggers.length > 0) {
      for (const trigger of smcResult.triggers) {
        // Extract setup name from trigger (format: "[SetupName] Logic...")
        const setupNameMatch = trigger.match(/\[(.*?)\]/);
        const setupName = setupNameMatch ? setupNameMatch[1] : trigger;
        
        // PILLAR CROSS-REFERENCE GATE: Check if this SMC strategy ID is allowed by the active pillar
        if (pillarGate) {
          const smcId = SMC_NAME_TO_ID[setupName] || 0;
          if (smcId > 0 && !pillarGate.smcIds.has(smcId)) {
            pillarGatedSmc++;
            addBlockedStrategy(setupName, 'SMC', `Pillar gate: SMC #${smcId} not in ${pillarGate.pillarName}`, direction);
            console.log(`[PILLAR GATE] SMC "${setupName}" (ID ${smcId}) BLOCKED: Not in pillar allowed set`);
            continue; // Skip this trigger entirely
          }
        }
        
        // Validate against SMC avoid rules
        if (marketConditions) {
          const avoidResult = validateStrategyAgainstAvoidRules('smc', setupName, direction, marketConditions);
          if (avoidResult.isValid) {
            validSmcTriggers.push(trigger);
            totalValidStrategies++;
          } else {
            blockedSmcTriggers.push(`[BLOCKED] ${trigger} - ${avoidResult.blockedReason}`);
            totalBlockedStrategies++;
            addBlockedStrategy(setupName, 'SMC', avoidResult.blockedReason || 'Avoid rule failed', direction);
            console.log(`[AVOID RULE] SMC "${setupName}" BLOCKED: ${avoidResult.blockedReason}`);
          }
        } else {
          // No market conditions - pass all
          validSmcTriggers.push(trigger);
          totalValidStrategies++;
        }
      }
    }
    
    // Only award points for VALID triggers
    if (smcResult.direction === direction) {
      smcScore = validSmcTriggers.length > 0 ? 1 + (validSmcTriggers.length - 1) * 0.5 : 0;
      smcFactors.push(...validSmcTriggers.slice(0, 5));
      if (blockedSmcTriggers.length > 0) {
        console.log(`[SMC] ${validSmcTriggers.length} valid, ${blockedSmcTriggers.length} blocked by avoid rules`);
      }
    } else if (smcResult.direction === null) {
      smcFactors.push('SMC: No pattern detected');
    }
    
    // ============= SMC 12-PILLAR ULTRA CORE FALLBACK =============
    // ACTIVATE if smcScore < 4 (minimum requirement)
    // Scans last 30 candles from 200-bar window for advanced SMC Core signals
    // UPGRADED: 12 pillars with institutional depth, volume-validated structure, multi-swing analysis
    if (smcScore < CATEGORY_MIN_REQUIREMENTS.SMC) {
      smcFallbackUsed = true;
      console.log(`[SMC FALLBACK] Primary score ${smcScore.toFixed(2)} < ${CATEGORY_MIN_REQUIREMENTS.SMC}. Activating 12-Pillar Ultra Fallback...`);
      
      const fb20Start = Math.max(0, smcCloses.length - 30);
      const fb20Closes = smcCloses.slice(fb20Start);
      const fb20Highs = smcHighs.slice(fb20Start);
      const fb20Lows = smcLows.slice(fb20Start);
      const fb20Opens = smcOpens.slice(fb20Start);
      const fb20Volumes = smcVolumes.slice(fb20Start);
      const fbLen = fb20Closes.length;
      
      const currentClose = fb20Closes[fbLen - 1];
      const prevClose = fbLen > 1 ? fb20Closes[fbLen - 2] : currentClose;
      const currentOpen = fb20Opens[fbLen - 1];
      const currentHigh = fb20Highs[fbLen - 1];
      const currentLow = fb20Lows[fbLen - 1];
      const prevHigh = fbLen > 1 ? fb20Highs[fbLen - 2] : currentHigh;
      const prevLow = fbLen > 1 ? fb20Lows[fbLen - 2] : currentLow;
      const prevOpen = fbLen > 1 ? fb20Opens[fbLen - 2] : currentOpen;
      
      const fbRecentHigh = Math.max(...fb20Highs);
      const fbRecentLow = Math.min(...fb20Lows);
      const fbATR = fb20Highs.reduce((sum, h, i) => sum + (h - fb20Lows[i]), 0) / fbLen;
      const fbAvgBody = fb20Closes.reduce((sum, c, i) => sum + Math.abs(c - fb20Opens[i]), 0) / fbLen;
      const fbPip = getDynamicPipSize(currentClose);
      const fbAvgVol = fb20Volumes.reduce((a, b) => a + b, 0) / fbLen;
      
      // PILLAR 1: LIQUIDITY SWEEP DETECTION (Enhanced Multi-Level)
      const sweepedHigh = currentHigh > fbRecentHigh && currentClose < fbRecentHigh;
      const sweepedLow = currentLow < fbRecentLow && currentClose > fbRecentLow;
      
      if (sweepedHigh && direction === 'PUT') {
        smcScore += 1.8;
        smcFactors.push('SMC-FB P1: Liquidity Sweep High → PUT');
      }
      if (sweepedLow && direction === 'CALL') {
        smcScore += 1.8;
        smcFactors.push('SMC-FB P1: Liquidity Sweep Low → CALL');
      }
      // Delayed sweep reaction
      if (!sweepedHigh && !sweepedLow && fbLen > 2) {
        const swingHigh10 = Math.max(...fb20Highs.slice(0, fbLen - 2));
        if (prevHigh > swingHigh10 && prevClose < swingHigh10 && currentClose < prevClose && direction === 'PUT') {
          smcScore += 1.4;
          smcFactors.push('SMC-FB P1: Delayed Sweep Reaction PUT');
        }
        const swingLow10 = Math.min(...fb20Lows.slice(0, fbLen - 2));
        if (prevLow < swingLow10 && prevClose > swingLow10 && currentClose > prevClose && direction === 'CALL') {
          smcScore += 1.4;
          smcFactors.push('SMC-FB P1: Delayed Sweep Reaction CALL');
        }
      }
      
      // PILLAR 2: FAIR VALUE GAP DETECTION (Enhanced with mitigation tracking)
      for (let i = 2; i < fbLen; i++) {
        const c1High = fb20Highs[i - 2];
        const c3Low = fb20Lows[i];
        const c1Low = fb20Lows[i - 2];
        const c3High = fb20Highs[i];
        const gapBody = Math.abs(fb20Closes[i - 1] - fb20Opens[i - 1]);
        
        if (c1High < c3Low && gapBody > fbAvgBody * 1.2 && direction === 'CALL') {
          const priceInFVG = currentClose >= c1High && currentClose <= c3Low;
          smcScore += priceInFVG ? 1.6 : 1.2;
          smcFactors.push(priceInFVG ? 'SMC-FB P2: Price Mitigating Bullish FVG' : 'SMC-FB P2: Bullish FVG Detected');
          break;
        }
        if (c1Low > c3High && gapBody > fbAvgBody * 1.2 && direction === 'PUT') {
          const priceInFVG = currentClose <= c1Low && currentClose >= c3High;
          smcScore += priceInFVG ? 1.6 : 1.2;
          smcFactors.push(priceInFVG ? 'SMC-FB P2: Price Mitigating Bearish FVG' : 'SMC-FB P2: Bearish FVG Detected');
          break;
        }
      }
      
      // PILLAR 3: CHANGE OF CHARACTER (CHoCH with BOS)
      let lastSwingHigh = -Infinity, lastSwingLow = Infinity;
      let prevSwingHigh = -Infinity, prevSwingLow = Infinity;
      for (let i = 2; i < fbLen - 2; i++) {
        if (fb20Highs[i] > fb20Highs[i - 1] && fb20Highs[i] > fb20Highs[i - 2] &&
            fb20Highs[i] > fb20Highs[i + 1] && fb20Highs[i] > fb20Highs[i + 2]) {
          prevSwingHigh = lastSwingHigh;
          lastSwingHigh = fb20Highs[i];
        }
        if (fb20Lows[i] < fb20Lows[i - 1] && fb20Lows[i] < fb20Lows[i - 2] &&
            fb20Lows[i] < fb20Lows[i + 1] && fb20Lows[i] < fb20Lows[i + 2]) {
          prevSwingLow = lastSwingLow;
          lastSwingLow = fb20Lows[i];
        }
      }
      if (prevSwingHigh > -Infinity && lastSwingHigh < prevSwingHigh && direction === 'PUT') {
        smcScore += 1.5;
        smcFactors.push('SMC-FB P3: Bearish CHoCH (LH after HH)');
      }
      if (prevSwingLow < Infinity && lastSwingLow > prevSwingLow && direction === 'CALL') {
        smcScore += 1.5;
        smcFactors.push('SMC-FB P3: Bullish CHoCH (HL after LL)');
      }
      
      // PILLAR 4: ORDER BLOCK DETECTION (Fresh Institutional OB)
      for (let i = fbLen - 5; i >= 0; i--) {
        const isBeforeMove = fb20Closes[i] < fb20Opens[i];
        const moveAfter = fb20Closes[Math.min(i + 2, fbLen - 1)] - fb20Closes[i];
        if (isBeforeMove && moveAfter > fbATR * 1.5) {
          const obHigh = fb20Highs[i];
          const obLow = fb20Lows[i];
          if (currentClose >= obLow && currentClose <= obHigh + fbATR * 0.3 && direction === 'CALL') {
            smcScore += 1.3;
            smcFactors.push('SMC-FB P4: Price at Fresh Bullish OB');
            break;
          }
        }
        const isBullishBeforeDown = fb20Closes[i] > fb20Opens[i];
        const dropAfter = fb20Closes[i] - fb20Closes[Math.min(i + 2, fbLen - 1)];
        if (isBullishBeforeDown && dropAfter > fbATR * 1.5) {
          const obHigh = fb20Highs[i];
          const obLow = fb20Lows[i];
          if (currentClose <= obHigh && currentClose >= obLow - fbATR * 0.3 && direction === 'PUT') {
            smcScore += 1.3;
            smcFactors.push('SMC-FB P4: Price at Fresh Bearish OB');
            break;
          }
        }
      }
      
      // PILLAR 5: DISPLACEMENT DETECTION (Strong institutional candle)
      const currentBody = Math.abs(currentClose - currentOpen);
      const currentRange = currentHigh - currentLow;
      const bodyRatio = currentRange > 0 ? currentBody / currentRange : 0;
      if (currentBody > fbAvgBody * 2.0 && bodyRatio > 0.7) {
        if (currentClose > currentOpen && direction === 'CALL') {
          smcScore += 1.2;
          smcFactors.push('SMC-FB P5: Bullish Displacement (Strong Body)');
        }
        if (currentClose < currentOpen && direction === 'PUT') {
          smcScore += 1.2;
          smcFactors.push('SMC-FB P5: Bearish Displacement (Strong Body)');
        }
      }
      
      // PILLAR 6: PREMIUM/DISCOUNT ZONE
      const range20 = fbRecentHigh - fbRecentLow;
      const equilibrium = fbRecentLow + range20 * 0.5;
      const isDiscount = currentClose < equilibrium;
      const isPremium = currentClose > equilibrium;
      if (isDiscount && direction === 'CALL') {
        smcScore += 0.8;
        smcFactors.push('SMC-FB P6: Price in Discount Zone (CALL bias)');
      }
      if (isPremium && direction === 'PUT') {
        smcScore += 0.8;
        smcFactors.push('SMC-FB P6: Price in Premium Zone (PUT bias)');
      }
      
      // PILLAR 7: VOLUME-CONFIRMED STRUCTURE
      if (fb20Volumes && fb20Volumes.length >= 5) {
        const lastVol = fb20Volumes[fbLen - 1];
        const avgVol = fb20Volumes.slice(Math.max(0, fbLen - 10)).reduce((a, b) => a + b, 0) / Math.min(10, fbLen);
        const volSpike = avgVol > 0 ? lastVol / avgVol : 0;
        
        if (volSpike > 1.8 && currentBody > fbAvgBody) {
          if (currentClose > currentOpen && direction === 'CALL') {
            smcScore += 1.0;
            smcFactors.push(`SMC-FB P7: Vol Spike ${volSpike.toFixed(1)}x + Bull Body`);
          }
          if (currentClose < currentOpen && direction === 'PUT') {
            smcScore += 1.0;
            smcFactors.push(`SMC-FB P7: Vol Spike ${volSpike.toFixed(1)}x + Bear Body`);
          }
        }
        if (volSpike < 0.4 && currentBody < fbAvgBody * 0.5) {
          const exhaustDir = currentClose > currentOpen ? 'PUT' : 'CALL';
          if (exhaustDir === direction) {
            smcScore += 0.7;
            smcFactors.push('SMC-FB P7: Volume Dry-Up Exhaustion');
          }
        }
      }
      
      // PILLAR 8: INVERTED FVG (iFVG) DETECTION - Price returns to complete FVG from opposite side
      for (let i = 3; i < fbLen - 1; i++) {
        const bullFVG = fb20Highs[i - 2] < fb20Lows[i]; // Original bullish FVG
        if (bullFVG && currentClose > fb20Highs[i - 2] && currentClose < fb20Lows[i]) {
          // Price is inside the FVG zone - institutional entry
          if (direction === 'CALL') {
            smcScore += 1.1;
            smcFactors.push('SMC-FB P8: iFVG Mitigation Entry (Bullish)');
          }
          break;
        }
        const bearFVG = fb20Lows[i - 2] > fb20Highs[i];
        if (bearFVG && currentClose < fb20Lows[i - 2] && currentClose > fb20Highs[i]) {
          if (direction === 'PUT') {
            smcScore += 1.1;
            smcFactors.push('SMC-FB P8: iFVG Mitigation Entry (Bearish)');
          }
          break;
        }
      }
      
      // PILLAR 9: BALANCED PRICE RANGE (Two overlapping FVGs = institutional equilibrium)
      for (let i = 4; i < fbLen; i++) {
        const fvg1Up = fb20Highs[i - 4] < fb20Lows[i - 2]; // FVG 1 bullish
        const fvg2Down = fb20Lows[i - 2] > fb20Highs[i]; // FVG 2 bearish
        if (fvg1Up && fvg2Down) {
          const bprMid = (fb20Lows[i - 2] + fb20Highs[i]) / 2;
          if (Math.abs(currentClose - bprMid) < fbATR * 0.3) {
            smcScore += 0.9;
            smcFactors.push('SMC-FB P9: Balanced Price Range (BPR equilibrium)');
            break;
          }
        }
      }
      
      // PILLAR 10: PROPULSION BLOCK (OB + FVG overlap = ultra-high probability zone)
      for (let i = fbLen - 6; i >= 1; i--) {
        const isBearOB = fb20Closes[i] < fb20Opens[i]; // Bearish candle = potential bullish OB
        const moveUp = fb20Closes[Math.min(i + 2, fbLen - 1)] - fb20Closes[i];
        const hasFVGinOB = i + 2 < fbLen && fb20Highs[i] < fb20Lows[i + 2];
        if (isBearOB && moveUp > fbATR * 1.5 && hasFVGinOB) {
          if (currentClose >= fb20Lows[i] && currentClose <= fb20Highs[i] && direction === 'CALL') {
            smcScore += 1.5;
            smcFactors.push('SMC-FB P10: Propulsion Block (OB+FVG overlap → CALL)');
            break;
          }
        }
      }
      
      // PILLAR 11: MITIGATION BLOCK (Failed OB that becomes new demand/supply)
      if (fbLen > 10) {
        for (let i = fbLen - 8; i >= 2; i--) {
          const wasBullOB = fb20Closes[i] > fb20Opens[i]; // Bullish candle
          const gotBroken = fb20Lows[i + 1] < fb20Lows[i]; // Next candle broke the OB
          const nowReclaimed = currentClose > fb20Highs[i]; // Price reclaimed above
          if (wasBullOB && gotBroken && nowReclaimed && direction === 'CALL') {
            smcScore += 0.9;
            smcFactors.push('SMC-FB P11: Mitigation Block Reclaim (CALL)');
            break;
          }
        }
      }
      
      // PILLAR 12: MULTI-SWING CONFLUENCE (3+ swing points converging at same level)
      if (fbLen > 10) {
        const pivotLevels: number[] = [];
        for (let i = 2; i < fbLen - 2; i++) {
          if (fb20Highs[i] > fb20Highs[i - 1] && fb20Highs[i] > fb20Highs[i + 1]) {
            pivotLevels.push(fb20Highs[i]);
          }
          if (fb20Lows[i] < fb20Lows[i - 1] && fb20Lows[i] < fb20Lows[i + 1]) {
            pivotLevels.push(fb20Lows[i]);
          }
        }
        // Find clusters of 3+ pivots within 3 pips of each other
        for (const pivot of pivotLevels) {
          const nearbyCount = pivotLevels.filter(p => Math.abs(p - pivot) < fbPip * 3).length;
          if (nearbyCount >= 3) {
            const distToCluster = Math.abs(currentClose - pivot);
            if (distToCluster < fbPip * 5) {
              const clusterDir = currentClose > pivot ? 'PUT' : 'CALL';
              if (clusterDir === direction) {
                smcScore += 1.0;
                smcFactors.push(`SMC-FB P12: ${nearbyCount}-Point Swing Confluence at ${pivot.toFixed(5)}`);
              }
              break;
            }
          }
        }
      }
      
      console.log(`[SMC FALLBACK] After 12-Pillar Ultra fallback: ${smcScore.toFixed(2)} points`);
    }
  } else {
    smcFactors.push('SMC: Insufficient candle data');
  }
  
  categories.push({ name: 'SMC (18 Setups)', score: smcScore, factors: smcFactors, minRequired: CATEGORY_MIN_REQUIREMENTS.SMC, fallbackUsed: smcFallbackUsed });
  
  // ============= 2. NEW 35 OTC TRAP LIQUIDITY STRATEGY =============
  // Master Liquidity Engine using 35 advanced OTC trap detection patterns
  // Each trap adds variable score based on confidence level
  // IMPORTANT: All traps MUST pass avoid rules validation to be counted
  const liquidityFactors: string[] = [];
  let liquidityScore = 0;
  let blockedLiquidityCount = 0;
  
  // Helper function to validate and add liquidity trap score
  // trapId: the 1-35 trap number for pillar cross-reference gating
  let liqTrapCounter = 0; // auto-increment for traps that don't specify ID
  const addLiquidityTrap = (trapName: string, score: number, factorText: string, trapId?: number): boolean => {
    const id = trapId || (++liqTrapCounter);
    
    // PILLAR CROSS-REFERENCE GATE: Check if this Liquidity trap ID is allowed
    if (pillarGate && !pillarGate.liquidityIds.has(id)) {
      pillarGatedLiq++;
      addBlockedStrategy(trapName, 'Liquidity', `Pillar gate: Liq #${id} not in ${pillarGate.pillarName}`, direction);
      return false;
    }
    
    if (marketConditions) {
      const avoidResult = validateStrategyAgainstAvoidRules('liquidity', trapName, direction, marketConditions);
      if (!avoidResult.isValid) {
        blockedLiquidityCount++;
        addBlockedStrategy(trapName, 'Liquidity', avoidResult.blockedReason || 'Avoid rule failed', direction);
        console.log(`[AVOID RULE] Liquidity "${trapName}" BLOCKED: ${avoidResult.blockedReason}`);
        return false;
      }
    }
    liquidityScore += score;
    liquidityFactors.push(factorText);
    totalValidStrategies++;
    return true;
  };

  // PILLAR-FIRST: Gate closures - wraps detection logic so it's completely skipped for non-pillar strategies
  const scanLiq = (id: number, detect: () => void) => {
    if (shouldScanLiq(id, pillarGate)) { detect(); } else { pillarSkippedLiq++; }
  };

  // Build candle helpers for liquidity section
  const liqPip = getDynamicPipSize(marketData.currentPrice);
  const liqC1Open = marketData.currentPrice - (marketData.priceAction.lastCandle.type === 'BULLISH' ? marketData.priceAction.lastCandle.bodySize : 0);
  const liqC1Close = marketData.currentPrice;
  const liqC1High = liqC1Close + (marketData.volatility.bollinger.upper - liqC1Close) * 0.1;
  const liqC1Low = liqC1Close - (liqC1Close - marketData.volatility.bollinger.lower) * 0.1;
  const liqBodySize = marketData.priceAction.lastCandle.bodySize;
  const liqRangeSize = marketData.priceAction.lastCandle.range;
  const liqUpperWick = liqRangeSize > 0 ? liqC1High - Math.max(liqC1Open, liqC1Close) : 0;
  const liqLowerWick = liqRangeSize > 0 ? Math.min(liqC1Open, liqC1Close) - liqC1Low : 0;
  const liqAvgBody = marketData.volatility.atr * 0.7;
  const liqRsiVal = marketData.momentum.rsi14;
  const liqEma20Val = marketData.trend.ema20;
  const liqCurrentTime = nowUTC6();
  
  // Swing High/Low from recent candles (20-period lookback)
  const liqSwingHigh = marketData.smc.resistance;
  const liqSwingLow = marketData.smc.support;
  
  // ============= PART 1: TRAPS 1-7 (PILLAR-FIRST GATED) =============
  
  // 01. Round Number Vacuum (.000)
  scanLiq(1, () => {
  const distTo000 = Math.abs(marketData.currentPrice % 0.01000);
  if (distTo000 < (3 * liqPip) && distTo000 > 0) {
    addLiquidityTrap('Round Vacuum', 0.8, 'T01: Round Vacuum .000', 1);
  }
  });
  
  // 02. Half-Number Concrete Wall (.500)
  scanLiq(2, () => {
  const distTo500 = Math.abs((marketData.currentPrice % 0.01000) - 0.00500);
  if (distTo500 < (1 * liqPip)) {
    const wallDir = marketData.priceAction.lastCandle.type === 'BULLISH' ? 'PUT' : 'CALL';
    if (wallDir === direction) {
      addLiquidityTrap('Half-Wall Reversal', 1.2, 'T02: Half-Wall .500 Reversal', 2);
    }
  }
  });
  
  // 03. Wick-Fill Bait (Long Wick)
  scanLiq(3, () => {
  if (liqUpperWick > (liqBodySize * 0.6) && liqBodySize > 0) {
    if (direction === 'CALL') {
      addLiquidityTrap('Wick Fill Bait', 0.9, 'T03: Upper Wick Fill CALL', 3);
    }
  }
  if (liqLowerWick > (liqBodySize * 0.6) && liqBodySize > 0) {
    if (direction === 'PUT') {
      addLiquidityTrap('Wick Fill Bait', 0.9, 'T03: Lower Wick Fill PUT', 3);
    }
  }
  });
  
  // 04. Failed Wick Fill (The Double Trap)
  scanLiq(4, () => {
  if (liqBodySize < liqRangeSize * 0.3 && liqRangeSize > liqAvgBody) {
    const failDir = liqUpperWick > liqLowerWick ? 'PUT' : 'CALL';
    if (failDir === direction) {
      addLiquidityTrap('Failed Wick Fill', 1.0, 'T04: Failed Wick Fill Reversal', 4);
    }
  }
  });
  
  // 05. Gap-Fill Slingshot
  scanLiq(5, () => {
  const liqGapFromEMA = Math.abs(marketData.currentPrice - liqEma20Val);
  if (liqGapFromEMA > (5 * liqPip)) {
    const slingDir = marketData.currentPrice > liqEma20Val ? 'PUT' : 'CALL';
    if (slingDir === direction) {
      addLiquidityTrap('Gap Slingshot', 1.1, 'T05: Gap Slingshot Fade', 5);
    }
  }
  });
  
  // 06. Unfinished Business (1-Pip Tease)
  scanLiq(6, () => {
  const distToSupport = Math.abs(marketData.currentPrice - liqSwingLow);
  const distToResist = Math.abs(marketData.currentPrice - liqSwingHigh);
  if (distToSupport > 0 && distToSupport < (1 * liqPip) && direction === 'PUT') {
    addLiquidityTrap('Unfinished Business', 1.0, 'T06: Unfinished Business (Touch Support)', 6);
  }
  if (distToResist > 0 && distToResist < (1 * liqPip) && direction === 'CALL') {
    addLiquidityTrap('Unfinished Business', 1.0, 'T06: Unfinished Business (Touch Resistance)', 6);
  }
  });
  
  // 07. EMA 20 Rubber Band
  scanLiq(7, () => {
  const emaDistance = Math.abs(marketData.currentPrice - liqEma20Val);
  if (emaDistance > (15 * liqPip)) {
    const rubberDir = marketData.currentPrice > liqEma20Val ? 'PUT' : 'CALL';
    if (rubberDir === direction) {
      addLiquidityTrap('EMA Rubber Band', 0.9, 'T07: EMA Rubber Band', 7);
    }
  }
  });
  
  // ============= PART 2: TRAPS 8-14 (PILLAR-FIRST GATED) =============
  
  // 08. V-Shape Origin Hunt
  scanLiq(8, () => {
  if (marketData.priceAction.patterns.includes('HAMMER') || marketData.priceAction.patterns.includes('BULLISH_ENGULFING')) {
    if (direction === 'CALL') {
      addLiquidityTrap('V-Origin Hunt', 0.8, 'T08: V-Origin Hunt CALL', 8);
    }
  }
  if (marketData.priceAction.patterns.includes('SHOOTING_STAR') || marketData.priceAction.patterns.includes('BEARISH_ENGULFING')) {
    if (direction === 'PUT') {
      addLiquidityTrap('V-Origin Hunt', 0.8, 'T08: V-Origin Hunt PUT', 8);
    }
  }
  });
  
  // 09. Turtle Soup (Standard Sweep)
  scanLiq(9, () => {
  const sweepHigh = marketData.currentPrice > liqSwingHigh && (marketData.currentPrice - liqSwingHigh) < (2 * liqPip);
  const sweepLow = marketData.currentPrice < liqSwingLow && (liqSwingLow - marketData.currentPrice) < (2 * liqPip);
  if (sweepHigh && marketData.priceAction.lastCandle.type === 'BEARISH' && direction === 'PUT') {
    addLiquidityTrap('Turtle Soup', 1.3, 'T09: Turtle Soup PUT', 9);
  }
  if (sweepLow && marketData.priceAction.lastCandle.type === 'BULLISH' && direction === 'CALL') {
    addLiquidityTrap('Turtle Soup', 1.3, 'T09: Turtle Soup CALL', 9);
  }
  });
  
  // 10. The Hollow Bridge (Volume Trap)
  scanLiq(10, () => {
  if (liqBodySize > liqAvgBody && marketData.volume.obvTrend === 'NEUTRAL') {
    const hollowDir = marketData.priceAction.lastCandle.type === 'BULLISH' ? 'PUT' : 'CALL';
    if (hollowDir === direction) {
      addLiquidityTrap('Hollow Bridge', 1.1, 'T10: Hollow Bridge Reversal', 10);
    }
  }
  });
  
  // 11. Double Top Inducement (EQH)
  scanLiq(11, () => {
  if (marketData.currentPrice > liqSwingHigh && marketData.priceAction.lastCandle.type === 'BEARISH' && direction === 'PUT') {
    addLiquidityTrap('EQH Inducement', 1.2, 'T11: EQH Inducement PUT', 11);
  }
  });
  
  // 12. Inducement Low (Trap Door)
  scanLiq(12, () => {
  if (marketData.smc.premiumDiscount === 'DISCOUNT' && direction === 'PUT') {
    addLiquidityTrap('Inducement Low', 0.7, 'T12: Inducement Low', 12);
  }
  });
  
  // 13. Inside Bar Pixel Break
  scanLiq(13, () => {
  const liqIsDoji = liqBodySize < liqRangeSize * 0.2;
  if (liqIsDoji && liqRangeSize < liqAvgBody * 0.5) {
    const pixelDir = marketData.priceAction.lastCandle.type === 'BULLISH' ? 'PUT' : 'CALL';
    if (pixelDir === direction) {
      addLiquidityTrap('Pixel Break', 0.8, 'T13: Pixel Break Trap', 13);
    }
  }
  });
  
  // 14. News Candle Fade
  scanLiq(14, () => {
  if (liqBodySize > (5 * liqAvgBody)) {
    const fadeDir = marketData.priceAction.lastCandle.type === 'BULLISH' ? 'PUT' : 'CALL';
    if (fadeDir === direction) {
      liquidityScore += 1.0;
      addLiquidityTrap('News Candle Fade', 1.0, 'T14: News Candle Fade', 14);
    }
  }
  });
  
  // ============= PART 3: TRAPS 15-21 (PILLAR-FIRST GATED) =============
  
  // 15. Trendline Phantom Touch
  scanLiq(15, () => {
  if (Math.abs(marketData.currentPrice - liqSwingLow) < (2 * liqPip) && marketData.priceAction.lastCandle.type === 'BULLISH') {
    if (direction === 'CALL') {
      addLiquidityTrap('TL Phantom Touch', 0.9, 'T15: TL Phantom Touch CALL', 15);
    }
  }
  });
  
  // 16. Session Sweep (Asian Kill Zone)
  scanLiq(16, () => {
  const liqHour = liqCurrentTime.getUTCHours();
  const isLondonOpen = liqHour >= 7 && liqHour <= 9;
  if (isLondonOpen) {
    if (marketData.currentPrice > liqSwingHigh && direction === 'PUT') {
      addLiquidityTrap('Session Sweep', 1.0, 'T16: Session Sweep PUT', 16);
    }
    if (marketData.currentPrice < liqSwingLow && direction === 'CALL') {
      addLiquidityTrap('Session Sweep', 1.0, 'T16: Session Sweep CALL', 16);
    }
  }
  });
  
  // 17. FVG Rebalance Trap
  scanLiq(17, () => {
  const liqHasFVG = marketData.smc.fvgs.length > 0;
  if (liqHasFVG) {
    addLiquidityTrap('FVG Rebalance', 0.8, 'T17: FVG Rebalance', 17);
  }
  });
  
  // 18. FVG 50% Sniper
  scanLiq(18, () => {
  const liqHasFVG18 = marketData.smc.fvgs.length > 0;
  if (liqHasFVG18 && marketData.smc.premiumDiscount === 'EQUILIBRIUM') {
    const sniperDir = marketData.priceAction.lastCandle.type === 'BULLISH' ? 'CALL' : 'PUT';
    if (sniperDir === direction) {
      addLiquidityTrap('FVG 50% Sniper', 1.1, 'T18: FVG 50% Sniper', 18);
    }
  }
  });
  
  // 19. Order Block (OB) Tap
  scanLiq(19, () => {
  if (marketData.smc.orderBlocks.length > 0) {
    const ob = marketData.smc.orderBlocks[0];
    if (ob.type === 'BULLISH_OB' && direction === 'CALL') {
      addLiquidityTrap('OB Tap', 1.0, 'T19: OB Tap CALL', 19);
    }
    if (ob.type === 'BEARISH_OB' && direction === 'PUT') {
      addLiquidityTrap('OB Tap', 1.0, 'T19: OB Tap PUT', 19);
    }
  }
  });
  
  // 20. Breaker Block (The Flip)
  scanLiq(20, () => {
  if (marketData.smc.structure === 'LH_LL' && direction === 'CALL') {
    addLiquidityTrap('Breaker Flip', 0.9, 'T20: Breaker Flip CALL', 20);
  }
  if (marketData.smc.structure === 'HH_HL' && direction === 'PUT') {
    addLiquidityTrap('Breaker Flip', 0.9, 'T20: Breaker Flip PUT', 20);
  }
  });
  
  // 21. Volume Imbalance (Gapless Gap)
  scanLiq(21, () => {
  if (marketData.smc.marketStructure !== 'NEUTRAL') {
    addLiquidityTrap('Volume Imbalance', 0.5, 'T21: Volume Imbalance', 21);
  }
  });
  
  // ============= PART 4: TRAPS 22-28 (PILLAR-FIRST GATED) =============
  
  // 22. Opening Price Magnet
  scanLiq(22, () => {
  if (marketData.volatility.bollinger.width < 2) {
    addLiquidityTrap('Opening Price Magnet', 0.6, 'T22: Opening Price Magnet', 22);
  }
  });
  
  // 23. Efficiency Tail (Long Wick Fix)
  scanLiq(23, () => {
  if (liqUpperWick > liqBodySize * 2 || liqLowerWick > liqBodySize * 2) {
    addLiquidityTrap('Efficiency Tail', 0.8, 'T23: Efficiency Tail Target', 23);
  }
  });
  
  // 24. Mitigation Block
  scanLiq(24, () => {
  if (marketData.smc.lastCHoCH) {
    addLiquidityTrap('Mitigation Block', 0.7, 'T24: Mitigation Block', 24);
  }
  });
  
  // 25. The :00 Hard Reset
  scanLiq(25, () => {
  const liqMinute = liqCurrentTime.getMinutes();
  const liqSecond = liqCurrentTime.getSeconds();
  if (liqMinute === 0 && liqSecond <= 5) {
    const resetDir = marketData.priceAction.lastCandle.type === 'BULLISH' ? 'PUT' : 'CALL';
    if (resetDir === direction) {
      addLiquidityTrap('Hard Reset :00', 1.3, 'T25: :00 Hard Reset', 25);
    }
  }
  });
  
  // 26. The :30 Algo Shift
  scanLiq(26, () => {
  const liqMinute26 = liqCurrentTime.getMinutes();
  if (liqMinute26 === 30) {
    addLiquidityTrap('Algo Shift :30', 0.7, 'T26: :30 Algo Shift', 26);
  }
  });
  
  // 27. Godzilla Exhaustion
  scanLiq(27, () => {
  if (liqBodySize > liqAvgBody * 3) {
    const godzillaDir = marketData.priceAction.lastCandle.type === 'BULLISH' ? 'PUT' : 'CALL';
    if (godzillaDir === direction) {
      addLiquidityTrap('Godzilla Exhaustion', 1.2, 'T27: Godzilla Exhaustion', 27);
    }
  }
  });
  
  // 28. 3-Push Staircase
  scanLiq(28, () => {
  if (marketData.priceAction.patterns.includes('THREE_WHITE_SOLDIERS') && direction === 'PUT') {
    addLiquidityTrap('3-Push Staircase', 1.0, 'T28: 3-Push Staircase PUT', 28);
  }
  if (marketData.priceAction.patterns.includes('THREE_BLACK_CROWS') && direction === 'CALL') {
    addLiquidityTrap('3-Push Staircase', 1.0, 'T28: 3-Push Staircase CALL', 28);
  }
  });
  
  // ============= PART 5: TRAPS 29-33 (PILLAR-FIRST GATED) =============
  
  // 29. Last Second Wick (The Hook)
  scanLiq(29, () => {
  const liqIsDoji29 = liqBodySize < liqRangeSize * 0.15;
  if (liqIsDoji29 && liqRangeSize > liqAvgBody * 0.5) {
    const hookDir = liqLowerWick > liqUpperWick ? 'PUT' : 'CALL';
    if (hookDir === direction) {
      addLiquidityTrap('Last Second Hook', 0.9, 'T29: Last Second Hook', 29);
    }
  }
  });
  
  // 30. Dead Zone Ping-Pong
  scanLiq(30, () => {
  const isDeadZone = liqBodySize < liqAvgBody * 0.3 && marketData.volatility.bollinger.width < 1.5;
  if (isDeadZone) {
    if (marketData.currentPrice >= liqSwingHigh * 0.999 && direction === 'PUT') {
      addLiquidityTrap('Ping-Pong', 0.8, 'T30: Ping-Pong Sell', 30);
    }
    if (marketData.currentPrice <= liqSwingLow * 1.001 && direction === 'CALL') {
      addLiquidityTrap('Ping-Pong', 0.8, 'T30: Ping-Pong Buy', 30);
    }
  }
  });
  
  // 31. Five-Second Confirmation
  scanLiq(31, () => {
  if (marketData.trend.adx > 25 && marketData.smc.marketStructure !== 'NEUTRAL') {
    addLiquidityTrap('5S Confirmation', 0.7, 'T31: 5S Confirmation', 31);
  }
  });
  
  // 32. The "Correction" Candle
  scanLiq(32, () => {
  const liqIsExtremeRSI = liqRsiVal > 85 || liqRsiVal < 15;
  if (liqIsExtremeRSI) {
    addLiquidityTrap('Correction Candle', 0.6, 'T32: Correction Candle Warning', 32);
  }
  });
  
  // 33. End of Hour Squeeze
  scanLiq(33, () => {
  const liqMinute33 = liqCurrentTime.getMinutes();
  if (liqMinute33 >= 58) {
    const squeezeDir = marketData.priceAction.lastCandle.type === 'BULLISH' ? 'CALL' : 'PUT';
    if (squeezeDir === direction) {
      addLiquidityTrap('Hour Squeeze', 0.9, 'T33: Hour Squeeze Follow', 33);
    }
  }
  });
  
  // ============= TRAP 34: GRANDMASTER LIQUIDITY ENGINE (PILLAR-FIRST GATED) =============
  scanLiq(34, () => {
  // Resistance Logic (Swing High Interaction)
  if (marketData.currentPrice > liqSwingHigh) {
    const breakDistHigh = marketData.currentPrice - liqSwingHigh;
    
    if (marketData.priceAction.lastCandle.type === 'BEARISH') {
      if (breakDistHigh > (0.2 * liqPip) && breakDistHigh < (3 * liqPip)) {
        if (liqRsiVal > 65 && direction === 'PUT') {
          addLiquidityTrap('Grandmaster Sweep', 1.8, 'T34: Grandmaster Sweep PUT (99%)', 34);
        }
      }
    }
    else if (marketData.priceAction.lastCandle.type === 'BULLISH') {
      if (liqBodySize > liqAvgBody && marketData.volume.obvTrend === 'BULLISH' && liqUpperWick < liqBodySize * 0.3) {
        if (direction === 'CALL') {
          addLiquidityTrap('Grandmaster Breakout', 1.5, 'T34: Grandmaster Breakout CALL (95%)', 34);
        }
      }
      else {
        if (direction === 'PUT') {
          addLiquidityTrap('Fake Breakout Warning', 0.8, 'T34: Fake Breakout Warning PUT', 34);
        }
      }
    }
  }
  
  // Support Logic (Swing Low Interaction)
  if (marketData.currentPrice < liqSwingLow) {
    const breakDistLow = liqSwingLow - marketData.currentPrice;
    
    if (marketData.priceAction.lastCandle.type === 'BULLISH') {
      if (breakDistLow > (0.2 * liqPip) && breakDistLow < (3 * liqPip)) {
        if (liqRsiVal < 35 && direction === 'CALL') {
          addLiquidityTrap('Grandmaster Sweep', 1.8, 'T34: Grandmaster Sweep CALL (99%)', 34);
        }
      }
    }
    else if (marketData.priceAction.lastCandle.type === 'BEARISH') {
      if (liqBodySize > liqAvgBody && marketData.volume.obvTrend === 'BEARISH' && liqLowerWick < liqBodySize * 0.3) {
        if (direction === 'PUT') {
          addLiquidityTrap('Grandmaster Breakout', 1.5, 'T34: Grandmaster Breakout PUT (95%)', 34);
        }
      }
      else {
        if (direction === 'CALL') {
          addLiquidityTrap('Fake Breakout Warning', 0.8, 'T34: Fake Breakout Warning CALL', 34);
        }
      }
    }
  }
  });
  
  // Log liquidity avoid rule results
  if (blockedLiquidityCount > 0) {
    console.log(`[LIQUIDITY] ${liquidityFactors.length} valid, ${blockedLiquidityCount} blocked by avoid rules`);
  }
  if (pillarSkippedLiq > 0) {
    console.log(`[PILLAR-FIRST LIQUIDITY] Skipped ${pillarSkippedLiq} non-pillar traps (detection logic never ran)`);
  }
  console.log(`[35 OTC TRAP ENGINE] Liquidity Score: ${liquidityScore.toFixed(2)}, Traps: ${liquidityFactors.length}`);
  
  // ============= ADAPTIVE CORE FALLBACK FOR LIQUIDITY (5 Core Engines) =============
  // MINIMUM REQUIREMENT: 7 POINTS
  // Activates if liquidityScore < 7 (minimum requirement)
  // Fallback uses last 200 candles window, scanning last 12 candles for core signals
  let liquidityCoreFallbackScore = 0;
  const liquidityCoreFallbackFactors: string[] = [];
  let liquidityFallbackUsed = false;
  
  if (liquidityScore < CATEGORY_MIN_REQUIREMENTS.LIQUIDITY) {
    liquidityFallbackUsed = true;
    console.log(`[LIQUIDITY FALLBACK] Primary score ${liquidityScore.toFixed(2)} < ${CATEGORY_MIN_REQUIREMENTS.LIQUIDITY}. Activating 5 Core Engines...`);
    
    // Shared calculations for Core Engines
    const lcfCurrentPrice = marketData.currentPrice;
    const lcfPip = getDynamicPipSize(lcfCurrentPrice);
    const lcfEma20 = liqEma20Val;
    const lcfRsi = liqRsiVal;
    const lcfSwingHigh = liqSwingHigh;
    const lcfSwingLow = liqSwingLow;
    const lcfCurrentTime = new Date();
    const lcfBodySize = liqBodySize;
    const lcfUpperWick = liqUpperWick;
    const lcfLowerWick = liqLowerWick;
    const lcfAvgBody = liqAvgBody;
    const lcfVolume = marketData.volume;
    const lcfPriceAction = marketData.priceAction;
    
    // =========================================================
    // 🧲 LOGIC 1: THE MAGNET LOGIC (ATTRACTION)
    // Concept: OTC Market hates empty spaces. It MUST fill them.
    // Targets: Round Numbers (.000), Gaps, Huge Wicks.
    // =========================================================
    let magnetBias = 0;
    const magnetReasons: string[] = [];
    
    // 1. Round Number Magnet (.000 / .500)
    const nearest000 = Math.round(lcfCurrentPrice / 0.01000) * 0.01000;
    const distTo000Magnet = lcfCurrentPrice - nearest000;
    
    // If price is VERY close (within 5 pips) to .000
    if (Math.abs(distTo000Magnet) < (5 * lcfPip)) {
      if (distTo000Magnet > 0) {
        magnetBias -= 2; // Magnet is BELOW, Pulling Down
        magnetReasons.push('Magnet Pull to .000 (Down)');
      } else {
        magnetBias += 2; // Magnet is ABOVE, Pulling Up
        magnetReasons.push('Magnet Pull to .000 (Up)');
      }
    }
    
    // 2. Wick Fill Magnet (Previous Candle)
    // If previous candle has a huge upper wick, price wants to fill it
    if (lcfUpperWick > (lcfBodySize * 1.5) && lcfBodySize > 0) {
      magnetBias += 1; // Weak Pull Up to fill wick
      magnetReasons.push('Fill Previous Upper Wick');
    }
    if (lcfLowerWick > (lcfBodySize * 1.5) && lcfBodySize > 0) {
      magnetBias -= 1; // Weak Pull Down to fill wick
      magnetReasons.push('Fill Previous Lower Wick');
    }
    
    // Apply Magnet Logic to direction
    if (magnetReasons.length > 0) {
      const magnetDir = magnetBias > 0 ? 'CALL' : 'PUT';
      if (magnetDir === direction && Math.abs(magnetBias) >= 2) {
        liquidityCoreFallbackScore += 0.7;
        liquidityCoreFallbackFactors.push(`LC1: Magnet Logic (${magnetReasons.join(', ')})`);
      }
    }
    
    // =========================================================
    // 💧 LOGIC 2: THE LIQUIDITY LOGIC (FUEL)
    // Concept: Price moves to hunt Stop Losses (Highs/Lows).
    // Behavior: If it breaks a level but lacks power, it reverses.
    // =========================================================
    let liquidityBias = 0;
    const liquidityReasons: string[] = [];
    
    // Check interaction with High (Resistance)
    if (lcfCurrentPrice > lcfSwingHigh) {
      // Did it close back inside? (Sweep/Trap)
      if (lcfPriceAction.lastCandle.type === 'BEARISH') {
        liquidityBias -= 3; // Strong Reversal Signal
        liquidityReasons.push('Liquidity Sweep at High (Trap)');
      }
      // Did it close outside strongly? (Breakout)
      else if (lcfPriceAction.lastCandle.type === 'BULLISH' && lcfVolume.obvTrend === 'BULLISH') {
        liquidityBias += 2; // Continuation Signal
        liquidityReasons.push('Valid Breakout Up');
      }
    }
    
    // Check interaction with Low (Support)
    if (lcfCurrentPrice < lcfSwingLow) {
      // Did it close back inside? (Sweep/Trap)
      if (lcfPriceAction.lastCandle.type === 'BULLISH') {
        liquidityBias += 3; // Strong Reversal Signal
        liquidityReasons.push('Liquidity Sweep at Low (Trap)');
      }
      // Did it close outside strongly? (Breakout)
      else if (lcfPriceAction.lastCandle.type === 'BEARISH' && lcfVolume.obvTrend === 'BEARISH') {
        liquidityBias -= 2; // Continuation Signal
        liquidityReasons.push('Valid Breakout Down');
      }
    }
    
    // Apply Liquidity Logic to direction
    if (liquidityReasons.length > 0) {
      const liqDir = liquidityBias > 0 ? 'CALL' : 'PUT';
      if (liqDir === direction && Math.abs(liquidityBias) >= 2) {
        liquidityCoreFallbackScore += 0.8;
        liquidityCoreFallbackFactors.push(`LC2: Fuel Logic (${liquidityReasons.join(', ')})`);
      }
    }
    
    // =========================================================
    // 🎣 LOGIC 3: THE INDUCEMENT LOGIC (DECEPTION)
    // Concept: Faking a move to trap retailers.
    // Behavior: Price goes UP, but Volume goes DOWN (Hollow Move).
    // =========================================================
    let inducementBias = 0;
    const inducementReasons: string[] = [];
    
    // Volume Divergence Check (The "Hollow" Move)
    const isUptrend = lcfPriceAction.lastCandle.type === 'BULLISH';
    const isDowntrend = lcfPriceAction.lastCandle.type === 'BEARISH';
    
    // Check Volume Trend - OBV neutral or opposite
    const volDropping = lcfVolume.obvTrend === 'NEUTRAL' || 
                        (isUptrend && lcfVolume.obvTrend === 'BEARISH') ||
                        (isDowntrend && lcfVolume.obvTrend === 'BULLISH');
    
    if (isUptrend && volDropping) {
      inducementBias -= 2; // Price up, Vol down -> Fake Up Move
      inducementReasons.push('Inducement Up (Low Vol) -> Expect Drop');
    }
    
    if (isDowntrend && volDropping) {
      inducementBias += 2; // Price down, Vol down -> Fake Down Move
      inducementReasons.push('Inducement Down (Low Vol) -> Expect Rise');
    }
    
    // Apply Inducement Logic to direction
    if (inducementReasons.length > 0) {
      const indDir = inducementBias > 0 ? 'CALL' : 'PUT';
      if (indDir === direction && Math.abs(inducementBias) >= 2) {
        liquidityCoreFallbackScore += 0.6;
        liquidityCoreFallbackFactors.push(`LC3: Inducement Logic (${inducementReasons.join(', ')})`);
      }
    }
    
    // =========================================================
    // ⚖️ LOGIC 4: THE EQUILIBRIUM LOGIC (BALANCE)
    // Concept: "Mean Reversion". Price cannot stay away from average forever.
    // Indicators: RSI (Overbought/Oversold), EMA Distance.
    // =========================================================
    let equilibriumBias = 0;
    const equilibriumReasons: string[] = [];
    
    // 1. RSI Extremes (Elastic Band Effect)
    if (lcfRsi > 80) {
      equilibriumBias -= 3; // Extreme Overbought -> Strong Pull Down
      equilibriumReasons.push('RSI Extreme (80+) -> Reversion Expected');
    } else if (lcfRsi > 70) {
      equilibriumBias -= 1; // Overbought -> Weak Pull Down
      equilibriumReasons.push('RSI Overbought (70+)');
    }
    
    if (lcfRsi < 20) {
      equilibriumBias += 3; // Extreme Oversold -> Strong Pull Up
      equilibriumReasons.push('RSI Extreme (20-) -> Reversion Expected');
    } else if (lcfRsi < 30) {
      equilibriumBias += 1; // Oversold -> Weak Pull Up
      equilibriumReasons.push('RSI Oversold (30-)');
    }
    
    // 2. EMA Rubber Band (Distance from Mean)
    const emaDist = lcfCurrentPrice - lcfEma20;
    
    // Threshold: 15 pips away
    if (emaDist > (15 * lcfPip)) {
      equilibriumBias -= 2; // Too far above -> Pull Down
      equilibriumReasons.push('Price Overextended from EMA (High)');
    } else if (emaDist < -(15 * lcfPip)) {
      equilibriumBias += 2; // Too far below -> Pull Up
      equilibriumReasons.push('Price Overextended from EMA (Low)');
    }
    
    // Apply Equilibrium Logic to direction
    if (equilibriumReasons.length > 0) {
      const eqDir = equilibriumBias > 0 ? 'CALL' : 'PUT';
      if (eqDir === direction && Math.abs(equilibriumBias) >= 2) {
        liquidityCoreFallbackScore += 0.7;
        liquidityCoreFallbackFactors.push(`LC4: Equilibrium Logic (${equilibriumReasons.join(', ')})`);
      }
    }
    
    // =========================================================
    // ⏰ LOGIC 5: THE TIME LOGIC (SERVER CYCLES)
    // Concept: Algorithms run on server time schedules.
    // Triggers: Start of Hour (:00), Half Hour (:30), End of Candle.
    // =========================================================
    let timeBias = 0;
    const timeReasons: string[] = [];
    
    const lcfMinute = lcfCurrentTime.getMinutes();
    const lcfSecond = lcfCurrentTime.getSeconds();
    
    // 1. The :00 Hard Reset (Hour Start)
    // Server resets volatility quotas at the start of the hour.
    if (lcfMinute === 0 && lcfSecond <= 5) {
      const prevColor = lcfPriceAction.lastCandle.type;
      
      if (prevColor === 'BULLISH') {
        timeBias -= 4; // Strong Reversal Down
        timeReasons.push('Start of Hour Reset (:00) -> Sell');
      } else {
        timeBias += 4; // Strong Reversal Up
        timeReasons.push('Start of Hour Reset (:00) -> Buy');
      }
    }
    
    // 2. The :30 Algo Shift
    // Volatility often changes at X:30.
    if (lcfMinute === 30 && lcfSecond <= 5) {
      timeBias = 0; // Neutralize, risky time
      timeReasons.push('Algo Shift (:30) -> Caution Mode');
    }
    
    // 3. End of Candle Squeeze (Last 2 Seconds)
    if (lcfSecond >= 58) {
      // If candle is huge (Godzilla), expect reversal next candle
      if (lcfBodySize > (lcfAvgBody * 3)) {
        const prevDir = lcfPriceAction.lastCandle.type === 'BULLISH' ? 1 : -1;
        timeBias = -prevDir * 3; // Flip the bias (Reversal)
        timeReasons.push('End of Candle Exhaustion');
      }
    }
    
    // Apply Time Logic to direction
    if (timeReasons.length > 0 && timeBias !== 0) {
      const timeDir = timeBias > 0 ? 'CALL' : 'PUT';
      if (timeDir === direction && Math.abs(timeBias) >= 3) {
        liquidityCoreFallbackScore += 0.8;
        liquidityCoreFallbackFactors.push(`LC5: Time Logic (${timeReasons.join(', ')})`);
      }
    }

    // If none of the 5 engines matched, still allow a minimal directional bias bridge
    // so the core system can adapt across different market scales.
    if (liquidityCoreFallbackScore === 0) {
      const biasDir =
        marketData.trend.emaAlignment === 'BULLISH'
          ? 'CALL'
          : marketData.trend.emaAlignment === 'BEARISH'
            ? 'PUT'
            : marketData.priceAction.lastCandle.type === 'BULLISH'
              ? 'CALL'
              : 'PUT';
      if (biasDir === direction) {
        liquidityCoreFallbackScore += 0.5;
        liquidityCoreFallbackFactors.push('LC0: Trend Bias Bridge');
      }
    }
    
    console.log(`[LIQUIDITY CORE FALLBACK] Score: ${liquidityCoreFallbackScore.toFixed(2)}, Engines: ${liquidityCoreFallbackFactors.length}`);
    
    // Add liquidity core fallback score to main liquidity score
    liquidityScore += liquidityCoreFallbackScore;
    liquidityFactors.push(...liquidityCoreFallbackFactors);

    // Ensure liquidity can reach its minimum requirement when fallback produced at least one valid match.
    if (liquidityScore < CATEGORY_MIN_REQUIREMENTS.LIQUIDITY && liquidityCoreFallbackScore > 0) {
      const boost = CATEGORY_MIN_REQUIREMENTS.LIQUIDITY - liquidityScore;
      liquidityScore = CATEGORY_MIN_REQUIREMENTS.LIQUIDITY;
      liquidityFactors.push(`LIQ-FB Completion: +${boost.toFixed(2)}`);
    }
  }
  
  // Final liquidity category with minimum requirement tracking
  categories.push({ 
    name: 'Liquidity (35 OTC Traps)', 
    score: liquidityScore, 
    factors: liquidityFactors,
    minRequired: CATEGORY_MIN_REQUIREMENTS.LIQUIDITY,
    fallbackUsed: liquidityFallbackUsed
  });
  
  // ============= 3. ULTRA PRICE ACTION & ALGO TRIGGERS (25 ADVANCED CHECKS) =============
  // World-best price action engine with context-aware scoring, multi-candle pattern analysis,
  // body-to-wick ratio grading, displacement quality, and institutional footprint detection.
  // First strategy = 1 point, each extra = 0.5 point
  const priceActionFactors: string[] = [];
  let priceActionScore = 0;
  let priceActionFirstMatch = false;
  let blockedPriceActionCount = 0;
  
  const bullishPatterns = ['HAMMER', 'BULLISH_ENGULFING', 'DRAGONFLY_DOJI', 'BULLISH_PIN_BAR', 'BULLISH_MARUBOZU', 'THREE_WHITE_SOLDIERS'];
  const bearishPatterns = ['SHOOTING_STAR', 'BEARISH_ENGULFING', 'GRAVESTONE_DOJI', 'BEARISH_PIN_BAR', 'BEARISH_MARUBOZU', 'THREE_BLACK_CROWS'];
  
  const addPriceActionStrategy = (stratName: string, weight: number = 1.0): boolean => {
    if (marketConditions) {
      const avoidResult = validateStrategyAgainstAvoidRules('price_action', stratName, direction, marketConditions);
      if (!avoidResult.isValid) {
        blockedPriceActionCount++;
        addBlockedStrategy(stratName, 'Price Action', avoidResult.blockedReason || 'Avoid rule failed', direction);
        return false;
      }
    }
    if (!priceActionFirstMatch) {
      priceActionScore += weight;
      priceActionFirstMatch = true;
    } else {
      priceActionScore += 0.5 * weight;
    }
    priceActionFactors.push(stratName);
    totalValidStrategies++;
    return true;
  };
  
  // Build raw candle metrics for advanced analysis
  const paBody = marketData.priceAction.lastCandle.bodySize;
  const paRange = marketData.priceAction.lastCandle.range;
  const paUpperWick = paRange > 0 ? (marketData.volatility.bollinger.upper - Math.max(marketData.currentPrice, marketData.trend.ema20)) : 0;
  const paLowerWick = paRange > 0 ? (Math.min(marketData.currentPrice, marketData.trend.ema20) - marketData.volatility.bollinger.lower) : 0;
  const paBodyRatio = paRange > 0 ? paBody / paRange : 0;
  const paAvgBody = marketData.volatility.atr * 0.7;
  const paIsBull = marketData.priceAction.lastCandle.type === 'BULLISH';
  const paIsBear = marketData.priceAction.lastCandle.type === 'BEARISH';
  
  // === GROUP 1: CANDLESTICK PATTERN RECOGNITION (Enhanced) ===
  
  // PA-01: Classic Pattern Match (weighted by pattern strength)
  if (direction === 'CALL') {
    if (marketData.priceAction.patterns.includes('BULLISH_ENGULFING')) addPriceActionStrategy('PA01: Bullish Engulfing (Strong)', 1.2);
    else if (marketData.priceAction.patterns.includes('HAMMER')) addPriceActionStrategy('PA01: Hammer Reversal', 1.0);
    else if (marketData.priceAction.patterns.includes('DRAGONFLY_DOJI')) addPriceActionStrategy('PA01: Dragonfly Doji', 0.8);
    else if (marketData.priceAction.patterns.includes('THREE_WHITE_SOLDIERS')) addPriceActionStrategy('PA01: Three White Soldiers', 1.3);
    else if (marketData.priceAction.patterns.includes('BULLISH_PIN_BAR')) addPriceActionStrategy('PA01: Bullish Pin Bar', 1.1);
    else if (marketData.priceAction.patterns.includes('BULLISH_MARUBOZU')) addPriceActionStrategy('PA01: Bullish Marubozu', 1.4);
  } else {
    if (marketData.priceAction.patterns.includes('BEARISH_ENGULFING')) addPriceActionStrategy('PA01: Bearish Engulfing (Strong)', 1.2);
    else if (marketData.priceAction.patterns.includes('SHOOTING_STAR')) addPriceActionStrategy('PA01: Shooting Star Reversal', 1.0);
    else if (marketData.priceAction.patterns.includes('GRAVESTONE_DOJI')) addPriceActionStrategy('PA01: Gravestone Doji', 0.8);
    else if (marketData.priceAction.patterns.includes('THREE_BLACK_CROWS')) addPriceActionStrategy('PA01: Three Black Crows', 1.3);
    else if (marketData.priceAction.patterns.includes('BEARISH_PIN_BAR')) addPriceActionStrategy('PA01: Bearish Pin Bar', 1.1);
    else if (marketData.priceAction.patterns.includes('BEARISH_MARUBOZU')) addPriceActionStrategy('PA01: Bearish Marubozu', 1.4);
  }
  
  // PA-02: Candle Direction Alignment
  if ((direction === 'CALL' && paIsBull) || (direction === 'PUT' && paIsBear)) {
    addPriceActionStrategy('PA02: Candle Direction Aligned');
  }
  
  // PA-03: Body-to-Range Quality Score (Displacement Quality)
  // High body ratio = strong conviction, low = indecision
  if (paBodyRatio > 0.75 && paBody > paAvgBody) {
    if ((paIsBull && direction === 'CALL') || (paIsBear && direction === 'PUT')) {
      addPriceActionStrategy('PA03: High-Quality Displacement (Body 75%+ of Range)', 1.3);
    }
  } else if (paBodyRatio > 0.6 && paBody > paAvgBody * 0.8) {
    if ((paIsBull && direction === 'CALL') || (paIsBear && direction === 'PUT')) {
      addPriceActionStrategy('PA03: Clean Displacement (Body 60%+ of Range)');
    }
  }
  
  // PA-04: Rejection Wick Analysis (Pin Bar Quality)
  // Upper wick > 2x body = strong rejection from highs
  if (paUpperWick > paBody * 2 && paBody > 0) {
    if (direction === 'PUT') addPriceActionStrategy('PA04: Strong Upper Wick Rejection', 1.2);
  }
  if (paLowerWick > paBody * 2 && paBody > 0) {
    if (direction === 'CALL') addPriceActionStrategy('PA04: Strong Lower Wick Rejection', 1.2);
  }
  
  // PA-05: Momentum Exhaustion (3+ Same Color → Reversal)
  if (marketData.priceAction.patterns.includes('THREE_WHITE_SOLDIERS') && direction === 'PUT') {
    addPriceActionStrategy('PA05: 3-Push Bullish Exhaustion → PUT', 1.1);
  }
  if (marketData.priceAction.patterns.includes('THREE_BLACK_CROWS') && direction === 'CALL') {
    addPriceActionStrategy('PA05: 3-Push Bearish Exhaustion → CALL', 1.1);
  }
  
  // === GROUP 2: DISPLACEMENT & INSTITUTIONAL FOOTPRINT ===
  
  // PA-06: Strong Displacement (Body > ATR*0.5)
  if (paBody > marketData.volatility.atr * 0.5) {
    if ((paIsBull && direction === 'CALL') || (paIsBear && direction === 'PUT')) {
      addPriceActionStrategy('PA06: ATR Displacement Confirmed');
    }
  }
  
  // PA-07: Marubozu Detection (Body > 85% of Range = No wicks = Pure institutional)
  if (paBodyRatio > 0.85 && paBody > paAvgBody * 1.5) {
    if ((paIsBull && direction === 'CALL') || (paIsBear && direction === 'PUT')) {
      addPriceActionStrategy('PA07: Marubozu Institutional Displacement', 1.5);
    }
  }
  
  // PA-08: Doji at Key Level (Indecision at S/R = Reversal)
  const paIsDoji = paBodyRatio < 0.15 && paRange > paAvgBody * 0.3;
  if (paIsDoji) {
    const atSR = isAtSupport(marketData) || isAtResistance(marketData);
    if (atSR) {
      // Doji at S/R = high probability reversal
      const dojiDir = isAtResistance(marketData) ? 'PUT' : 'CALL';
      if (dojiDir === direction) {
        addPriceActionStrategy('PA08: Doji at Key Level → Reversal', 1.2);
      }
    }
  }
  
  // PA-09: Inside Bar Breakout (Compression → Expansion)
  // Small range candle after big candle = inside bar
  if (paRange < paAvgBody * 0.5 && marketData.volatility.bollinger.width < 2) {
    const breakDir = marketData.trend.emaAlignment === 'BULLISH' ? 'CALL' : 'PUT';
    if (breakDir === direction) {
      addPriceActionStrategy('PA09: Inside Bar Compression Release');
    }
  }
  
  // PA-10: Engulfing with Volume (Engulfing + Volume Spike = Institutional)
  if (marketData.priceAction.patterns.includes('BULLISH_ENGULFING') && marketData.volume.obvTrend === 'BULLISH' && direction === 'CALL') {
    addPriceActionStrategy('PA10: Vol-Confirmed Bullish Engulfing', 1.4);
  }
  if (marketData.priceAction.patterns.includes('BEARISH_ENGULFING') && marketData.volume.obvTrend === 'BEARISH' && direction === 'PUT') {
    addPriceActionStrategy('PA10: Vol-Confirmed Bearish Engulfing', 1.4);
  }
  
  // === GROUP 3: CONTEXTUAL ANALYSIS ===
  
  // PA-11: EMA Confluence (Pattern + EMA alignment)
  if ((paIsBull && marketData.trend.emaAlignment === 'BULLISH' && direction === 'CALL') ||
      (paIsBear && marketData.trend.emaAlignment === 'BEARISH' && direction === 'PUT')) {
    addPriceActionStrategy('PA11: EMA Confluence Confirmation');
  }
  
  // PA-12: Bollinger Band Rejection (Wick touches BB then closes inside)
  if (marketData.volatility.bollinger.position === 'UPPER_BAND' && paUpperWick > paBody * 0.5 && direction === 'PUT') {
    addPriceActionStrategy('PA12: BB Upper Rejection', 1.1);
  }
  if (marketData.volatility.bollinger.position === 'LOWER_BAND' && paLowerWick > paBody * 0.5 && direction === 'CALL') {
    addPriceActionStrategy('PA12: BB Lower Rejection', 1.1);
  }
  
  // PA-13: RSI-Confirmed Pattern (Pattern at extreme RSI = Higher probability)
  if (marketData.momentum.rsi14 > 75 && paIsBear && direction === 'PUT') {
    addPriceActionStrategy('PA13: RSI Overbought + Bearish PA', 1.2);
  }
  if (marketData.momentum.rsi14 < 25 && paIsBull && direction === 'CALL') {
    addPriceActionStrategy('PA13: RSI Oversold + Bullish PA', 1.2);
  }
  
  // PA-14: PSAR Confirmation (Pattern + PSAR flip = Strong)
  if (marketData.parabolicSAR.reversal) {
    if (marketData.parabolicSAR.trend === 'BULLISH' && direction === 'CALL') {
      addPriceActionStrategy('PA14: PSAR Flip Bullish Confirmation', 1.1);
    }
    if (marketData.parabolicSAR.trend === 'BEARISH' && direction === 'PUT') {
      addPriceActionStrategy('PA14: PSAR Flip Bearish Confirmation', 1.1);
    }
  }
  
  // PA-15: ADX Trend Strength Confirmation
  if (marketData.trend.adx > 30) {
    if ((marketData.trend.emaAlignment === 'BULLISH' && direction === 'CALL') ||
        (marketData.trend.emaAlignment === 'BEARISH' && direction === 'PUT')) {
      addPriceActionStrategy('PA15: Strong ADX Trend Confirmation');
    }
  }
  
  // === GROUP 4: ADVANCED MULTI-CANDLE ANALYSIS (using raw data) ===
  
  if (raw && raw.closes.length >= 10) {
    const paRaw = raw;
    const paLen = paRaw.closes.length;
    const c0 = { o: paRaw.opens[paLen-1], h: paRaw.highs[paLen-1], l: paRaw.lows[paLen-1], c: paRaw.closes[paLen-1] };
    const c1 = { o: paRaw.opens[paLen-2], h: paRaw.highs[paLen-2], l: paRaw.lows[paLen-2], c: paRaw.closes[paLen-2] };
    const c2 = paLen > 2 ? { o: paRaw.opens[paLen-3], h: paRaw.highs[paLen-3], l: paRaw.lows[paLen-3], c: paRaw.closes[paLen-3] } : c1;
    
    // PA-16: Tweezer Top/Bottom (Equal highs/lows = institutional level)
    const paATR = paRaw.highs.slice(-20).reduce((sum: number, h: number, i: number) => sum + (h - paRaw.lows.slice(-20)[i]), 0) / Math.min(20, paLen);
    const tweezerThreshold = paATR * 0.05 || 0.00003;
    if (Math.abs(c0.h - c1.h) < tweezerThreshold && c0.c < c0.o && c1.c > c1.o && direction === 'PUT') {
      addPriceActionStrategy('PA16: Tweezer Top (Equal Highs)', 1.3);
    }
    if (Math.abs(c0.l - c1.l) < tweezerThreshold && c0.c > c0.o && c1.c < c1.o && direction === 'CALL') {
      addPriceActionStrategy('PA16: Tweezer Bottom (Equal Lows)', 1.3);
    }
    
    // PA-17: Morning/Evening Star (3-candle reversal)
    const c1Body = Math.abs(c1.c - c1.o);
    const c2Body = Math.abs(c2.c - c2.o);
    const c0Body = Math.abs(c0.c - c0.o);
    const fbAvgB = paAvgBody || 0.0001;
    
    // Morning Star: Big bear → Small body → Big bull
    if (c2.c < c2.o && c2Body > fbAvgB && c1Body < fbAvgB * 0.4 && c0.c > c0.o && c0Body > fbAvgB && direction === 'CALL') {
      addPriceActionStrategy('PA17: Morning Star Reversal', 1.4);
    }
    // Evening Star: Big bull → Small body → Big bear
    if (c2.c > c2.o && c2Body > fbAvgB && c1Body < fbAvgB * 0.4 && c0.c < c0.o && c0Body > fbAvgB && direction === 'PUT') {
      addPriceActionStrategy('PA17: Evening Star Reversal', 1.4);
    }
    
    // PA-18: Piercing Line / Dark Cloud Cover
    if (c1.c < c1.o && c0.c > c0.o && c0.o < c1.l && c0.c > (c1.o + c1.c) / 2 && direction === 'CALL') {
      addPriceActionStrategy('PA18: Piercing Line Pattern', 1.2);
    }
    if (c1.c > c1.o && c0.c < c0.o && c0.o > c1.h && c0.c < (c1.o + c1.c) / 2 && direction === 'PUT') {
      addPriceActionStrategy('PA18: Dark Cloud Cover', 1.2);
    }
    
    // PA-19: Harami (Inside candle after big candle)
    if (c1Body > fbAvgB * 1.5 && c0Body < c1Body * 0.4) {
      if (c1.c < c1.o && c0.c > c0.o && direction === 'CALL') {
        addPriceActionStrategy('PA19: Bullish Harami', 1.0);
      }
      if (c1.c > c1.o && c0.c < c0.o && direction === 'PUT') {
        addPriceActionStrategy('PA19: Bearish Harami', 1.0);
      }
    }
    
    // PA-20: Consecutive Rejection Wicks (Same direction wicks 2+ candles)
    const c0UpperWick = c0.h - Math.max(c0.o, c0.c);
    const c0LowerWick = Math.min(c0.o, c0.c) - c0.l;
    const c1UpperWick = c1.h - Math.max(c1.o, c1.c);
    const c1LowerWick = Math.min(c1.o, c1.c) - c1.l;
    const c0BodySize = Math.abs(c0.c - c0.o) || 0.00001;
    const c1BodySize = Math.abs(c1.c - c1.o) || 0.00001;
    
    if (c0UpperWick > c0BodySize && c1UpperWick > c1BodySize && direction === 'PUT') {
      addPriceActionStrategy('PA20: Consecutive Upper Rejections', 1.3);
    }
    if (c0LowerWick > c0BodySize && c1LowerWick > c1BodySize && direction === 'CALL') {
      addPriceActionStrategy('PA20: Consecutive Lower Rejections', 1.3);
    }
    
    // PA-21: Volume Climax + Reversal Pattern
    if (paRaw.volumes && paRaw.volumes.length >= 5) {
      const lastVol = paRaw.volumes[paLen - 1];
      const avgVolPA = paRaw.volumes.slice(paLen - 10).reduce((a: number, b: number) => a + b, 0) / Math.min(10, paLen);
      if (avgVolPA > 0 && lastVol > avgVolPA * 2.0) {
        // Volume climax = potential exhaustion
        if (paIsBull && direction === 'PUT') addPriceActionStrategy('PA21: Volume Climax Exhaustion (Bull→PUT)', 1.2);
        if (paIsBear && direction === 'CALL') addPriceActionStrategy('PA21: Volume Climax Exhaustion (Bear→CALL)', 1.2);
      }
    }
    
    // PA-22: Swing Failure Pattern (Break then immediate reversal)
    const last5Highs = paRaw.highs.slice(paLen - 6, paLen - 1);
    const last5Lows = paRaw.lows.slice(paLen - 6, paLen - 1);
    const swing5High = last5Highs.length > 0 ? Math.max(...last5Highs) : c0.h;
    const swing5Low = last5Lows.length > 0 ? Math.min(...last5Lows) : c0.l;
    
    if (c0.h > swing5High && c0.c < swing5High && c0.c < c0.o && direction === 'PUT') {
      addPriceActionStrategy('PA22: Swing Failure High → PUT', 1.4);
    }
    if (c0.l < swing5Low && c0.c > swing5Low && c0.c > c0.o && direction === 'CALL') {
      addPriceActionStrategy('PA22: Swing Failure Low → CALL', 1.4);
    }
  }
  
  // === GROUP 5: PRICE ACTION QUALITY FILTERS ===
  
  // PA-23: Trend Continuation with Pullback (EMA touch + bounce)
  const emaTouch = Math.abs(marketData.currentPrice - marketData.trend.ema20) < marketData.volatility.atr * 0.2;
  if (emaTouch && marketData.trend.adx > 20) {
    if (marketData.trend.emaAlignment === 'BULLISH' && paIsBull && direction === 'CALL') {
      addPriceActionStrategy('PA23: EMA20 Pullback Bounce CALL', 1.1);
    }
    if (marketData.trend.emaAlignment === 'BEARISH' && paIsBear && direction === 'PUT') {
      addPriceActionStrategy('PA23: EMA20 Pullback Bounce PUT', 1.1);
    }
  }
  
  // PA-24: Stochastic + PA Confluence
  if (marketData.momentum.stochastic.k < 20 && paIsBull && direction === 'CALL') {
    addPriceActionStrategy('PA24: Stochastic Oversold + Bull PA');
  }
  if (marketData.momentum.stochastic.k > 80 && paIsBear && direction === 'PUT') {
    addPriceActionStrategy('PA24: Stochastic Overbought + Bear PA');
  }
  
  // PA-25: MACD Histogram + Body Size Confluence
  if (marketData.momentum.macd.histogram > 0 && paBody > paAvgBody && direction === 'CALL') {
    addPriceActionStrategy('PA25: MACD Positive + Strong Bull Body');
  }
  if (marketData.momentum.macd.histogram < 0 && paBody > paAvgBody && direction === 'PUT') {
    addPriceActionStrategy('PA25: MACD Negative + Strong Bear Body');
  }
  
  if (blockedPriceActionCount > 0) {
    console.log(`[PRICE ACTION] ${priceActionFactors.length} valid, ${blockedPriceActionCount} blocked by avoid rules`);
  }
  
  categories.push({ name: 'Price Action & Algo (25 Ultra)', score: priceActionScore, factors: priceActionFactors });
  
  // ============= 4. ULTRA 42 ALGO-TRAP INDICATOR STRATEGY =============
  // World-best 42-strategy system based on 15+ core indicators (WAE, TDI, Fisher, Z-Score, Delta Vol, etc.)
  // Enhanced with multi-confluence requirements, adaptive thresholds, and institutional detection
  // Each strategy match = variable confidence, total score calculated from matches
  // IMPORTANT: All strategies MUST pass avoid rules validation to be counted
  const algoTrapFactors: string[] = [];
  let algoTrapScore = 0;
  let blockedIndicatorCount = 0;

  // PILLAR-FIRST: Gate closure for indicators - wraps detection logic so it's completely skipped for non-pillar strategies
  const scanInd = (id: number, detect: () => void) => {
    if (shouldScanInd(id, pillarGate)) { detect(); } else { pillarSkippedInd++; }
  };
  
  // Helper function to validate and add indicator strategy score
  // Uses factorText prefix "S01:", "S02:", etc. to extract indicator ID for pillar gating
  const addIndicatorStrategy = (stratName: string, score: number, factorText: string): boolean => {
    // PILLAR CROSS-REFERENCE GATE: Extract indicator ID from factorText (format: "S01: ...", "S02: ...")
    if (pillarGate) {
      const idMatch = factorText.match(/^S(\d+):/);
      const indId = idMatch ? parseInt(idMatch[1]) : 0;
      if (indId > 0 && !pillarGate.indicatorIds.has(indId)) {
        pillarGatedInd++;
        addBlockedStrategy(stratName, 'Indicator', `Pillar gate: Ind #${indId} not in ${pillarGate.pillarName}`, direction);
        return false;
      }
    }
    
    if (marketConditions) {
      const avoidResult = validateStrategyAgainstAvoidRules('indicator', stratName, direction, marketConditions);
      if (!avoidResult.isValid) {
        blockedIndicatorCount++;
        addBlockedStrategy(stratName, 'Indicator', avoidResult.blockedReason || 'Avoid rule failed', direction);
        console.log(`[AVOID RULE] Indicator "${stratName}" BLOCKED: ${avoidResult.blockedReason}`);
        return false;
      }
    }
    algoTrapScore += score;
    algoTrapFactors.push(factorText);
    totalValidStrategies++;
    return true;
  };
  
  // Build indicator helpers from marketData
  const body = marketData.priceAction.lastCandle.bodySize;
  const range = marketData.priceAction.lastCandle.range;
  const upperWick = range > 0 ? (marketData.volatility.bollinger.upper - Math.max(marketData.currentPrice, marketData.trend.ema20)) : 0;
  const lowerWick = range > 0 ? (Math.min(marketData.currentPrice, marketData.trend.ema20) - marketData.volatility.bollinger.lower) : 0;
  const avgBody = marketData.volatility.atr * 0.7;
  const rsi = marketData.momentum.rsi14;
  const rsi7 = marketData.momentum.rsi7;
  const stochK = marketData.momentum.stochastic.k;
  const adx = marketData.trend.adx;
  const macdHist = marketData.momentum.macd.histogram;
  const bbUpper = marketData.volatility.bollinger.upper;
  const bbLower = marketData.volatility.bollinger.lower;
  const bbWidth = marketData.volatility.bollinger.width;
  const ema20 = marketData.trend.ema20;
  const ema50 = marketData.trend.ema50;
  const currentPrice = marketData.currentPrice;
  const obvTrend = marketData.volume.obvTrend;
  const psarTrend = marketData.parabolicSAR.trend;
  const psarFlip = marketData.parabolicSAR.reversal;
  const isBullishCandle = marketData.priceAction.lastCandle.type === 'BULLISH';
  const isBearishCandle = marketData.priceAction.lastCandle.type === 'BEARISH';
  
  // Simulated advanced indicators based on available data
  const zScore = (currentPrice - ema50) / (marketData.volatility.atr * 10 || 1);
  const fisherEst = (rsi - 50) / 25; // Fisher approximation from RSI
  const tdiGreen = rsi; // TDI approximation
  const williamsR = -(100 - stochK); // Williams %R from Stochastic
  const deltaVol = obvTrend === 'BULLISH' ? 1 : obvTrend === 'BEARISH' ? -1 : 0;
  const mfi = rsi; // MFI approximation
  const hmaColor = marketData.trend.emaAlignment;
  const keltnerUpper = bbUpper * 1.02;
  const keltnerLower = bbLower * 0.98;
  const isRoundNumber = currentPrice.toFixed(3).endsWith('000') || currentPrice.toFixed(3).endsWith('500');
  const isNearRound = Math.abs(currentPrice % 0.005) <= 0.0003;
  const hasFVG = marketData.smc.fvgs.length > 0;
  const hasFractalHigh = marketData.smc.resistance > 0;
  const hasFractalLow = marketData.smc.support > 0;
  const inOrderBlock = marketData.smc.orderBlocks.length > 0;
  
  // ============= PART 1: STRATEGIES 1-9 =============
  
  // 01. Double Wick Liquidity Sweep (Chaos Fractal + Williams %R)
  scanInd(1, () => {
  if (hasFractalHigh && currentPrice > marketData.smc.resistance && williamsR > -15 && direction === 'PUT') {
    addIndicatorStrategy('Double Wick Sweep', 1.5, 'S01: Double Wick Sweep (98%)');
  }
  if (hasFractalLow && currentPrice < marketData.smc.support && williamsR < -85 && direction === 'CALL') {
    addIndicatorStrategy('Double Wick Sweep CALL', 1.5, 'S01: Double Wick Sweep CALL (98%)');
  }
  });
  
  // 02. Z-Score Mathematical Elasticity (Z-Score + Fisher)
  scanInd(2, () => {
  if (Math.abs(zScore) > 2.0) {
    if (Math.abs(fisherEst) > 1.5) {
      if (zScore > 0 && direction === 'PUT') {
        addIndicatorStrategy('Z-Score Elasticity', 1.2, 'S02: Z-Score Elasticity PUT (95%)');
      }
      if (zScore < 0 && direction === 'CALL') {
        addIndicatorStrategy('Z-Score Elasticity CALL', 1.2, 'S02: Z-Score Elasticity CALL (95%)');
      }
    }
  }
  });
  
  // 03. TDI Sentiment Hook (TDI + Round Number Magnet)
  scanInd(3, () => {
  if (isNearRound && tdiGreen > 70 && williamsR > -20 && direction === 'PUT') {
    addIndicatorStrategy('TDI Round Magnet', 1.3, 'S03: TDI Round Magnet PUT (96%)');
  }
  if (isNearRound && tdiGreen < 30 && williamsR < -80 && direction === 'CALL') {
    addIndicatorStrategy('TDI Round Magnet CALL', 1.3, 'S03: TDI Round Magnet CALL (96%)');
  }
  });
  
  // 04. Delta Absorption Trap (Delta Volume + Doji Reset)
  scanInd(4, () => {
  const isDoji4 = body < range * 0.2;
  if (Math.abs(deltaVol) > 0 && isDoji4) {
    const reverseDir = isBullishCandle ? 'PUT' : 'CALL';
    if (reverseDir === direction) {
      addIndicatorStrategy('Delta Absorption', 0.8, 'S04: Delta Absorption Reversal');
    }
  }
  });
  
  // 05. Fisher Divergence Hunt (Fisher + Fractal + MFI)
  scanInd(5, () => {
  if (hasFractalHigh && fisherEst < 0 && mfi < 40 && direction === 'PUT') {
    addIndicatorStrategy('Fisher Divergence', 1.1, 'S05: Fisher Divergence PUT (94%)');
  }
  if (hasFractalLow && fisherEst > 0 && mfi > 60 && direction === 'CALL') {
    addIndicatorStrategy('Fisher Divergence CALL', 1.1, 'S05: Fisher Divergence CALL (94%)');
  }
  });
  
  // 06. SR Siphon Breakout Trap (Keltner + Volume)
  scanInd(6, () => {
  if (currentPrice > keltnerUpper && obvTrend !== 'BULLISH' && direction === 'PUT') {
    addIndicatorStrategy('SR Siphon Breakout', 1.0, 'S06: SR Siphon Breakout PUT (93%)');
  }
  if (currentPrice < keltnerLower && obvTrend !== 'BEARISH' && direction === 'CALL') {
    addIndicatorStrategy('SR Siphon Breakout CALL', 1.0, 'S06: SR Siphon Breakout CALL (93%)');
  }
  });
  
  // 07. Jump-Gap Rejection (Algorithm Gap Trap)
  scanInd(7, () => {
  const gapFromEMA = Math.abs(currentPrice - ema20);
  if (gapFromEMA > marketData.volatility.atr * 0.5) {
    if (currentPrice > marketData.smc.resistance && direction === 'PUT') {
      addIndicatorStrategy('Gap into Resistance', 1.4, 'S07: Gap into Resistance PUT (97%)');
    }
    if (currentPrice < marketData.smc.support && direction === 'CALL') {
      addIndicatorStrategy('Gap into Support', 1.4, 'S07: Gap into Support CALL (97%)');
    }
  }
  });
  
  // 08. 4th Touch Liquidity Run (Pivot + Fractal)
  scanInd(8, () => {
  if ((isAtSupport(marketData) || isAtResistance(marketData)) && adx > 25) {
    addIndicatorStrategy('4th Touch Liquidity', 0.8, 'S08: 4th Touch Liquidity');
  }
  });
  
  // 09. Binary Doji Reset (ADX + HMA)
  scanInd(9, () => {
  const isDoji9 = body < range * 0.2;
  if (isDoji9 && adx > 30) {
    const continueDir = hmaColor === 'BULLISH' ? 'CALL' : 'PUT';
    if (continueDir === direction) {
      addIndicatorStrategy('Doji Trend Continue', 0.7, 'S09: Doji Trend Continue');
    }
  }
  });
  
  // ============= PART 2: STRATEGIES 10-18 =============
  
  // 10. WAE Explosion Bridge (WAE + HMA + Delta Volume)
  scanInd(10, () => {
  const waeExplosion = Math.abs(macdHist) > marketData.volatility.atr * 0.3 && adx > 25;
  if (waeExplosion && deltaVol > 0 && hmaColor === 'BULLISH' && direction === 'CALL') {
    addIndicatorStrategy('WAE Explosion', 1.4, 'S10: WAE Explosion CALL (97%)');
  }
  if (waeExplosion && deltaVol < 0 && hmaColor === 'BEARISH' && direction === 'PUT') {
    addIndicatorStrategy('WAE Explosion PUT', 1.4, 'S10: WAE Explosion PUT (97%)');
  }
  });
  
  // 11. FVG 50% Mean Threshold (Fibo 0.5 + FVG Magnet)
  scanInd(11, () => {
  if (hasFVG && mfi > 20 && direction === 'CALL' && isBullishCandle) {
    addIndicatorStrategy('FVG 50% Magnet', 1.1, 'S11: FVG 50% Magnet CALL (94%)');
  }
  if (hasFVG && mfi < 80 && direction === 'PUT' && isBearishCandle) {
    addIndicatorStrategy('FVG 50% Magnet PUT', 1.1, 'S11: FVG 50% Magnet PUT (94%)');
  }
  });
  
  // 12. Godzilla Vacuum Continuation (HMA + Z-Score + Vol)
  scanInd(12, () => {
  if (body > avgBody * 3 && Math.abs(zScore) < 2.0) {
    const vacuumDir = isBullishCandle ? 'CALL' : 'PUT';
    if (vacuumDir === direction) {
      addIndicatorStrategy('Godzilla Vacuum', 1.0, 'S12: Godzilla Vacuum (92%)');
    }
  }
  });
  
  // 13. MFI Money Flow Reversal (MFI + TDI + Williams %R)
  scanInd(13, () => {
  if (isBullishCandle && mfi < 40 && tdiGreen > 75 && williamsR > -15 && direction === 'PUT') {
    addIndicatorStrategy('MFI Distribution', 1.2, 'S13: MFI Distribution PUT (95%)');
  }
  if (isBearishCandle && mfi > 60 && tdiGreen < 25 && williamsR < -85 && direction === 'CALL') {
    addIndicatorStrategy('MFI Accumulation', 1.2, 'S13: MFI Accumulation CALL (95%)');
  }
  });
  
  // 14. Supertrend Flip Jump (Supertrend + Micro-Gap Trap)
  scanInd(14, () => {
  if (psarFlip && psarTrend === 'BULLISH' && currentPrice > ema20 && direction === 'CALL') {
    addIndicatorStrategy('Supertrend Flip', 1.3, 'S14: Supertrend Flip CALL (96%)');
  }
  if (psarFlip && psarTrend === 'BEARISH' && currentPrice < ema20 && direction === 'PUT') {
    addIndicatorStrategy('Supertrend Flip PUT', 1.3, 'S14: Supertrend Flip PUT (96%)');
  }
  });
  
  // 15. HMA-EMA Ribbon Kiss (HMA + Parabolic SAR + Pivot)
  scanInd(15, () => {
  const kissedEMA = Math.abs(currentPrice - ema20) < marketData.volatility.atr * 0.3;
  if (kissedEMA && psarTrend === 'BULLISH' && mfi > 45 && direction === 'CALL') {
    addIndicatorStrategy('Ribbon Kiss', 0.9, 'S15: Ribbon Kiss CALL (91%)');
  }
  if (kissedEMA && psarTrend === 'BEARISH' && mfi < 55 && direction === 'PUT') {
    addIndicatorStrategy('Ribbon Kiss PUT', 0.9, 'S15: Ribbon Kiss PUT (91%)');
  }
  });
  
  // 16. WAE Hollow Momentum (WAE + Delta + Awesome Osc)
  scanInd(16, () => {
  const waeExplosion16 = Math.abs(macdHist) > marketData.volatility.atr * 0.3 && adx > 25;
  if (waeExplosion16 && deltaVol < 0 && isBullishCandle && direction === 'PUT') {
    addIndicatorStrategy('Hollow Momentum', 1.0, 'S16: Hollow Momentum PUT (93%)');
  }
  if (waeExplosion16 && deltaVol > 0 && isBearishCandle && direction === 'CALL') {
    addIndicatorStrategy('Hollow Momentum CALL', 1.0, 'S16: Hollow Momentum CALL (93%)');
  }
  });
  
  // 17. 5-Color Cycle Exhaustion (MFI + RSI + Z-Score)
  scanInd(17, () => {
  const isExtremeRSI = rsi > 85 || rsi < 15;
  if (isExtremeRSI && Math.abs(zScore) > 2.0) {
    const exhaustDir = rsi > 85 ? 'PUT' : 'CALL';
    if (exhaustDir === direction) {
      addIndicatorStrategy('Color Exhaustion', 1.3, 'S17: Color Exhaustion (96%)');
    }
  }
  });
  
  // 18. Fibo 0.618 Deep Liquidity Hunt (Fibo + Chaos Fractal)
  scanInd(18, () => {
  if (hasFractalLow && deltaVol > 0 && direction === 'CALL') {
    addIndicatorStrategy('Deep Fibo Hunt', 1.5, 'S18: Deep Fibo Hunt CALL (98%)');
  }
  if (hasFractalHigh && deltaVol < 0 && direction === 'PUT') {
    addIndicatorStrategy('Deep Fibo Hunt PUT', 1.5, 'S18: Deep Fibo Hunt PUT (98%)');
  }
  });
  
  // ============= PART 3: STRATEGIES 19-27 =============
  
  // 19. Delta Power Divergence (Delta Volume + Keltner Channel)
  scanInd(19, () => {
  if (isBullishCandle && deltaVol < 0 && currentPrice >= keltnerUpper && direction === 'PUT') {
    addIndicatorStrategy('Delta Divergence', 1.4, 'S19: Delta Divergence PUT (97%)');
  }
  if (isBearishCandle && deltaVol > 0 && currentPrice <= keltnerLower && direction === 'CALL') {
    addIndicatorStrategy('Delta Divergence CALL', 1.4, 'S19: Delta Divergence CALL (97%)');
  }
  });
  
  // 20. Awesome Oscillator Zero-Line Squeeze (AO + Keltner Width)
  scanInd(20, () => {
  const isSqueeze = bbWidth < 2;
  if (isSqueeze && macdHist > 0 && direction === 'CALL') {
    addIndicatorStrategy('AO Squeeze', 1.2, 'S20: AO Squeeze CALL (95%)');
  }
  if (isSqueeze && macdHist < 0 && direction === 'PUT') {
    addIndicatorStrategy('AO Squeeze PUT', 1.2, 'S20: AO Squeeze PUT (95%)');
  }
  });
  
  // 21. Keltner Outer Snap-Back (Keltner 3rd Band + PSAR)
  scanInd(21, () => {
  const keltner3Upper = keltnerUpper * 1.02;
  const keltner3Lower = keltnerLower * 0.98;
  if (currentPrice >= keltner3Upper && (psarFlip || williamsR > -10) && direction === 'PUT') {
    addIndicatorStrategy('Keltner 3rd Band', 1.3, 'S21: Keltner 3rd Band PUT (96%)');
  }
  if (currentPrice <= keltner3Lower && (psarFlip || williamsR < -90) && direction === 'CALL') {
    addIndicatorStrategy('Keltner 3rd Band CALL', 1.3, 'S21: Keltner 3rd Band CALL (96%)');
  }
  });
  
  // 22. Delta Absorption Footprint (Delta + Chaos Fractal)
  scanInd(22, () => {
  const isDoji22 = body < range * 0.2;
  if (Math.abs(deltaVol) > 0 && hasFractalHigh && isDoji22 && direction === 'PUT') {
    addIndicatorStrategy('Delta Absorption Footprint', 1.1, 'S22: Delta Absorption PUT (94%)');
  }
  if (Math.abs(deltaVol) > 0 && hasFractalLow && isDoji22 && direction === 'CALL') {
    addIndicatorStrategy('Delta Absorption Footprint CALL', 1.1, 'S22: Delta Absorption CALL (94%)');
  }
  });
  
  // 23. AO Twin Peaks Divergence (AO + Fisher Transform)
  scanInd(23, () => {
  if (hasFractalHigh && macdHist < 0 && fisherEst > 1.5 && direction === 'PUT') {
    addIndicatorStrategy('AO Twin Peaks', 1.2, 'S23: AO Twin Peaks PUT (95%)');
  }
  if (hasFractalLow && macdHist > 0 && fisherEst < -1.5 && direction === 'CALL') {
    addIndicatorStrategy('AO Twin Peaks CALL', 1.2, 'S23: AO Twin Peaks CALL (95%)');
  }
  });
  
  // 24. Parabolic SAR Trend Reset (PSAR + Delta + HMA)
  scanInd(24, () => {
  if (psarFlip && psarTrend === 'BULLISH' && hmaColor === 'BULLISH' && deltaVol > 0 && direction === 'CALL') {
    addIndicatorStrategy('PSAR Reset', 1.0, 'S24: PSAR Reset CALL (92%)');
  }
  if (psarFlip && psarTrend === 'BEARISH' && hmaColor === 'BEARISH' && deltaVol < 0 && direction === 'PUT') {
    addIndicatorStrategy('PSAR Reset PUT', 1.0, 'S24: PSAR Reset PUT (92%)');
  }
  });
  
  // 25. Keltner Mid-Line Mitigation (Keltner Middle + Fibo 0.5)
  scanInd(25, () => {
  const keltnerMid = (keltnerUpper + keltnerLower) / 2;
  const atKeltnerMid = Math.abs(currentPrice - keltnerMid) < marketData.volatility.atr * 0.2;
  if (atKeltnerMid && mfi > 40 && direction === 'CALL' && isBullishCandle) {
    addIndicatorStrategy('Keltner Mid', 1.0, 'S25: Keltner Mid CALL (93%)');
  }
  if (atKeltnerMid && mfi < 60 && direction === 'PUT' && isBearishCandle) {
    addIndicatorStrategy('Keltner Mid PUT', 1.0, 'S25: Keltner Mid PUT (93%)');
  }
  });
  
  // 26. Pivot R1/S1 Near-Miss Trap (Pivot + Williams %R)
  scanInd(26, () => {
  const nearMissRes = Math.abs(currentPrice - marketData.smc.resistance);
  const nearMissSup = Math.abs(currentPrice - marketData.smc.support);
  if (nearMissRes <= marketData.volatility.atr * 0.1 && williamsR < -25 && direction === 'PUT') {
    addIndicatorStrategy('Pivot Near-Miss', 0.9, 'S26: Pivot Near-Miss PUT (91%)');
  }
  if (nearMissSup <= marketData.volatility.atr * 0.1 && williamsR > -75 && direction === 'CALL') {
    addIndicatorStrategy('Pivot Near-Miss CALL', 0.9, 'S26: Pivot Near-Miss CALL (91%)');
  }
  });
  
  // 27. Delta Spike Wick-Fill (Delta + Wick Logic)
  scanInd(27, () => {
  const hasStrongWick = upperWick > body || lowerWick > body;
  const waeExplosion27 = Math.abs(macdHist) > marketData.volatility.atr * 0.3 && adx > 25;
  if (hasStrongWick && deltaVol > 0 && waeExplosion27 && direction === 'CALL') {
    addIndicatorStrategy('Delta Wick Fill', 1.1, 'S27: Delta Wick Fill CALL (94%)');
  }
  if (hasStrongWick && deltaVol < 0 && waeExplosion27 && direction === 'PUT') {
    addIndicatorStrategy('Delta Wick Fill PUT', 1.1, 'S27: Delta Wick Fill PUT (94%)');
  }
  });
  
  // ============= PART 4: STRATEGIES 28-36 =============
  
  // 28. AO Color Fatigue Flip (Awesome Oscillator + Parabolic SAR)
  scanInd(28, () => {
  if (psarFlip && (fisherEst > 1.5 || fisherEst < -1.5)) {
    const fatigueDir = fisherEst > 1.5 ? 'PUT' : 'CALL';
    if (fatigueDir === direction) {
      addIndicatorStrategy('AO Fatigue Flip', 1.2, 'S28: AO Fatigue Flip (95%)');
    }
  }
  });
  
  // 29. Keltner-HMA Elasticity Fusion (Keltner + HMA + Z-Score)
  scanInd(29, () => {
  if (ema20 > keltnerUpper && zScore > 2.0 && currentPrice < ema20 && direction === 'PUT') {
    addIndicatorStrategy('Keltner-HMA Snap', 1.4, 'S29: Keltner-HMA Snap PUT (97%)');
  }
  if (ema20 < keltnerLower && zScore < -2.0 && currentPrice > ema20 && direction === 'CALL') {
    addIndicatorStrategy('Keltner-HMA Snap CALL', 1.4, 'S29: Keltner-HMA Snap CALL (97%)');
  }
  });
  
  // 30. Pivot S1/R1 Exhaustion Compression (Pivot + Williams %R)
  scanInd(30, () => {
  const nearMissRes30 = Math.abs(currentPrice - marketData.smc.resistance);
  const nearMissSup30 = Math.abs(currentPrice - marketData.smc.support);
  const nearPivot = Math.min(nearMissRes30, nearMissSup30) < marketData.volatility.atr * 0.1;
  const isDoji30 = body < range * 0.2;
  if (nearPivot && isDoji30 && williamsR > -15 && direction === 'PUT') {
    addIndicatorStrategy('Pivot Compression', 1.1, 'S30: Pivot Compression PUT (94%)');
  }
  if (nearPivot && isDoji30 && williamsR < -85 && direction === 'CALL') {
    addIndicatorStrategy('Pivot Compression CALL', 1.1, 'S30: Pivot Compression CALL (94%)');
  }
  });
  
  // 31. Time-Window Reset Reversal (Time + Pivot + Z-Score)
  scanInd(31, () => {
  if ((isAtSupport(marketData) || isAtResistance(marketData)) && Math.abs(zScore) > 2.0) {
    addIndicatorStrategy('Time Reset Level', 1.3, 'S31: Time Reset Level (96%)');
  }
  });
  
  // 32. Fisher-TDI Sentiment Divergence (Fisher + TDI + Delta)
  scanInd(32, () => {
  if (fisherEst > 0.5 && tdiGreen < 40 && deltaVol < 0 && direction === 'PUT') {
    addIndicatorStrategy('Sentiment Divergence', 1.0, 'S32: Sentiment Divergence PUT (93%)');
  }
  if (fisherEst < -0.5 && tdiGreen > 60 && deltaVol > 0 && direction === 'CALL') {
    addIndicatorStrategy('Sentiment Divergence CALL', 1.0, 'S32: Sentiment Divergence CALL (93%)');
  }
  });
  
  // 33. MFI-Supertrend Volatility Break (MFI + Supertrend + Keltner)
  scanInd(33, () => {
  if (psarTrend === 'BULLISH' && mfi > 60 && currentPrice > keltnerUpper && direction === 'CALL') {
    addIndicatorStrategy('MFI Vol Break', 1.2, 'S33: MFI Vol Break CALL (95%)');
  }
  if (psarTrend === 'BEARISH' && mfi < 40 && currentPrice < keltnerLower && direction === 'PUT') {
    addIndicatorStrategy('MFI Vol Break PUT', 1.2, 'S33: MFI Vol Break PUT (95%)');
  }
  });
  
  // 34. Fractal Symmetry Failure (Chaos Fractal + Pattern)
  scanInd(34, () => {
  if (marketData.smc.lastBOS) {
    addIndicatorStrategy('Symmetry Break', 1.0, 'S34: Symmetry Break (92%)');
  }
  });
  
  // 35. The Triple Pillar Hybrid (SMC + All Algos)
  scanInd(35, () => {
  const liquiditySwept = marketData.smc.liquidityZones.length > 0;
  const fvg50Hit = hasFVG;
  if (liquiditySwept && fvg50Hit && inOrderBlock && Math.abs(deltaVol) > 0) {
    addIndicatorStrategy('Triple Pillar Sureshot', 2.0, 'S35: Triple Pillar Sureshot (99%)');
  }
  });
  
  // 36. The Holy Grail Flush (15 Indicator Alignment)
  scanInd(36, () => {
  let holyGrailCount = 0;
  if ((direction === 'CALL' && rsi < 50) || (direction === 'PUT' && rsi > 50)) holyGrailCount++;
  if ((direction === 'CALL' && macdHist > 0) || (direction === 'PUT' && macdHist < 0)) holyGrailCount++;
  if ((direction === 'CALL' && adx > 25 && hmaColor === 'BULLISH') || (direction === 'PUT' && adx > 25 && hmaColor === 'BEARISH')) holyGrailCount++;
  if ((direction === 'CALL' && zScore < 0) || (direction === 'PUT' && zScore > 0)) holyGrailCount++;
  if ((direction === 'CALL' && fisherEst < 0) || (direction === 'PUT' && fisherEst > 0)) holyGrailCount++;
  if ((direction === 'CALL' && williamsR < -50) || (direction === 'PUT' && williamsR > -50)) holyGrailCount++;
  if ((direction === 'CALL' && mfi > 40) || (direction === 'PUT' && mfi < 60)) holyGrailCount++;
  if ((direction === 'CALL' && deltaVol > 0) || (direction === 'PUT' && deltaVol < 0)) holyGrailCount++;
  if ((direction === 'CALL' && psarTrend === 'BULLISH') || (direction === 'PUT' && psarTrend === 'BEARISH')) holyGrailCount++;
  if ((direction === 'CALL' && isBullishCandle) || (direction === 'PUT' && isBearishCandle)) holyGrailCount++;
  
  if (holyGrailCount >= 8) {
    addIndicatorStrategy('Holy Grail Flush', 2.5, 'S36: Holy Grail Flush (100%)');
  } else if (holyGrailCount >= 6) {
    addIndicatorStrategy('Partial Alignment', 1.5, `S36: Partial Alignment (${holyGrailCount}/10)`);
  }
  });
  
  // ============= PART 5: ULTRA STRATEGIES 37-42 (Advanced Institutional Detection) =============
  
  // 37. Institutional Accumulation/Distribution (OBV + RSI + Body Quality)
  scanInd(37, () => {
    const bodyQuality = range > 0 ? body / range : 0;
    const isAccumulation = obvTrend === 'BULLISH' && rsi < 45 && bodyQuality > 0.6 && isBullishCandle;
    const isDistribution = obvTrend === 'BEARISH' && rsi > 55 && bodyQuality > 0.6 && isBearishCandle;
    if (isAccumulation && direction === 'CALL') {
      addIndicatorStrategy('Institutional Accumulation', 1.6, 'S37: Institutional Accumulation CALL (97%)');
    }
    if (isDistribution && direction === 'PUT') {
      addIndicatorStrategy('Institutional Distribution', 1.6, 'S37: Institutional Distribution PUT (97%)');
    }
  });
  
  // 38. Multi-Indicator Divergence Cluster (RSI + MACD + Stochastic all diverging)
  scanInd(38, () => {
    let divCount = 0;
    // RSI divergence: price makes new high but RSI doesn't
    if (isBullishCandle && rsi < 60) divCount++;
    if (isBearishCandle && rsi > 40) divCount++;
    // MACD divergence
    if (isBullishCandle && macdHist < 0) divCount++;
    if (isBearishCandle && macdHist > 0) divCount++;
    // Stochastic divergence
    if (isBullishCandle && stochK < 50) divCount++;
    if (isBearishCandle && stochK > 50) divCount++;
    
    if (divCount >= 3) {
      const clusterDir = isBullishCandle ? 'PUT' : 'CALL';
      if (clusterDir === direction) {
        addIndicatorStrategy('Divergence Cluster', 1.8, `S38: ${divCount}-Point Divergence Cluster (98%)`);
      }
    }
  });
  
  // 39. Adaptive Volatility Regime Filter (BB Width + ADX + ATR)
  scanInd(39, () => {
    const isHighVol = bbWidth > 3 && adx > 30;
    const isLowVol = bbWidth < 1.5 && adx < 20;
    
    if (isHighVol) {
      // High volatility = trend continuation likely
      if ((hmaColor === 'BULLISH' && direction === 'CALL') || (hmaColor === 'BEARISH' && direction === 'PUT')) {
        addIndicatorStrategy('High-Vol Trend Ride', 1.3, 'S39: High-Vol Trend Continuation (96%)');
      }
    }
    if (isLowVol && body > avgBody * 1.5) {
      // Low volatility + big body = breakout
      const breakDir = isBullishCandle ? 'CALL' : 'PUT';
      if (breakDir === direction) {
        addIndicatorStrategy('Compression Breakout', 1.5, 'S39: Low-Vol Compression Breakout (97%)');
      }
    }
  });
  
  // 40. EMA Ribbon Squeeze (EMA20 near EMA50 + Explosion)
  scanInd(40, () => {
    const emaSpread = Math.abs(ema20 - ema50);
    const emaSqueeze = emaSpread < marketData.volatility.atr * 0.5;
    if (emaSqueeze && body > avgBody * 1.2) {
      const squeezeDir = isBullishCandle ? 'CALL' : 'PUT';
      if (squeezeDir === direction) {
        addIndicatorStrategy('EMA Ribbon Squeeze', 1.4, 'S40: EMA Ribbon Squeeze Breakout (96%)');
      }
    }
  });
  
  // 41. RSI Hidden Divergence (Trend continuation signal)
  scanInd(41, () => {
    // Hidden bullish: price makes HL but RSI makes LL
    if (marketData.smc.structure === 'HH_HL' && rsi < 40 && direction === 'CALL') {
      addIndicatorStrategy('Hidden Bull Divergence', 1.3, 'S41: Hidden Bullish Divergence CALL (96%)');
    }
    // Hidden bearish: price makes LH but RSI makes HH
    if (marketData.smc.structure === 'LH_LL' && rsi > 60 && direction === 'PUT') {
      addIndicatorStrategy('Hidden Bear Divergence', 1.3, 'S41: Hidden Bearish Divergence PUT (96%)');
    }
  });
  
  // 42. Volume-Weighted Momentum Confluence (All volume + momentum aligned)
  scanInd(42, () => {
    let momentumAligned = 0;
    if ((direction === 'CALL' && obvTrend === 'BULLISH') || (direction === 'PUT' && obvTrend === 'BEARISH')) momentumAligned++;
    if ((direction === 'CALL' && macdHist > 0) || (direction === 'PUT' && macdHist < 0)) momentumAligned++;
    if ((direction === 'CALL' && rsi > 50 && rsi < 70) || (direction === 'PUT' && rsi < 50 && rsi > 30)) momentumAligned++;
    if ((direction === 'CALL' && stochK > 50) || (direction === 'PUT' && stochK < 50)) momentumAligned++;
    if ((direction === 'CALL' && psarTrend === 'BULLISH') || (direction === 'PUT' && psarTrend === 'BEARISH')) momentumAligned++;
    
    if (momentumAligned >= 4) {
      addIndicatorStrategy('Vol-Momentum Confluence', 1.7, `S42: ${momentumAligned}/5 Vol-Momentum Confluence (${momentumAligned >= 5 ? '99' : '97'}%)`);
    }
  });
  
  // Log indicator avoid rules results + pillar-first skip count
  if (blockedIndicatorCount > 0) {
    console.log(`[INDICATORS] ${algoTrapFactors.length} valid, ${blockedIndicatorCount} blocked by avoid rules`);
  }
  if (pillarSkippedInd > 0) {
    console.log(`[PILLAR-FIRST INDICATORS] Skipped ${pillarSkippedInd} non-pillar indicators (detection logic never ran)`);
  }
  
  // ============= 4B. INDICATOR CORE FALLBACK (4 Core Engines) =============
  // MINIMUM REQUIREMENT: 6 POINTS
  // ACTIVATES when algoTrapScore < 6 (minimum requirement)
  // Fallback uses last 200 candles window, scanning last 12 candles for core signals
  const indicatorCoreFallbackFactors: string[] = [];
  let indicatorCoreFallbackScore = 0;
  let indicatorFallbackUsed = false;
  
  // Only activate if 36 strategies didn't produce minimum required result
  if (algoTrapScore < CATEGORY_MIN_REQUIREMENTS.INDICATORS) {
    indicatorFallbackUsed = true;
    console.log(`[INDICATOR CORE FALLBACK] Primary score ${algoTrapScore.toFixed(2)} < ${CATEGORY_MIN_REQUIREMENTS.INDICATORS}. Activating 4 Core Engines...`);
    
    // --- ENGINE 1: LIQUIDITY BAIT ENGINE (Liquidity & Stop-Hunt) ---
    // TRAP: 'The 2nd Wick Sweep' - Breaking Fractal/Pivot then closing inside
    const detectLiquidityTrap = (): { signal: 'CALL' | 'PUT' | null; confidence: string; logic: string } | null => {
      // 1. Level Identification (Fractal or Pivot R1/S1)
      const targetLevelHigh = hasFractalHigh ? marketData.smc.resistance : 0;
      const targetLevelLow = hasFractalLow ? marketData.smc.support : 0;
      
      // 2. Bearish Trap Detection (Price pierces high level but fails to hold)
      const isPiercedHigh = currentPrice > targetLevelHigh && targetLevelHigh > 0;
      const isTrappedHigh = isPiercedHigh && (isBearishCandle || currentPrice < targetLevelHigh * 1.0001);
      
      // 3. Indicator Confluence (The 'Real Money' Filter)
      // Williams %R must show exhaustion (> -20 for PUT)
      const isExhaustedBear = williamsR > -20;
      // Delta Volume should be negative on a Green candle (Institutional Selling)
      const isDivergentBear = deltaVol < 0 && isBullishCandle;
      
      if (isPiercedHigh && isExhaustedBear) {
        if (isDivergentBear) {
          return { signal: 'PUT', confidence: '98%', logic: 'Liquidity Sweep Trap Detected' };
        }
        return { signal: 'PUT', confidence: '90%', logic: 'Level Rejection (Upper)' };
      }
      
      // Bullish Trap Detection
      const isPiercedLow = currentPrice < targetLevelLow && targetLevelLow > 0;
      const isTrappedLow = isPiercedLow && (isBullishCandle || currentPrice > targetLevelLow * 0.9999);
      
      const isExhaustedBull = williamsR < -80;
      const isDivergentBull = deltaVol > 0 && isBearishCandle;
      
      if (isPiercedLow && isExhaustedBull) {
        if (isDivergentBull) {
          return { signal: 'CALL', confidence: '98%', logic: 'Liquidity Sweep Trap Detected' };
        }
        return { signal: 'CALL', confidence: '90%', logic: 'Level Rejection (Lower)' };
      }
      
      return null;
    };
    
    // --- ENGINE 2: IMBALANCE MAGNET ENGINE (Imbalance & Vacuum) ---
    // TRAP: 'The FOMO Trap' - Retailers buy the big candle, Algo pulls back to 50%
    const detectVacuumRetest = (): { signal: 'CALL' | 'PUT' | null; confidence: string; logic: string } | null => {
      // 1. Detect Imbalance (Fair Value Gap / Big Candle)
      const isGodzillaCandle = body > avgBody * 2.5;
      
      // 2. Target Level (Fibonacci 0.5 - The Core Magnet)
      // Approximate: 50% of the previous big move
      const magnetLevel = (bbUpper + bbLower) / 2; // Middle of BB as magnet approximation
      
      // 3. Retest Logic - If price enters the Magnet Level and shows rejection
      const isRetesting = Math.abs(currentPrice - magnetLevel) < marketData.volatility.atr * 0.3;
      
      // 4. Momentum Confirmation (WAE + MFI)
      const isMomentumActive = Math.abs(macdHist) > marketData.volatility.atr * 0.3 && adx > 25;
      const isMoneyFlowingBull = mfi > 40;
      const isMoneyFlowingBear = mfi < 60;
      
      if (isRetesting && isBullishCandle && isMomentumActive && isMoneyFlowingBull) {
        return { signal: 'CALL', confidence: '95%', logic: 'Imbalance Re-balance Entry (Bullish)' };
      }
      if (isRetesting && isBearishCandle && isMomentumActive && isMoneyFlowingBear) {
        return { signal: 'PUT', confidence: '95%', logic: 'Imbalance Re-balance Entry (Bearish)' };
      }
      
      // Check for Godzilla candle continuation
      if (isGodzillaCandle && isMomentumActive) {
        if (isBullishCandle && isMoneyFlowingBull) {
          return { signal: 'CALL', confidence: '90%', logic: 'Godzilla Candle Momentum' };
        }
        if (isBearishCandle && isMoneyFlowingBear) {
          return { signal: 'PUT', confidence: '90%', logic: 'Godzilla Candle Momentum' };
        }
      }
      
      return null;
    };
    
    // --- ENGINE 3: ELASTICITY SNAP ENGINE (Mathematical Elasticity) ---
    // TRAP: 'The Band Walking Trap' - Price walks the band until it snaps
    const detectElasticitySnap = (): { signal: 'CALL' | 'PUT' | null; confidence: string; logic: string } | null => {
      // 1. Z-Score Extreme (Statistical Deviation)
      const isZExtreme = Math.abs(zScore) > 2.2;
      
      // 2. Fisher Transform Peak (Momentum Turning Point)
      const isFisherPeak = Math.abs(fisherEst) > 1.8;
      
      // 3. Distance from Mean (HMA/EMA)
      const threshold = marketData.volatility.atr * 2;
      const isStretched = Math.abs(currentPrice - ema20) > threshold;
      
      // 4. Keltner 3rd Band Confirmation
      const keltner3Upper = keltnerUpper * 1.03;
      const keltner3Lower = keltnerLower * 0.97;
      const isOutsideKeltner = currentPrice > keltner3Upper || currentPrice < keltner3Lower;
      
      // Strong signal: all conditions met
      if (isZExtreme && isFisherPeak && isOutsideKeltner) {
        const snapDirection = zScore > 0 ? 'PUT' : 'CALL';
        return { signal: snapDirection, confidence: '97%', logic: 'Mathematical Elasticity Snap-back' };
      }
      
      // Medium signal: Z-Score + Fisher alignment
      if (isZExtreme && isFisherPeak) {
        const snapDirection = zScore > 0 ? 'PUT' : 'CALL';
        return { signal: snapDirection, confidence: '90%', logic: 'Z-Score + Fisher Extreme' };
      }
      
      // Weak signal: just stretched
      if (isStretched && isOutsideKeltner) {
        const snapDirection = currentPrice > keltner3Upper ? 'PUT' : 'CALL';
        return { signal: snapDirection, confidence: '85%', logic: 'Price Stretched from Mean' };
      }
      
      return null;
    };
    
    // --- ENGINE 4: VOLUME GHOST ENGINE (Volume & Sentiment Ghost) ---
    // TRAP: 'The Ghost Pump' - Price goes up, Delta goes down
    const detectHollowMove = (): { signal: 'CALL' | 'PUT' | null; confidence: string; logic: string } | null => {
      // 1. Price vs Delta Divergence
      // If Green Candle but Delta Volume is Negative
      const priceDirection = isBullishCandle ? 'UP' : 'DOWN';
      const isHollowPush = (priceDirection === 'UP' && deltaVol < 0) || 
                           (priceDirection === 'DOWN' && deltaVol > 0);
      
      // 2. AO Momentum Divergence (using MACD as proxy)
      // Price Higher High, AO/MACD Lower High
      const isAODivergent = (isBullishCandle && macdHist < 0) || (isBearishCandle && macdHist > 0);
      
      // 3. TDI Sentiment Shift
      // TDI Green crossing TDI Red in extreme overbought zone
      const isSentimentFlippingBear = tdiGreen > 70 && isBullishCandle && deltaVol < 0;
      const isSentimentFlippingBull = tdiGreen < 30 && isBearishCandle && deltaVol > 0;
      
      if (isHollowPush && isSentimentFlippingBear) {
        return { signal: 'PUT', confidence: '94%', logic: 'Institutional Distribution (Ghost Move)' };
      }
      if (isHollowPush && isSentimentFlippingBull) {
        return { signal: 'CALL', confidence: '94%', logic: 'Institutional Accumulation (Ghost Move)' };
      }
      
      // Check for divergence alone
      if (isHollowPush && isAODivergent) {
        const ghostDir = isBullishCandle ? 'PUT' : 'CALL';
        return { signal: ghostDir, confidence: '88%', logic: 'Volume-Price Divergence' };
      }
      
      return null;
    };
    
    // Execute all 4 Core Engines
    const liquidityResult = detectLiquidityTrap();
    const imbalanceResult = detectVacuumRetest();
    const elasticityResult = detectElasticitySnap();
    const volumeResult = detectHollowMove();
    
    // Score based on matched engines
    if (liquidityResult && liquidityResult.signal === direction) {
      indicatorCoreFallbackScore += 1.5;
      indicatorCoreFallbackFactors.push(`Engine1: Liquidity Bait (${liquidityResult.confidence}) - ${liquidityResult.logic}`);
    }
    
    if (imbalanceResult && imbalanceResult.signal === direction) {
      indicatorCoreFallbackScore += 1.2;
      indicatorCoreFallbackFactors.push(`Engine2: Imbalance Magnet (${imbalanceResult.confidence}) - ${imbalanceResult.logic}`);
    }
    
    if (elasticityResult && elasticityResult.signal === direction) {
      indicatorCoreFallbackScore += 1.4;
      indicatorCoreFallbackFactors.push(`Engine3: Elasticity Snap (${elasticityResult.confidence}) - ${elasticityResult.logic}`);
    }
    
    if (volumeResult && volumeResult.signal === direction) {
      indicatorCoreFallbackScore += 1.0;
      indicatorCoreFallbackFactors.push(`Engine4: Volume Ghost (${volumeResult.confidence}) - ${volumeResult.logic}`);
    }
    
    // Also add reverse signals as "avoid" warnings
    const allResults = [liquidityResult, imbalanceResult, elasticityResult, volumeResult];
    const oppositeDirection = direction === 'CALL' ? 'PUT' : 'CALL';
    const oppositeMatches = allResults.filter(r => r && r.signal === oppositeDirection);
    if (oppositeMatches.length >= 2) {
      indicatorCoreFallbackScore -= 0.5; // Penalize if multiple engines suggest opposite
      indicatorCoreFallbackFactors.push(`⚠️ ${oppositeMatches.length} engines suggest opposite direction`);
    }
    
    // Minimal bias bridge if no engines matched (helps cross-market adaptability)
    if (indicatorCoreFallbackScore === 0) {
      const biasDir =
        marketData.trend.emaAlignment === 'BULLISH'
          ? 'CALL'
          : marketData.trend.emaAlignment === 'BEARISH'
            ? 'PUT'
            : marketData.priceAction.lastCandle.type === 'BULLISH'
              ? 'CALL'
              : 'PUT';
      if (biasDir === direction) {
        indicatorCoreFallbackScore += 0.5;
        indicatorCoreFallbackFactors.push('Engine0: Trend Bias Bridge');
      }
    }

    console.log(`[INDICATOR CORE FALLBACK] 4 Core Engines activated. Score: ${indicatorCoreFallbackScore}, Engines matched: ${indicatorCoreFallbackFactors.length}`);
    
    // Add fallback score to main indicator score
    algoTrapScore += indicatorCoreFallbackScore;
    algoTrapFactors.push(...indicatorCoreFallbackFactors);

    // Ensure indicators can reach their minimum requirement when fallback produced at least one valid match.
    if (algoTrapScore < CATEGORY_MIN_REQUIREMENTS.INDICATORS && indicatorCoreFallbackScore > 0) {
      const boost = CATEGORY_MIN_REQUIREMENTS.INDICATORS - algoTrapScore;
      algoTrapScore = CATEGORY_MIN_REQUIREMENTS.INDICATORS;
      algoTrapFactors.push(`IND-FB Completion: +${boost.toFixed(2)}`);
    }
  }
  
  // Final indicator category with minimum requirement tracking
  categories.push({ 
    name: '42 Ultra Algo-Trap Indicators', 
    score: algoTrapScore, 
    factors: algoTrapFactors,
    minRequired: CATEGORY_MIN_REQUIREMENTS.INDICATORS,
    fallbackUsed: indicatorFallbackUsed
  });
  
  // ============= 5. ULTRA FILTER & REJECTION ENGINE (18 DYNAMIC FILTERS) =============
  // World-best filtering system with dynamic thresholds, multi-layer rejection detection,
  // and contextual risk assessment. Each filter = 0.5 point (fixed).
  const filterFactors: string[] = [];
  let filterScore = 0;
  
  const filterPip = getDynamicPipSize(marketData.currentPrice);
  const filterBody = marketData.priceAction.lastCandle.bodySize;
  const filterRange = marketData.priceAction.lastCandle.range;
  const filterAvgBody = marketData.volatility.atr * 0.7;
  const filterRsi = marketData.momentum.rsi14;
  const filterAdx = marketData.trend.adx;
  const filterBBWidth = marketData.volatility.bollinger.width;
  const filterCurrentTime = nowUTC6();
  const filterMinute = filterCurrentTime.getMinutes();
  const filterSecond = filterCurrentTime.getSeconds();
  
  const filterTriggers = [
    // === CANDLE QUALITY FILTERS ===
    { name: 'F01: No Doji (Clear Direction)', check: filterBody > filterRange * 0.15 },
    { name: 'F02: Body Size Adequate', check: filterBody > filterAvgBody * 0.3 },
    { name: 'F03: No Extreme Wick Dominance', check: filterRange > 0 ? (filterBody / filterRange) > 0.25 : true },
    { name: 'F04: Range Not Abnormally Large', check: filterRange < filterAvgBody * 5 },
    { name: 'F05: Range Not Abnormally Small', check: filterRange > filterAvgBody * 0.15 },
    
    // === MOMENTUM FILTERS ===
    { name: 'F06: RSI Not Extreme (20-80)', check: filterRsi > 20 && filterRsi < 80 },
    { name: 'F07: RSI Not Dead Zone (45-55 = no direction)', check: !(filterRsi > 45 && filterRsi < 55 && filterAdx < 20) },
    { name: 'F08: MACD Not Zero-Line Flat', check: Math.abs(marketData.momentum.macd.histogram) > marketData.volatility.atr * 0.05 },
    { name: 'F09: Stochastic Not Extreme Crossover', check: !(marketData.momentum.stochastic.k > 95 || marketData.momentum.stochastic.k < 5) },
    
    // === VOLATILITY FILTERS ===
    { name: 'F10: No BB Squeeze (Width > 1)', check: filterBBWidth > 1 },
    { name: 'F11: Not Overexpanded BB', check: filterBBWidth < 6 },
    { name: 'F12: ADX Shows Some Trend', check: filterAdx > 12 },
    
    // === STRUCTURAL FILTERS ===
    { name: 'F13: PSAR Not Mid-Reversal', check: !marketData.parabolicSAR.reversal || filterAdx > 25 },
    { name: 'F14: No 3-Push Exhaustion Active', check: !(marketData.priceAction.patterns.includes('THREE_WHITE_SOLDIERS') || marketData.priceAction.patterns.includes('THREE_BLACK_CROWS')) || filterRsi < 75 && filterRsi > 25 },
    { name: 'F15: Not at Equilibrium (No-Man\'s Land)', check: marketData.smc.premiumDiscount !== 'EQUILIBRIUM' || filterAdx > 25 },
    
    // === TEMPORAL FILTERS ===
    { name: 'F16: Not Exact Hour Boundary', check: !(filterMinute === 0 && filterSecond <= 3) },
    { name: 'F17: Not Exact Half-Hour', check: !(filterMinute === 30 && filterSecond <= 3) },
    
    // === VOLUME FILTERS ===
    { name: 'F18: Volume Not Completely Dead', check: marketData.volume.obvTrend !== 'NEUTRAL' || filterBody > filterAvgBody * 0.5 },
  ];
  
  filterTriggers.forEach(f => {
    if (f.check) {
      filterScore += 0.5;
      filterFactors.push(f.name);
    }
  });
  
  categories.push({ name: 'Filter & Rejection (18 Ultra)', score: filterScore, factors: filterFactors });
  
  // ============= 6. 235 SETUP DATABASE (PILLAR-FIRST GATED) =============
  // MINIMUM REQUIREMENT: 20 POINTS
  // Minimum 2 setups agree = 2 points, each extra setup = 1 point
  // If score < 20, activate 27 Core Engine Fallback to complete remaining points
  // IMPORTANT: Each setup MUST PASS its avoid rules to be counted
  // PILLAR-FIRST: Only scan setups whose IDs belong to the active pillar
  
  // Pre-filter: only include setups whose ID is in the active pillar's setupIds set
  const pillarFilteredSetups = pillarGate
    ? MASTER_235_SETUPS.filter(s => pillarGate.setupIds.has(s.id))
    : MASTER_235_SETUPS;
  
  const pillarSkipped235 = MASTER_235_SETUPS.length - pillarFilteredSetups.length;
  if (pillarSkipped235 > 0) {
    console.log(`[PILLAR-FIRST 235] Skipped ${pillarSkipped235} non-pillar setups (checkLogic never ran). Scanning ${pillarFilteredSetups.length}/${MASTER_235_SETUPS.length}`);
  }
  
  const allMatchedSetups = pillarFilteredSetups.filter(setup => {
    try {
      return setup.direction === direction && setup.checkLogic(marketData);
    } catch {
      return false;
    }
  });
  
  // ============= VALIDATE 235 SETUPS AGAINST AVOID RULES =============
  const validMatchedSetups: TrapSetup[] = [];
  const blockedSetupNames: string[] = [];
  
  for (const setup of allMatchedSetups) {
    if (marketConditions) {
      const avoidResult = validateStrategyAgainstAvoidRules('setup_235', setup.name, direction, marketConditions);
      if (avoidResult.isValid) {
        validMatchedSetups.push(setup);
        totalValidStrategies++;
      } else {
        blockedSetupNames.push(`#${setup.id}: ${setup.name} - ${avoidResult.blockedReason}`);
        totalBlockedStrategies++;
        addBlockedStrategy(setup.name, '235 Setup', avoidResult.blockedReason || 'Avoid rule failed', direction);
        console.log(`[AVOID RULE] 235 Setup "${setup.name}" BLOCKED: ${avoidResult.blockedReason}`);
      }
    } else {
      // No market conditions - pass all
      validMatchedSetups.push(setup);
      totalValidStrategies++;
    }
  }
  
  // Use ONLY valid setups for scoring
  const matchedSetups = validMatchedSetups;
  
  if (blockedSetupNames.length > 0) {
    console.log(`[235 SETUPS] ${validMatchedSetups.length} valid, ${blockedSetupNames.length} blocked by avoid rules`);
  }
  
  let setupScore = 0;
  const setupFactors: string[] = [];
  let setupFallbackUsed = false;
  
  if (matchedSetups.length >= 2) {
    setupScore = 2;
    const extraSetups = matchedSetups.length - 2;
    setupScore += extraSetups * 1;
    matchedSetups.slice(0, 10).forEach(s => setupFactors.push(`#${s.id}: ${s.name}`));
  }
  
  // ============= STAGE 4: ADAPTIVE CORE FALLBACK (27 Universal Trap Engines) =============
  // MINIMUM REQUIREMENT: 20 POINTS
  // ACTIVATES when setupScore < 20 (minimum requirement)
  // Fallback uses last 200 candles window, scanning last 12 candles for core signals
  const adaptiveFallbackFactors: string[] = [];
  let adaptiveFallbackScore = 0;
  
  // Only activate if 235 setups didn't meet minimum requirement
  if (setupScore < CATEGORY_MIN_REQUIREMENTS.SETUPS_235) {
    setupFallbackUsed = true;
    console.log(`[ADAPTIVE FALLBACK] Primary score ${setupScore.toFixed(2)} < ${CATEGORY_MIN_REQUIREMENTS.SETUPS_235}. Activating 27 Core Engines...`);
    
    // Calculate candle metrics for 27 Core Engines
    const body = marketData.priceAction.lastCandle.bodySize;
    const range = marketData.priceAction.lastCandle.range;
    const upperWick = marketData.volatility.bollinger.upper - Math.max(marketData.currentPrice, marketData.trend.ema20);
    const lowerWick = Math.min(marketData.currentPrice, marketData.trend.ema20) - marketData.volatility.bollinger.lower;
    const avgBody = marketData.volatility.atr * 0.7; // Approximate average body
    const avgVol = marketData.volume.obv > 0 ? 1 : 0; // Normalized volume check
    
    // --- 27 UNIVERSAL GLOBAL TRAP SCANNER ENGINES ---
    
    // 1. Universal Wick-Fill (Liquidity Neutralization)
    const wickRatio = body > 0 ? Math.max(upperWick, lowerWick) / body : 0;
    if (wickRatio > 0.60 && marketData.momentum.rsi14 > 20 && marketData.momentum.rsi14 < 80) {
      const wickDirection = upperWick > lowerWick ? 'PUT' : 'CALL';
      if (wickDirection === direction) {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 1: Wick Fill');
      }
    }
    
    // 2. Universal S/R Siphon (Clean Break Trap)
    const isCleanBreak = range <= body * 1.05;
    if (isCleanBreak) {
      if (direction === 'CALL' && marketData.currentPrice < marketData.smc.support) {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 2: S/R Siphon CALL');
      }
      if (direction === 'PUT' && marketData.currentPrice > marketData.smc.resistance) {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 2: S/R Siphon PUT');
      }
    }
    
    // 3. Universal Jump Gap (Algorithm Continuity)
    const gapSize = Math.abs(marketData.currentPrice - marketData.trend.ema20);
    if (gapSize >= 0.00005) {
      if (direction === 'PUT' && marketData.currentPrice > marketData.smc.resistance) {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 3: Gap at Resistance');
      }
      if (direction === 'CALL' && marketData.currentPrice < marketData.smc.support) {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 3: Gap at Support');
      }
    }
    
    // 4. Universal 3-5 Color Cycle (Momentum Drain)
    const isBullishCandle = marketData.priceAction.lastCandle.type === 'BULLISH';
    const consecutiveCheck = isBullishCandle ? direction === 'CALL' : direction === 'PUT';
    if (consecutiveCheck && marketData.momentum.rsi14 > 25 && marketData.momentum.rsi14 < 75) {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 4: Color Cycle Continue');
    }
    if ((marketData.momentum.rsi14 > 80 || marketData.momentum.rsi14 < 20)) {
      const reverseDir = marketData.momentum.rsi14 > 80 ? 'PUT' : 'CALL';
      if (reverseDir === direction) {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 4: RSI Extreme Reversal');
      }
    }
    
    // 5. Universal Round Number Magnet (.000 / .500)
    const priceStr = marketData.currentPrice.toFixed(5);
    const isNear000 = priceStr.includes('.000') || priceStr.endsWith('000');
    const isNear500 = priceStr.includes('.500') || priceStr.endsWith('500');
    if (isNear000 || isNear500) {
      const outsideBB = marketData.currentPrice > marketData.volatility.bollinger.upper || 
                        marketData.currentPrice < marketData.volatility.bollinger.lower;
      if (outsideBB) {
        const magnetDir = marketData.currentPrice > marketData.volatility.bollinger.upper ? 'PUT' : 'CALL';
        if (magnetDir === direction) {
          adaptiveFallbackScore += 0.5;
          adaptiveFallbackFactors.push('Trap 5: Round Magnet Reverse');
        }
      }
    }
    
    // 6. Universal FVG Symmetrizer (Institutional Gap)
    if (body > 2.5 * avgBody) {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 6: FVG 50% Target');
    }
    
    // 7. Universal Binary Doji Reset
    const isDoji = body <= range * 0.10;
    if (isDoji && marketData.trend.adx > 25) {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 7: Doji Trend Continue');
    }
    
    // 8. Universal Liquidity Sweep (Double Top/Bottom)
    const nearHigh = Math.abs(marketData.currentPrice - marketData.smc.resistance) < 0.00003;
    const nearLow = Math.abs(marketData.currentPrice - marketData.smc.support) < 0.00003;
    if (nearHigh && marketData.priceAction.lastCandle.type === 'BEARISH' && direction === 'PUT') {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 8: Sweep PUT');
    }
    if (nearLow && marketData.priceAction.lastCandle.type === 'BULLISH' && direction === 'CALL') {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 8: Sweep CALL');
    }
    
    // 9. Universal M-W Exhaustion (Second Leg Trap)
    if (marketData.smc.structure === 'HH_HL' && direction === 'PUT' && marketData.momentum.rsi14 > 70) {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 9: M Pattern Exhaustion');
    }
    if (marketData.smc.structure === 'LH_LL' && direction === 'CALL' && marketData.momentum.rsi14 < 30) {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 9: W Pattern Exhaustion');
    }
    
    // 10. Universal RSI Algorithm Lock
    if (marketData.momentum.rsi14 > 90 || marketData.momentum.rsi14 < 10) {
      const emaCrossing = Math.abs(marketData.currentPrice - marketData.trend.ema20) < marketData.volatility.atr * 0.3;
      if (emaCrossing) {
        const unlockDir = marketData.momentum.rsi14 > 90 ? 'PUT' : 'CALL';
        if (unlockDir === direction) {
          adaptiveFallbackScore += 0.5;
          adaptiveFallbackFactors.push('Trap 10: Algo Unlock Reverse');
        }
      }
    }
    
    // 11. Universal Z-Level (Flip Level Pivot)
    const flipLevelDist = Math.min(
      Math.abs(marketData.currentPrice - marketData.smc.support),
      Math.abs(marketData.currentPrice - marketData.smc.resistance)
    );
    if (flipLevelDist <= 0.00002) {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 11: Z-Level Reaction');
    }
    
    // 12. Universal Institutional Stop Hunt (4th Touch Rule)
    // Approximated by checking if we're at a major S/R level
    if (isAtSupport(marketData) || isAtResistance(marketData)) {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 12: 4th Touch Hunt');
    }
    
    // 13. Universal Invalidated Rejection (99% Bridge)
    const prevWickRatio = body > 0 ? upperWick / body : 0;
    if (prevWickRatio > 0.60 && marketData.priceAction.lastCandle.type === 'BULLISH' && direction === 'CALL') {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 13: Wick Fill Bridge');
    }
    
    // 14. Universal Vacuum Effect (ATR Expansion)
    if (body > 3 * avgBody) {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 14: Vacuum Momentum');
    }
    
    // 15. Universal Color Switching Fatigue
    const atEMA = isAtEMA(marketData, 20) || isAtEMA(marketData, 50);
    if (atEMA) {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 15: Color Repeat Expected');
    }
    
    // 16. Universal Exhaustion Escalator (Godzilla Candle)
    if (body >= 2 * avgBody) {
      const godzillaDir = marketData.priceAction.lastCandle.type === 'BULLISH' ? 'PUT' : 'CALL';
      if (godzillaDir === direction) {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 16: Godzilla Reversal');
      }
    }
    
    // 17. Universal Micro-Gap Magnet
    const microGap = Math.abs(marketData.currentPrice - marketData.trend.ema20);
    if (microGap >= 0.00001 && microGap <= 0.00003) {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 17: Micro-Gap Continue');
    }
    
    // 18. Universal Fractal Symmetry Break
    if (marketData.smc.lastBOS) {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 18: Symmetry Break');
    }
    
    // 19. Universal Volatility Spike Snap-Back
    const outsideBB = marketData.volatility.bollinger.position !== 'MIDDLE';
    if (outsideBB && (isNear000 || isNear500)) {
      const snapDir = marketData.volatility.bollinger.position === 'UPPER_BAND' ? 'PUT' : 'CALL';
      if (snapDir === direction) {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 19: Snap-Back');
      }
    }
    
    // 20. Universal Near-Miss Breakout
    const nearMissToRes = Math.abs(marketData.currentPrice - marketData.smc.resistance);
    const nearMissToSup = Math.abs(marketData.currentPrice - marketData.smc.support);
    if ((nearMissToRes >= 0.00001 && nearMissToRes <= 0.00002) || 
        (nearMissToSup >= 0.00001 && nearMissToSup <= 0.00002)) {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 20: Delayed Breakout');
    }
    
    // 21. Universal Doji Compression Spring
    if (isDoji) {
      const springDir = marketData.trend.emaAlignment === 'BULLISH' ? 'CALL' : 'PUT';
      if (springDir === direction) {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 21: Doji Spring');
      }
    }
    
    // 22. Universal Ribbon Kiss Continuation
    const ema20 = marketData.trend.ema20;
    const ema50 = marketData.trend.ema50;
    const parallelEMAs = (ema20 > ema50) || (ema20 < ema50);
    if (parallelEMAs) {
      const kissTouch = Math.abs(marketData.currentPrice - ema20) < marketData.volatility.atr * 0.2;
      if (kissTouch && direction === (ema20 > ema50 ? 'CALL' : 'PUT')) {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 22: Ribbon Kiss');
      }
    }
    
    // 23. Universal Round Number Liquidity Flush
    if (isNear000 || isNear500) {
      const tinyBody = body <= range * 0.25;
      if (tinyBody) {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 23: Liquidity Flush');
      }
    }
    
    // 24. Universal Second-Leg M/W Exhaustion
    const rsiDivergence = (marketData.smc.structure === 'HH_HL' && marketData.momentum.rsi14 < 50) ||
                          (marketData.smc.structure === 'LH_LL' && marketData.momentum.rsi14 > 50);
    if (rsiDivergence) {
      const divDir = marketData.smc.structure === 'LH_LL' ? 'CALL' : 'PUT';
      if (divDir === direction) {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 24: Smart Money M/W');
      }
    }
    
    // 25. Universal Time-Window Reset
    // Cannot check time directly but add logic hook
    if (isAtSupport(marketData) || isAtResistance(marketData)) {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 25: Time Reset Level');
    }
    
    // 26. Universal Micro-Range Expansion
    const tightRange = range <= 0.00003;
    if (tightRange) {
      // Fake breakout detection - if price broke out, reverse
      const breakoutDir = marketData.priceAction.lastCandle.type === 'BULLISH' ? 'PUT' : 'CALL';
      if (breakoutDir === direction) {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 26: Micro-Range Fakeout');
      }
    }
    
    // 27. Universal Volume-Price Divergence (Hollow Move)
    if (body > 2 * avgBody) {
      // Volume falling while price expanding = hollow move
      const hollowDir = marketData.priceAction.lastCandle.type === 'BULLISH' ? 'PUT' : 'CALL';
      if (hollowDir === direction && marketData.volume.obvTrend === 'NEUTRAL') {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 27: Hollow Move');
      }
    }
    
    // ============= ULTRA TRAPS 28-35 (Advanced Institutional Detection) =============
    
    // 28. Institutional Volume Profile (Volume spike at key levels)
    if (raw && raw.volumes && raw.volumes.length >= 10) {
      const lastVol = raw.volumes[raw.volumes.length - 1];
      const avgVol28 = raw.volumes.slice(-10).reduce((a: number, b: number) => a + b, 0) / 10;
      if (avgVol28 > 0 && lastVol > avgVol28 * 2.0) {
        const volDir = marketData.priceAction.lastCandle.type === 'BULLISH' ? 'CALL' : 'PUT';
        if (volDir === direction) {
          adaptiveFallbackScore += 0.8;
          adaptiveFallbackFactors.push('Trap 28: Institutional Volume Spike');
        }
      }
    }
    
    // 29. Multi-EMA Confluence (EMA20 + EMA50 both supporting direction)
    if (marketData.trend.ema20 > marketData.trend.ema50 && marketData.currentPrice > marketData.trend.ema20 && direction === 'CALL') {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 29: Multi-EMA Bull Stack');
    }
    if (marketData.trend.ema20 < marketData.trend.ema50 && marketData.currentPrice < marketData.trend.ema20 && direction === 'PUT') {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 29: Multi-EMA Bear Stack');
    }
    
    // 30. Stochastic Extreme Recovery (K crosses back from extreme)
    if (marketData.momentum.stochastic.k > 20 && marketData.momentum.stochastic.k < 30 && direction === 'CALL') {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 30: Stoch Recovery from Oversold');
    }
    if (marketData.momentum.stochastic.k < 80 && marketData.momentum.stochastic.k > 70 && direction === 'PUT') {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 30: Stoch Recovery from Overbought');
    }
    
    // 31. Price-EMA Separation Velocity (Speed of separation)
    const emaDist31 = Math.abs(marketData.currentPrice - marketData.trend.ema20);
    if (emaDist31 > marketData.volatility.atr * 0.8) {
      const snapDir31 = marketData.currentPrice > marketData.trend.ema20 ? 'PUT' : 'CALL';
      if (snapDir31 === direction) {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 31: EMA Separation Snap');
      }
    }
    
    // 32. MACD-RSI Alignment (Both confirming same direction)
    if (marketData.momentum.macd.histogram > 0 && marketData.momentum.rsi14 > 50 && direction === 'CALL') {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 32: MACD+RSI Bull Alignment');
    }
    if (marketData.momentum.macd.histogram < 0 && marketData.momentum.rsi14 < 50 && direction === 'PUT') {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 32: MACD+RSI Bear Alignment');
    }
    
    // 33. BB Position Quality (Price at optimal BB zone)
    if (marketData.volatility.bollinger.position === 'LOWER_BAND' && direction === 'CALL') {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 33: BB Lower Band Bounce');
    }
    if (marketData.volatility.bollinger.position === 'UPPER_BAND' && direction === 'PUT') {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 33: BB Upper Band Rejection');
    }
    
    // 34. Premium/Discount Zone Alignment
    if (marketData.smc.premiumDiscount === 'DISCOUNT' && direction === 'CALL') {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 34: Discount Zone CALL');
    }
    if (marketData.smc.premiumDiscount === 'PREMIUM' && direction === 'PUT') {
      adaptiveFallbackScore += 0.5;
      adaptiveFallbackFactors.push('Trap 34: Premium Zone PUT');
    }
    
    // 35. PSAR Trend Confirmation (Non-reversal PSAR supporting direction)
    if (!marketData.parabolicSAR.reversal) {
      if (marketData.parabolicSAR.trend === 'BULLISH' && direction === 'CALL') {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 35: PSAR Trend Bullish');
      }
      if (marketData.parabolicSAR.trend === 'BEARISH' && direction === 'PUT') {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 35: PSAR Trend Bearish');
      }
    }
    
    console.log(`[ADAPTIVE FALLBACK] 35 Ultra Core Engines activated. Score: ${adaptiveFallbackScore}, Traps matched: ${adaptiveFallbackFactors.length}`);

    // Minimal bias bridge if no traps matched
    if (adaptiveFallbackScore === 0) {
      const biasDir =
        marketData.trend.emaAlignment === 'BULLISH'
          ? 'CALL'
          : marketData.trend.emaAlignment === 'BEARISH'
            ? 'PUT'
            : marketData.priceAction.lastCandle.type === 'BULLISH'
              ? 'CALL'
              : 'PUT';
      if (biasDir === direction) {
        adaptiveFallbackScore += 0.5;
        adaptiveFallbackFactors.push('Trap 0: Trend Bias Bridge');
      }
    }
    
    // Add fallback score to main 235 setup score
    setupScore += adaptiveFallbackScore;
    setupFactors.push(...adaptiveFallbackFactors);

    // Ensure 235 can reach its minimum requirement when fallback produced at least one valid match.
    if (setupScore < CATEGORY_MIN_REQUIREMENTS.SETUPS_235 && adaptiveFallbackScore > 0) {
      const boost = CATEGORY_MIN_REQUIREMENTS.SETUPS_235 - setupScore;
      setupScore = CATEGORY_MIN_REQUIREMENTS.SETUPS_235;
      setupFactors.push(`235-FB Completion: +${boost.toFixed(2)}`);
    }
  }
  
  // Final 235 Setups category with minimum requirement tracking
  categories.push({ 
    name: '235 Ultra Setups', 
    score: setupScore, 
    factors: setupFactors,
    minRequired: CATEGORY_MIN_REQUIREMENTS.SETUPS_235,
    fallbackUsed: setupFallbackUsed
  });
  
  // ============= 7. HTF ANALYZING (20 MASTER HTF STRATEGIES) =============
  // MINIMUM REQUIREMENT: 3 POINTS
  // First HTF strategy agrees = 1 point, each extra = 0.5 point
  // If score < 3, activate 8-Pillar HTF Core Fallback
  // IMPORTANT: All strategies MUST pass avoid rules validation to be counted
  const htfFactors: string[] = [];
  let htfScore = 0;
  let htfFirstMatch = false;
  let htfFallbackUsed = false;
  let blockedHtfCount = 0;
  
  const htfPip = getDynamicPipSize(marketData.currentPrice);
  const htfCurrentTime = nowUTC6();
  const htfMinute = htfCurrentTime.getMinutes();
  const htfSecond = htfCurrentTime.getSeconds();
  
  // Helper function to add HTF score with avoid rules validation + pillar gate
  // htfId: the 1-20 strategy number for pillar cross-reference gating
  let htfStratCounter = 0; // auto-increment for HTF strategies
  const addHtfMatch = (stratName: string, htfId?: number): boolean => {
    const id = htfId || (++htfStratCounter);
    
    // PILLAR CROSS-REFERENCE GATE: Check if this HTF strategy ID is allowed
    if (pillarGate && !pillarGate.htfIds.has(id)) {
      pillarGatedHtf++;
      addBlockedStrategy(stratName, 'HTF', `Pillar gate: HTF #${id} not in ${pillarGate.pillarName}`, direction);
      return false;
    }
    
    if (marketConditions) {
      const avoidResult = validateStrategyAgainstAvoidRules('htf', stratName, direction, marketConditions);
      if (!avoidResult.isValid) {
        blockedHtfCount++;
        addBlockedStrategy(stratName, 'HTF', avoidResult.blockedReason || 'Avoid rule failed', direction);
        console.log(`[AVOID RULE] HTF "${stratName}" BLOCKED: ${avoidResult.blockedReason}`);
        return false;
      }
    }
    if (!htfFirstMatch) {
      htfScore += 1;
      htfFirstMatch = true;
    } else {
      htfScore += 0.5;
    }
    htfFactors.push(stratName);
    totalValidStrategies++;
    return true;
  };
  
  // PILLAR-FIRST: Gate closure for HTF - wraps detection logic so it's completely skipped for non-pillar strategies
  const scanHtf = (id: number, detect: () => void) => {
    if (shouldScanHtf(id, pillarGate)) { detect(); } else { pillarSkippedHtf++; }
  };

  // Get 1M candle data for HTF analysis
  const htfC1Close = marketData.currentPrice;
  const htfC1BodySize = marketData.priceAction.lastCandle.bodySize;
  const htfC1Range = marketData.priceAction.lastCandle.range;
  const htfC1Type = marketData.priceAction.lastCandle.type;
  
  // ============= PART 1: STRATEGIES 1-10 =============
  
  // 1. Wick-Fill Magnet (Institutional Liquidity)
  scanHtf(1, () => {
  if (marketDataM15) {
    const h15BodySize = marketDataM15.priceAction.lastCandle.bodySize;
    const h15Range = marketDataM15.priceAction.lastCandle.range;
    const h15WickTotal = h15Range - h15BodySize;
    if (h15WickTotal > (h15BodySize * 0.6) && h15BodySize > 0) {
      if (marketDataM15.priceAction.lastCandle.type === 'BEARISH' && direction === 'CALL') {
        addHtfMatch('HTF1: 15M Wick-Fill Magnet CALL', 1);
      }
      if (marketDataM15.priceAction.lastCandle.type === 'BULLISH' && direction === 'PUT') {
        addHtfMatch('HTF1: 15M Wick-Fill Magnet PUT', 1);
      }
    }
  }
  });
  
  // 2. FVG 50% Symmetrizer (The Void Logic)
  scanHtf(2, () => {
  if (marketDataM15) {
    const h15BodySize = marketDataM15.priceAction.lastCandle.bodySize;
    const h15AvgBody = marketDataM15.volatility.atr * 0.8;
    if (h15BodySize > (h15AvgBody * 2)) {
      const fvgDir = marketDataM15.smc.premiumDiscount === 'PREMIUM' ? 'PUT' : 'CALL';
      if (fvgDir === direction) {
        addHtfMatch('HTF2: 15M FVG 50% Symmetrizer', 2);
      }
    }
  }
  });
  
  // 3. Round Number Magnet (Gravity Pillar)
  const roundDist000 = Math.abs(htfC1Close % 0.01000);
  const roundDist500 = Math.abs((htfC1Close % 0.01000) - 0.00500);
  scanHtf(3, () => {
  if (roundDist000 <= (3 * htfPip) && roundDist000 > 0) {
    const magnetDir = (htfC1Close % 0.01000) < 0.00500 ? 'PUT' : 'CALL';
    if (magnetDir === direction) {
      addHtfMatch('HTF3: Round .000 Magnet', 3);
    }
  }
  if (roundDist500 <= (3 * htfPip)) {
    const magnetDir500 = (htfC1Close % 0.01000) < 0.00500 ? 'CALL' : 'PUT';
    if (magnetDir500 === direction) {
      addHtfMatch('HTF3: Round .500 Magnet', 3);
    }
  }
  });
  
  // 4. OB Mean Threshold (Order Block Target)
  scanHtf(4, () => {
  if (marketDataM15 && marketDataM15.smc.orderBlocks.length > 0) {
    const ob = marketDataM15.smc.orderBlocks[0];
    const distToOB = Math.abs(htfC1Close - ob.level);
    if (distToOB <= (2 * htfPip)) {
      const obDir = ob.type === 'BULLISH_OB' ? 'CALL' : 'PUT';
      if (obDir === direction) {
        addHtfMatch('HTF4: 15M OB Threshold Mitigation', 4);
      }
    }
  }
  });
  
  // 5. Liquidity Sweep (S/R Break-and-Reclaim)
  scanHtf(5, () => {
  if (marketDataM15) {
    const m15Resist = marketDataM15.smc.resistance;
    const m15Support = marketDataM15.smc.support;
    if (htfC1Close > m15Resist && htfC1Type === 'BEARISH' && direction === 'PUT') {
      addHtfMatch('HTF5: 15M Liquidity Sweep PUT', 5);
    }
    if (htfC1Close < m15Support && htfC1Type === 'BULLISH' && direction === 'CALL') {
      addHtfMatch('HTF5: 15M Liquidity Sweep CALL', 5);
    }
  }
  });
  
  // 6. Near-Miss Breakout (First Bounce Trap)
  scanHtf(6, () => {
  if (marketDataM15) {
    const m15Resist = marketDataM15.smc.resistance;
    const m15Support = marketDataM15.smc.support;
    const distToResist = Math.abs(htfC1Close - m15Resist);
    const distToSupport = Math.abs(htfC1Close - m15Support);
    if (distToResist >= htfPip && distToResist <= (2 * htfPip) && direction === 'PUT') {
      addHtfMatch('HTF6: Near-Miss Resistance Trap', 6);
    }
    if (distToSupport >= htfPip && distToSupport <= (2 * htfPip) && direction === 'CALL') {
      addHtfMatch('HTF6: Near-Miss Support Trap', 6);
    }
  }
  });
  
  // 7. Time-Window Reset (Temporal Reversal)
  scanHtf(7, () => {
  if ([0, 15, 30, 45].includes(htfMinute) && htfSecond <= 5) {
    const timeResetDir = htfC1Type === 'BULLISH' ? 'PUT' : 'CALL';
    if (timeResetDir === direction) {
      addHtfMatch('HTF7: Algo Time Reset Reversal', 7);
    }
  }
  });
  
  // 8. V-Shape Mirroring (15M Symmetry)
  scanHtf(8, () => {
  const isM1Pinbar = marketData.priceAction.patterns.includes('HAMMER') || 
                     marketData.priceAction.patterns.includes('SHOOTING_STAR');
  if (isM1Pinbar && htfMinute % 15 <= 5) {
    if (marketData.priceAction.patterns.includes('HAMMER') && direction === 'CALL') {
      addHtfMatch('HTF8: V-Shape Symmetry CALL', 8);
    }
    if (marketData.priceAction.patterns.includes('SHOOTING_STAR') && direction === 'PUT') {
      addHtfMatch('HTF8: V-Shape Symmetry PUT', 8);
    }
  }
  });
  
  // 9. Color Switching Fatigue (Burnout Pillar)
  scanHtf(9, () => {
  if (marketDataM15 && marketDataM15.smc.marketStructure === 'NEUTRAL') {
    const fatigueDir = htfC1Type === 'BULLISH' ? 'CALL' : 'PUT';
    if (fatigueDir === direction) {
      addHtfMatch('HTF9: 15M Color Switch Fatigue', 9);
    }
  }
  });
  
  // 10. HTF RSI Lock (Momentum Anchor)
  scanHtf(10, () => {
  if (marketDataM15) {
    const m15Rsi = marketDataM15.momentum.rsi14;
    if (m15Rsi >= 85 && htfC1Close < marketData.trend.ema20 && direction === 'PUT') {
      addHtfMatch('HTF10: 15M RSI Lock Reversal PUT', 10);
    }
    if (m15Rsi <= 15 && htfC1Close > marketData.trend.ema20 && direction === 'CALL') {
      addHtfMatch('HTF10: 15M RSI Lock Reversal CALL', 10);
    }
  }
  });
  
  // ============= PART 2: STRATEGIES 11-20 =============
  
  // 11. Vol-Price Divergence (The Hollow Move)
  scanHtf(11, () => {
  if (marketDataM15) {
    const m15BodySize = marketDataM15.priceAction.lastCandle.bodySize;
    const m15AvgBody = marketDataM15.volatility.atr * 0.8;
    const isHollow = m15BodySize > m15AvgBody && marketDataM15.volume.obvTrend === 'NEUTRAL';
    if (isHollow) {
      const hollowDir = marketDataM15.priceAction.lastCandle.type === 'BULLISH' ? 'PUT' : 'CALL';
      if (hollowDir === direction) {
        addHtfMatch('HTF11: 15M Hollow Move Trap', 11);
      }
    }
  }
  });
  
  // 12. BB Outer Walk Exit (Mean Reversion Extreme)
  scanHtf(12, () => {
  if (marketDataM15) {
    const m15Close = marketDataM15.currentPrice;
    const bbUpper12 = marketDataM15.volatility.bollinger.upper;
    const bbLower12 = marketDataM15.volatility.bollinger.lower;
    if (m15Close > bbUpper12 && direction === 'PUT') {
      addHtfMatch('HTF12: 15M BB Extreme Reversion PUT', 12);
    }
    if (m15Close < bbLower12 && direction === 'CALL') {
      addHtfMatch('HTF12: 15M BB Extreme Reversion CALL', 12);
    }
  }
  });
  
  // 13. Godzilla Vacuum (ATR Expansion)
  scanHtf(13, () => {
  if (marketDataM15) {
    const m15BodySize = marketDataM15.priceAction.lastCandle.bodySize;
    const m15Range = marketDataM15.priceAction.lastCandle.range;
    const m15AvgBody = marketDataM15.volatility.atr * 0.8;
    const m15WickRatio = m15Range > 0 ? m15BodySize / m15Range : 0;
    if (m15BodySize >= (m15AvgBody * 3) && m15WickRatio > 0.8) {
      const godzillaDir = marketDataM15.priceAction.lastCandle.type === 'BULLISH' ? 'CALL' : 'PUT';
      if (godzillaDir === direction) {
        addHtfMatch('HTF13: 15M Godzilla Vacuum Continuation', 13);
      }
    }
  }
  });
  
  // 14. Doji Compression Spring (Volatility Squeeze)
  scanHtf(14, () => {
  if (marketDataM15 && marketDataM15.volatility.bollinger.width < 1.5) {
    const preSqueezeDir = marketData.smc.marketStructure === 'BULLISH' ? 'CALL' : 'PUT';
    if (preSqueezeDir === direction) {
      addHtfMatch('HTF14: 15M Doji Spring Release', 14);
    }
  }
  });
  
  // 15. Fractal Symmetry Break (Structural Failure)
  scanHtf(15, () => {
  if (marketDataM15 && marketDataM15.smc.lastCHoCH) {
    const choch = marketDataM15.smc.lastCHoCH;
    const breakDir = choch.includes('BULL') || choch.includes('UP') ? 'CALL' : 'PUT';
    if (breakDir === direction) {
      addHtfMatch('HTF15: 15M Fractal Symmetry Break', 15);
    }
  }
  });
  
  // 16. Session Range Sweep (Macro Liquidity Hunt)
  scanHtf(16, () => {
  if (marketDataH1) {
    const h1Resist = marketDataH1.smc.resistance;
    const h1Support = marketDataH1.smc.support;
    if (htfC1Close > h1Resist && htfC1Type === 'BEARISH' && direction === 'PUT') {
      addHtfMatch('HTF16: Session High Sweep PUT', 16);
    }
    if (htfC1Close < h1Support && htfC1Type === 'BULLISH' && direction === 'CALL') {
      addHtfMatch('HTF16: Session Low Sweep CALL', 16);
    }
  }
  });
  
  // 17. HTF Inside Bar Trap (The Mother Bar Squeeze)
  scanHtf(17, () => {
  if (marketDataM15 && marketDataM15.volatility.bollinger.width < 2) {
    const m15Resist = marketDataM15.smc.resistance;
    const m15Support = marketDataM15.smc.support;
    if (htfC1Close > m15Resist && direction === 'CALL') {
      addHtfMatch('HTF17: 15M Inside Bar Breakout CALL', 17);
    }
    if (htfC1Close < m15Support && direction === 'PUT') {
      addHtfMatch('HTF17: 15M Inside Bar Breakout PUT', 17);
    }
  }
  });
  
  // 18. EMA Mean Reversion (The 20-Pip Debt Rule)
  scanHtf(18, () => {
  if (marketDataM15) {
    const m15Ema = marketDataM15.trend.ema20;
    const debtDist = Math.abs(htfC1Close - m15Ema);
    if (debtDist >= (20 * htfPip)) {
      const debtDir = htfC1Close > m15Ema ? 'PUT' : 'CALL';
      if (debtDir === direction) {
        addHtfMatch('HTF18: 15M EMA Debt Reversion', 18);
      }
    }
  }
  });
  
  // 19. Three-Push Exhaustion (Staircase Fatigue)
  scanHtf(19, () => {
  const isThreePush = marketData.priceAction.patterns.includes('THREE_WHITE_SOLDIERS') ||
                      marketData.priceAction.patterns.includes('THREE_BLACK_CROWS');
  const nearRound = roundDist000 <= (1 * htfPip) || roundDist500 <= (1 * htfPip);
  if (isThreePush && nearRound) {
    const pushDir = marketData.priceAction.patterns.includes('THREE_WHITE_SOLDIERS') ? 'PUT' : 'CALL';
    if (pushDir === direction) {
      addHtfMatch('HTF19: Three-Push Exhaustion Reversal', 19);
    }
  }
  });
  
  // 20. Algorithmic Book Reset (Hourly Turn Pivot)
  scanHtf(20, () => {
  if (htfMinute === 0 && marketDataM15) {
    const m15Resist = marketDataM15.smc.resistance;
    const m15Support = marketDataM15.smc.support;
    const nearM15SR = Math.abs(htfC1Close - m15Resist) <= (2 * htfPip) || 
                      Math.abs(htfC1Close - m15Support) <= (2 * htfPip);
    if (nearM15SR) {
      const resetDir = htfC1Type === 'BULLISH' ? 'PUT' : 'CALL';
      if (resetDir === direction) {
        addHtfMatch('HTF20: Hourly Algo Reset Reversal', 20);
      }
    }
  }
  });
  
  // Log HTF avoid rules results + pillar-first skip count
  if (blockedHtfCount > 0) {
    console.log(`[HTF] ${htfFactors.length} valid, ${blockedHtfCount} blocked by avoid rules`);
  }
  if (pillarSkippedHtf > 0) {
    console.log(`[PILLAR-FIRST HTF] Skipped ${pillarSkippedHtf} non-pillar HTF strategies (detection logic never ran)`);
  }
  console.log(`[20 HTF MASTER ENGINE] HTF Score: ${htfScore.toFixed(2)}, Strategies: ${htfFactors.length}`);
  
  // ============= PILLAR CROSS-REFERENCE GATE SUMMARY =============
  if (pillarGate) {
    const totalGated = pillarGatedSmc + pillarGatedLiq + pillarGatedInd + pillarGatedHtf;
    if (totalGated > 0) {
      console.log(`[PILLAR GATE SUMMARY] ${pillarGate.pillarName} filtered ${totalGated} strategies: SMC=${pillarGatedSmc} Liq=${pillarGatedLiq} Ind=${pillarGatedInd} HTF=${pillarGatedHtf}`);
    }
  }
  
  // ============= ADAPTIVE CORE FALLBACK FOR HTF (8 Core Pillars) =============
  // MINIMUM REQUIREMENT: 3 POINTS
  // Activates when htfScore < 3 (minimum requirement)
  // Fallback uses last 200 candles window, scanning last 12 candles for core signals
  let htfCoreFallbackScore = 0;
  const htfCoreFallbackFactors: string[] = [];
  
  if (htfScore < CATEGORY_MIN_REQUIREMENTS.HTF) {
    htfFallbackUsed = true;
    console.log(`[HTF CORE FALLBACK] Primary score ${htfScore.toFixed(2)} < ${CATEGORY_MIN_REQUIREMENTS.HTF}. Activating 8 Pillars...`);
    
    // Shared calculations for Core Pillars
    const hcfCurrentPrice = marketData.currentPrice;
    const hcfPip = getDynamicPipSize(hcfCurrentPrice);
    const hcfCurrentTime = nowUTC6();
    const hcfMinute = hcfCurrentTime.getMinutes();
    const hcfSecond = hcfCurrentTime.getSeconds();
    
    // Get 15M and H1 data if available
    const hcfM15Ema = marketDataM15 ? marketDataM15.trend.ema20 : hcfCurrentPrice;
    const hcfM15Ema50 = marketDataM15 ? marketDataM15.trend.ema50 : hcfCurrentPrice;
    const hcfM15Resist = marketDataM15 ? marketDataM15.smc.resistance : hcfCurrentPrice + 0.001;
    const hcfM15Support = marketDataM15 ? marketDataM15.smc.support : hcfCurrentPrice - 0.001;
    const hcfH1Resist = marketDataH1 ? marketDataH1.smc.resistance : hcfM15Resist;
    const hcfH1Support = marketDataH1 ? marketDataH1.smc.support : hcfM15Support;
    
    // ==============================================================================
    // 🏛️ PILLAR 1: LIQUIDITY MAGNET (THE "WHERE" LOGIC)
    // Core Logic: If price is close to a major level, follow the Magnet.
    // ==============================================================================
    let pillar1Matched = false;
    
    // 1. Check Round Numbers (.000 / .500)
    const p1DistRound000 = Math.abs(hcfCurrentPrice % 0.01000);
    const p1DistRound500 = Math.abs((hcfCurrentPrice % 0.01000) - 0.00500);
    
    if (p1DistRound000 <= (3 * hcfPip) && p1DistRound000 > 0) {
      const p1Dir = (hcfCurrentPrice % 0.01000) < 0.00500 ? 'PUT' : 'CALL';
      if (p1Dir === direction) {
        htfCoreFallbackScore += 0.6;
        htfCoreFallbackFactors.push('HCF1: Round .000 Magnet');
        pillar1Matched = true;
      }
    }
    if (!pillar1Matched && p1DistRound500 <= (3 * hcfPip)) {
      const p1Dir500 = (hcfCurrentPrice % 0.01000) < 0.00500 ? 'CALL' : 'PUT';
      if (p1Dir500 === direction) {
        htfCoreFallbackScore += 0.6;
        htfCoreFallbackFactors.push('HCF1: Round .500 Magnet');
        pillar1Matched = true;
      }
    }
    
    // 2. Check HTF S/R Levels (15M has wider pull)
    if (!pillar1Matched && marketDataM15) {
      const distToM15Resist = Math.abs(hcfCurrentPrice - hcfM15Resist);
      const distToM15Support = Math.abs(hcfCurrentPrice - hcfM15Support);
      
      if (distToM15Resist <= (4 * hcfPip) && hcfCurrentPrice < hcfM15Resist && direction === 'CALL') {
        htfCoreFallbackScore += 0.5;
        htfCoreFallbackFactors.push('HCF1: 15M Resistance Magnet CALL');
      }
      if (distToM15Support <= (4 * hcfPip) && hcfCurrentPrice > hcfM15Support && direction === 'PUT') {
        htfCoreFallbackScore += 0.5;
        htfCoreFallbackFactors.push('HCF1: 15M Support Magnet PUT');
      }
    }
    
    // ==============================================================================
    // 🏛️ PILLAR 2: TIME-BLOCK EXHAUSTION (THE "WHEN" LOGIC)
    // Core Logic: End of a 5M or 15M block forces a "Vacuum Push" to close the candle.
    // ==============================================================================
    
    // 1. 15-Minute Block Exhaustion (minutes: 14, 29, 44, 59)
    if (hcfMinute % 15 === 14 && hcfSecond >= 30) {
      const m15Type = marketDataM15 ? marketDataM15.priceAction.lastCandle.type : marketData.priceAction.lastCandle.type;
      const p2Dir = m15Type === 'BULLISH' ? 'CALL' : 'PUT';
      if (p2Dir === direction) {
        htfCoreFallbackScore += 0.7;
        htfCoreFallbackFactors.push('HCF2: 15M Block Vacuum Push');
      }
    }
    
    // 2. 5-Minute Block Exhaustion (minutes: 4, 9, 14, 19, etc.)
    if (hcfMinute % 5 === 4 && hcfSecond >= 30) {
      const m1Type = marketData.priceAction.lastCandle.type;
      const p2DirM5 = m1Type === 'BULLISH' ? 'CALL' : 'PUT';
      if (p2DirM5 === direction) {
        htfCoreFallbackScore += 0.5;
        htfCoreFallbackFactors.push('HCF2: 5M Block Vacuum Push');
      }
    }
    
    // ==============================================================================
    // 🏛️ PILLAR 3: MEAN REVERSION DEBT (THE "BALANCE" LOGIC)
    // Core Logic: Price cannot sustain large distances from EMA. It acts as "Debt".
    // ==============================================================================
    
    // 1. Global Debt Check (15M EMA50) - > 20 pips = reversal
    if (marketDataM15) {
      const distTo15MEma50 = Math.abs(hcfCurrentPrice - hcfM15Ema50);
      if (distTo15MEma50 > (20 * hcfPip)) {
        const p3Dir = hcfCurrentPrice > hcfM15Ema50 ? 'PUT' : 'CALL';
        if (p3Dir === direction) {
          htfCoreFallbackScore += 0.8;
          htfCoreFallbackFactors.push('HCF3: 15M Global Debt Reversion');
        }
      }
    }
    
    // 2. Local Debt Check (M15 EMA20) - > 10 pips = pullback
    if (marketDataM15) {
      const distTo15MEma20 = Math.abs(hcfCurrentPrice - hcfM15Ema);
      if (distTo15MEma20 > (10 * hcfPip) && distTo15MEma20 <= (20 * hcfPip)) {
        const p3DirLocal = hcfCurrentPrice > hcfM15Ema ? 'PUT' : 'CALL';
        if (p3DirLocal === direction) {
          htfCoreFallbackScore += 0.5;
          htfCoreFallbackFactors.push('HCF3: 15M Local Debt Pullback');
        }
      }
    }
    
    // ==============================================================================
    // 🏛️ PILLAR 4: VOLUME-PRICE DIVERGENCE (THE "FUEL" LOGIC)
    // Core Logic: Big Body + Neutral/Low Volume = Fake Move (Hollow Bridge).
    // ==============================================================================
    
    // Check 15M for hollow move
    if (marketDataM15) {
      const m15BodySize = marketDataM15.priceAction.lastCandle.bodySize;
      const m15AvgBody = marketDataM15.volatility.atr * 0.8;
      const isHollowM15 = m15BodySize > m15AvgBody && marketDataM15.volume.obvTrend === 'NEUTRAL';
      
      if (isHollowM15) {
        const p4Dir = marketDataM15.priceAction.lastCandle.type === 'BULLISH' ? 'PUT' : 'CALL';
        if (p4Dir === direction) {
          htfCoreFallbackScore += 0.6;
          htfCoreFallbackFactors.push('HCF4: 15M Hollow Move Reversal');
        }
      }
    }
    
    // Check 1M for hollow move
    const m1BodySize = marketData.priceAction.lastCandle.bodySize;
    const m1AvgBody = marketData.volatility.atr * 0.5;
    const isHollowM1 = m1BodySize > m1AvgBody && marketData.volume.obvTrend === 'NEUTRAL';
    
    if (isHollowM1) {
      const p4DirM1 = marketData.priceAction.lastCandle.type === 'BULLISH' ? 'PUT' : 'CALL';
      if (p4DirM1 === direction) {
        htfCoreFallbackScore += 0.4;
        htfCoreFallbackFactors.push('HCF4: 1M Hollow Move Warning');
      }
    }
    
    // ==============================================================================
    // 🏛️ PILLAR 5: SYMMETRY & MIRRORING (THE "MATH CONTINUITY" PILLAR)
    // Core Logic: If retrace < 50% of previous impulse, Trend is VALID.
    // ==============================================================================
    
    // 15M Macro Symmetry - Use premium/discount for trend continuation
    if (marketDataM15 && marketDataM15.smc.premiumDiscount !== 'EQUILIBRIUM') {
      const m15Structure = marketDataM15.smc.marketStructure;
      const p5Dir = m15Structure === 'BULLISH' ? 'CALL' : 'PUT';
      
      // If in discount zone and bullish structure, or premium zone and bearish structure
      const validSymmetry = (marketDataM15.smc.premiumDiscount === 'DISCOUNT' && m15Structure === 'BULLISH') ||
                            (marketDataM15.smc.premiumDiscount === 'PREMIUM' && m15Structure === 'BEARISH');
      
      if (validSymmetry && p5Dir === direction) {
        htfCoreFallbackScore += 0.5;
        htfCoreFallbackFactors.push('HCF5: 15M Symmetry Continuation');
      }
    }
    
    // ==============================================================================
    // 🏛️ PILLAR 6: TEMPORAL RESET & SESSION CYCLES (THE "TEMPORAL" PILLAR)
    // Core Logic: Server "Hard Resets" at fixed clock intervals.
    // ==============================================================================
    
    // 1. The Hourly Reset (HH:00) - Massive Reversal Probability
    if (hcfMinute === 0 && hcfSecond <= 5) {
      const p6Dir = marketData.priceAction.lastCandle.type === 'BULLISH' ? 'PUT' : 'CALL';
      if (p6Dir === direction) {
        htfCoreFallbackScore += 0.8;
        htfCoreFallbackFactors.push('HCF6: Hourly Hard Reset Reversal');
      }
    }
    
    // 2. The Half-Hour Reset (HH:30) - Volatility Adjustment
    if (hcfMinute === 30 && hcfSecond <= 5) {
      const p6Dir30 = marketData.priceAction.lastCandle.type === 'BULLISH' ? 'PUT' : 'CALL';
      if (p6Dir30 === direction) {
        htfCoreFallbackScore += 0.6;
        htfCoreFallbackFactors.push('HCF6: Half-Hour Volatility Reset');
      }
    }
    
    // ==============================================================================
    // 🏛️ PILLAR 7: THE "THREE-PUSH" EXHAUSTION (THE "FATIGUE" PILLAR)
    // Core Logic: Algo Budget runs out after 3 waves. 3rd Wave + Extreme RSI = End of Trend.
    // ==============================================================================
    
    // Detect three-push patterns
    const hasThreePushUp = marketData.priceAction.patterns.includes('THREE_WHITE_SOLDIERS');
    const hasThreePushDown = marketData.priceAction.patterns.includes('THREE_BLACK_CROWS');
    
    // 15M Macro Fatigue - Check with RSI extreme
    if (marketDataM15) {
      const m15Rsi = marketDataM15.momentum.rsi14;
      
      if (hasThreePushUp && m15Rsi > 75 && direction === 'PUT') {
        htfCoreFallbackScore += 0.7;
        htfCoreFallbackFactors.push('HCF7: 15M Three-Push Exhaustion PUT');
      }
      if (hasThreePushDown && m15Rsi < 25 && direction === 'CALL') {
        htfCoreFallbackScore += 0.7;
        htfCoreFallbackFactors.push('HCF7: 15M Three-Push Exhaustion CALL');
      }
    }
    
    // 1M Micro Fatigue
    const m1Rsi = marketData.momentum.rsi14;
    if (hasThreePushUp && m1Rsi > 80 && direction === 'PUT') {
      htfCoreFallbackScore += 0.5;
      htfCoreFallbackFactors.push('HCF7: 1M Micro Fatigue PUT');
    }
    if (hasThreePushDown && m1Rsi < 20 && direction === 'CALL') {
      htfCoreFallbackScore += 0.5;
      htfCoreFallbackFactors.push('HCF7: 1M Micro Fatigue CALL');
    }
    
    // ==============================================================================
    // 🏛️ PILLAR 8: PIVOT/FLIP DYNAMICS (THE "DATA BRIDGE" PILLAR)
    // Core Logic: A level that flips from S to R is an "Algorithmic Bridge".
    // ==============================================================================
    
    // Check if price is at CHoCH level (structure flip point)
    if (marketDataM15 && marketDataM15.smc.lastCHoCH) {
      // CHoCH indicates a flip - price should reverse at this level
      const chochLevel = marketDataM15.smc.equilibrium;
      const distToChoch = Math.abs(hcfCurrentPrice - chochLevel);
      
      if (distToChoch <= (2 * hcfPip)) {
        const p8Dir = marketDataM15.smc.lastCHoCH.includes('BULL') ? 'CALL' : 'PUT';
        if (p8Dir === direction) {
          htfCoreFallbackScore += 0.6;
          htfCoreFallbackFactors.push('HCF8: 15M Pivot Flip Bridge');
        }
      }
    }
    
    // H1 Major Flip Level
    if (marketDataH1 && marketDataH1.smc.lastCHoCH) {
      const h1ChochLevel = marketDataH1.smc.equilibrium;
      const distToH1Choch = Math.abs(hcfCurrentPrice - h1ChochLevel);
      
      if (distToH1Choch <= (3 * hcfPip)) {
        const p8DirH1 = marketDataH1.smc.lastCHoCH.includes('BULL') ? 'CALL' : 'PUT';
        if (p8DirH1 === direction) {
          htfCoreFallbackScore += 0.7;
          htfCoreFallbackFactors.push('HCF8: H1 Major Pivot Bridge');
        }
      }
    }
    
    // ==============================================================================
    // 🏛️ PILLAR 9: M5 INSTITUTIONAL FLOW (THE "SHORT-TERM INSTITUTION" PILLAR)
    // Core Logic: M5 data reveals institutional entries invisible on M1.
    // ==============================================================================
    if (marketDataM5) {
      const m5Structure = marketDataM5.smc.marketStructure;
      const m5EmaAlign = marketDataM5.trend.emaAlignment;
      const m5Rsi = marketDataM5.momentum.rsi14;
      
      // M5 structure + M1 entry alignment
      if (m5Structure === 'BULLISH' && m5EmaAlign === 'BULLISH' && m5Rsi > 40 && m5Rsi < 70 && direction === 'CALL') {
        htfCoreFallbackScore += 0.7;
        htfCoreFallbackFactors.push('HCF9: M5 Institutional Bull Flow');
      }
      if (m5Structure === 'BEARISH' && m5EmaAlign === 'BEARISH' && m5Rsi > 30 && m5Rsi < 60 && direction === 'PUT') {
        htfCoreFallbackScore += 0.7;
        htfCoreFallbackFactors.push('HCF9: M5 Institutional Bear Flow');
      }
      
      // M5 Exhaustion Detection
      if (m5Rsi > 80 && direction === 'PUT') {
        htfCoreFallbackScore += 0.5;
        htfCoreFallbackFactors.push('HCF9: M5 RSI Overbought Exhaustion');
      }
      if (m5Rsi < 20 && direction === 'CALL') {
        htfCoreFallbackScore += 0.5;
        htfCoreFallbackFactors.push('HCF9: M5 RSI Oversold Exhaustion');
      }
    }
    
    // ==============================================================================
    // 🏛️ PILLAR 10: TRIPLE-TF CONFLUENCE (THE "ULTIMATE CONFIRMATION" PILLAR)
    // Core Logic: When M1 + M5 + M15 all agree = highest probability trade.
    // ==============================================================================
    if (marketDataM5 && marketDataM15) {
      const m1Dir = marketData.trend.emaAlignment;
      const m5Dir = marketDataM5.trend.emaAlignment;
      const m15Dir = marketDataM15.trend.emaAlignment;
      
      if (m1Dir === 'BULLISH' && m5Dir === 'BULLISH' && m15Dir === 'BULLISH' && direction === 'CALL') {
        htfCoreFallbackScore += 1.0;
        htfCoreFallbackFactors.push('HCF10: TRIPLE-TF BULL CONFLUENCE (M1+M5+M15)');
      }
      if (m1Dir === 'BEARISH' && m5Dir === 'BEARISH' && m15Dir === 'BEARISH' && direction === 'PUT') {
        htfCoreFallbackScore += 1.0;
        htfCoreFallbackFactors.push('HCF10: TRIPLE-TF BEAR CONFLUENCE (M1+M5+M15)');
      }
    }
    
    console.log(`[HTF CORE FALLBACK] Score: ${htfCoreFallbackScore.toFixed(2)}, Pillars: ${htfCoreFallbackFactors.length}`);
    
    // Add fallback score to main HTF score
    htfScore += htfCoreFallbackScore;
    htfFactors.push(...htfCoreFallbackFactors);

    // If none of the 8 pillars matched, add a minimal structure bias bridge.
    // This prevents the HTF fallback from becoming a hard "0" in many market scales.
    if (htfCoreFallbackScore === 0) {
      const basis = marketDataM15 || marketData;
      const biasDir =
        basis.trend.emaAlignment === 'BULLISH'
          ? 'CALL'
          : basis.trend.emaAlignment === 'BEARISH'
            ? 'PUT'
            : basis.priceAction.lastCandle.type === 'BULLISH'
              ? 'CALL'
              : 'PUT';
      if (biasDir === direction) {
        htfCoreFallbackScore += 0.5;
        htfFactors.push('HCF0: Structure Bias Bridge');
        // also reflect in htfScore
        htfScore += 0.5;
      }
    }

    // Ensure HTF can reach its minimum requirement when fallback produced at least one valid match.
    if (htfScore < CATEGORY_MIN_REQUIREMENTS.HTF && htfCoreFallbackScore > 0) {
      const boost = CATEGORY_MIN_REQUIREMENTS.HTF - htfScore;
      htfScore = CATEGORY_MIN_REQUIREMENTS.HTF;
      htfFactors.push(`HTF-FB Completion: +${boost.toFixed(2)}`);
    }
  }
  
  // Final HTF category with minimum requirement tracking
  categories.push({ 
    name: 'HTF Ultra Analyzing (20 Master + 8 Pillars)', 
    score: htfScore, 
    factors: htfFactors,
    minRequired: CATEGORY_MIN_REQUIREMENTS.HTF,
    fallbackUsed: htfFallbackUsed
  });
  
  // ============= CATEGORY 8: MULTI-TIMEFRAME ANALYSIS (M5 + M15 DEEP SCAN) =============
  // Converts 2000 M1 candles → M5 and M15 for institutional-grade HTF confluence
  // Applies full SMC, Liquidity, ICT, and structure analysis on higher timeframes
  let mtfScore = 0;
  const mtfFactors: string[] = [];
  
  if (marketDataM5 || marketDataM15) {
    const pip = getDynamicPipSize(marketData.currentPrice);
    
    // === M5 ANALYSIS (Short-term institutional flow) ===
    if (marketDataM5) {
      // M5 Trend Alignment with M1
      const m5TrendAlign = marketDataM5.trend.emaAlignment;
      const m1TrendAlign = marketData.trend.emaAlignment;
      if (m5TrendAlign === 'BULLISH' && direction === 'CALL') {
        mtfScore += 0.8;
        mtfFactors.push('MTF-M5: Bullish EMA alignment confirms CALL');
      } else if (m5TrendAlign === 'BEARISH' && direction === 'PUT') {
        mtfScore += 0.8;
        mtfFactors.push('MTF-M5: Bearish EMA alignment confirms PUT');
      }
      
      // M5 Cross-TF Trend Harmony (M1 + M5 same direction)
      if (m5TrendAlign === m1TrendAlign && m5TrendAlign !== 'NEUTRAL') {
        const harmDir = m5TrendAlign === 'BULLISH' ? 'CALL' : 'PUT';
        if (harmDir === direction) {
          mtfScore += 0.6;
          mtfFactors.push('MTF-M5: M1↔M5 Trend Harmony');
        }
      }
      
      // M5 SMC Structure (Order Blocks, FVG, CHoCH)
      if (marketDataM5.smc.marketStructure === 'BULLISH' && direction === 'CALL') {
        mtfScore += 0.7;
        mtfFactors.push('MTF-M5: Bullish SMC structure (HH/HL)');
      } else if (marketDataM5.smc.marketStructure === 'BEARISH' && direction === 'PUT') {
        mtfScore += 0.7;
        mtfFactors.push('MTF-M5: Bearish SMC structure (LH/LL)');
      }
      
      // M5 FVG Detection
      if (marketDataM5.smc.hasBullishFVG && direction === 'CALL') {
        mtfScore += 0.5;
        mtfFactors.push('MTF-M5: Bullish FVG detected');
      }
      if (marketDataM5.smc.hasBearishFVG && direction === 'PUT') {
        mtfScore += 0.5;
        mtfFactors.push('MTF-M5: Bearish FVG detected');
      }
      
      // M5 Order Block proximity
      if (marketDataM5.smc.nearDemandOB && direction === 'CALL') {
        mtfScore += 0.6;
        mtfFactors.push('MTF-M5: Price at M5 Demand OB');
      }
      if (marketDataM5.smc.nearSupplyOB && direction === 'PUT') {
        mtfScore += 0.6;
        mtfFactors.push('MTF-M5: Price at M5 Supply OB');
      }
      
      // M5 Premium/Discount Zone
      if (marketDataM5.smc.premiumDiscount === 'DISCOUNT' && direction === 'CALL') {
        mtfScore += 0.5;
        mtfFactors.push('MTF-M5: M5 Discount zone (institutional buy zone)');
      }
      if (marketDataM5.smc.premiumDiscount === 'PREMIUM' && direction === 'PUT') {
        mtfScore += 0.5;
        mtfFactors.push('MTF-M5: M5 Premium zone (institutional sell zone)');
      }
      
      // M5 Liquidity Sweep Detection
      if (marketDataM5.smc.hasLiquiditySweep) {
        const sweepType = marketDataM5.smc.lastLiquiditySweep;
        if (sweepType === 'SSL' && direction === 'CALL') {
          mtfScore += 0.8;
          mtfFactors.push('MTF-M5: SSL sweep on M5 (smart money accumulation)');
        }
        if (sweepType === 'BSL' && direction === 'PUT') {
          mtfScore += 0.8;
          mtfFactors.push('MTF-M5: BSL sweep on M5 (smart money distribution)');
        }
      }
      
      // M5 RSI Confluence
      const m5Rsi = marketDataM5.momentum.rsi14;
      if (m5Rsi < 30 && direction === 'CALL') {
        mtfScore += 0.4;
        mtfFactors.push(`MTF-M5: RSI oversold ${m5Rsi.toFixed(0)} (reversal zone)`);
      }
      if (m5Rsi > 70 && direction === 'PUT') {
        mtfScore += 0.4;
        mtfFactors.push(`MTF-M5: RSI overbought ${m5Rsi.toFixed(0)} (reversal zone)`);
      }
      
      // M5 Volume Profile
      if (marketDataM5.volume.obvTrend === 'BULLISH' && direction === 'CALL') {
        mtfScore += 0.4;
        mtfFactors.push('MTF-M5: OBV bullish trend on M5');
      }
      if (marketDataM5.volume.obvTrend === 'BEARISH' && direction === 'PUT') {
        mtfScore += 0.4;
        mtfFactors.push('MTF-M5: OBV bearish trend on M5');
      }
      
      // M5 CHoCH (Change of Character) detection
      if (marketDataM5.smc.lastCHoCH) {
        if (marketDataM5.smc.lastCHoCH.includes('BULL') && direction === 'CALL') {
          mtfScore += 0.7;
          mtfFactors.push('MTF-M5: Bullish CHoCH on M5 timeframe');
        }
        if (marketDataM5.smc.lastCHoCH.includes('BEAR') && direction === 'PUT') {
          mtfScore += 0.7;
          mtfFactors.push('MTF-M5: Bearish CHoCH on M5 timeframe');
        }
      }
      
      // M5 BOS (Break of Structure)
      if (marketDataM5.smc.lastBOS === 'BULLISH_BOS' && direction === 'CALL') {
        mtfScore += 0.6;
        mtfFactors.push('MTF-M5: Bullish BOS confirmed on M5');
      }
      if (marketDataM5.smc.lastBOS === 'BEARISH_BOS' && direction === 'PUT') {
        mtfScore += 0.6;
        mtfFactors.push('MTF-M5: Bearish BOS confirmed on M5');
      }
    }
    
    // === M15 ANALYSIS (Macro institutional flow) ===
    if (marketDataM15) {
      // M15 Trend Alignment
      if (marketDataM15.trend.emaAlignment === 'BULLISH' && direction === 'CALL') {
        mtfScore += 1.0;
        mtfFactors.push('MTF-M15: Bullish macro trend alignment');
      } else if (marketDataM15.trend.emaAlignment === 'BEARISH' && direction === 'PUT') {
        mtfScore += 1.0;
        mtfFactors.push('MTF-M15: Bearish macro trend alignment');
      }
      
      // M15 SMC Structure
      if (marketDataM15.smc.marketStructure === 'BULLISH' && direction === 'CALL') {
        mtfScore += 0.8;
        mtfFactors.push('MTF-M15: Bullish institutional structure');
      } else if (marketDataM15.smc.marketStructure === 'BEARISH' && direction === 'PUT') {
        mtfScore += 0.8;
        mtfFactors.push('MTF-M15: Bearish institutional structure');
      }
      
      // M15 FVG
      if (marketDataM15.smc.hasBullishFVG && direction === 'CALL') {
        mtfScore += 0.6;
        mtfFactors.push('MTF-M15: Bullish FVG on macro timeframe');
      }
      if (marketDataM15.smc.hasBearishFVG && direction === 'PUT') {
        mtfScore += 0.6;
        mtfFactors.push('MTF-M15: Bearish FVG on macro timeframe');
      }
      
      // M15 Order Blocks
      if (marketDataM15.smc.nearDemandOB && direction === 'CALL') {
        mtfScore += 0.7;
        mtfFactors.push('MTF-M15: Price at M15 Demand Order Block');
      }
      if (marketDataM15.smc.nearSupplyOB && direction === 'PUT') {
        mtfScore += 0.7;
        mtfFactors.push('MTF-M15: Price at M15 Supply Order Block');
      }
      
      // M15 Liquidity Sweep
      if (marketDataM15.smc.hasLiquiditySweep) {
        const sweepType15 = marketDataM15.smc.lastLiquiditySweep;
        if (sweepType15 === 'SSL' && direction === 'CALL') {
          mtfScore += 1.0;
          mtfFactors.push('MTF-M15: SSL sweep (major smart money accumulation)');
        }
        if (sweepType15 === 'BSL' && direction === 'PUT') {
          mtfScore += 1.0;
          mtfFactors.push('MTF-M15: BSL sweep (major smart money distribution)');
        }
      }
      
      // M15 CHoCH
      if (marketDataM15.smc.lastCHoCH) {
        if (marketDataM15.smc.lastCHoCH.includes('BULL') && direction === 'CALL') {
          mtfScore += 0.9;
          mtfFactors.push('MTF-M15: Bullish CHoCH (macro character change)');
        }
        if (marketDataM15.smc.lastCHoCH.includes('BEAR') && direction === 'PUT') {
          mtfScore += 0.9;
          mtfFactors.push('MTF-M15: Bearish CHoCH (macro character change)');
        }
      }
      
      // M15 Premium/Discount
      if (marketDataM15.smc.premiumDiscount === 'DISCOUNT' && direction === 'CALL') {
        mtfScore += 0.6;
        mtfFactors.push('MTF-M15: M15 Discount zone');
      }
      if (marketDataM15.smc.premiumDiscount === 'PREMIUM' && direction === 'PUT') {
        mtfScore += 0.6;
        mtfFactors.push('MTF-M15: M15 Premium zone');
      }
      
      // M15 RSI Extremes
      const m15Rsi = marketDataM15.momentum.rsi14;
      if (m15Rsi < 25 && direction === 'CALL') {
        mtfScore += 0.5;
        mtfFactors.push(`MTF-M15: Deep oversold RSI ${m15Rsi.toFixed(0)}`);
      }
      if (m15Rsi > 75 && direction === 'PUT') {
        mtfScore += 0.5;
        mtfFactors.push(`MTF-M15: Deep overbought RSI ${m15Rsi.toFixed(0)}`);
      }
      
      // M15 Stochastic Confluence
      const m15Stoch = marketDataM15.momentum.stochastic;
      const m15BullishCross = m15Stoch.k > m15Stoch.d;
      const m15BearishCross = m15Stoch.k < m15Stoch.d;
      if (m15Stoch.k < 20 && m15BullishCross && direction === 'CALL') {
        mtfScore += 0.6;
        mtfFactors.push('MTF-M15: Stochastic bullish crossover in oversold');
      }
      if (m15Stoch.k > 80 && m15BearishCross && direction === 'PUT') {
        mtfScore += 0.6;
        mtfFactors.push('MTF-M15: Stochastic bearish crossover in overbought');
      }
    }
    
    // === TRIPLE TIMEFRAME CONFLUENCE (M1 + M5 + M15 all agree) ===
    if (marketDataM5 && marketDataM15) {
      const m1Dir = marketData.trend.emaAlignment;
      const m5Dir = marketDataM5.trend.emaAlignment;
      const m15Dir = marketDataM15.trend.emaAlignment;
      
      if (m1Dir === 'BULLISH' && m5Dir === 'BULLISH' && m15Dir === 'BULLISH' && direction === 'CALL') {
        mtfScore += 1.5;
        mtfFactors.push('MTF-TRIPLE: M1+M5+M15 ALL BULLISH (maximum confluence)');
      }
      if (m1Dir === 'BEARISH' && m5Dir === 'BEARISH' && m15Dir === 'BEARISH' && direction === 'PUT') {
        mtfScore += 1.5;
        mtfFactors.push('MTF-TRIPLE: M1+M5+M15 ALL BEARISH (maximum confluence)');
      }
      
      // Triple SMC alignment
      const m1Smc = marketData.smc.marketStructure;
      const m5Smc = marketDataM5.smc.marketStructure;
      const m15Smc = marketDataM15.smc.marketStructure;
      if (m1Smc === 'BULLISH' && m5Smc === 'BULLISH' && m15Smc === 'BULLISH' && direction === 'CALL') {
        mtfScore += 1.2;
        mtfFactors.push('MTF-TRIPLE: SMC structure aligned BULLISH across all TFs');
      }
      if (m1Smc === 'BEARISH' && m5Smc === 'BEARISH' && m15Smc === 'BEARISH' && direction === 'PUT') {
        mtfScore += 1.2;
        mtfFactors.push('MTF-TRIPLE: SMC structure aligned BEARISH across all TFs');
      }
    }
    
    console.log(`[MTF ANALYSIS] Score: ${mtfScore.toFixed(2)}, Factors: ${mtfFactors.length}`);
  }
  
  if (mtfFactors.length > 0) {
    categories.push({ name: 'Multi-Timeframe Analysis (M5+M15)', score: mtfScore, factors: mtfFactors });
  }
  
  // ============= CATEGORY 9: REVERSAL TRIGGER ENGINE =============
  // Deep analysis across ALL categories to find high-probability reversal points
  // Uses exhaustion, divergence, liquidity grabs, and institutional displacement
  let reversalScore = 0;
  const reversalFactors: string[] = [];
  
  if (raw && raw.closes.length >= 30) {
    const revCloses = raw.closes;
    const revOpens = raw.opens;
    const revHighs = raw.highs;
    const revLows = raw.lows;
    const revVolumes = raw.volumes;
    const revLen = revCloses.length;
    const lastI = revLen - 1;
    const revPip = getDynamicPipSize(revCloses[lastI]);
    const revBody = Math.abs(revCloses[lastI] - revOpens[lastI]);
    const revAvgBody = revCloses.slice(-20).reduce((s, c, i) => s + Math.abs(c - revOpens[revOpens.length - 20 + i]), 0) / 20;
    const revAvgVol = revVolumes.slice(-20).reduce((s, v) => s + v, 0) / 20;
    
    // R1: Price Exhaustion Detection (3+ consecutive same-direction candles + RSI extreme)
    let consecCount = 0;
    const lastBullish = revCloses[lastI] > revOpens[lastI];
    for (let i = lastI; i > Math.max(lastI - 10, 0); i--) {
      if ((revCloses[i] > revOpens[i]) === lastBullish) consecCount++;
      else break;
    }
    if (consecCount >= 3 && marketData.momentum.rsi14 > 75 && direction === 'PUT') {
      reversalScore += 1.2;
      reversalFactors.push(`REV-R1: ${consecCount} bullish candles + RSI ${marketData.momentum.rsi14.toFixed(0)} (exhaustion PUT)`);
    }
    if (consecCount >= 3 && marketData.momentum.rsi14 < 25 && direction === 'CALL') {
      reversalScore += 1.2;
      reversalFactors.push(`REV-R1: ${consecCount} bearish candles + RSI ${marketData.momentum.rsi14.toFixed(0)} (exhaustion CALL)`);
    }
    
    // R2: Wick Rejection Reversal (long wick = institutional rejection)
    const upperWick = revHighs[lastI] - Math.max(revCloses[lastI], revOpens[lastI]);
    const lowerWick = Math.min(revCloses[lastI], revOpens[lastI]) - revLows[lastI];
    const totalRange = revHighs[lastI] - revLows[lastI];
    
    if (totalRange > 0) {
      if (upperWick / totalRange > 0.65 && direction === 'PUT') {
        reversalScore += 1.0;
        reversalFactors.push('REV-R2: Long upper wick rejection (65%+ wick ratio)');
      }
      if (lowerWick / totalRange > 0.65 && direction === 'CALL') {
        reversalScore += 1.0;
        reversalFactors.push('REV-R2: Long lower wick rejection (65%+ wick ratio)');
      }
    }
    
    // R3: Volume Climax Reversal (spike volume + small body = institutional distribution)
    if (revVolumes[lastI] > revAvgVol * 2.5 && revBody < revAvgBody * 0.6) {
      const climaxDir = revCloses[lastI] > revOpens[lastI] ? 'PUT' : 'CALL';
      if (climaxDir === direction) {
        reversalScore += 1.1;
        reversalFactors.push('REV-R3: Volume climax with small body (distribution reversal)');
      }
    }
    
    // R4: Divergence Detection (Price makes new high/low but RSI doesn't)
    if (lastI >= 10) {
      const priceHigh10 = Math.max(...revHighs.slice(-10));
      const priceLow10 = Math.min(...revLows.slice(-10));
      const currentRsi = marketData.momentum.rsi14;
      
      // Bearish divergence: price at high but RSI declining
      if (revHighs[lastI] >= priceHigh10 * 0.998 && currentRsi < 60 && direction === 'PUT') {
        reversalScore += 0.9;
        reversalFactors.push('REV-R4: Bearish divergence (price high + RSI declining)');
      }
      // Bullish divergence: price at low but RSI rising
      if (revLows[lastI] <= priceLow10 * 1.002 && currentRsi > 40 && direction === 'CALL') {
        reversalScore += 0.9;
        reversalFactors.push('REV-R4: Bullish divergence (price low + RSI rising)');
      }
    }
    
    // R5: Liquidity Grab Reversal (sweep then reverse)
    if (lastI >= 3) {
      const prevHigh = Math.max(...revHighs.slice(-5, -1));
      const prevLow = Math.min(...revLows.slice(-5, -1));
      
      // Swept high then closed below = bearish reversal
      if (revHighs[lastI] > prevHigh && revCloses[lastI] < prevHigh && direction === 'PUT') {
        reversalScore += 1.3;
        reversalFactors.push('REV-R5: Liquidity grab above highs + close below (bearish reversal)');
      }
      // Swept low then closed above = bullish reversal
      if (revLows[lastI] < prevLow && revCloses[lastI] > prevLow && direction === 'CALL') {
        reversalScore += 1.3;
        reversalFactors.push('REV-R5: Liquidity grab below lows + close above (bullish reversal)');
      }
    }
    
    // R6: Engulfing Pattern Reversal
    if (lastI >= 1) {
      const prevBody = Math.abs(revCloses[lastI - 1] - revOpens[lastI - 1]);
      const bullEngulf = revCloses[lastI] > revOpens[lastI] && revCloses[lastI - 1] < revOpens[lastI - 1] && revBody > prevBody * 1.5;
      const bearEngulf = revCloses[lastI] < revOpens[lastI] && revCloses[lastI - 1] > revOpens[lastI - 1] && revBody > prevBody * 1.5;
      
      if (bullEngulf && direction === 'CALL') {
        reversalScore += 0.8;
        reversalFactors.push('REV-R6: Bullish engulfing pattern (1.5x body)');
      }
      if (bearEngulf && direction === 'PUT') {
        reversalScore += 0.8;
        reversalFactors.push('REV-R6: Bearish engulfing pattern (1.5x body)');
      }
    }
    
    // R7: S/R Level Bounce Reversal
    const distToSupport = Math.abs(revCloses[lastI] - marketData.smc.support);
    const distToResistance = Math.abs(revCloses[lastI] - marketData.smc.resistance);
    if (distToSupport < revPip * 3 && direction === 'CALL') {
      reversalScore += 0.7;
      reversalFactors.push('REV-R7: Price at support level (bounce reversal)');
    }
    if (distToResistance < revPip * 3 && direction === 'PUT') {
      reversalScore += 0.7;
      reversalFactors.push('REV-R7: Price at resistance level (rejection reversal)');
    }
    
    // R8: Stochastic Extreme Reversal
    const stochK = marketData.momentum.stochastic.k;
    const stochD = marketData.momentum.stochastic.d;
    if (stochK < 15 && stochK > stochD && direction === 'CALL') {
      reversalScore += 0.6;
      reversalFactors.push('REV-R8: Stochastic extreme oversold + K crossing above D');
    }
    if (stochK > 85 && stochK < stochD && direction === 'PUT') {
      reversalScore += 0.6;
      reversalFactors.push('REV-R8: Stochastic extreme overbought + K crossing below D');
    }
    
    // R9: Three-Push Exhaustion Pattern
    if (lastI >= 6) {
      let pushes = 0;
      for (let p = lastI; p > lastI - 6 && p >= 1; p--) {
        if (lastBullish && revHighs[p] > revHighs[p - 1]) pushes++;
        if (!lastBullish && revLows[p] < revLows[p - 1]) pushes++;
      }
      if (pushes >= 3) {
        const exhDir = lastBullish ? 'PUT' : 'CALL';
        if (exhDir === direction) {
          reversalScore += 0.9;
          reversalFactors.push(`REV-R9: Three-push exhaustion (${pushes} pushes → reversal)`);
        }
      }
    }
    
    // R10: HTF Reversal Confluence (M5/M15 opposing M1 trend)
    if (marketDataM5 && marketDataM15) {
      const m1Trend = marketData.trend.emaAlignment;
      const m15Trend = marketDataM15.trend.emaAlignment;
      if (m1Trend === 'BULLISH' && m15Trend === 'BEARISH' && direction === 'PUT') {
        reversalScore += 0.8;
        reversalFactors.push('REV-R10: M1 bullish vs M15 bearish (HTF reversal confluence)');
      }
      if (m1Trend === 'BEARISH' && m15Trend === 'BULLISH' && direction === 'CALL') {
        reversalScore += 0.8;
        reversalFactors.push('REV-R10: M1 bearish vs M15 bullish (HTF reversal confluence)');
      }
    }
    
    // R11: MACD Histogram Reversal (Histogram shrinking after peak = momentum loss)
    if (marketData.momentum.macd) {
      const hist = marketData.momentum.macd.histogram;
      if (hist > 0 && hist < marketData.volatility.atr * 0.1 && lastBullish && direction === 'PUT') {
        reversalScore += 0.7;
        reversalFactors.push('REV-R11: MACD histogram fading bullish → reversal PUT');
      }
      if (hist < 0 && hist > -marketData.volatility.atr * 0.1 && !lastBullish && direction === 'CALL') {
        reversalScore += 0.7;
        reversalFactors.push('REV-R11: MACD histogram fading bearish → reversal CALL');
      }
    }
    
    // R12: Bollinger Band Extreme Rejection (Price touches outer band + reversal candle)
    if (marketData.volatility.bollinger.position === 'UPPER_BAND' && revBody < revAvgBody * 0.6 && direction === 'PUT') {
      reversalScore += 0.8;
      reversalFactors.push('REV-R12: BB upper band rejection + small body (exhaustion)');
    }
    if (marketData.volatility.bollinger.position === 'LOWER_BAND' && revBody < revAvgBody * 0.6 && direction === 'CALL') {
      reversalScore += 0.8;
      reversalFactors.push('REV-R12: BB lower band rejection + small body (exhaustion)');
    }
    
    // R13: Volume-Price Divergence Reversal (Big body + dropping volume = hollow move)
    if (revVolumes[lastI] < revAvgVol * 0.5 && revBody > revAvgBody * 1.5) {
      const hollowDir = lastBullish ? 'PUT' : 'CALL';
      if (hollowDir === direction) {
        reversalScore += 0.9;
        reversalFactors.push('REV-R13: Hollow move reversal (big body + low volume)');
      }
    }
    
    // R14: Double Top/Bottom Reversal (Equal highs/lows then reverse)
    if (lastI >= 10) {
      const recent5Highs = revHighs.slice(-5);
      const recent5Lows = revLows.slice(-5);
      const prev5Highs = revHighs.slice(-10, -5);
      const prevMaxHigh = Math.max(...prev5Highs);
      const recentMaxHigh = Math.max(...recent5Highs);
      if (Math.abs(recentMaxHigh - prevMaxHigh) < revPip * 2 && !lastBullish && direction === 'PUT') {
        reversalScore += 1.0;
        reversalFactors.push('REV-R14: Double top reversal (equal highs → PUT)');
      }
      const prevMinLow = Math.min(...revLows.slice(-10, -5));
      const recentMinLow = Math.min(...recent5Lows);
      if (Math.abs(recentMinLow - prevMinLow) < revPip * 2 && lastBullish && direction === 'CALL') {
        reversalScore += 1.0;
        reversalFactors.push('REV-R14: Double bottom reversal (equal lows → CALL)');
      }
    }
    
    // R15: OTC Algo Boundary Reversal (Price at max deviation from 50-candle mean)
    if (lastI >= 50) {
      const mean50 = revCloses.slice(-50).reduce((a, b) => a + b, 0) / 50;
      const maxDev = Math.max(...revCloses.slice(-50).map(c => Math.abs(c - mean50)));
      const currentDev = Math.abs(revCloses[lastI] - mean50);
      if (currentDev > maxDev * 0.85) {
        const boundaryDir = revCloses[lastI] > mean50 ? 'PUT' : 'CALL';
        if (boundaryDir === direction) {
          reversalScore += 1.1;
          reversalFactors.push('REV-R15: Algo boundary reversal (85%+ max deviation)');
        }
      }
    }
    
    // R16: SMC Zone Reversal (Price at OB/FVG zone + exhaustion = institutional reversal)
    if (marketData.smc.nearDemandOB && consecCount >= 2 && !lastBullish && direction === 'CALL') {
      reversalScore += 1.4;
      reversalFactors.push('REV-R16: SMC Demand OB + bearish exhaustion → institutional CALL reversal');
    }
    if (marketData.smc.nearSupplyOB && consecCount >= 2 && lastBullish && direction === 'PUT') {
      reversalScore += 1.4;
      reversalFactors.push('REV-R16: SMC Supply OB + bullish exhaustion → institutional PUT reversal');
    }
    
    // R17: ICT FVG Mitigation Reversal (Price filling FVG + reversal candle = smart money entry)
    if (marketData.smc.hasBullishFVG && marketData.momentum.rsi14 < 35 && direction === 'CALL') {
      reversalScore += 1.2;
      reversalFactors.push('REV-R17: ICT bullish FVG + RSI oversold (smart money accumulation reversal)');
    }
    if (marketData.smc.hasBearishFVG && marketData.momentum.rsi14 > 65 && direction === 'PUT') {
      reversalScore += 1.2;
      reversalFactors.push('REV-R17: ICT bearish FVG + RSI overbought (smart money distribution reversal)');
    }
    
    // R18: Liquidity Sweep + SMC Confluence Reversal (Sweep liquidity then reverse at SMC zone)
    if (lastI >= 5) {
      const sweepHigh = revHighs[lastI] > Math.max(...revHighs.slice(-10, -1));
      const sweepLow = revLows[lastI] < Math.min(...revLows.slice(-10, -1));
      if (sweepHigh && marketData.smc.nearSupplyOB && revCloses[lastI] < revOpens[lastI] && direction === 'PUT') {
        reversalScore += 1.6;
        reversalFactors.push('REV-R18: Liquidity sweep high + Supply OB rejection (institutional trap reversal)');
      }
      if (sweepLow && marketData.smc.nearDemandOB && revCloses[lastI] > revOpens[lastI] && direction === 'CALL') {
        reversalScore += 1.6;
        reversalFactors.push('REV-R18: Liquidity sweep low + Demand OB bounce (institutional trap reversal)');
      }
    }
    
    // R19: OTC Trap Confluence Reversal (Volume Ghost + Wick Assassin = algo reversal)
    const r19UpperW = revHighs[lastI] - Math.max(revCloses[lastI], revOpens[lastI]);
    const r19LowerW = Math.min(revCloses[lastI], revOpens[lastI]) - revLows[lastI];
    if (revVolumes[lastI] > revAvgVol * 2 && revBody < revAvgBody * 0.5 && r19UpperW > revBody * 2 && direction === 'PUT') {
      reversalScore += 1.3;
      reversalFactors.push('REV-R19: OTC Volume Ghost + Wick Assassin combo (algo reversal PUT)');
    }
    if (revVolumes[lastI] > revAvgVol * 2 && revBody < revAvgBody * 0.5 && r19LowerW > revBody * 2 && direction === 'CALL') {
      reversalScore += 1.3;
      reversalFactors.push('REV-R19: OTC Volume Ghost + Wick Assassin combo (algo reversal CALL)');
    }
    
    // R20: Multi-Indicator Extreme Convergence Reversal (RSI + Stoch + BB all at extremes)
    const r20Rsi = marketData.momentum.rsi14;
    const r20StochK = marketData.momentum.stochastic.k;
    const r20BB = marketData.volatility.bollinger.position;
    if (r20Rsi > 75 && r20StochK > 80 && r20BB === 'UPPER_BAND' && direction === 'PUT') {
      reversalScore += 1.5;
      reversalFactors.push('REV-R20: Triple-indicator extreme (RSI+Stoch+BB overbought convergence → PUT)');
    }
    if (r20Rsi < 25 && r20StochK < 20 && r20BB === 'LOWER_BAND' && direction === 'CALL') {
      reversalScore += 1.5;
      reversalFactors.push('REV-R20: Triple-indicator extreme (RSI+Stoch+BB oversold convergence → CALL)');
    }
    
    // R21: ICT Market Maker Model Reversal (Sweep + Displacement + CHoCH = MMM reversal)
    if (marketData.smc.lastCHoCH) {
      const chochBull = marketData.smc.lastCHoCH.includes('BULL');
      const chochBear = marketData.smc.lastCHoCH.includes('BEAR');
      if (chochBear && revBody > revAvgBody * 1.5 && revCloses[lastI] < revOpens[lastI] && direction === 'PUT') {
        reversalScore += 1.4;
        reversalFactors.push('REV-R21: ICT MMM Reversal (Bearish CHoCH + displacement → institutional PUT)');
      }
      if (chochBull && revBody > revAvgBody * 1.5 && revCloses[lastI] > revOpens[lastI] && direction === 'CALL') {
        reversalScore += 1.4;
        reversalFactors.push('REV-R21: ICT MMM Reversal (Bullish CHoCH + displacement → institutional CALL)');
      }
    }
    
    // R22: MTF Divergence Reversal (M1 exhausted + M5/M15 opposing = HTF reversal)
    if (marketDataM5 && marketDataM15) {
      const m1Exh = (marketData.momentum.rsi14 > 70 || marketData.momentum.rsi14 < 30);
      const m5Trend = marketDataM5.trend.emaAlignment;
      const m15Trend = marketDataM15.trend.emaAlignment;
      if (m1Exh && marketData.momentum.rsi14 > 70 && (m5Trend === 'BEARISH' || m15Trend === 'BEARISH') && direction === 'PUT') {
        reversalScore += 1.3;
        reversalFactors.push('REV-R22: MTF Divergence (M1 overbought + M5/M15 bearish → HTF reversal PUT)');
      }
      if (m1Exh && marketData.momentum.rsi14 < 30 && (m5Trend === 'BULLISH' || m15Trend === 'BULLISH') && direction === 'CALL') {
        reversalScore += 1.3;
        reversalFactors.push('REV-R22: MTF Divergence (M1 oversold + M5/M15 bullish → HTF reversal CALL)');
      }
    }
    
    // R23: BOS + Liquidity Grab Reversal (Structure break + liquidity sweep = institutional reversal)
    if (marketData.smc.lastBOS) {
      const bosRecent = marketData.smc.lastBOS;
      if (lastI >= 3) {
        const swept5H = revHighs[lastI] > Math.max(...revHighs.slice(-5, -1));
        const swept5L = revLows[lastI] < Math.min(...revLows.slice(-5, -1));
        if (bosRecent === 'BEARISH_BOS' && swept5H && revCloses[lastI] < revOpens[lastI] && direction === 'PUT') {
          reversalScore += 1.5;
          reversalFactors.push('REV-R23: BOS + Liquidity sweep high (structure break reversal PUT)');
        }
        if (bosRecent === 'BULLISH_BOS' && swept5L && revCloses[lastI] > revOpens[lastI] && direction === 'CALL') {
          reversalScore += 1.5;
          reversalFactors.push('REV-R23: BOS + Liquidity sweep low (structure break reversal CALL)');
        }
      }
    }
    
    // R24: Parabolic SAR Flip + Volume Confirmation Reversal
    if (marketData.parabolicSAR.trend === 'BEARISH' && revVolumes[lastI] > revAvgVol * 1.5 && direction === 'PUT') {
      if (consecCount >= 2 && lastBullish) {
        reversalScore += 1.1;
        reversalFactors.push('REV-R24: PSAR bearish flip + volume spike after bullish run → reversal PUT');
      }
    }
    if (marketData.parabolicSAR.trend === 'BULLISH' && revVolumes[lastI] > revAvgVol * 1.5 && direction === 'CALL') {
      if (consecCount >= 2 && !lastBullish) {
        reversalScore += 1.1;
        reversalFactors.push('REV-R24: PSAR bullish flip + volume spike after bearish run → reversal CALL');
      }
    }
    
    // R25: Full-Category Convergence Reversal (4+ categories signal reversal simultaneously)
    let revConvergenceCount = 0;
    if (marketData.momentum.rsi14 > 70 || marketData.momentum.rsi14 < 30) revConvergenceCount++;
    if (marketData.smc.lastCHoCH) revConvergenceCount++;
    if (marketData.smc.nearDemandOB || marketData.smc.nearSupplyOB) revConvergenceCount++;
    if (marketData.volatility.bollinger.position === 'UPPER_BAND' || marketData.volatility.bollinger.position === 'LOWER_BAND') revConvergenceCount++;
    if (marketData.momentum.stochastic.k > 80 || marketData.momentum.stochastic.k < 20) revConvergenceCount++;
    if (marketDataM5 && marketDataM5.trend.emaAlignment !== marketData.trend.emaAlignment) revConvergenceCount++;
    if (revConvergenceCount >= 4) {
      reversalScore += 1.8;
      reversalFactors.push(`REV-R25: ULTRA Convergence Reversal (${revConvergenceCount}/6 categories confirm reversal)`);
    }
    
    console.log(`[REVERSAL ENGINE] Score: ${reversalScore.toFixed(2)}, Triggers: ${reversalFactors.length}`);
  }
  
  if (reversalFactors.length > 0) {
    categories.push({ name: 'Reversal Trigger Engine (25 Ultra)', score: reversalScore, factors: reversalFactors });
  }
  
  // ============= CATEGORY 10: CONTINUATION TRIGGER ENGINE =============
  // Identifies high-probability trend continuation setups using momentum, structure, and volume
  let contScore = 0;
  const contFactors: string[] = [];
  
  if (raw && raw.closes.length >= 30) {
    const cCloses = raw.closes;
    const cOpens = raw.opens;
    const cHighs = raw.highs;
    const cLows = raw.lows;
    const cVolumes = raw.volumes;
    const cLen = cCloses.length;
    const cLast = cLen - 1;
    const cBody = Math.abs(cCloses[cLast] - cOpens[cLast]);
    const cAvgBody = cCloses.slice(-20).reduce((s, c, i) => s + Math.abs(c - cOpens[cOpens.length - 20 + i]), 0) / 20;
    const cAvgVol = cVolumes.slice(-20).reduce((s, v) => s + v, 0) / 20;
    const cBullish = cCloses[cLast] > cOpens[cLast];
    
    // C1: Strong Trend Momentum (EMA stack + ADX > 25)
    if (marketData.trend.adx > 25) {
      if (marketData.trend.emaAlignment === 'BULLISH' && direction === 'CALL') {
        contScore += 1.0;
        contFactors.push(`CONT-C1: Strong bullish momentum (ADX ${marketData.trend.adx.toFixed(0)} + EMA bullish stack)`);
      }
      if (marketData.trend.emaAlignment === 'BEARISH' && direction === 'PUT') {
        contScore += 1.0;
        contFactors.push(`CONT-C1: Strong bearish momentum (ADX ${marketData.trend.adx.toFixed(0)} + EMA bearish stack)`);
      }
    }
    
    // C2: Pullback to EMA20 in Trend (healthy retracement)
    const ema20Dist = Math.abs(cCloses[cLast] - marketData.trend.ema20);
    const pip = getDynamicPipSize(cCloses[cLast]);
    if (ema20Dist < pip * 3 && marketData.trend.emaAlignment === 'BULLISH' && cBullish && direction === 'CALL') {
      contScore += 0.9;
      contFactors.push('CONT-C2: Bullish pullback to EMA20 (healthy retracement)');
    }
    if (ema20Dist < pip * 3 && marketData.trend.emaAlignment === 'BEARISH' && !cBullish && direction === 'PUT') {
      contScore += 0.9;
      contFactors.push('CONT-C2: Bearish pullback to EMA20 (healthy retracement)');
    }
    
    // C3: Higher Highs / Lower Lows Continuation
    if (cLast >= 3) {
      const hh = cHighs[cLast] > cHighs[cLast - 1] && cHighs[cLast - 1] > cHighs[cLast - 2];
      const ll = cLows[cLast] < cLows[cLast - 1] && cLows[cLast - 1] < cLows[cLast - 2];
      const hl = cLows[cLast] > cLows[cLast - 1] && cLows[cLast - 1] > cLows[cLast - 2];
      const lh = cHighs[cLast] < cHighs[cLast - 1] && cHighs[cLast - 1] < cHighs[cLast - 2];
      
      if (hh && hl && direction === 'CALL') {
        contScore += 1.1;
        contFactors.push('CONT-C3: HH + HL pattern (strong bullish continuation)');
      }
      if (ll && lh && direction === 'PUT') {
        contScore += 1.1;
        contFactors.push('CONT-C3: LL + LH pattern (strong bearish continuation)');
      }
    }
    
    // C4: Volume Confirmation (increasing volume in trend direction)
    if (cVolumes[cLast] > cAvgVol * 1.3) {
      if (cBullish && direction === 'CALL') {
        contScore += 0.7;
        contFactors.push('CONT-C4: Rising volume on bullish candle (institutional continuation)');
      }
      if (!cBullish && direction === 'PUT') {
        contScore += 0.7;
        contFactors.push('CONT-C4: Rising volume on bearish candle (institutional continuation)');
      }
    }
    
    // C5: BOS (Break of Structure) Continuation
    if (marketData.smc.lastBOS === 'BULLISH_BOS' && direction === 'CALL') {
      contScore += 0.8;
      contFactors.push('CONT-C5: Bullish BOS → trend continuation');
    }
    if (marketData.smc.lastBOS === 'BEARISH_BOS' && direction === 'PUT') {
      contScore += 0.8;
      contFactors.push('CONT-C5: Bearish BOS → trend continuation');
    }
    
    // C6: MACD Histogram Expansion (momentum building)
    if (marketData.momentum.macd) {
      const macdHist = marketData.momentum.macd.histogram;
      if (macdHist > 0 && marketData.momentum.macd.signal > 0 && direction === 'CALL') {
        contScore += 0.6;
        contFactors.push('CONT-C6: MACD histogram expanding bullish');
      }
      if (macdHist < 0 && marketData.momentum.macd.signal < 0 && direction === 'PUT') {
        contScore += 0.6;
        contFactors.push('CONT-C6: MACD histogram expanding bearish');
      }
    }
    
    // C7: Bollinger Band Walk (price riding the band)
    if (marketData.volatility.bollinger.position === 'UPPER_BAND' && direction === 'CALL') {
      contScore += 0.5;
      contFactors.push('CONT-C7: Bollinger upper band walk (strong bullish trend)');
    }
    if (marketData.volatility.bollinger.position === 'LOWER_BAND' && direction === 'PUT') {
      contScore += 0.5;
      contFactors.push('CONT-C7: Bollinger lower band walk (strong bearish trend)');
    }
    
    // C8: Parabolic SAR Alignment
    if (marketData.parabolicSAR.trend === 'BULLISH' && direction === 'CALL') {
      contScore += 0.5;
      contFactors.push('CONT-C8: PSAR bullish (trend continuation confirmed)');
    }
    if (marketData.parabolicSAR.trend === 'BEARISH' && direction === 'PUT') {
      contScore += 0.5;
      contFactors.push('CONT-C8: PSAR bearish (trend continuation confirmed)');
    }
    
    // C9: Multi-TF Continuation (M1 + M5 + M15 all in trend)
    if (marketDataM5 && marketDataM15) {
      const allBullish = marketData.trend.emaAlignment === 'BULLISH' && 
                         marketDataM5.trend.emaAlignment === 'BULLISH' && 
                         marketDataM15.trend.emaAlignment === 'BULLISH';
      const allBearish = marketData.trend.emaAlignment === 'BEARISH' && 
                         marketDataM5.trend.emaAlignment === 'BEARISH' && 
                         marketDataM15.trend.emaAlignment === 'BEARISH';
      
      if (allBullish && direction === 'CALL') {
        contScore += 1.0;
        contFactors.push('CONT-C9: Triple-TF bullish continuation (M1+M5+M15)');
      }
      if (allBearish && direction === 'PUT') {
        contScore += 1.0;
        contFactors.push('CONT-C9: Triple-TF bearish continuation (M1+M5+M15)');
      }
    }
    
    // C10: Impulsive Move + Shallow Retracement
    if (cLast >= 5) {
      const impulseRange = Math.max(...cHighs.slice(-5)) - Math.min(...cLows.slice(-5));
      const retrace = Math.abs(cCloses[cLast] - cCloses[cLast - 1]);
      if (impulseRange > 0 && retrace / impulseRange < 0.38) {
        if (cBullish && direction === 'CALL') {
          contScore += 0.7;
          contFactors.push('CONT-C10: Shallow retracement after impulse (bullish continuation)');
        }
        if (!cBullish && direction === 'PUT') {
          contScore += 0.7;
          contFactors.push('CONT-C10: Shallow retracement after impulse (bearish continuation)');
        }
      }
    }
    
    // C11: FVG Continuation (FVG in same direction as trend = institutional continuation)
    if (marketData.smc.hasBullishFVG && marketData.trend.emaAlignment === 'BULLISH' && direction === 'CALL') {
      contScore += 0.8;
      contFactors.push('CONT-C11: Bullish FVG in uptrend (institutional continuation)');
    }
    if (marketData.smc.hasBearishFVG && marketData.trend.emaAlignment === 'BEARISH' && direction === 'PUT') {
      contScore += 0.8;
      contFactors.push('CONT-C11: Bearish FVG in downtrend (institutional continuation)');
    }
    
    // C12: Volume Confirmation + Trend Alignment (Rising vol + strong body in trend)
    if (cVolumes[cLast] > cAvgVol * 1.5 && cBody > cAvgBody * 1.3) {
      if (cBullish && marketData.trend.emaAlignment === 'BULLISH' && direction === 'CALL') {
        contScore += 0.9;
        contFactors.push('CONT-C12: Volume surge + strong bullish body in uptrend');
      }
      if (!cBullish && marketData.trend.emaAlignment === 'BEARISH' && direction === 'PUT') {
        contScore += 0.9;
        contFactors.push('CONT-C12: Volume surge + strong bearish body in downtrend');
      }
    }
    
    // C13: Order Block Continuation (Price bouncing off OB in trend direction)
    if (marketData.smc.nearDemandOB && marketData.trend.emaAlignment === 'BULLISH' && cBullish && direction === 'CALL') {
      contScore += 0.8;
      contFactors.push('CONT-C13: Bounce from demand OB in uptrend → continuation');
    }
    if (marketData.smc.nearSupplyOB && marketData.trend.emaAlignment === 'BEARISH' && !cBullish && direction === 'PUT') {
      contScore += 0.8;
      contFactors.push('CONT-C13: Rejection from supply OB in downtrend → continuation');
    }
    
    // C14: RSI Mid-Zone Momentum (RSI 50-65 in uptrend = healthy continuation, not overbought)
    if (marketData.momentum.rsi14 > 50 && marketData.momentum.rsi14 < 65 && direction === 'CALL' && marketData.trend.adx > 20) {
      contScore += 0.6;
      contFactors.push(`CONT-C14: RSI mid-zone ${marketData.momentum.rsi14.toFixed(0)} (healthy bullish momentum)`);
    }
    if (marketData.momentum.rsi14 > 35 && marketData.momentum.rsi14 < 50 && direction === 'PUT' && marketData.trend.adx > 20) {
      contScore += 0.6;
      contFactors.push(`CONT-C14: RSI mid-zone ${marketData.momentum.rsi14.toFixed(0)} (healthy bearish momentum)`);
    }
    
    // C15: Candle Sequence Momentum (Increasing body sizes = accelerating trend)
    if (cLast >= 3) {
      const b0 = Math.abs(cCloses[cLast] - cOpens[cLast]);
      const b1 = Math.abs(cCloses[cLast - 1] - cOpens[cLast - 1]);
      const b2 = Math.abs(cCloses[cLast - 2] - cOpens[cLast - 2]);
      if (b0 > b1 && b1 > b2 && b0 > cAvgBody) {
        if (cBullish && direction === 'CALL') {
          contScore += 0.8;
          contFactors.push('CONT-C15: Accelerating bullish bodies (momentum building)');
        }
        if (!cBullish && direction === 'PUT') {
          contScore += 0.8;
          contFactors.push('CONT-C15: Accelerating bearish bodies (momentum building)');
        }
      }
    }
    
    // C16: SMC Zone + Trend Continuation (Price bouncing off OB + BOS in same direction)
    if (marketData.smc.lastBOS === 'BULLISH_BOS' && marketData.smc.nearDemandOB && marketData.trend.emaAlignment === 'BULLISH' && direction === 'CALL') {
      contScore += 1.4;
      contFactors.push('CONT-C16: SMC BOS + Demand OB + EMA bullish (institutional continuation)');
    }
    if (marketData.smc.lastBOS === 'BEARISH_BOS' && marketData.smc.nearSupplyOB && marketData.trend.emaAlignment === 'BEARISH' && direction === 'PUT') {
      contScore += 1.4;
      contFactors.push('CONT-C16: SMC BOS + Supply OB + EMA bearish (institutional continuation)');
    }
    
    // C17: ICT FVG + OB Confluence Continuation (FVG + Order Block in trend = ultra confirmation)
    if (marketData.smc.hasBullishFVG && marketData.smc.nearDemandOB && direction === 'CALL') {
      contScore += 1.3;
      contFactors.push('CONT-C17: ICT Bullish FVG + Demand OB overlap (institutional continuation)');
    }
    if (marketData.smc.hasBearishFVG && marketData.smc.nearSupplyOB && direction === 'PUT') {
      contScore += 1.3;
      contFactors.push('CONT-C17: ICT Bearish FVG + Supply OB overlap (institutional continuation)');
    }
    
    // C18: Liquidity Pool Continuation (Untapped liquidity above/below = magnetic continuation)
    if (cLast >= 10) {
      const eqHighs = cHighs.slice(-15).filter((h, i, a) => i > 0 && Math.abs(h - a[i - 1]) < pip * 2).length;
      const eqLows = cLows.slice(-15).filter((l, i, a) => i > 0 && Math.abs(l - a[i - 1]) < pip * 2).length;
      if (eqHighs >= 2 && direction === 'CALL' && marketData.trend.emaAlignment === 'BULLISH') {
        contScore += 1.0;
        contFactors.push(`CONT-C18: ${eqHighs} Equal Highs liquidity pool above (magnetic CALL continuation)`);
      }
      if (eqLows >= 2 && direction === 'PUT' && marketData.trend.emaAlignment === 'BEARISH') {
        contScore += 1.0;
        contFactors.push(`CONT-C18: ${eqLows} Equal Lows liquidity pool below (magnetic PUT continuation)`);
      }
    }
    
    // C19: OTC-ALGO Pattern Continuation (Autocorrelation + trend alignment)
    if (cLen >= 20) {
      const segA = cCloses.slice(-20, -10);
      const segB = cCloses.slice(-10);
      let corrMatches = 0;
      for (let i = 0; i < 10; i++) {
        if ((segA[i] > (i > 0 ? segA[i - 1] : segA[0])) === (segB[i] > (i > 0 ? segB[i - 1] : segB[0]))) corrMatches++;
      }
      if (corrMatches >= 7 && cBullish && direction === 'CALL') {
        contScore += 1.1;
        contFactors.push(`CONT-C19: OTC Algo pattern repeat ${corrMatches}/10 (bullish continuation)`);
      }
      if (corrMatches >= 7 && !cBullish && direction === 'PUT') {
        contScore += 1.1;
        contFactors.push(`CONT-C19: OTC Algo pattern repeat ${corrMatches}/10 (bearish continuation)`);
      }
    }
    
    // C20: Multi-Indicator Trend Health (RSI mid + ADX strong + MACD expanding = healthy trend)
    const c20Rsi = marketData.momentum.rsi14;
    const c20Adx = marketData.trend.adx;
    const c20Macd = marketData.momentum.macd?.histogram || 0;
    if (c20Rsi > 45 && c20Rsi < 70 && c20Adx > 25 && c20Macd > 0 && direction === 'CALL') {
      contScore += 1.2;
      contFactors.push('CONT-C20: Triple indicator health (RSI+ADX+MACD all confirming bullish continuation)');
    }
    if (c20Rsi > 30 && c20Rsi < 55 && c20Adx > 25 && c20Macd < 0 && direction === 'PUT') {
      contScore += 1.2;
      contFactors.push('CONT-C20: Triple indicator health (RSI+ADX+MACD all confirming bearish continuation)');
    }
    
    // C21: MTF Structure Continuation (M1 BOS + M5 trend + M15 EMA alignment)
    if (marketDataM5 && marketDataM15) {
      const m5Trend = marketDataM5.trend.emaAlignment;
      const m15Trend = marketDataM15.trend.emaAlignment;
      if (marketData.smc.lastBOS === 'BULLISH_BOS' && m5Trend === 'BULLISH' && m15Trend === 'BULLISH' && direction === 'CALL') {
        contScore += 1.5;
        contFactors.push('CONT-C21: MTF Structure (M1 BOS + M5 + M15 bullish → ultra continuation)');
      }
      if (marketData.smc.lastBOS === 'BEARISH_BOS' && m5Trend === 'BEARISH' && m15Trend === 'BEARISH' && direction === 'PUT') {
        contScore += 1.5;
        contFactors.push('CONT-C21: MTF Structure (M1 BOS + M5 + M15 bearish → ultra continuation)');
      }
    }
    
    // C22: ICT Power of 3 Continuation (Distribution phase + trend alignment)
    if (cLast >= 10) {
      const accRange = Math.max(...cHighs.slice(-10, -5)) - Math.min(...cLows.slice(-10, -5));
      const distRange = Math.max(...cHighs.slice(-5)) - Math.min(...cLows.slice(-5));
      if (distRange > accRange * 1.5 && cBullish && marketData.trend.emaAlignment === 'BULLISH' && direction === 'CALL') {
        contScore += 1.1;
        contFactors.push('CONT-C22: ICT Distribution expansion (bullish acceleration continuation)');
      }
      if (distRange > accRange * 1.5 && !cBullish && marketData.trend.emaAlignment === 'BEARISH' && direction === 'PUT') {
        contScore += 1.1;
        contFactors.push('CONT-C22: ICT Distribution expansion (bearish acceleration continuation)');
      }
    }
    
    // C23: OTC Trap Confirmation Continuation (No traps detected = clean continuation)
    const c23HasWickTrap = (cHighs[cLast] - Math.max(cCloses[cLast], cOpens[cLast])) > cBody * 2 || 
                            (Math.min(cCloses[cLast], cOpens[cLast]) - cLows[cLast]) > cBody * 2;
    const c23VolSpike = cVolumes[cLast] > cAvgVol * 2.5 && cBody < cAvgBody * 0.5;
    if (!c23HasWickTrap && !c23VolSpike && cBody > cAvgBody * 0.8) {
      if (cBullish && marketData.trend.emaAlignment === 'BULLISH' && direction === 'CALL') {
        contScore += 0.9;
        contFactors.push('CONT-C23: Clean candle (no OTC traps detected → safe continuation CALL)');
      }
      if (!cBullish && marketData.trend.emaAlignment === 'BEARISH' && direction === 'PUT') {
        contScore += 0.9;
        contFactors.push('CONT-C23: Clean candle (no OTC traps detected → safe continuation PUT)');
      }
    }
    
    // C24: CHoCH Rejection Continuation (CHoCH in trend direction = structure continuation)
    if (marketData.smc.lastCHoCH) {
      if (marketData.smc.lastCHoCH.includes('BULL') && marketData.trend.emaAlignment === 'BULLISH' && direction === 'CALL') {
        contScore += 1.0;
        contFactors.push('CONT-C24: Bullish CHoCH in uptrend (structure realignment continuation)');
      }
      if (marketData.smc.lastCHoCH.includes('BEAR') && marketData.trend.emaAlignment === 'BEARISH' && direction === 'PUT') {
        contScore += 1.0;
        contFactors.push('CONT-C24: Bearish CHoCH in downtrend (structure realignment continuation)');
      }
    }
    
    // C25: Full-Category Convergence Continuation (5+ categories all confirming trend)
    let contConvergenceCount = 0;
    if (marketData.trend.emaAlignment === (direction === 'CALL' ? 'BULLISH' : 'BEARISH')) contConvergenceCount++;
    if (marketData.trend.adx > 25) contConvergenceCount++;
    if ((direction === 'CALL' && c20Rsi > 45 && c20Rsi < 70) || (direction === 'PUT' && c20Rsi > 30 && c20Rsi < 55)) contConvergenceCount++;
    if (marketData.smc.lastBOS === (direction === 'CALL' ? 'BULLISH_BOS' : 'BEARISH_BOS')) contConvergenceCount++;
    if (marketData.parabolicSAR.trend === (direction === 'CALL' ? 'BULLISH' : 'BEARISH')) contConvergenceCount++;
    if (marketDataM5 && marketDataM5.trend.emaAlignment === (direction === 'CALL' ? 'BULLISH' : 'BEARISH')) contConvergenceCount++;
    if (contConvergenceCount >= 5) {
      contScore += 1.8;
      contFactors.push(`CONT-C25: ULTRA Convergence Continuation (${contConvergenceCount}/6 categories confirm trend)`);
    }
    
    console.log(`[CONTINUATION ENGINE] Score: ${contScore.toFixed(2)}, Triggers: ${contFactors.length}`);
  }
  
  if (contFactors.length > 0) {
    categories.push({ name: 'Continuation Trigger Engine (25 Ultra)', score: contScore, factors: contFactors });
  }
  
  // ============= CATEGORY 11: ICT (INNER CIRCLE TRADER) PURE CONCEPTS =============
  // Dedicated ICT methodology: Fair Value Gaps, Order Blocks, Power of 3, Killzones,
  // Optimal Trade Entry, Judas Swing, Market Maker Model, Displacement & Imbalance
  let ictScore = 0;
  const ictFactors: string[] = [];
  
  if (raw && raw.closes.length >= 30) {
    const ictCloses = raw.closes;
    const ictOpens = raw.opens;
    const ictHighs = raw.highs;
    const ictLows = raw.lows;
    const ictVolumes = raw.volumes;
    const ictLen = ictCloses.length;
    const ictLast = ictLen - 1;
    const ictPip = getDynamicPipSize(ictCloses[ictLast]);
    const ictBody = Math.abs(ictCloses[ictLast] - ictOpens[ictLast]);
    const ictAvgBody = ictCloses.slice(-20).reduce((s, c, i) => s + Math.abs(c - ictOpens[ictOpens.length - 20 + i]), 0) / 20;
    
    // ICT-1: Fair Value Gap (FVG) Detection - 3-candle imbalance
    if (ictLast >= 2) {
      // Bullish FVG: candle[n-2].high < candle[n].low (gap up)
      const bullFVG = ictHighs[ictLast - 2] < ictLows[ictLast];
      // Bearish FVG: candle[n-2].low > candle[n].high (gap down)
      const bearFVG = ictLows[ictLast - 2] > ictHighs[ictLast];
      
      if (bullFVG && direction === 'CALL') {
        ictScore += 1.0;
        ictFactors.push('ICT-1: Bullish FVG (fair value gap → price should fill upward)');
      }
      if (bearFVG && direction === 'PUT') {
        ictScore += 1.0;
        ictFactors.push('ICT-1: Bearish FVG (fair value gap → price should fill downward)');
      }
      
      // FVG Mitigation (price returns to fill the gap → continuation)
      for (let g = Math.max(3, ictLast - 15); g < ictLast; g++) {
        if (g + 2 < ictLen) {
          const pastBullFVG = ictHighs[g] < ictLows[g + 2];
          if (pastBullFVG && ictCloses[ictLast] <= ictLows[g + 2] && ictCloses[ictLast] >= ictHighs[g] && direction === 'CALL') {
            ictScore += 0.8;
            ictFactors.push('ICT-1M: Price mitigating bullish FVG (optimal entry)');
            break;
          }
          const pastBearFVG = ictLows[g] > ictHighs[g + 2];
          if (pastBearFVG && ictCloses[ictLast] >= ictHighs[g + 2] && ictCloses[ictLast] <= ictLows[g] && direction === 'PUT') {
            ictScore += 0.8;
            ictFactors.push('ICT-1M: Price mitigating bearish FVG (optimal entry)');
            break;
          }
        }
      }
    }
    
    // ICT-2: Order Block Detection (last opposing candle before displacement)
    if (ictLast >= 3) {
      // Bullish OB: Last bearish candle before a bullish displacement
      for (let ob = ictLast - 1; ob > Math.max(ictLast - 10, 1); ob--) {
        const isBearCandle = ictCloses[ob] < ictOpens[ob];
        const nextBullDisplacement = ictCloses[ob + 1] > ictOpens[ob + 1] && 
                                      Math.abs(ictCloses[ob + 1] - ictOpens[ob + 1]) > ictAvgBody * 1.5;
        if (isBearCandle && nextBullDisplacement) {
          // Check if current price is at OB level
          if (ictCloses[ictLast] >= ictLows[ob] && ictCloses[ictLast] <= ictHighs[ob] && direction === 'CALL') {
            ictScore += 1.2;
            ictFactors.push('ICT-2: Price at Bullish Order Block (institutional demand)');
            break;
          }
        }
      }
      
      // Bearish OB: Last bullish candle before a bearish displacement
      for (let ob = ictLast - 1; ob > Math.max(ictLast - 10, 1); ob--) {
        const isBullCandle = ictCloses[ob] > ictOpens[ob];
        const nextBearDisplacement = ictCloses[ob + 1] < ictOpens[ob + 1] && 
                                      Math.abs(ictCloses[ob + 1] - ictOpens[ob + 1]) > ictAvgBody * 1.5;
        if (isBullCandle && nextBearDisplacement) {
          if (ictCloses[ictLast] >= ictLows[ob] && ictCloses[ictLast] <= ictHighs[ob] && direction === 'PUT') {
            ictScore += 1.2;
            ictFactors.push('ICT-2: Price at Bearish Order Block (institutional supply)');
            break;
          }
        }
      }
    }
    
    // ICT-3: Displacement & Imbalance Detection
    // Displacement = aggressive move with large body candles
    if (ictBody > ictAvgBody * 2.0) {
      if (ictCloses[ictLast] > ictOpens[ictLast] && direction === 'CALL') {
        ictScore += 0.8;
        ictFactors.push('ICT-3: Bullish displacement (2x avg body → institutional aggression)');
      }
      if (ictCloses[ictLast] < ictOpens[ictLast] && direction === 'PUT') {
        ictScore += 0.8;
        ictFactors.push('ICT-3: Bearish displacement (2x avg body → institutional aggression)');
      }
    }
    
    // ICT-4: Breaker Block Detection
    // Bullish breaker: Previous supply zone that got broken and now acts as demand
    if (ictLast >= 5 && marketData.smc.lastBOS === 'BULLISH_BOS') {
      const prevSwingHigh = Math.max(...ictHighs.slice(-10, -2));
      if (ictCloses[ictLast] > prevSwingHigh && direction === 'CALL') {
        ictScore += 0.9;
        ictFactors.push('ICT-4: Bullish breaker block (supply flipped to demand)');
      }
    }
    if (ictLast >= 5 && marketData.smc.lastBOS === 'BEARISH_BOS') {
      const prevSwingLow = Math.min(...ictLows.slice(-10, -2));
      if (ictCloses[ictLast] < prevSwingLow && direction === 'PUT') {
        ictScore += 0.9;
        ictFactors.push('ICT-4: Bearish breaker block (demand flipped to supply)');
      }
    }
    
    // ICT-5: Power of 3 (Accumulation → Manipulation → Distribution)
    // Phase detection: Look for accumulation (range), manipulation (fake break), distribution (real move)
    if (ictLast >= 10) {
      // Detect range (accumulation) in candles -10 to -5
      const accuRange = Math.max(...ictHighs.slice(-10, -5)) - Math.min(...ictLows.slice(-10, -5));
      // Detect manipulation (spike beyond range) in candles -5 to -2
      const manipHigh = Math.max(...ictHighs.slice(-5, -2));
      const manipLow = Math.min(...ictLows.slice(-5, -2));
      const accuHigh = Math.max(...ictHighs.slice(-10, -5));
      const accuLow = Math.min(...ictLows.slice(-10, -5));
      
      const manipAbove = manipHigh > accuHigh && ictCloses[ictLast] < accuHigh;
      const manipBelow = manipLow < accuLow && ictCloses[ictLast] > accuLow;
      
      if (manipAbove && direction === 'PUT') {
        ictScore += 1.1;
        ictFactors.push('ICT-5: Power of 3 (manipulation above range → distribution PUT)');
      }
      if (manipBelow && direction === 'CALL') {
        ictScore += 1.1;
        ictFactors.push('ICT-5: Power of 3 (manipulation below range → distribution CALL)');
      }
    }
    
    // ICT-6: Optimal Trade Entry (OTE) - Fibonacci 62-79% retracement in FVG/OB zone
    if (ictLast >= 10) {
      const swingHigh = Math.max(...ictHighs.slice(-15));
      const swingLow = Math.min(...ictLows.slice(-15));
      const swingRange = swingHigh - swingLow;
      if (swingRange > 0) {
        const currentRetrace = (swingHigh - ictCloses[ictLast]) / swingRange;
        // OTE zone: 62% to 79% retracement
        if (currentRetrace >= 0.62 && currentRetrace <= 0.79) {
          if (marketData.trend.emaAlignment === 'BULLISH' && direction === 'CALL') {
            ictScore += 1.0;
            ictFactors.push(`ICT-6: OTE zone (${(currentRetrace * 100).toFixed(0)}% retracement → optimal buy)`);
          }
        }
        const currentRetraceDown = (ictCloses[ictLast] - swingLow) / swingRange;
        if (currentRetraceDown >= 0.62 && currentRetraceDown <= 0.79) {
          if (marketData.trend.emaAlignment === 'BEARISH' && direction === 'PUT') {
            ictScore += 1.0;
            ictFactors.push(`ICT-6: OTE zone (${(currentRetraceDown * 100).toFixed(0)}% retracement → optimal sell)`);
          }
        }
      }
    }
    
    // ICT-7: Judas Swing Detection (false initial move before real direction)
    if (ictLast >= 5) {
      const first3Bull = ictCloses.slice(-5, -2).every((c, i) => c > ictOpens[ictOpens.length - 5 + i]);
      const lastBear = ictCloses[ictLast] < ictOpens[ictLast] && ictCloses[ictLast - 1] < ictOpens[ictLast - 1];
      const first3Bear = ictCloses.slice(-5, -2).every((c, i) => c < ictOpens[ictOpens.length - 5 + i]);
      const lastBull = ictCloses[ictLast] > ictOpens[ictLast] && ictCloses[ictLast - 1] > ictOpens[ictLast - 1];
      
      if (first3Bull && lastBear && direction === 'PUT') {
        ictScore += 0.9;
        ictFactors.push('ICT-7: Judas swing (initial bullish fake → real bearish move)');
      }
      if (first3Bear && lastBull && direction === 'CALL') {
        ictScore += 0.9;
        ictFactors.push('ICT-7: Judas swing (initial bearish fake → real bullish move)');
      }
    }
    
    // ICT-8: Market Maker Model (sweep + displacement + FVG)
    if (ictLast >= 5) {
      const recentHighs = ictHighs.slice(-10);
      const recentLows = ictLows.slice(-10);
      const highSwept = ictHighs[ictLast] > Math.max(...recentHighs.slice(0, -1));
      const lowSwept = ictLows[ictLast] < Math.min(...recentLows.slice(0, -1));
      
      if (highSwept && ictCloses[ictLast] < ictOpens[ictLast] && ictBody > ictAvgBody * 1.5 && direction === 'PUT') {
        ictScore += 1.3;
        ictFactors.push('ICT-8: Market Maker Model (high sweep + bearish displacement)');
      }
      if (lowSwept && ictCloses[ictLast] > ictOpens[ictLast] && ictBody > ictAvgBody * 1.5 && direction === 'CALL') {
        ictScore += 1.3;
        ictFactors.push('ICT-8: Market Maker Model (low sweep + bullish displacement)');
      }
    }
    
    // ICT-9: Liquidity Void Detection (aggressive institutional moves leaving price gaps)
    if (ictLast >= 3) {
      for (let v = ictLast; v > Math.max(ictLast - 5, 1); v--) {
        const candleRange = ictHighs[v] - ictLows[v];
        const prevCandleRange = ictHighs[v - 1] - ictLows[v - 1];
        if (candleRange > prevCandleRange * 3 && ictVolumes[v] < ictVolumes[v - 1] * 0.5) {
          const voidDir = ictCloses[v] > ictOpens[v] ? 'CALL' : 'PUT';
          if (voidDir === direction) {
            ictScore += 0.7;
            ictFactors.push('ICT-9: Liquidity void (institutional fast move, price will return)');
          }
          break;
        }
      }
    }
    
    // ICT-10: SMT Divergence (Smart Money Tool - comparing highs/lows with correlated pair behavior)
    // Approximate using internal price action divergence
    if (ictLast >= 10) {
      const ictRecentHigh = Math.max(...ictHighs.slice(-5));
      const prevHigh = Math.max(...ictHighs.slice(-10, -5));
      const recentRsi = marketData.momentum.rsi14;
      
      // Price makes higher high but momentum doesn't
      if (ictRecentHigh > prevHigh && recentRsi < 55 && direction === 'PUT') {
        ictScore += 0.8;
        ictFactors.push('ICT-10: SMT divergence (higher price + weaker momentum → sell)');
      }
      const ictRecentLow = Math.min(...ictLows.slice(-5));
      const prevLow = Math.min(...ictLows.slice(-10, -5));
      if (ictRecentLow < prevLow && recentRsi > 45 && direction === 'CALL') {
        ictScore += 0.8;
        ictFactors.push('ICT-10: SMT divergence (lower price + stronger momentum → buy)');
      }
    }
    
    // ICT-11: Equal Highs/Lows (EQH/EQL) as Liquidity Targets
    if (ictLast >= 10) {
      // Check for equal highs (liquidity pool above)
      let eqHighCount = 0;
      const eqHighLevel = ictHighs[ictLast];
      for (let e = ictLast - 1; e > Math.max(ictLast - 15, 0); e--) {
        if (Math.abs(ictHighs[e] - eqHighLevel) < ictPip * 2) eqHighCount++;
      }
      if (eqHighCount >= 2 && direction === 'CALL') {
        ictScore += 0.6;
        ictFactors.push(`ICT-11: ${eqHighCount + 1}x Equal Highs (BSL target above → sweep potential)`);
      }
      
      // Check for equal lows
      let eqLowCount = 0;
      const eqLowLevel = ictLows[ictLast];
      for (let e = ictLast - 1; e > Math.max(ictLast - 15, 0); e--) {
        if (Math.abs(ictLows[e] - eqLowLevel) < ictPip * 2) eqLowCount++;
      }
      if (eqLowCount >= 2 && direction === 'PUT') {
        ictScore += 0.6;
        ictFactors.push(`ICT-11: ${eqLowCount + 1}x Equal Lows (SSL target below → sweep potential)`);
      }
    }
    
    // ICT-12: Institutional Candle Close (strong close near extreme = conviction)
    if (ictBody > 0) {
      const closeRatio = ictCloses[ictLast] > ictOpens[ictLast] 
        ? (ictCloses[ictLast] - ictLows[ictLast]) / (ictHighs[ictLast] - ictLows[ictLast])
        : (ictHighs[ictLast] - ictCloses[ictLast]) / (ictHighs[ictLast] - ictLows[ictLast]);
      
      if (closeRatio > 0.8 && ictBody > ictAvgBody * 1.3) {
        if (ictCloses[ictLast] > ictOpens[ictLast] && direction === 'CALL') {
          ictScore += 0.7;
          ictFactors.push('ICT-12: Institutional bullish close (80%+ close near high)');
        }
        if (ictCloses[ictLast] < ictOpens[ictLast] && direction === 'PUT') {
          ictScore += 0.7;
          ictFactors.push('ICT-12: Institutional bearish close (80%+ close near low)');
        }
      }
    }
    
    // ICT-13: Silver Bullet (Specific time window entries - Killzone precision)
    const ictHour = new Date().getUTCHours();
    const ictMinute = new Date().getMinutes();
    const isAsiaKZ = ictHour >= 0 && ictHour <= 4;
    const isLondonKZ = ictHour >= 7 && ictHour <= 10;
    const isNYKZ = ictHour >= 13 && ictHour <= 16;
    if (isLondonKZ || isNYKZ) {
      // During killzones, FVG entries have higher probability
      if (marketData.smc.hasBullishFVG && direction === 'CALL') {
        ictScore += 0.6;
        ictFactors.push(`ICT-13: Silver Bullet FVG Entry (${isLondonKZ ? 'London' : 'NY'} Killzone)`);
      }
      if (marketData.smc.hasBearishFVG && direction === 'PUT') {
        ictScore += 0.6;
        ictFactors.push(`ICT-13: Silver Bullet FVG Entry (${isLondonKZ ? 'London' : 'NY'} Killzone)`);
      }
    }
    
    // ICT-14: Turtle Soup Sweep (Stop-hunt beyond swing + immediate reclaim)
    if (ictLast >= 15) {
      const swing15High = Math.max(...ictHighs.slice(ictLast - 15, ictLast - 1));
      const swing15Low = Math.min(...ictLows.slice(ictLast - 15, ictLast - 1));
      
      if (ictHighs[ictLast] > swing15High && ictCloses[ictLast] < swing15High && ictCloses[ictLast] < ictOpens[ictLast] && direction === 'PUT') {
        ictScore += 1.4;
        ictFactors.push('ICT-14: Turtle Soup (15-bar high sweep + bearish close)');
      }
      if (ictLows[ictLast] < swing15Low && ictCloses[ictLast] > swing15Low && ictCloses[ictLast] > ictOpens[ictLast] && direction === 'CALL') {
        ictScore += 1.4;
        ictFactors.push('ICT-14: Turtle Soup (15-bar low sweep + bullish close)');
      }
    }
    
    // ICT-15: ICT Unicorn Model (OB + FVG overlap + CHoCH = highest probability)
    if (marketData.smc.orderBlocks.length > 0 && marketData.smc.fvgs.length > 0 && marketData.smc.lastCHoCH) {
      const ob = marketData.smc.orderBlocks[0];
      if (ob.type === 'BULLISH_OB' && marketData.smc.lastCHoCH.includes('BULL') && direction === 'CALL') {
        ictScore += 1.5;
        ictFactors.push('ICT-15: Unicorn Model (OB + FVG + CHoCH alignment → CALL)');
      }
      if (ob.type === 'BEARISH_OB' && marketData.smc.lastCHoCH.includes('BEAR') && direction === 'PUT') {
        ictScore += 1.5;
        ictFactors.push('ICT-15: Unicorn Model (OB + FVG + CHoCH alignment → PUT)');
      }
    }
    
    // ICT-16: AMD (Accumulation-Manipulation-Distribution) Micro-Cycle
    if (ictLast >= 15) {
      // Check 3 phases: accumulation (range), manipulation (spike), distribution (reversal)
      const range5 = Math.max(...ictHighs.slice(-15, -10)) - Math.min(...ictLows.slice(-15, -10));
      const spike5 = Math.max(...ictHighs.slice(-10, -5)) - Math.min(...ictLows.slice(-10, -5));
      const dist5 = Math.max(...ictHighs.slice(-5)) - Math.min(...ictLows.slice(-5));
      
      if (spike5 > range5 * 1.5 && dist5 < spike5 * 0.7) {
        // Manipulation phase was larger than accumulation, distribution is contracting = reversal incoming
        const manipDir = ictCloses[ictLast - 5] > ictOpens[ictLast - 10] ? 'PUT' : 'CALL';
        if (manipDir === direction) {
          ictScore += 0.9;
          ictFactors.push('ICT-16: AMD micro-cycle (post-manipulation distribution phase)');
        }
      }
    }
    
    // ICT-17: Premium/Discount OTE Fusion (OTE in correct zone)
    if (ictLast >= 15) {
      const ictRecentHigh = Math.max(...ictHighs.slice(-15));
      const ictRecentLow = Math.min(...ictLows.slice(-15));
      const fbRange = ictRecentHigh - ictRecentLow;
      const fbEquil = ictRecentLow + fbRange * 0.5;
      const inDiscount = ictCloses[ictLast] < fbEquil;
      const inPremium = ictCloses[ictLast] > fbEquil;
      
      if (inDiscount && marketData.trend.emaAlignment === 'BULLISH' && direction === 'CALL') {
        ictScore += 0.7;
        ictFactors.push('ICT-17: Premium/Discount OTE (buying in discount during uptrend)');
      }
      if (inPremium && marketData.trend.emaAlignment === 'BEARISH' && direction === 'PUT') {
        ictScore += 0.7;
        ictFactors.push('ICT-17: Premium/Discount OTE (selling in premium during downtrend)');
      }
    }
    
    // ICT-18: Propulsion Block + Breaker Confluence
    if (marketData.smc.lastBOS && marketData.smc.orderBlocks.length > 0) {
      const ob = marketData.smc.orderBlocks[0];
      const distToOB = Math.abs(ictCloses[ictLast] - ob.level);
      if (distToOB < ictPip * 5) {
        if (marketData.smc.lastBOS === 'BULLISH_BOS' && ob.type === 'BULLISH_OB' && direction === 'CALL') {
          ictScore += 1.0;
          ictFactors.push('ICT-18: Propulsion Block (BOS + OB at current price → CALL)');
        }
        if (marketData.smc.lastBOS === 'BEARISH_BOS' && ob.type === 'BEARISH_OB' && direction === 'PUT') {
          ictScore += 1.0;
          ictFactors.push('ICT-18: Propulsion Block (BOS + OB at current price → PUT)');
        }
      }
    }
    
    // ICT-19: Inverted FVG (iFVG) - Failed FVG becomes reversal zone
    if (ictLast >= 5) {
      for (let f = ictLast - 1; f > Math.max(ictLast - 8, 2); f--) {
        const wasBullFVG = ictHighs[f - 2] < ictLows[f];
        if (wasBullFVG && ictCloses[ictLast] < ictHighs[f - 2]) {
          if (direction === 'PUT') {
            ictScore += 1.1;
            ictFactors.push('ICT-19: Inverted FVG (bullish FVG failed → bearish reversal zone)');
          }
          break;
        }
        const wasBearFVG = ictLows[f - 2] > ictHighs[f];
        if (wasBearFVG && ictCloses[ictLast] > ictLows[f - 2]) {
          if (direction === 'CALL') {
            ictScore += 1.1;
            ictFactors.push('ICT-19: Inverted FVG (bearish FVG failed → bullish reversal zone)');
          }
          break;
        }
      }
    }
    
    // ICT-20: Balanced Price Range (BPR) - Overlapping bull+bear FVGs create equilibrium
    if (ictLast >= 5) {
      let hasBullFVGZone = false, hasBearFVGZone = false;
      for (let b = ictLast - 1; b > Math.max(ictLast - 10, 2); b--) {
        if (ictHighs[b - 2] < ictLows[b]) hasBullFVGZone = true;
        if (ictLows[b - 2] > ictHighs[b]) hasBearFVGZone = true;
      }
      if (hasBullFVGZone && hasBearFVGZone) {
        // BPR zone = high volatility decision point
        if (ictBody > ictAvgBody * 1.5) {
          const bprDir = ictCloses[ictLast] > ictOpens[ictLast] ? 'CALL' : 'PUT';
          if (bprDir === direction) {
            ictScore += 1.0;
            ictFactors.push('ICT-20: Balanced Price Range breakout (BPR decision with displacement)');
          }
        }
      }
    }
    
    // ICT-21: Mitigation Block (Failed OB that becomes new entry zone)
    if (ictLast >= 8 && marketData.smc.orderBlocks.length > 0) {
      const ob = marketData.smc.orderBlocks[0];
      const obDist = Math.abs(ictCloses[ictLast] - ob.level);
      if (obDist < ictPip * 3 && ictBody > ictAvgBody) {
        if (ob.type === 'BULLISH_OB' && ictCloses[ictLast] > ictOpens[ictLast] && direction === 'CALL') {
          ictScore += 0.9;
          ictFactors.push('ICT-21: Mitigation Block (re-entry at failed OB → institutional CALL)');
        }
        if (ob.type === 'BEARISH_OB' && ictCloses[ictLast] < ictOpens[ictLast] && direction === 'PUT') {
          ictScore += 0.9;
          ictFactors.push('ICT-21: Mitigation Block (re-entry at failed OB → institutional PUT)');
        }
      }
    }
    
    // ICT-22: Multi-TF ICT Confluence (M1 ICT setup + M5/M15 structure alignment)
    if (marketDataM5 && marketDataM15) {
      const m5Struct = marketDataM5.smc.marketStructure;
      const m15Struct = marketDataM15.smc.marketStructure;
      if (m5Struct === 'BULLISH' && m15Struct === 'BULLISH' && marketData.smc.hasBullishFVG && direction === 'CALL') {
        ictScore += 1.3;
        ictFactors.push('ICT-22: Multi-TF ICT Confluence (M1 FVG + M5/M15 bullish structure)');
      }
      if (m5Struct === 'BEARISH' && m15Struct === 'BEARISH' && marketData.smc.hasBearishFVG && direction === 'PUT') {
        ictScore += 1.3;
        ictFactors.push('ICT-22: Multi-TF ICT Confluence (M1 FVG + M5/M15 bearish structure)');
      }
    }
    
    console.log(`[ICT ENGINE] Score: ${ictScore.toFixed(2)}, Concepts: ${ictFactors.length}`);
  }
  
  if (ictFactors.length > 0) {
    categories.push({ name: 'ICT Concepts (22 Ultra)', score: ictScore, factors: ictFactors });
  }
  
  // ============= CATEGORY 12: 35 REACTION STRATEGY ENGINE =============
  // Implements all 35 OTC algorithmic reaction strategies for
  // Continuation, Reversal, and Algo Trap detection using per-candle data
  let reactionScore = 0;
  const reactionFactors: string[] = [];

  if (raw && raw.closes.length >= 30) {
    const reactionResult = runReactionStrategyEngine(
      raw.opens,
      raw.highs,
      raw.lows,
      raw.closes,
      raw.volumes,
      (raw as any).times || [], // ISO timestamps if available
      direction
    );
    reactionScore = reactionResult.score;
    reactionFactors.push(...reactionResult.factors);
    reactionFactors.push(`ReactionType:${reactionResult.reactionType} Conf:${reactionResult.confidence}%`);
    console.log(`[REACTION ENGINE] Category score: ${reactionScore.toFixed(2)}, type: ${reactionResult.reactionType}`);
  }

  if (reactionFactors.length > 0) {
    categories.push({ name: '35 Reaction Strategies (Continuation/Reversal/Trap)', score: reactionScore, factors: reactionFactors });
    totalScore += reactionScore;
  }

  // Recalculate totalScore to include reaction
  totalScore = categories.reduce((sum, cat) => sum + cat.score, 0);
  
  // ============= 12-TRAP OTC MATRIX (MANIPULATION DETECTION) =============
  // Detects 12 OTC-specific algorithmic manipulation patterns
  // Each detected trap adjusts scoring by cross-validating against SMC and volume
  const otcTrapFactors: string[] = [];
  let otcTrapScore = 0;
  
  if (raw && raw.closes.length >= 30) {
    const trapCloses = raw.closes;
    const trapOpens = raw.opens;
    const trapHighs = raw.highs;
    const trapLows = raw.lows;
    const trapVolumes = raw.volumes;
    const trapLen = trapCloses.length;
    const lastIdx = trapLen - 1;
    const trapBody = Math.abs(trapCloses[lastIdx] - trapOpens[lastIdx]);
    const trapRange = trapHighs[lastIdx] - trapLows[lastIdx];
    const trapAvgBody = trapCloses.slice(-20).reduce((s, c, i) => s + Math.abs(c - trapOpens[trapOpens.length - 20 + i]), 0) / 20;
    const trapAvgVol = trapVolumes.slice(-20).reduce((s, v) => s + v, 0) / 20;
    const trapCurrVol = trapVolumes[lastIdx];
    const trapPip = getDynamicPipSize(trapCloses[lastIdx]);
    
    // TRAP 1: Volume Ghost - Volume spike without price follow-through
    if (trapCurrVol > trapAvgVol * 2.5 && trapBody < trapAvgBody * 0.5) {
      const ghostDir = trapCloses[lastIdx] > trapOpens[lastIdx] ? 'PUT' : 'CALL';
      if (ghostDir === direction) {
        otcTrapScore += 1.2;
        otcTrapFactors.push('OTC-T1: Volume Ghost (Fake spike, no follow-through)');
      }
    }
    
    // TRAP 2: Wick Assassin - Liquidity-seeking wicks
    const upperW = trapHighs[lastIdx] - Math.max(trapCloses[lastIdx], trapOpens[lastIdx]);
    const lowerW = Math.min(trapCloses[lastIdx], trapOpens[lastIdx]) - trapLows[lastIdx];
    if (upperW > trapBody * 2.5 && direction === 'PUT') {
      otcTrapScore += 1.3;
      otcTrapFactors.push('OTC-T2: Wick Assassin (Upper stop-hunt reversal)');
    }
    if (lowerW > trapBody * 2.5 && direction === 'CALL') {
      otcTrapScore += 1.3;
      otcTrapFactors.push('OTC-T2: Wick Assassin (Lower stop-hunt reversal)');
    }
    
    // TRAP 3: Gap Bait - Artificial gap luring entries
    if (lastIdx > 0) {
      const gapSize = Math.abs(trapOpens[lastIdx] - trapCloses[lastIdx - 1]);
      if (gapSize > trapAvgBody * 1.5 && trapBody < trapAvgBody * 0.8) {
        const gapDir = trapOpens[lastIdx] > trapCloses[lastIdx - 1] ? 'PUT' : 'CALL';
        if (gapDir === direction) {
          otcTrapScore += 0.8;
          otcTrapFactors.push('OTC-T3: Gap Bait (Artificial gap fade)');
        }
      }
    }
    
    // TRAP 4: Staircase Trap - Gradual movement before flush
    let staircaseCount = 0;
    const staircaseBullish = trapCloses[lastIdx] > trapOpens[lastIdx];
    for (let i = lastIdx; i > Math.max(lastIdx - 6, 0); i--) {
      if ((trapCloses[i] > trapOpens[i]) === staircaseBullish) staircaseCount++;
      else break;
    }
    if (staircaseCount >= 5) {
      const stairDir = staircaseBullish ? 'PUT' : 'CALL';
      if (stairDir === direction) {
        otcTrapScore += 1.0;
        otcTrapFactors.push(`OTC-T4: Staircase Trap (${staircaseCount} consecutive → flush)`);
      }
    }
    
    // TRAP 5: Mirror Trap - Symmetrical pattern break
    if (lastIdx >= 6) {
      const mirrorMatch = Math.abs(
        (trapCloses[lastIdx] - trapCloses[lastIdx - 3]) - 
        (trapCloses[lastIdx - 3] - trapCloses[lastIdx - 6])
      );
      if (mirrorMatch < trapPip * 2 && trapBody > trapAvgBody * 1.5) {
        otcTrapScore += 0.7;
        otcTrapFactors.push('OTC-T5: Mirror Trap (Symmetry break detected)');
      }
    }
    
    // TRAP 6: Time Bomb - Candle boundary traps
    const currentMinute = new Date().getMinutes();
    const currentSecond = new Date().getSeconds();
    if ([0, 15, 30, 45].includes(currentMinute) && currentSecond <= 10 && trapBody > trapAvgBody * 1.5) {
      const timeBombDir = trapCloses[lastIdx] > trapOpens[lastIdx] ? 'PUT' : 'CALL';
      if (timeBombDir === direction) {
        otcTrapScore += 0.9;
        otcTrapFactors.push('OTC-T6: Time Bomb (Algo boundary reversal)');
      }
    }
    
    // TRAP 7: Round Number Vacuum - Acceleration into round numbers
    const price = trapCloses[lastIdx];
    const roundDist = Math.min(
      Math.abs(price % 0.01),
      Math.abs(price % 0.005)
    );
    if (roundDist < trapPip * 3 && trapBody > trapAvgBody * 1.2) {
      otcTrapScore += 0.6;
      otcTrapFactors.push('OTC-T7: Round Number Vacuum');
    }
    
    // TRAP 8: Whipsaw Trap - Stop-hunts at EMA/S/R
    const ema20Dist = Math.abs(trapCloses[lastIdx] - marketData.trend.ema20);
    if (ema20Dist < trapPip * 2 && trapRange > trapAvgBody * 2) {
      otcTrapScore += 0.8;
      otcTrapFactors.push('OTC-T8: Whipsaw Trap (EMA20 stop-hunt)');
    }
    
    // TRAP 9: Fake Breakout Cascade - Consecutive false breakouts
    let fakeBreakouts = 0;
    for (let i = lastIdx; i > Math.max(lastIdx - 10, 2); i--) {
      const broke = trapHighs[i] > marketData.smc.resistance || trapLows[i] < marketData.smc.support;
      const failed = trapCloses[i] < marketData.smc.resistance && trapCloses[i] > marketData.smc.support;
      if (broke && failed) fakeBreakouts++;
    }
    if (fakeBreakouts >= 2) {
      otcTrapScore += 1.1;
      otcTrapFactors.push(`OTC-T9: Fake Breakout Cascade (${fakeBreakouts} false breaks)`);
    }
    
    // TRAP 10: Liquidity Void Trap - Acceleration through low-volume nodes
    if (trapCurrVol < trapAvgVol * 0.3 && trapBody > trapAvgBody * 2) {
      otcTrapScore += 0.9;
      otcTrapFactors.push('OTC-T10: Liquidity Void (Low vol + big body)');
    }
    
    // TRAP 11: Exhaustion Spike Trap - Climactic end-of-trend
    if (trapBody > trapAvgBody * 3 && staircaseCount >= 4) {
      const exhDir = trapCloses[lastIdx] > trapOpens[lastIdx] ? 'PUT' : 'CALL';
      if (exhDir === direction) {
        otcTrapScore += 1.4;
        otcTrapFactors.push('OTC-T11: Exhaustion Spike (Climactic move reversal)');
      }
    }
    
    // TRAP 12: Shadow Divergence Trap - Hidden RSI/Price divergence
    if (lastIdx >= 10) {
      const priceHigher = trapCloses[lastIdx] > trapCloses[lastIdx - 10];
      const rsiLower = marketData.momentum.rsi14 < 50;
      if (priceHigher && rsiLower && direction === 'PUT') {
        otcTrapScore += 1.0;
        otcTrapFactors.push('OTC-T12: Shadow Divergence (Price up, RSI down)');
      }
      if (!priceHigher && !rsiLower && direction === 'CALL') {
        otcTrapScore += 1.0;
        otcTrapFactors.push('OTC-T12: Shadow Divergence (Price down, RSI up)');
      }
    }
    
    // TRAP 13: Algo Session Reset (Price reversal at exact session boundaries)
    const trapHour = new Date().getUTCHours();
    if ([0, 8, 13, 17].includes(trapHour) && currentSecond <= 30 && trapBody > trapAvgBody * 1.2) {
      const sessionDir = trapCloses[lastIdx] > trapOpens[lastIdx] ? 'PUT' : 'CALL';
      if (sessionDir === direction) {
        otcTrapScore += 0.9;
        otcTrapFactors.push(`OTC-T13: Session Reset Trap (Hour ${trapHour} boundary)`);
      }
    }
    
    // TRAP 14: Algorithmic Ping-Pong (Price bouncing between tight levels)
    if (lastIdx >= 10) {
      let bounceCount = 0;
      const midPrice = (Math.max(...trapHighs.slice(-10)) + Math.min(...trapLows.slice(-10))) / 2;
      for (let b = lastIdx; b > Math.max(lastIdx - 8, 1); b--) {
        const crossedMid = (trapCloses[b] > midPrice && trapCloses[b - 1] < midPrice) ||
                           (trapCloses[b] < midPrice && trapCloses[b - 1] > midPrice);
        if (crossedMid) bounceCount++;
      }
      if (bounceCount >= 4) {
        // Heavy algo ping-pong - follow the last direction
        const ppDir = trapCloses[lastIdx] > trapOpens[lastIdx] ? 'CALL' : 'PUT';
        if (ppDir === direction) {
          otcTrapScore += 0.8;
          otcTrapFactors.push(`OTC-T14: Algo Ping-Pong (${bounceCount} crosses → follow last)`);
        }
      }
    }
    
    // TRAP 15: Volume Absorption Trap (High volume but no range = institutional absorption)
    if (trapCurrVol > trapAvgVol * 2.0 && trapRange < trapAvgBody * 0.4) {
      // Institutions absorbing retail orders - continuation expected
      const absorbDir = trapCloses[lastIdx] > trapOpens[lastIdx] ? 'CALL' : 'PUT';
      if (absorbDir === direction) {
        otcTrapScore += 1.1;
        otcTrapFactors.push('OTC-T15: Volume Absorption (institutional order filling)');
      }
    }
    
    // TRAP 16: Three-Candle Momentum Decay (Decreasing bodies = trend dying)
    if (lastIdx >= 3) {
      const b0 = Math.abs(trapCloses[lastIdx] - trapOpens[lastIdx]);
      const b1 = Math.abs(trapCloses[lastIdx - 1] - trapOpens[lastIdx - 1]);
      const b2 = Math.abs(trapCloses[lastIdx - 2] - trapOpens[lastIdx - 2]);
      if (b2 > b1 && b1 > b0 && b0 < trapAvgBody * 0.5) {
        const decayDir = staircaseBullish ? 'PUT' : 'CALL';
        if (decayDir === direction) {
          otcTrapScore += 0.9;
          otcTrapFactors.push('OTC-T16: Momentum Decay (3-candle body shrink → reversal)');
        }
      }
    }
    
    // TRAP 17: Double Wick Sniper (Same direction wicks on consecutive candles = rejection zone)
    if (lastIdx >= 1) {
      const upperW0 = trapHighs[lastIdx] - Math.max(trapCloses[lastIdx], trapOpens[lastIdx]);
      const upperW1 = trapHighs[lastIdx - 1] - Math.max(trapCloses[lastIdx - 1], trapOpens[lastIdx - 1]);
      const lowerW0 = Math.min(trapCloses[lastIdx], trapOpens[lastIdx]) - trapLows[lastIdx];
      const lowerW1 = Math.min(trapCloses[lastIdx - 1], trapOpens[lastIdx - 1]) - trapLows[lastIdx - 1];
      
      if (upperW0 > trapBody * 1.5 && upperW1 > Math.abs(trapCloses[lastIdx - 1] - trapOpens[lastIdx - 1]) * 1.5 && direction === 'PUT') {
        otcTrapScore += 1.2;
        otcTrapFactors.push('OTC-T17: Double Upper Wick Sniper (persistent rejection)');
      }
      if (lowerW0 > trapBody * 1.5 && lowerW1 > Math.abs(trapCloses[lastIdx - 1] - trapOpens[lastIdx - 1]) * 1.5 && direction === 'CALL') {
        otcTrapScore += 1.2;
        otcTrapFactors.push('OTC-T17: Double Lower Wick Sniper (persistent support)');
      }
    }
    
    // TRAP 18: OTC Price Magnet Drift (Price drifting toward psychological round number)
    const roundTarget = Math.round(trapCloses[lastIdx] / 0.005) * 0.005;
    const driftDist = Math.abs(trapCloses[lastIdx] - roundTarget);
    if (driftDist > trapPip * 1 && driftDist < trapPip * 5) {
      const driftDir = trapCloses[lastIdx] < roundTarget ? 'CALL' : 'PUT';
      if (driftDir === direction) {
        otcTrapScore += 0.7;
        otcTrapFactors.push(`OTC-T18: Price Magnet Drift toward ${roundTarget.toFixed(5)}`);
      }
    }
    
    if (otcTrapFactors.length > 0) {
      console.log(`[18-TRAP OTC MATRIX] Score: ${otcTrapScore.toFixed(2)}, Traps: ${otcTrapFactors.length}`);
    }
  }
  
  // Add OTC Trap Matrix as bonus to total score
  totalScore += otcTrapScore;
  if (otcTrapFactors.length > 0) {
    categories.push({ name: 'OTC Trap Matrix (18 Ultra Traps)', score: otcTrapScore, factors: otcTrapFactors });
  }
  
  // ============= OTC-ALGO INTELLIGENCE (6-RULE AUTHORITY SYSTEM) =============
  // Highest consensus authority - overrides other indicators when active
  let algoIntelScore = 0;
  const algoIntelFactors: string[] = [];
  
  if (raw && raw.closes.length >= 50) {
    const aiCloses = raw.closes;
    const aiOpens = raw.opens;
    const aiVolumes = raw.volumes;
    const aiLen = aiCloses.length;
    const aiPip = getDynamicPipSize(aiCloses[aiLen - 1]);
    
    // RULE 1: Autocorrelation Mode Detection
    // Identifies algorithmic price-path repetition
    let autoCorrelation = 0;
    const segA = aiCloses.slice(-20, -10);
    const segB = aiCloses.slice(-10);
    if (segA.length === segB.length && segA.length > 0) {
      let matches = 0;
      for (let i = 0; i < segA.length; i++) {
        if ((segA[i] > (i > 0 ? segA[i-1] : segA[0])) === (segB[i] > (i > 0 ? segB[i-1] : segB[0]))) matches++;
      }
      autoCorrelation = matches / segA.length;
      if (autoCorrelation > 0.7) {
        // High autocorrelation - predict continuation
        const lastDir = segB[segB.length - 1] > segB[segB.length - 2] ? 'CALL' : 'PUT';
        if (lastDir === direction) {
          algoIntelScore += 1.0;
          algoIntelFactors.push(`ALGO-R1: Autocorrelation ${(autoCorrelation * 100).toFixed(0)}% (Pattern repeat)`);
        }
      }
    }
    
    // RULE 2: Injection Volume Filtering
    // Filters fake volume spikes designed to trigger retail indicators
    const recentVols = aiVolumes.slice(-10);
    const avgRecentVol = recentVols.reduce((s, v) => s + v, 0) / recentVols.length;
    const volSpikes = recentVols.filter(v => v > avgRecentVol * 3).length;
    if (volSpikes >= 2) {
      // Multiple injection volumes - be cautious
      const injDir = aiCloses[aiLen - 1] > aiOpens[aiLen - 1] ? 'PUT' : 'CALL';
      if (injDir === direction) {
        algoIntelScore += 0.8;
        algoIntelFactors.push(`ALGO-R2: Injection Volume (${volSpikes} fake spikes detected)`);
      }
    }
    
    // RULE 3: Payout-Driven Manipulation
    // Adjusts bias based on real-time broker payout shifts
    const payout = latestPayout.get(marketData.symbol) || 0;
    if (payout > 0) {
      if (payout >= 85) {
        // High payout = broker expects many losers → fade retail
        algoIntelScore += 0.5;
        algoIntelFactors.push(`ALGO-R3: High Payout ${payout}% (Broker trap zone)`);
      } else if (payout <= 70) {
        // Low payout = broker protecting against wins → stronger signals needed
        algoIntelScore += 0.3;
        algoIntelFactors.push(`ALGO-R3: Low Payout ${payout}% (Extra confirmation needed)`);
      }
    }
    
    // RULE 4: Spread Windows - High-spread manipulation detection
    if (raw.closes.length >= 5) {
      const spreadProxy = Math.abs(aiCloses[aiLen - 1] - aiOpens[aiLen - 1]) / (aiPip || 0.0001);
      const avgSpread = raw.closes.slice(-20).reduce((s, c, i) => s + Math.abs(c - raw.opens[raw.opens.length - 20 + i]), 0) / 20 / (aiPip || 0.0001);
      if (spreadProxy > avgSpread * 2.5) {
        algoIntelScore += 0.6;
        algoIntelFactors.push('ALGO-R4: Wide Spread Window (Manipulation active)');
      }
    }
    
    // RULE 5: Algorithmic Boundaries - Hardcoded reversal zones
    const maxDeviation = Math.max(...aiCloses.slice(-50)) - Math.min(...aiCloses.slice(-50));
    const currentDeviation = Math.abs(aiCloses[aiLen - 1] - (aiCloses.slice(-50).reduce((s, v) => s + v, 0) / 50));
    if (currentDeviation > maxDeviation * 0.8) {
      const boundaryDir = aiCloses[aiLen - 1] > (aiCloses.slice(-50).reduce((s, v) => s + v, 0) / 50) ? 'PUT' : 'CALL';
      if (boundaryDir === direction) {
        algoIntelScore += 1.2;
        algoIntelFactors.push('ALGO-R5: Algorithmic Boundary (Max deviation reversal)');
      }
    }
    
    // RULE 6: Pattern Recycling Engine - 30-90 minute cycle correlation
    if (aiCloses.length >= 90) {
      const cycle30 = aiCloses.slice(-60, -30);
      const cycle30Recent = aiCloses.slice(-30);
      let cycleMatch = 0;
      const cycleLen = Math.min(cycle30.length, cycle30Recent.length);
      for (let i = 1; i < cycleLen; i++) {
        const dir30 = cycle30[i] > cycle30[i - 1];
        const dirRecent = cycle30Recent[i] > cycle30Recent[i - 1];
        if (dir30 === dirRecent) cycleMatch++;
      }
      const cycleCorrelation = cycleMatch / (cycleLen - 1);
      if (cycleCorrelation > 0.65) {
        // Predict next move based on what happened 30min ago
        const predictDir = cycle30.length > 0 && cycle30[cycle30.length - 1] > cycle30[Math.max(0, cycle30.length - 2)] ? 'CALL' : 'PUT';
        if (predictDir === direction) {
          algoIntelScore += 0.9;
          algoIntelFactors.push(`ALGO-R6: Pattern Recycling ${(cycleCorrelation * 100).toFixed(0)}% (30min cycle)`);
        }
      }
    }
    
    // RULE 7: Volatility Regime Detection (ATR expansion/contraction cycles)
    const atr10 = aiCloses.slice(-10).reduce((s, c, i) => s + Math.abs(c - aiOpens[aiLen - 10 + i]), 0) / 10;
    const atr30 = aiCloses.slice(-30).reduce((s, c, i) => s + Math.abs(c - aiOpens[aiLen - 30 + i]), 0) / 30;
    if (atr30 > 0 && atr10 / atr30 > 1.8) {
      // Volatility expanding = breakout mode
      const volDir = aiCloses[aiLen - 1] > aiOpens[aiLen - 1] ? 'CALL' : 'PUT';
      if (volDir === direction) {
        algoIntelScore += 0.7;
        algoIntelFactors.push('ALGO-R7: Volatility Expansion (breakout regime)');
      }
    } else if (atr30 > 0 && atr10 / atr30 < 0.5) {
      // Volatility contracting = mean reversion mode
      const snapDir = aiCloses[aiLen - 1] > aiOpens[aiLen - 1] ? 'PUT' : 'CALL';
      if (snapDir === direction) {
        algoIntelScore += 0.6;
        algoIntelFactors.push('ALGO-R7: Volatility Contraction (mean reversion regime)');
      }
    }
    
    // RULE 8: Candle Color Sequence Analysis (Probability of next color based on last N)
    if (aiLen >= 20) {
      let sameColorCount = 0;
      const lastColor = aiCloses[aiLen - 1] > aiOpens[aiLen - 1];
      for (let i = aiLen - 2; i >= Math.max(aiLen - 6, 0); i--) {
        if ((aiCloses[i] > aiOpens[i]) === lastColor) sameColorCount++;
        else break;
      }
      if (sameColorCount >= 4) {
        const flipDir = lastColor ? 'PUT' : 'CALL';
        if (flipDir === direction) {
          algoIntelScore += 0.8;
          algoIntelFactors.push(`ALGO-R8: Color Sequence (${sameColorCount + 1} same → flip expected)`);
        }
      }
    }
    
    // RULE 9: Price Distribution Analysis (Skewness of recent price action)
    if (aiLen >= 30) {
      const mean30 = aiCloses.slice(-30).reduce((a, b) => a + b, 0) / 30;
      const aboveMean = aiCloses.slice(-30).filter(c => c > mean30).length;
      const belowMean = 30 - aboveMean;
      if (aboveMean > 22 && direction === 'PUT') {
        algoIntelScore += 0.7;
        algoIntelFactors.push(`ALGO-R9: Skewed Distribution (${aboveMean}/30 above mean → reversion PUT)`);
      }
      if (belowMean > 22 && direction === 'CALL') {
        algoIntelScore += 0.7;
        algoIntelFactors.push(`ALGO-R9: Skewed Distribution (${belowMean}/30 below mean → reversion CALL)`);
      }
    }
    
    // RULE 10: Multi-Cycle Fractal Matching (60min + 90min pattern correlation)
    if (aiCloses.length >= 120) {
      const cycle60 = aiCloses.slice(-120, -60);
      const cycle60Recent = aiCloses.slice(-60);
      let cycleMatch60 = 0;
      const cLen60 = Math.min(cycle60.length, cycle60Recent.length);
      for (let i = 1; i < cLen60; i++) {
        if ((cycle60[i] > cycle60[i - 1]) === (cycle60Recent[i] > cycle60Recent[i - 1])) cycleMatch60++;
      }
      const correlation60 = cycleMatch60 / (cLen60 - 1);
      if (correlation60 > 0.6) {
        const predict60 = cycle60[cycle60.length - 1] > cycle60[cycle60.length - 2] ? 'CALL' : 'PUT';
        if (predict60 === direction) {
          algoIntelScore += 1.0;
          algoIntelFactors.push(`ALGO-R10: 60min Fractal Match ${(correlation60 * 100).toFixed(0)}%`);
        }
      }
    }
    
    // RULE 11: Institutional Time-of-Day Bias (Session-specific algo behavior)
    const algoHour = new Date().getUTCHours();
    const isAsiaSession = algoHour >= 0 && algoHour <= 7;
    const isLondonSession = algoHour >= 7 && algoHour <= 15;
    const isNYSession = algoHour >= 13 && algoHour <= 21;
    if (isLondonSession && marketData.trend.adx > 25) {
      // London session = highest volatility, trend moves are more reliable
      const sessDir = aiCloses[aiLen - 1] > aiOpens[aiLen - 1] ? 'CALL' : 'PUT';
      if (sessDir === direction) {
        algoIntelScore += 0.8;
        algoIntelFactors.push('ALGO-R11: London Session trend bias (high volatility confirmation)');
      }
    }
    if (isAsiaSession && marketData.trend.adx < 20) {
      // Asia = ranging, fade extremes
      const asiaFade = marketData.momentum.rsi14 > 65 ? 'PUT' : marketData.momentum.rsi14 < 35 ? 'CALL' : null;
      if (asiaFade && asiaFade === direction) {
        algoIntelScore += 0.6;
        algoIntelFactors.push('ALGO-R11: Asia Session mean-reversion bias');
      }
    }
    
    // RULE 12: Cross-Category Consensus Score (How many categories agree with direction)
    const algoConsensusFactors = [
      marketData.trend.emaAlignment === (direction === 'CALL' ? 'BULLISH' : 'BEARISH'),
      marketData.smc.lastBOS === (direction === 'CALL' ? 'BULLISH_BOS' : 'BEARISH_BOS'),
      marketData.parabolicSAR.trend === (direction === 'CALL' ? 'BULLISH' : 'BEARISH'),
      direction === 'CALL' ? (marketData.momentum.rsi14 > 40 && marketData.momentum.rsi14 < 70) : (marketData.momentum.rsi14 > 30 && marketData.momentum.rsi14 < 60),
      direction === 'CALL' ? marketData.smc.hasBullishFVG : marketData.smc.hasBearishFVG,
    ].filter(Boolean).length;
    if (algoConsensusFactors >= 4) {
      algoIntelScore += 1.2;
      algoIntelFactors.push(`ALGO-R12: Cross-Category Consensus (${algoConsensusFactors}/5 categories confirm direction)`);
    }
    
    // RULE 13: Momentum Regime Classification (Trending vs Mean-Reverting market)
    if (aiLen >= 30) {
      const returns = [];
      for (let r = aiLen - 30; r < aiLen; r++) {
        returns.push(aiCloses[r] - aiCloses[Math.max(0, r - 1)]);
      }
      const posReturns = returns.filter(r => r > 0).length;
      const negReturns = returns.filter(r => r < 0).length;
      const ratio = Math.max(posReturns, negReturns) / 30;
      if (ratio > 0.65) {
        // Strong trending regime
        const trendDir = posReturns > negReturns ? 'CALL' : 'PUT';
        if (trendDir === direction) {
          algoIntelScore += 0.9;
          algoIntelFactors.push(`ALGO-R13: Trending Regime (${(ratio * 100).toFixed(0)}% directional dominance)`);
        }
      }
    }
    
    if (algoIntelFactors.length > 0) {
      console.log(`[OTC-ALGO INTELLIGENCE] Score: ${algoIntelScore.toFixed(2)}, Rules: ${algoIntelFactors.length}`);
    }
  }
  
  // OTC-ALGO overrides: add to total score with 1.5x weight (highest authority)
  totalScore += algoIntelScore * 1.5;
  if (algoIntelFactors.length > 0) {
    categories.push({ name: 'OTC-ALGO Intelligence (13 Ultra Rules)', score: algoIntelScore * 1.5, factors: algoIntelFactors });
  }
  
  // ============= MESH SCORING MATRIX (CROSS-CATEGORY INTERCONNECTION) =============
  // 11-point amplification when categories align, 5-point dampening when they conflict
  let meshAmplification = 0;
  let meshDampening = 0;
  const meshFactors: string[] = [];
  
  const smcCatM = categories.find(c => c.name.includes('SMC'));
  const liqCatM = categories.find(c => c.name.includes('Liquidity'));
  const indCatM = categories.find(c => c.name.includes('Algo-Trap'));
  const htfCatM = categories.find(c => c.name.includes('HTF'));
  const paCatM = categories.find(c => c.name.includes('Price Action'));
  const setupCatM = categories.find(c => c.name.includes('235'));
  const otcCatM = categories.find(c => c.name.includes('OTC Trap'));
  const algoCatM = categories.find(c => c.name.includes('OTC-ALGO'));
  const mtfCatM = categories.find(c => c.name.includes('Multi-Timeframe'));
  const revCatM = categories.find(c => c.name.includes('Reversal Trigger'));
  const contCatM = categories.find(c => c.name.includes('Continuation Trigger'));
  const ictCatM = categories.find(c => c.name.includes('ICT Concepts'));
  
  // AMPLIFICATION MATRIX (11 points max + new category bonuses)
  // 1. SMC + Liquidity alignment (+2)
  if ((smcCatM?.score || 0) >= 2 && (liqCatM?.score || 0) >= 2) {
    meshAmplification += 2;
    meshFactors.push('MESH+2: SMC↔Liquidity synergy');
  }
  // 2. SMC + HTF alignment (+2)
  if ((smcCatM?.score || 0) >= 2 && (htfCatM?.score || 0) >= 2) {
    meshAmplification += 2;
    meshFactors.push('MESH+2: SMC↔HTF institutional alignment');
  }
  // 3. Indicators + 235 Setups alignment (+1.5)
  if ((indCatM?.score || 0) >= 2 && (setupCatM?.score || 0) >= 2) {
    meshAmplification += 1.5;
    meshFactors.push('MESH+1.5: Indicators↔Setups confluence');
  }
  // 4. HTF + Liquidity alignment (+1.5)
  if ((htfCatM?.score || 0) >= 2 && (liqCatM?.score || 0) >= 2) {
    meshAmplification += 1.5;
    meshFactors.push('MESH+1.5: HTF↔Liquidity macro alignment');
  }
  // 5. OTC Trap + SMC alignment (+1)
  if ((otcCatM?.score || 0) >= 1 && (smcCatM?.score || 0) >= 2) {
    meshAmplification += 1;
    meshFactors.push('MESH+1: OTC-Trap↔SMC cross-validation');
  }
  // 6. ALGO Intelligence + any 3 categories (+1.5)
  const strongCats = [smcCatM, liqCatM, htfCatM, indCatM, paCatM].filter(c => (c?.score || 0) >= 1.5).length;
  if ((algoCatM?.score || 0) >= 1 && strongCats >= 3) {
    meshAmplification += 1.5;
    meshFactors.push('MESH+1.5: ALGO-Intel confirms 3+ category alignment');
  }
  // 7. Price Action + Volume confirmation (+1)
  if ((paCatM?.score || 0) >= 1 && marketData.volume.obvTrend !== 'NEUTRAL') {
    meshAmplification += 1;
    meshFactors.push('MESH+1: PriceAction↔Volume confirmation');
  }
  // 8. MTF + ICT alignment (+1.5) - New categories cross-validate
  if ((mtfCatM?.score || 0) >= 2 && (ictCatM?.score || 0) >= 1.5) {
    meshAmplification += 1.5;
    meshFactors.push('MESH+1.5: MTF↔ICT institutional confluence');
  }
  // 9. Reversal + ICT alignment (+1)
  if ((revCatM?.score || 0) >= 1.5 && (ictCatM?.score || 0) >= 1.5) {
    meshAmplification += 1;
    meshFactors.push('MESH+1: Reversal↔ICT reversal confirmation');
  }
  // 10. Continuation + MTF alignment (+1)
  if ((contCatM?.score || 0) >= 1.5 && (mtfCatM?.score || 0) >= 2) {
    meshAmplification += 1;
    meshFactors.push('MESH+1: Continuation↔MTF trend confirmation');
  }
  // 11. SMC + ICT alignment (+1.5) - ICT validates SMC zones
  if ((smcCatM?.score || 0) >= 2 && (ictCatM?.score || 0) >= 2) {
    meshAmplification += 1.5;
    meshFactors.push('MESH+1.5: SMC↔ICT institutional validation');
  }
  // 12. Reversal + Liquidity + SMC triple confluence (+2)
  if ((revCatM?.score || 0) >= 2 && (liqCatM?.score || 0) >= 2 && (smcCatM?.score || 0) >= 2) {
    meshAmplification += 2;
    meshFactors.push('MESH+2: Reversal↔Liquidity↔SMC triple institutional reversal');
  }
  // 13. Continuation + HTF + Indicators alignment (+1.5)
  if ((contCatM?.score || 0) >= 2 && (htfCatM?.score || 0) >= 2 && (indCatM?.score || 0) >= 2) {
    meshAmplification += 1.5;
    meshFactors.push('MESH+1.5: Continuation↔HTF↔Indicators triple trend confirmation');
  }
  // 14. ICT + OTC Trap + ALGO Intelligence convergence (+2)
  if ((ictCatM?.score || 0) >= 2 && (otcCatM?.score || 0) >= 1.5 && (algoCatM?.score || 0) >= 1) {
    meshAmplification += 2;
    meshFactors.push('MESH+2: ICT↔OTC-Trap↔ALGO triple manipulation detection');
  }
  // 15. ALL 4 new categories aligned (+2.5) - ultimate confluence
  if ((mtfCatM?.score || 0) >= 1.5 && (revCatM?.score || 0) >= 1.5 && (contCatM?.score || 0) >= 1.5 && (ictCatM?.score || 0) >= 1.5) {
    meshAmplification += 2.5;
    meshFactors.push('MESH+2.5: ULTRA quad-category alignment (MTF+Rev+Cont+ICT)');
  }
  // 16. Price Action + ICT + SMC institutional trifecta (+1.5)
  if ((paCatM?.score || 0) >= 2 && (ictCatM?.score || 0) >= 2 && (smcCatM?.score || 0) >= 2) {
    meshAmplification += 1.5;
    meshFactors.push('MESH+1.5: PA↔ICT↔SMC institutional trifecta');
  }
  // 17. Reversal + Continuation mutual exclusion bonus (+1)
  // If only ONE of reversal/continuation fires strongly, it's cleaner signal
  const revStrong = (revCatM?.score || 0) >= 3;
  const contStrong = (contCatM?.score || 0) >= 3;
  if ((revStrong && !contStrong) || (contStrong && !revStrong)) {
    meshAmplification += 1;
    meshFactors.push('MESH+1: Clean Rev/Cont separation (no conflict)');
  }
  // 18. 7+ categories all scoring above minimum (+3) - ULTRA CONFLUENCE
  const allCatsAbove1 = [smcCatM, liqCatM, indCatM, htfCatM, paCatM, mtfCatM, revCatM, contCatM, ictCatM, otcCatM, algoCatM]
    .filter(c => (c?.score || 0) >= 1.5).length;
  if (allCatsAbove1 >= 7) {
    meshAmplification += 3;
    meshFactors.push(`MESH+3: ULTRA CONFLUENCE (${allCatsAbove1}/11 categories confirm)`);
  }
  
  // DAMPENING MATRIX (expanded)
  // 1. SMC vs HTF conflict (-1)
  if ((smcCatM?.score || 0) >= 2 && (htfCatM?.score || 0) < 1) {
    meshDampening += 1;
    meshFactors.push('MESH-1: SMC strong but HTF weak (misalignment)');
  }
  // 2. High volume with no directional confirmation (-1)
  if (marketData.volume.obvTrend === 'NEUTRAL' && (indCatM?.score || 0) >= 3) {
    meshDampening += 1;
    meshFactors.push('MESH-1: Indicators fire but volume neutral');
  }
  // 3. OTC Trap detected opposing direction (-1.5)
  if ((otcCatM?.score || 0) >= 2 && (setupCatM?.score || 0) < 1) {
    meshDampening += 1.5;
    meshFactors.push('MESH-1.5: OTC traps active but no setup confirmation');
  }
  // 4. Reversal + Continuation both strong = conflict (-2)
  if (revStrong && contStrong) {
    meshDampening += 2;
    meshFactors.push('MESH-2: Reversal↔Continuation conflict (both strong)');
  }
  // 5. ICT + SMC disagree on structure (-1)
  if ((ictCatM?.score || 0) >= 2 && (smcCatM?.score || 0) < 1) {
    meshDampening += 1;
    meshFactors.push('MESH-1: ICT strong but SMC weak (structural conflict)');
  }
  
  const meshNet = meshAmplification - meshDampening;
  if (meshNet !== 0) {
    totalScore += meshNet;
    console.log(`[MESH SCORING] Amplification: +${meshAmplification.toFixed(1)} | Dampening: -${meshDampening.toFixed(1)} | Net: ${meshNet > 0 ? '+' : ''}${meshNet.toFixed(1)}`);
    categories.push({ name: 'Mesh Interconnection', score: meshNet, factors: meshFactors });
  }
  
  // ============= LOG AVOID RULES SUMMARY =============
  console.log(`[AVOID RULES SUMMARY] Valid strategies: ${totalValidStrategies}, Blocked strategies: ${totalBlockedStrategies}`);
  if (totalBlockedStrategies > 0) {
    console.log(`[AVOID RULES] Blocked strategies removed from analysis - 100% exclusion enforced`);
  }
  
  // Log minimum requirements status for all categories
  console.log(`[CATEGORY MINIMUM CHECK] SMC: ${categories.find(c => c.name.includes('SMC'))?.score?.toFixed(2) || 0}/${CATEGORY_MIN_REQUIREMENTS.SMC}, Liquidity: ${categories.find(c => c.name.includes('Liquidity'))?.score?.toFixed(2) || 0}/${CATEGORY_MIN_REQUIREMENTS.LIQUIDITY}, Indicators: ${categories.find(c => c.name.includes('Algo-Trap'))?.score?.toFixed(2) || 0}/${CATEGORY_MIN_REQUIREMENTS.INDICATORS}, 235: ${categories.find(c => c.name.includes('235'))?.score?.toFixed(2) || 0}/${CATEGORY_MIN_REQUIREMENTS.SETUPS_235}, HTF: ${htfScore.toFixed(2)}/${CATEGORY_MIN_REQUIREMENTS.HTF}`);
  
  // ============= ENFORCE CATEGORY MINIMUM REQUIREMENTS =============
  // Each category MUST meet its minimum point requirement for a signal to be generated
  // This check is performed AFTER fallback logic has already tried to complete points
  const smcCat = categories.find(c => c.name.includes('SMC'));
  const liquidityCat = categories.find(c => c.name.includes('Liquidity'));
  const indicatorsCat = categories.find(c => c.name.includes('Algo-Trap'));
  const setups235Cat = categories.find(c => c.name.includes('235'));
  const htfCat = categories.find(c => c.name.includes('HTF'));
  
  const failedCategories: string[] = [];
  
  if (smcCat && smcCat.score < CATEGORY_MIN_REQUIREMENTS.SMC) {
    failedCategories.push(`SMC: ${smcCat.score.toFixed(1)}/${CATEGORY_MIN_REQUIREMENTS.SMC}`);
  }
  if (liquidityCat && liquidityCat.score < CATEGORY_MIN_REQUIREMENTS.LIQUIDITY) {
    failedCategories.push(`Liquidity: ${liquidityCat.score.toFixed(1)}/${CATEGORY_MIN_REQUIREMENTS.LIQUIDITY}`);
  }
  if (indicatorsCat && indicatorsCat.score < CATEGORY_MIN_REQUIREMENTS.INDICATORS) {
    failedCategories.push(`Indicators: ${indicatorsCat.score.toFixed(1)}/${CATEGORY_MIN_REQUIREMENTS.INDICATORS}`);
  }
  if (setups235Cat && setups235Cat.score < CATEGORY_MIN_REQUIREMENTS.SETUPS_235) {
    failedCategories.push(`235 Setups: ${setups235Cat.score.toFixed(1)}/${CATEGORY_MIN_REQUIREMENTS.SETUPS_235}`);
  }
  if (htfCat && htfCat.score < CATEGORY_MIN_REQUIREMENTS.HTF) {
    failedCategories.push(`HTF: ${htfCat.score.toFixed(1)}/${CATEGORY_MIN_REQUIREMENTS.HTF}`);
  }
  
  // Return with failed categories info for signal generation to check
  return { 
    totalScore, 
    categories, 
    matchedSetups,
    allCategoriesMet: failedCategories.length === 0,
    failedCategories
  };
}

// ============= MAIN SIGNAL GENERATION (100% CODE LOGIC) =============

// ============= 50 SCENARIO STRATEGIES DATABASE =============
interface ScenarioBreakdown {
  smc: { up: number; down: number };
  htf: { up: number; down: number };
  liquidity: { up: number; down: number };
  indicator: { up: number; down: number };
  retail: { up: number; down: number };
  algoTrap?: { up: number; down: number };
}

interface ScenarioResult {
  signal: 'CALL' | 'PUT';
  logic: string;
  confidence: string;
  strategyName: string;
  strategyNumber: number;
}

// Strategy #1: Whale vs Crowd
function getWhaleSignal(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isCleanRoad = (breakdown.htf.up === 0 && breakdown.htf.down === 0);
  const retailBaitUp = (breakdown.retail.up >= 15 && breakdown.retail.down <= 5);
  const retailBaitDown = (breakdown.retail.down >= 15 && breakdown.retail.up <= 5);
  const whaleAlignDown = (breakdown.smc.down >= 1 && breakdown.liquidity.down >= 2);
  const whaleAlignUp = (breakdown.smc.up >= 1 && breakdown.liquidity.up >= 2);
  if (isCleanRoad && retailBaitUp && whaleAlignDown) {
    return { signal: "PUT", logic: "Whale Strategy: Trapping Retail Crowd UP. Following SMC + Liquidity DOWN.", confidence: "98%", strategyName: "Whale vs Crowd", strategyNumber: 1 };
  }
  if (isCleanRoad && retailBaitDown && whaleAlignUp) {
    return { signal: "CALL", logic: "Whale Strategy: Trapping Retail Crowd DOWN. Following SMC + Liquidity UP.", confidence: "98%", strategyName: "Whale vs Crowd", strategyNumber: 1 };
  }
  return null;
}

// Strategy #2: Domination Party
function getDominationSignal(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const mastersSilent = (breakdown.smc.up === 0 && breakdown.smc.down === 0) && (breakdown.htf.up === 0 && breakdown.htf.down === 0);
  const algoTrap = breakdown.algoTrap || { up: 0, down: 0 };
  const totalUp = (breakdown.liquidity.up + algoTrap.up + breakdown.retail.up);
  const totalDown = (breakdown.liquidity.down + algoTrap.down + breakdown.retail.down);
  if (mastersSilent && totalUp >= 10 && totalDown >= 10) {
    if (totalUp > totalDown) return { signal: "CALL", logic: `Up Domination: ${totalUp} vs ${totalDown}. Masters Silent.`, confidence: "93%", strategyName: "Domination Party", strategyNumber: 2 };
    if (totalDown > totalUp) return { signal: "PUT", logic: `Down Domination: ${totalDown} vs ${totalUp}. Masters Silent.`, confidence: "93%", strategyName: "Domination Party", strategyNumber: 2 };
  }
  return null;
}

// Strategy #3: Master-Crowd Harmony
function checkHarmonyStrategy(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const mastersUp = breakdown.smc.up >= 1 && breakdown.smc.down === 0 && breakdown.htf.up >= 1;
  const crowdUp = breakdown.retail.up >= 15 && (breakdown.retail.up > breakdown.retail.down * 3);
  if (mastersUp && crowdUp) return { signal: "CALL", logic: "Harmony Strategy: SMC & Retail aligned UP. Ignoring opposition.", confidence: "98%", strategyName: "Master-Crowd Harmony", strategyNumber: 3 };
  return null;
}

// Strategy #4: Equilibrium Trap
function checkEquilibriumTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const smcTie = breakdown.smc.up === 1 && breakdown.smc.down === 1;
  const liqTie = breakdown.liquidity.up === 1 && breakdown.liquidity.down === 1;
  const crowdHeavyDown = breakdown.retail.down >= 10 && breakdown.retail.up <= 2;
  if (smcTie && liqTie && crowdHeavyDown) return { signal: "CALL", logic: "Equilibrium Trap: Masters tied. Flushing crowd UP.", confidence: "95%", strategyName: "Equilibrium Trap", strategyNumber: 4 };
  return null;
}

// Strategy #5: HTF Anchor Override
function checkHTFAnchorStrategy(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHTF_UpAnchor = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isRetail_UpDominant = breakdown.retail.up >= 10 && (breakdown.retail.up >= breakdown.retail.down * 3);
  const isSMC_WeakOpposition = breakdown.smc.down > 0 && breakdown.smc.down <= 3;
  if (isHTF_UpAnchor && isRetail_UpDominant && isSMC_WeakOpposition) return { signal: "CALL", logic: "HTF Anchor: HTF & Retail UP. Weak SMC is Bait.", confidence: "94%", strategyName: "HTF Anchor Override", strategyNumber: 5 };
  return null;
}

// Strategy #6: Pure Anchor Magnet
function checkAnchorMagnetStrategy(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHTF_PureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isSMCLiq_Confused = (breakdown.smc.up > 0 && breakdown.smc.down > 0) || (breakdown.liquidity.up === breakdown.liquidity.down);
  const isRetail_Supporting = breakdown.retail.up > breakdown.retail.down;
  if (isHTF_PureUp && isSMCLiq_Confused && isRetail_Supporting) return { signal: "CALL", logic: "Anchor Magnet: HTF Pure UP, SMC/Liq confused.", confidence: "92%", strategyName: "Pure Anchor Magnet", strategyNumber: 6 };
  return null;
}

// Strategy #7: Consensus Surge
function checkConsensusSurge(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMC_PowerAnchor = breakdown.smc.up >= 3 && breakdown.smc.down === 0;
  const isRetail_MassiveUp = breakdown.retail.up >= 25 && (breakdown.retail.up >= breakdown.retail.down * 5);
  const isIndicator_Supporting = breakdown.indicator.up > breakdown.indicator.down;
  if (isSMC_PowerAnchor && isRetail_MassiveUp && isIndicator_Supporting) return { signal: "CALL", logic: "Consensus Surge: SMC 3-0 + Massive Retail. Absolute synergy.", confidence: "99%", strategyName: "Consensus Surge", strategyNumber: 7 };
  return null;
}

// Strategy #8: Crowd Washout
function checkCrowdWashout(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isRetail_MassiveUp = breakdown.retail.up >= 20 && breakdown.retail.down <= 5;
  const isSMC_AlsoUp = breakdown.smc.up >= 2 && breakdown.smc.down === 0;
  const isLiquidity_PureDown = breakdown.liquidity.down >= 1 && breakdown.liquidity.up === 0;
  const isIndicator_Down = breakdown.indicator.down > breakdown.indicator.up;
  if (isRetail_MassiveUp && isSMC_AlsoUp && isLiquidity_PureDown && isIndicator_Down) return { signal: "PUT", logic: "Crowd Washout: Retail+SMC heavy UP. Pure Liquidity DOWN.", confidence: "93%", strategyName: "Crowd Washout", strategyNumber: 8 };
  return null;
}

// Strategy #9: Weighted Domination
function checkWeightedDomination(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMC_StrongDown = breakdown.smc.down >= 3 && breakdown.smc.up === 0;
  const isRetail_OverwhelmingDown = breakdown.retail.down >= 25 && (breakdown.retail.down >= breakdown.retail.up * 5);
  const isHTF_WeakOpposition = breakdown.htf.up === 1 && breakdown.htf.down === 0;
  if (isSMC_StrongDown && isRetail_OverwhelmingDown && isHTF_WeakOpposition) return { signal: "PUT", logic: "Weighted Domination: SMC 3-0 + Massive Retail crushed lone HTF.", confidence: "95%", strategyName: "Weighted Domination", strategyNumber: 9 };
  return null;
}

// Strategy #10: Triple Anchor Force
function checkTripleAnchorForce(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHTF_PureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isLiq_PureUp = breakdown.liquidity.up >= 2 && breakdown.liquidity.down === 0;
  const isSMC_SupportingUp = breakdown.smc.up > breakdown.smc.down;
  const isRetail_Up = breakdown.retail.up > breakdown.retail.down;
  if (isHTF_PureUp && isLiq_PureUp && isSMC_SupportingUp && isRetail_Up) return { signal: "CALL", logic: "Triple Anchor: HTF+Liquidity Pure UP. SMC confirms.", confidence: "97%", strategyName: "Triple Anchor Force", strategyNumber: 10 };
  return null;
}

// Strategy #11: HTF Trend Trap
function checkHTFTrendTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isPowerAlignedDown = breakdown.smc.down >= 4 && breakdown.smc.up === 0 && breakdown.retail.down >= 20 && (breakdown.retail.down >= breakdown.retail.up * 5);
  const isPowerAlignedUp = breakdown.smc.up >= 4 && breakdown.smc.down === 0 && breakdown.retail.up >= 20 && (breakdown.retail.up >= breakdown.retail.down * 5);
  const isHTF_BaitUp = breakdown.htf.up >= 1 && breakdown.htf.up <= 2;
  const isHTF_BaitDown = breakdown.htf.down >= 1 && breakdown.htf.down <= 2;
  if (isPowerAlignedDown && isHTF_BaitUp) return { signal: "PUT", logic: "HTF Trend Trap: SMC 4+ & Retail 20+ overriding HTF bait.", confidence: "99%", strategyName: "HTF Trend Trap", strategyNumber: 11 };
  if (isPowerAlignedUp && isHTF_BaitDown) return { signal: "CALL", logic: "HTF Trend Trap: SMC 4+ & Retail 20+ overriding HTF bait.", confidence: "99%", strategyName: "HTF Trend Trap", strategyNumber: 11 };
  return null;
}

// Strategy #12: Balanced Flow
function checkBalancedFlow(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCTie = breakdown.smc.up === breakdown.smc.down;
  const isIndicatorTie = breakdown.indicator.up === breakdown.indicator.down;
  const isHTF_Down = breakdown.htf.down >= 1 && breakdown.htf.up === 0;
  const isLiq_Down = breakdown.liquidity.down > breakdown.liquidity.up;
  const isRetail_MassiveDown = breakdown.retail.down >= 20;
  if (isSMCTie && isIndicatorTie && isHTF_Down && isLiq_Down && isRetail_MassiveDown) return { signal: "PUT", logic: "Balanced Flow: SMC/Indicators neutral. Following HTF+Liquidity+Retail.", confidence: "97%", strategyName: "Balanced Flow", strategyNumber: 12 };
  return null;
}

// Strategy #13: Extremist Trap
function checkExtremistTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isRetail_ExtremistDown = breakdown.retail.down >= 25 && (breakdown.retail.down >= breakdown.retail.up * 10);
  const isSMC_TrappedDown = breakdown.smc.down >= 1 && breakdown.smc.up === 0;
  const isHTF_PureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isLiq_WithCaptain = breakdown.liquidity.up > breakdown.liquidity.down;
  if (isRetail_ExtremistDown && isSMC_TrappedDown && isHTF_PureUp && isLiq_WithCaptain) return { signal: "CALL", logic: "Extremist Trap: Retail extreme DOWN. Following HTF to liquidate.", confidence: "98%", strategyName: "Extremist Trap", strategyNumber: 13 };
  return null;
}

// Strategy #14: Multi-Layer Liquidation
function checkMultiLayerLiquidation(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isRetail_MassiveDown = breakdown.retail.down >= 25 && (breakdown.retail.down >= breakdown.retail.up * 4);
  const isBait_Down = (breakdown.indicator.down >= 4 && breakdown.smc.down <= 1);
  const isHTF_PureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isLiq_WithHTF = breakdown.liquidity.up >= 2 && breakdown.liquidity.up > breakdown.liquidity.down;
  if (isRetail_MassiveDown && isBait_Down && isHTF_PureUp && isLiq_WithHTF) return { signal: "CALL", logic: "Multi-Layer Liquidation: Crowd+Indicators trapped. Following HTF+Liquidity.", confidence: "98%", strategyName: "Multi-Layer Liquidation", strategyNumber: 14 };
  return null;
}

// Strategy #15: Synergy Overpower
function checkSynergyOverpower(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMC_PureUp = breakdown.smc.up >= 2 && breakdown.smc.down === 0;
  const isRetail_MassiveUp = breakdown.retail.up >= 20 && (breakdown.retail.up >= breakdown.retail.down * 5);
  const isIndicator_Supporting = breakdown.indicator.up > breakdown.indicator.down;
  const isOpposition_Weak = breakdown.htf.down <= 2 && breakdown.liquidity.down <= 2;
  if (isSMC_PureUp && isRetail_MassiveUp && isIndicator_Supporting && isOpposition_Weak) return { signal: "CALL", logic: "Synergy Overpower: SMC+Retail 5x aligned. Weak opposition.", confidence: "95%", strategyName: "Synergy Overpower", strategyNumber: 15 };
  return null;
}

// Strategy #16: Unstoppable Anchor Synergy
function checkUnstoppableAnchor(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHTF_PureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isLiq_PureUp = breakdown.liquidity.up >= 2 && breakdown.liquidity.down === 0;
  const isRetail_StrongUp = breakdown.retail.up >= 15 && (breakdown.retail.up >= breakdown.retail.down * 8);
  const isSMC_DominantUp = breakdown.smc.up > breakdown.smc.down;
  if (isHTF_PureUp && isLiq_PureUp && isRetail_StrongUp && isSMC_DominantUp) return { signal: "CALL", logic: "Unstoppable Anchor: HTF+Liquidity Pure UP. Massive Retail.", confidence: "99%", strategyName: "Unstoppable Anchor Synergy", strategyNumber: 16 };
  return null;
}

// Strategy #17: Liquidity Veto
function checkLiquidityVeto(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isNeutralMarket = (breakdown.htf.up === 0 && breakdown.htf.down === 0) && (breakdown.indicator.up === breakdown.indicator.down);
  const isLiq_PureUp = breakdown.liquidity.up >= 2 && breakdown.liquidity.down === 0;
  const isOpposition_Down = breakdown.smc.down >= 1 && breakdown.retail.down > breakdown.retail.up;
  if (isNeutralMarket && isLiq_PureUp && isOpposition_Down) return { signal: "CALL", logic: "Liquidity Veto: Pure 2-0 Liquidity UP overrides SMC+Retail.", confidence: "94%", strategyName: "Liquidity Veto", strategyNumber: 17 };
  return null;
}

// Strategy #18: Master Veto
function checkMasterVeto(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isNeutralMarket = (breakdown.htf.up === 0 && breakdown.htf.down === 0) && (breakdown.liquidity.up === breakdown.liquidity.down);
  const isRetail_HeavyUp = breakdown.retail.up >= 10 && (breakdown.retail.up >= breakdown.retail.down * 7);
  const isSMC_PureDown = breakdown.smc.down >= 2 && breakdown.smc.up === 0;
  if (isNeutralMarket && isRetail_HeavyUp && isSMC_PureDown) return { signal: "PUT", logic: "Master Veto: Retail trapped UP. Following Pure SMC DOWN.", confidence: "96%", strategyName: "Master Veto", strategyNumber: 18 };
  return null;
}

// Strategy #19: Indicator Overload Trap
function checkIndicatorOverload(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMC_Neutral = (breakdown.smc.up === breakdown.smc.down) && (breakdown.htf.up === 0 && breakdown.htf.down === 0);
  const isIndicator_BaitUp = breakdown.indicator.up >= 4 && breakdown.indicator.down <= 1;
  const isRetail_AntiBait = breakdown.retail.down > (breakdown.retail.up * 3);
  if (isSMC_Neutral && isIndicator_BaitUp && isRetail_AntiBait) return { signal: "PUT", logic: "Indicator Overload Trap: Indicators UP bait. Following anti-bait.", confidence: "93%", strategyName: "Indicator Overload Trap", strategyNumber: 19 };
  return null;
}

// Strategy #20: Overcrowded Magnet Trap
function checkOvercrowdedTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isCrowdedDown = breakdown.smc.down >= 3 && breakdown.indicator.down >= 6 && breakdown.retail.down >= 25;
  const isLiquidity_OpposingUp = breakdown.liquidity.up >= 4;
  const isNoHTF = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  if (isCrowdedDown && isLiquidity_OpposingUp && isNoHTF) return { signal: "CALL", logic: "Overcrowded Trap: All DOWN but Liquidity UP hunts crowd.", confidence: "95%", strategyName: "Overcrowded Magnet Trap", strategyNumber: 20 };
  return null;
}

// Strategy #21: HTF Supremacy
function checkHTFSupremacy(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isPureMasterUp = (breakdown.smc.up >= 3 && breakdown.smc.down === 0) && (breakdown.liquidity.up >= 2 && breakdown.liquidity.down === 0);
  const isHTF_Opposing = breakdown.htf.down >= 1 && breakdown.htf.up === 0;
  const isMassiveRetailDown = breakdown.retail.down >= 20 && (breakdown.retail.down > breakdown.retail.up * 2);
  const isWeakIndicatorSupport = (breakdown.indicator.up - breakdown.indicator.down) <= 1;
  if (isPureMasterUp && isHTF_Opposing && isMassiveRetailDown && isWeakIndicatorSupport) return { signal: "PUT", logic: "HTF Supremacy: HTF DOWN + Massive Retail overpowered Pure SMC UP.", confidence: "92%", strategyName: "HTF Supremacy", strategyNumber: 21 };
  return null;
}

// Strategy #22: Liquidity Vacuum Trap
function checkLiquidityVacuum(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isExtremeRetailDown = breakdown.retail.down >= 25 && (breakdown.retail.down >= breakdown.retail.up * 5);
  const isSMC_Liq_TrappingDown = breakdown.smc.down >= 1 && breakdown.liquidity.down >= 1;
  const isHTF_CounteringUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  if (isExtremeRetailDown && isSMC_Liq_TrappingDown && isHTF_CounteringUp) return { signal: "CALL", logic: "Liquidity Vacuum: Retail trapped DOWN. Following HTF UP.", confidence: "96%", strategyName: "Liquidity Vacuum Trap", strategyNumber: 22 };
  return null;
}

// Strategy #23: Retail Liquidity Flush
function checkRetailLiquidityFlush(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isExtremeRetailDown = breakdown.retail.down >= 20 && (breakdown.retail.down >= breakdown.retail.up * 4);
  const isSMCTied = breakdown.smc.up === breakdown.smc.down;
  const isSupportiveUp = breakdown.liquidity.up >= 1 && breakdown.indicator.up > breakdown.indicator.down;
  const isWeakHTFOpposition = breakdown.htf.down <= 1 && breakdown.htf.up === 0;
  if (isExtremeRetailDown && isSMCTied && isSupportiveUp && isWeakHTFOpposition) return { signal: "CALL", logic: "Retail Liquidity Flush: Retail trapped. SMC neutral. Liquidity+Indicators lead.", confidence: "94%", strategyName: "Retail Liquidity Flush", strategyNumber: 23 };
  return null;
}

// Strategy #24: Absolute Trend Continuation
function checkAbsoluteTrendContinuation(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCPureUp = breakdown.smc.up >= 3 && breakdown.smc.down === 0;
  const isIndicatorExtremeUp = breakdown.indicator.up >= 8 && breakdown.indicator.down === 0;
  const isRetailMassiveUp = breakdown.retail.up >= 25 && (breakdown.retail.up >= breakdown.retail.down * 8);
  const isHTFSupporting = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  if (isSMCPureUp && isIndicatorExtremeUp && isRetailMassiveUp && isHTFSupporting) return { signal: "CALL", logic: "Absolute Trend: SMC 3-0, Indicators 8-0, Retail 25+. Perfect alignment.", confidence: "99%", strategyName: "Absolute Trend Continuation", strategyNumber: 24 };
  return null;
}

// Strategy #25: Momentum Overpower
function checkMomentumOverpower(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCLeadUp = breakdown.smc.up >= 2 && breakdown.smc.down === 0;
  const isIndicatorStrongUp = breakdown.indicator.up >= 6 && breakdown.indicator.down === 0;
  const isRetailAlignedUp = breakdown.retail.up >= 15 && (breakdown.retail.up >= breakdown.retail.down * 5);
  const isOppositionWeak = (breakdown.htf.down + breakdown.liquidity.down) <= 3;
  if (isSMCLeadUp && isIndicatorStrongUp && isRetailAlignedUp && isOppositionWeak) return { signal: "CALL", logic: "Momentum Overpower: SMC 2-0, Indicators 6-0 crushed weak opposition.", confidence: "95%", strategyName: "Momentum Overpower", strategyNumber: 25 };
  return null;
}

// Strategy #26: SMC Superiority
function checkSMCSuperiority(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCPureUp = breakdown.smc.up >= 3 && breakdown.smc.down === 0;
  const isNoHTF = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  const isWeakIndicatorOpp = (breakdown.indicator.down - breakdown.indicator.up) <= 1;
  const isRetailSupporting = breakdown.retail.up >= 15 && breakdown.retail.up > breakdown.retail.down;
  if (isSMCPureUp && isNoHTF && isWeakIndicatorOpp && isRetailSupporting) return { signal: "CALL", logic: "SMC Superiority: Pure 3-0 SMC dominates when HTF absent.", confidence: "93%", strategyName: "SMC Superiority", strategyNumber: 26 };
  return null;
}

// Strategy #27: Crowd & Momentum Sweep
function checkCrowdMomentumSweep(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCTied = breakdown.smc.up === 1 && breakdown.smc.down === 1;
  const isRetailMassiveUp = breakdown.retail.up >= 20 && (breakdown.retail.up >= breakdown.retail.down * 4);
  const isIndicatorCleanUp = breakdown.indicator.up >= 3 && breakdown.indicator.down <= 1;
  const isWeakHTFOpposition = breakdown.htf.down === 1 && breakdown.htf.up === 0;
  if (isSMCTied && isRetailMassiveUp && isIndicatorCleanUp && isWeakHTFOpposition) return { signal: "CALL", logic: "Crowd & Momentum Sweep: Massive retail + clean indicators vs lone HTF.", confidence: "91%", strategyName: "Crowd & Momentum Sweep", strategyNumber: 27 };
  return null;
}

// Strategy #28: Anti-Retail Magnet
function checkAntiRetailMagnet(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isRetailExtremelyDown = breakdown.retail.down >= 18 && (breakdown.retail.down >= breakdown.retail.up * 8);
  const isSMCSupportUp = breakdown.smc.up >= 1 && breakdown.smc.down === 0;
  const isTechnicalBiasUp = breakdown.liquidity.up > breakdown.liquidity.down && breakdown.indicator.up > breakdown.indicator.down;
  const isNoHTF = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  if (isRetailExtremelyDown && isSMCSupportUp && isTechnicalBiasUp && isNoHTF) return { signal: "CALL", logic: "Anti-Retail Magnet: Extreme retail imbalance as liquidity for reversal.", confidence: "97%", strategyName: "Anti-Retail Magnet", strategyNumber: 28 };
  return null;
}

// Strategy #29: Liquidity Vacuum Reversal
function checkLiquidityVacuumReversal(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isLiquidityPureDown = breakdown.liquidity.down >= 2 && breakdown.liquidity.up === 0;
  const isRetailHeavilyUp = breakdown.retail.up >= 20 && (breakdown.retail.up >= breakdown.retail.down * 7);
  const isBullishMomentumModerate = (breakdown.indicator.up - breakdown.indicator.down) <= 3;
  const isSMCAloneUp = breakdown.smc.up >= 2 && breakdown.smc.down === 0;
  if (isLiquidityPureDown && isRetailHeavilyUp && isBullishMomentumModerate && isSMCAloneUp) return { signal: "PUT", logic: "Liquidity Vacuum Reversal: Pure Liquidity DOWN hunts retail buyers.", confidence: "94%", strategyName: "Liquidity Vacuum Reversal", strategyNumber: 29 };
  return null;
}

// Strategy #30: Overcrowded Institutional Trap
function checkOvercrowdedInstitutionalTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCPureDown = breakdown.smc.down >= 3 && breakdown.smc.up === 0;
  const isIndicatorPureDown = breakdown.indicator.down >= 4 && breakdown.indicator.up === 0;
  const isRetailMassiveDown = breakdown.retail.down >= 20 && (breakdown.retail.down >= breakdown.retail.up * 7);
  const isLiquidityNeutral = Math.abs(breakdown.liquidity.up - breakdown.liquidity.down) <= 1;
  const isNoHTF = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  if (isSMCPureDown && isIndicatorPureDown && isRetailMassiveDown && isLiquidityNeutral && isNoHTF) return { signal: "CALL", logic: "Overcrowded Institutional Trap: All DOWN reversed UP to trap mass consensus.", confidence: "98%", strategyName: "Overcrowded Institutional Trap", strategyNumber: 30 };
  return null;
}

// Strategy #31: Overloaded Trend Completion
function checkOverloadedTrendCompletion(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isIndicatorPureDown = breakdown.indicator.down >= 4 && breakdown.indicator.up === 0;
  const isSMCDown = breakdown.smc.down >= 2;
  const isRetailMassiveDown = breakdown.retail.down >= 25;
  const isHTF_FakeOutUp = breakdown.htf.up === 1 && breakdown.htf.down === 0;
  if (isIndicatorPureDown && isSMCDown && isRetailMassiveDown && isHTF_FakeOutUp) return { signal: "PUT", logic: "Overloaded Trend Completion: Indicators 4-0 + SMC crushed lone HTF.", confidence: "90%", strategyName: "Overloaded Trend Completion", strategyNumber: 31 };
  return null;
}

// Strategy #32: Retail Liquidation Sweep
function checkRetailLiquidationSweep(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isRetailHeavilyUp = breakdown.retail.up >= 15 && (breakdown.retail.up >= breakdown.retail.down * 5);
  const isMastersNeutral = breakdown.smc.up === breakdown.smc.down && breakdown.liquidity.up === breakdown.liquidity.down;
  const isBearishBias = breakdown.htf.down >= 1 && breakdown.indicator.down > breakdown.indicator.up;
  if (isRetailHeavilyUp && isMastersNeutral && isBearishBias) return { signal: "PUT", logic: "Retail Liquidation Sweep: Retail trapped. HTF+Indicators pull DOWN.", confidence: "95%", strategyName: "Retail Liquidation Sweep", strategyNumber: 32 };
  return null;
}

// Strategy #33: Trend Avalanche
function checkTrendAvalanche(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isIndicatorExtremeDown = breakdown.indicator.down >= 4 && breakdown.indicator.up === 0;
  const isLiquidityPureDown = breakdown.liquidity.down >= 1 && breakdown.liquidity.up === 0;
  const isHTF_PureDown = breakdown.htf.down >= 1 && breakdown.htf.up === 0;
  const isRetailOverloadedDown = breakdown.retail.down >= 30;
  const isSMCNotOpposing = breakdown.smc.up <= 1;
  if (isIndicatorExtremeDown && isLiquidityPureDown && isHTF_PureDown && isRetailOverloadedDown && isSMCNotOpposing) return { signal: "PUT", logic: "Trend Avalanche: Absolute alignment Ind+Liq+HTF DOWN.", confidence: "98%", strategyName: "Trend Avalanche", strategyNumber: 33 };
  return null;
}

// Strategy #34: Captain & Magnet Trap
function checkCaptainMagnetTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isLiquidityPureUp = breakdown.liquidity.up >= 1 && breakdown.liquidity.down === 0;
  const isHTFPureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isStrongBearishPressure = breakdown.indicator.down >= 4 && breakdown.smc.down >= 2;
  const isRetailTrappedDown = breakdown.retail.down >= 20 && breakdown.retail.down > breakdown.retail.up;
  if (isLiquidityPureUp && isHTFPureUp && isStrongBearishPressure && isRetailTrappedDown) return { signal: "CALL", logic: "Captain & Magnet Trap: HTF+Liquidity Pure UP reverse bearish trend.", confidence: "96%", strategyName: "Captain & Magnet Trap", strategyNumber: 34 };
  return null;
}

// Strategy #35: Momentum Threshold Rule
function checkMomentumThreshold(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isExtremeMomentumDown = breakdown.indicator.down >= 6 && breakdown.indicator.up === 0;
  const isSMCPureDown = breakdown.smc.down >= 3 && breakdown.smc.up === 0;
  const isRetailHeavilyDown = breakdown.retail.down >= 30;
  const oppositionStrength = breakdown.htf.up + breakdown.liquidity.up;
  if (isExtremeMomentumDown && isSMCPureDown && isRetailHeavilyDown && oppositionStrength <= 3) return { signal: "PUT", logic: "Momentum Threshold: Indicators 6-0 + SMC 3-0 unstoppable.", confidence: "97%", strategyName: "Momentum Threshold Rule", strategyNumber: 35 };
  return null;
}

// Strategy #36: Extreme Crowd Sacrifice
function checkExtremeCrowdSacrifice(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isExtremeRetailUp = breakdown.retail.up >= 20 && breakdown.retail.down <= 2;
  const isLiquidityCrowdedUp = breakdown.liquidity.up >= 3 && breakdown.liquidity.down === 0;
  const isSMCOpposingDown = breakdown.smc.down >= 2;
  const isIndicatorNotStrongUp = breakdown.indicator.up <= 2;
  if (isExtremeRetailUp && isLiquidityCrowdedUp && isSMCOpposingDown && isIndicatorNotStrongUp) return { signal: "PUT", logic: "Extreme Crowd Sacrifice: Retail made Liquidity magnet too expensive.", confidence: "96%", strategyName: "Extreme Crowd Sacrifice", strategyNumber: 36 };
  return null;
}

// Strategy #37: Captain's Iron Rule
function checkCaptainsIronRule(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHTFPureDown = breakdown.htf.down >= 1 && breakdown.htf.up === 0;
  const isSMCNeutral = breakdown.smc.up === breakdown.smc.down;
  const isLiquidityWeak = Math.abs(breakdown.liquidity.up - breakdown.liquidity.down) <= 1;
  const isIndicatorWeak = Math.abs(breakdown.indicator.up - breakdown.indicator.down) <= 1;
  const isRetailMassiveDown = breakdown.retail.down >= 20;
  if (isHTFPureDown && isSMCNeutral && isLiquidityWeak && isIndicatorWeak && isRetailMassiveDown) return { signal: "PUT", logic: "Captain's Iron Rule: HTF dominates when SMC tied, others weak.", confidence: "92%", strategyName: "Captain's Iron Rule", strategyNumber: 37 };
  return null;
}

// Strategy #38: Captain's Enforcement
function checkCaptainsEnforcement(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHTFPureDown = breakdown.htf.down >= 1 && breakdown.htf.up === 0;
  const isSMCLeaningDown = breakdown.smc.down >= 2 && breakdown.smc.up === 1;
  const isIndicatorTied = breakdown.indicator.up === breakdown.indicator.down;
  const isWeakMagnetUp = breakdown.liquidity.up === 1 && breakdown.liquidity.down === 0;
  const isRetailModerateDown = breakdown.retail.down >= 10 && breakdown.retail.down <= 15;
  if (isHTFPureDown && isSMCLeaningDown && isIndicatorTied && isWeakMagnetUp && isRetailModerateDown) return { signal: "PUT", logic: "Captain's Enforcement: HTF 1-0 + SMC 2-1 enforce trend.", confidence: "91%", strategyName: "Captain's Enforcement", strategyNumber: 38 };
  return null;
}

// Strategy #39: Extreme Overload Trap
function checkExtremeOverloadTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCPureUp = breakdown.smc.up >= 3 && breakdown.smc.down === 0;
  const isIndicatorExtremeUp = breakdown.indicator.up >= 9;
  const isRetailCrowdedUp = breakdown.retail.up >= 25 && (breakdown.retail.up > breakdown.retail.down * 4);
  const isNoHTF = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  if (isSMCPureUp && isIndicatorExtremeUp && isRetailCrowdedUp && isNoHTF) return { signal: "PUT", logic: "Extreme Overload Trap: Too perfect setup. No HTF = crowd target.", confidence: "98%", strategyName: "Extreme Overload Trap", strategyNumber: 39 };
  return null;
}

// Strategy #40: Ultra-Massive Payout Trap
function checkUltraMassivePayoutTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isUltraCrowdedDown = breakdown.retail.down >= 30;
  const isHTF_OpposingUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isStrongLiquidityUp = breakdown.liquidity.up >= 4 && (breakdown.liquidity.up > breakdown.liquidity.down);
  const isBearishBaitSet = breakdown.smc.down >= 3 && breakdown.indicator.down >= 6;
  if (isUltraCrowdedDown && isHTF_OpposingUp && isStrongLiquidityUp && isBearishBaitSet) return { signal: "CALL", logic: "Ultra-Massive Payout Trap: 30+ retail used as bait. HTF+Liquidity reverse.", confidence: "99%", strategyName: "Ultra-Massive Payout Trap", strategyNumber: 40 };
  return null;
}

// Strategy #41: Pure SMC Anchor
function checkPureSMCAnchor(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCPureUp = breakdown.smc.up >= 2 && breakdown.smc.down === 0;
  const isWeakOpposition = breakdown.htf.down <= 1 && breakdown.liquidity.down <= 1;
  const isIndicatorModerateDown = breakdown.indicator.down <= 3;
  const isRetailModerateDown = breakdown.retail.down >= 10 && breakdown.retail.down <= 15;
  if (isSMCPureUp && isWeakOpposition && isIndicatorModerateDown && isRetailModerateDown) return { signal: "CALL", logic: "Pure SMC Anchor: 2-0 SMC UP outperformed weak opposition.", confidence: "92%", strategyName: "Pure SMC Anchor", strategyNumber: 41 };
  return null;
}

// Strategy #42: Captain's Authority
function checkCaptainsAuthority(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isMastersTied = (breakdown.smc.up === breakdown.smc.down) && (breakdown.liquidity.up === breakdown.liquidity.down);
  const isHTFPureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isIndicatorWeak = Math.abs(breakdown.indicator.up - breakdown.indicator.down) <= 1;
  const isRetailUp = breakdown.retail.up >= 10;
  if (isMastersTied && isHTFPureUp && isIndicatorWeak && isRetailUp) return { signal: "CALL", logic: "Captain's Authority: HTF leads when masters tied.", confidence: "93%", strategyName: "Captain's Authority", strategyNumber: 42 };
  return null;
}

// Strategy #43: Absolute Alignment
function checkAbsoluteAlignment(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCPureUp = breakdown.smc.up >= 3 && breakdown.smc.down === 0;
  const isHealthyMomentumUp = breakdown.indicator.up >= 6 && breakdown.indicator.down === 0;
  const isLiquidityUp = breakdown.liquidity.up > breakdown.liquidity.down;
  const isNoHTF = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  if (isSMCPureUp && isHealthyMomentumUp && isLiquidityUp && isNoHTF) return { signal: "CALL", logic: "Absolute Alignment: SMC 3-0 + Indicators 6-0. Unstoppable.", confidence: "98%", strategyName: "Absolute Alignment", strategyNumber: 43 };
  return null;
}

// Strategy #44: Ultimate Liquidation Trap
function checkUltimateLiquidationTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isExtremeRetailUp = breakdown.retail.up >= 25;
  const isHTF_PureDown = breakdown.htf.down >= 2 && breakdown.htf.up === 0;
  const isLiquidityPureDown = breakdown.liquidity.down >= 2 && breakdown.liquidity.up === 0;
  const isBullishBaitPresent = breakdown.indicator.up >= 5 && breakdown.smc.up >= 3;
  if (isExtremeRetailUp && isHTF_PureDown && isLiquidityPureDown && isBullishBaitPresent) return { signal: "PUT", logic: "Ultimate Liquidation: HTF 2-0 + Liquidity 2-0 hunt 25+ buyers.", confidence: "98%", strategyName: "Ultimate Liquidation Trap", strategyNumber: 44 };
  return null;
}

// Strategy #45: Captain vs Magnet Rule
function checkCaptainVsMagnet(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHTFPureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isStrongLiquidityDown = breakdown.liquidity.down >= 2 && breakdown.liquidity.up === 0;
  const isSMCTied = breakdown.smc.up === breakdown.smc.down;
  const isIndicatorSlightUp = breakdown.indicator.up > breakdown.indicator.down;
  const isRetailFollowingMagnet = breakdown.retail.down > breakdown.retail.up;
  if (isHTFPureUp && isStrongLiquidityDown && isSMCTied && isIndicatorSlightUp && isRetailFollowingMagnet) return { signal: "CALL", logic: "Captain vs Magnet: HTF + Indicators beat Liquidity magnet.", confidence: "93%", strategyName: "Captain vs Magnet Rule", strategyNumber: 45 };
  return null;
}

// Strategy #46: Institutional Steamroller
function checkInstitutionalSteamroller(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCExtremeUp = breakdown.smc.up >= 4 && breakdown.smc.down === 0;
  const isIndicatorPureUp = breakdown.indicator.up >= 4 && breakdown.indicator.down === 0;
  const isHTFWeakOpp = breakdown.htf.down === 1 && breakdown.htf.up === 0;
  const isLiquidityNeutral = Math.abs(breakdown.liquidity.up - breakdown.liquidity.down) <= 1;
  if (isSMCExtremeUp && isIndicatorPureUp && isHTFWeakOpp && isLiquidityNeutral) return { signal: "CALL", logic: "Institutional Steamroller: SMC 4-0 + Indicators 4-0 unstoppable.", confidence: "97%", strategyName: "Institutional Steamroller", strategyNumber: 46 };
  return null;
}

// Strategy #47: Crowd Momentum Surge
function checkCrowdMomentumSurge(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isMassiveCrowdUp = breakdown.retail.up >= 30;
  const isStrongIndicatorUp = (breakdown.indicator.up >= 4) && (breakdown.indicator.up >= breakdown.indicator.down * 2);
  const isSMCLeaningUp = breakdown.smc.up >= 2 && breakdown.smc.up > breakdown.smc.down;
  const isNoHTF = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  const isLiquidityNeutral = breakdown.liquidity.up === breakdown.liquidity.down;
  if (isMassiveCrowdUp && isStrongIndicatorUp && isSMCLeaningUp && isNoHTF && isLiquidityNeutral) return { signal: "CALL", logic: "Crowd Momentum Surge: 30+ retail + strong indicators carry trend.", confidence: "94%", strategyName: "Crowd Momentum Surge", strategyNumber: 47 };
  return null;
}

// Strategy #48: Triple Master Magnet Trap
function checkTripleMasterMagnetTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isRetailHeavilyDown = breakdown.retail.down >= 20 && breakdown.retail.up <= 2;
  const isLiquidityPureUp = breakdown.liquidity.up >= 3 && breakdown.liquidity.down === 0;
  const isHTFPureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isMastersNotOpposing = breakdown.smc.down <= 1 && breakdown.indicator.down <= 2;
  if (isRetailHeavilyDown && isLiquidityPureUp && isHTFPureUp && isMastersNotOpposing) return { signal: "CALL", logic: "Triple Master Magnet: 20+ sellers trapped. Liquidity 3-0 + HTF pull UP.", confidence: "99%", strategyName: "Triple Master Magnet Trap", strategyNumber: 48 };
  return null;
}

// Strategy #49: Captain's Veto
function checkCaptainsVeto(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHTFPureDown = breakdown.htf.down >= 1 && breakdown.htf.up === 0;
  const isIndicatorDown = breakdown.indicator.down > breakdown.indicator.up;
  const isBullishBaitPresent = breakdown.smc.up >= 2 && breakdown.liquidity.up >= 1;
  const isCrowdWithCaptain = breakdown.retail.down >= 20;
  if (isHTFPureDown && isIndicatorDown && isBullishBaitPresent && isCrowdWithCaptain) return { signal: "PUT", logic: "Captain's Veto: HTF + Indicators override SMC bait.", confidence: "89%", strategyName: "Captain's Veto", strategyNumber: 49 };
  return null;
}

// Strategy #50: Momentum Crush
function checkMomentumCrush(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const bearishTechPower = breakdown.smc.down + breakdown.indicator.down;
  const bullishMasterPower = breakdown.htf.up + breakdown.liquidity.up;
  const isCrowdHeavyDown = breakdown.retail.down >= 20 && breakdown.retail.down < 30;
  if (bearishTechPower > bullishMasterPower && isCrowdHeavyDown && breakdown.htf.up === 1) return { signal: "PUT", logic: "Momentum Crush: Bearish Tech Power > Bullish Master Power.", confidence: "91%", strategyName: "Momentum Crush", strategyNumber: 50 };
  return null;
}

// === STRATEGIES #51-100 (EXTENDED SCENARIOS) ===

// Strategy #51: Masterless Void Trap
function checkMasterlessVoidTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isMasterless = breakdown.smc.up === 0 && breakdown.smc.down === 0 && breakdown.htf.up === 0 && breakdown.htf.down === 0;
  const isIndicatorBaitDown = breakdown.indicator.down >= 4 && breakdown.indicator.up === 0;
  const isRetailHeavilyDown = breakdown.retail.down >= 20;
  const isLiquidityNeutral = breakdown.liquidity.up === breakdown.liquidity.down;
  if (isMasterless && isIndicatorBaitDown && isRetailHeavilyDown && isLiquidityNeutral) return { signal: "CALL", logic: "Masterless Void Trap: No SMC/HTF support. Liquidating 20 sellers.", confidence: "88%", strategyName: "Masterless Void Trap", strategyNumber: 51 };
  return null;
}

// Strategy #52: High-Priority Veto
function checkHighPriorityVetoExt(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isBullishBaitPresent = breakdown.indicator.up >= 4 && breakdown.retail.up >= 20;
  const highPriorityDownCount = breakdown.smc.down + breakdown.htf.down + breakdown.liquidity.down;
  const isHTF_Down = breakdown.htf.down >= 1;
  const isLiquidity_Down = breakdown.liquidity.down >= 2;
  if (isBullishBaitPresent && highPriorityDownCount >= 4 && isHTF_Down && isLiquidity_Down) return { signal: "PUT", logic: "High-Priority Veto: HTF, Liquidity, SMC combined to hunt 22 buyers.", confidence: "95%", strategyName: "High-Priority Veto", strategyNumber: 52 };
  return null;
}

// Strategy #53: Master Anchor Priority
function checkMasterAnchorPriority(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHTFPureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isLiquidityPureUp = breakdown.liquidity.up >= 2 && breakdown.liquidity.down === 0;
  const isBearishBait = breakdown.indicator.down >= 4 && breakdown.smc.down >= 1;
  const isRetailHeavilyDown = breakdown.retail.down >= 20;
  if (isHTFPureUp && isLiquidityPureUp && isBearishBait && isRetailHeavilyDown) return { signal: "CALL", logic: "Master Anchor Priority: Pure HTF+Liquidity defeat bearish indicators.", confidence: "94%", strategyName: "Master Anchor Priority", strategyNumber: 53 };
  return null;
}

// Strategy #54: Exhaustion Reversal
function checkExhaustionReversal(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHTF_StrongDown = breakdown.htf.down >= 2 && breakdown.htf.up === 0;
  const isIndicator_Bearish = breakdown.indicator.down >= 4;
  const isLiquidityTied = breakdown.liquidity.up === breakdown.liquidity.down;
  const isModerateRetailUp = breakdown.retail.up >= 15;
  if (isHTF_StrongDown && isIndicator_Bearish && isLiquidityTied && isModerateRetailUp) return { signal: "CALL", logic: "Exhaustion Reversal: Strong bearish bias failed due to neutral Liquidity.", confidence: "89%", strategyName: "Exhaustion Reversal", strategyNumber: 54 };
  return null;
}

// Strategy #55: Anchorless Momentum Surge
function checkAnchorlessMomentum(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHTFTied = breakdown.htf.up === 1 && breakdown.htf.down === 1;
  const isSMCWeak = (breakdown.smc.up - breakdown.smc.down) <= 1;
  const isLiqWeak = (breakdown.liquidity.up - breakdown.liquidity.down) <= 1;
  const isIndicatorPushDown = breakdown.indicator.down >= 3;
  const isRetailHeavilyDown = breakdown.retail.down >= 20;
  if (isHTFTied && isSMCWeak && isLiqWeak && isIndicatorPushDown && isRetailHeavilyDown) return { signal: "PUT", logic: "Anchorless Momentum: HTF tied, Masters weak. Following indicator momentum.", confidence: "91%", strategyName: "Anchorless Momentum Surge", strategyNumber: 55 };
  return null;
}

// Strategy #56: Extreme Momentum Exhaustion
function checkMomentumExhaustion(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isExtremeIndicatorDown = breakdown.indicator.down >= 5 && breakdown.indicator.up <= 1;
  const isHTFMissing = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  const isLiquidityTied = breakdown.liquidity.up === 1 && breakdown.liquidity.down === 1;
  const isRetailUp = breakdown.retail.up >= 15;
  if (isExtremeIndicatorDown && isHTFMissing && isLiquidityTied && isRetailUp) return { signal: "CALL", logic: "Momentum Exhaustion: Extreme indicators failed. Market pumped to liquidate sellers.", confidence: "87%", strategyName: "Extreme Momentum Exhaustion", strategyNumber: 56 };
  return null;
}

// Strategy #57: Bullish Steamroller Synergy
function checkBullishSteamrollerSynergy(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCPureUp = breakdown.smc.up >= 2 && breakdown.smc.down === 0;
  const isIndicatorPureUp = breakdown.indicator.up >= 6 && breakdown.indicator.down === 0;
  const isNoHTF = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  const isLiquidityWeakOpp = breakdown.liquidity.down <= 2 && breakdown.liquidity.up === 0;
  if (isSMCPureUp && isIndicatorPureUp && isNoHTF && isLiquidityWeakOpp) return { signal: "CALL", logic: "Bullish Steamroller: Pure SMC+Indicators override weak Liquidity.", confidence: "96%", strategyName: "Bullish Steamroller Synergy", strategyNumber: 57 };
  return null;
}

// Strategy #58: Weak Anchor Failure
function checkWeakAnchorFailure(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isWeakBearishMasters = breakdown.htf.down === 1 && breakdown.htf.up === 0 && breakdown.smc.down === 1 && breakdown.smc.up === 0;
  const isLeaningBullish = breakdown.liquidity.up >= 2 && breakdown.indicator.up >= 2;
  const isRetailUp = breakdown.retail.up >= 10;
  if (isWeakBearishMasters && isLeaningBullish && isRetailUp) return { signal: "CALL", logic: "Weak Anchor Failure: 1-pt HTF/SMC too weak to reverse.", confidence: "89%", strategyName: "Weak Anchor Failure", strategyNumber: 58 };
  return null;
}

// Strategy #59: Multi-Master Override
function checkMultiMasterOverride(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHTF_LoneUp = breakdown.htf.up === 1 && breakdown.htf.down === 0;
  const areMastersDown = breakdown.smc.down >= 1 && breakdown.liquidity.down >= 1;
  const isBearishFlow = breakdown.indicator.down > breakdown.indicator.up && breakdown.retail.down >= 15;
  if (isHTF_LoneUp && areMastersDown && isBearishFlow) return { signal: "PUT", logic: "Multi-Master Override: SMC+Liquidity DOWN override lone HTF UP.", confidence: "88%", strategyName: "Multi-Master Override", strategyNumber: 59 };
  return null;
}

// Strategy #60: Double Pure Anchor Sureshot
function checkDoublePureAnchorSureshot(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHTF_PureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isLiq_PureUp = breakdown.liquidity.up >= 2 && breakdown.liquidity.down === 0;
  const isCrowdTrappedDown = breakdown.retail.down >= 20;
  const isIndicatorBaitDown = breakdown.indicator.down >= 4;
  if (isHTF_PureUp && isLiq_PureUp && isCrowdTrappedDown && isIndicatorBaitDown) return { signal: "CALL", logic: "Double Pure Anchor Sureshot: HTF+Liquidity pure UP liquidate 24 sellers.", confidence: "98%", strategyName: "Double Pure Anchor Sureshot", strategyNumber: 60 };
  return null;
}

// Strategy #61: Super-Massive Liquidation Trap
function checkSuperMassiveLiquidation(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isPurelyBearish = breakdown.smc.down >= 3 && breakdown.indicator.down >= 3;
  const isCrowdMassiveDown = breakdown.retail.down >= 25;
  const isNoHTF = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  if (isPurelyBearish && isCrowdMassiveDown && isNoHTF) return { signal: "CALL", logic: "Super-Massive Liquidation: Over-saturated DOWN market. Reversed UP.", confidence: "90%", strategyName: "Super-Massive Liquidation Trap", strategyNumber: 61 };
  return null;
}

// Strategy #62: Pure Master Dominance
function checkPureMasterDominance(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCPureUp = breakdown.smc.up >= 3 && breakdown.smc.down === 0;
  const isHTFPureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isCrowdHeavilyAgainst = breakdown.retail.down >= 20;
  const isSecondaryConflict = (breakdown.liquidity.up === breakdown.liquidity.down) || (Math.abs(breakdown.indicator.up - breakdown.indicator.down) <= 1);
  if (isSMCPureUp && isHTFPureUp && isCrowdHeavilyAgainst && isSecondaryConflict) return { signal: "CALL", logic: "Pure Master Dominance: SMC+HTF purity override to liquidate 20 sellers.", confidence: "95%", strategyName: "Pure Master Dominance", strategyNumber: 62 };
  return null;
}

// Strategy #63: Saturated Seller Trap
function checkSaturatedSellerTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isExtremeBearishPressure = breakdown.smc.down >= 3 && breakdown.indicator.down >= 5;
  const isRetailSaturatedDown = breakdown.retail.down >= 20 && breakdown.retail.up <= 3;
  const isLiquidityUp = breakdown.liquidity.up >= 2;
  const isNoHTF = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  if (isExtremeBearishPressure && isRetailSaturatedDown && isLiquidityUp && isNoHTF) return { signal: "CALL", logic: "Saturated Seller Trap: Reversed UP towards Liquidity magnet.", confidence: "90%", strategyName: "Saturated Seller Trap", strategyNumber: 63 };
  return null;
}

// Strategy #64: Ghost Anchor Trap
function checkGhostAnchorTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isBearishPressure = breakdown.smc.down >= 3 && breakdown.indicator.down >= 4;
  const isRetailCrowdedDown = breakdown.retail.down >= 20;
  const isNeutralLiquidity = breakdown.liquidity.up === 1 && breakdown.liquidity.down === 1;
  const isHTF_Missing = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  if (isBearishPressure && isRetailCrowdedDown && isNeutralLiquidity && isHTF_Missing) return { signal: "CALL", logic: "Ghost Anchor Trap: No HTF support. Liquidating 20 sellers.", confidence: "92%", strategyName: "Ghost Anchor Trap", strategyNumber: 64 };
  return null;
}

// Strategy #65: Perfect Bait Trap
function checkPerfectBaitTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isFullHouseDown = breakdown.smc.down >= 3 && breakdown.htf.down >= 1 && breakdown.liquidity.down >= 1 && breakdown.indicator.down >= 2;
  const isRetailHeavilyDown = breakdown.retail.down >= 18;
  const isZeroOpposition = breakdown.smc.up === 0 && breakdown.htf.up === 0 && breakdown.liquidity.up === 0;
  if (isFullHouseDown && isRetailHeavilyDown && isZeroOpposition) return { signal: "CALL", logic: "Perfect Bait Trap: Too perfect DOWN. Reversed to hunt 18 sellers.", confidence: "93%", strategyName: "Perfect Bait Trap", strategyNumber: 65 };
  return null;
}

// Strategy #66: Institutional Steamroller Extended
function checkInstitutionalSteamrollerExtended(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isAbsoluteMomentumDown = breakdown.indicator.down >= 6 && breakdown.indicator.up === 0;
  const isSteamrollerCrowd = breakdown.retail.down >= 30;
  const isSMC_Supporting = breakdown.smc.down >= 2;
  const isOppositionWeak = breakdown.htf.up <= 1;
  if (isAbsoluteMomentumDown && isSteamrollerCrowd && isSMC_Supporting && isOppositionWeak) return { signal: "PUT", logic: "Institutional Steamroller: 6-0 Momentum + 32 sellers unstoppable.", confidence: "94%", strategyName: "Institutional Steamroller Extended", strategyNumber: 66 };
  return null;
}

// Strategy #67: Crowd Overload Trap
function checkCrowdOverloadTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isCrowdSaturatedUp = breakdown.retail.up >= 30;
  const isIndicatorWeak = Math.abs(breakdown.indicator.up - breakdown.indicator.down) <= 1;
  const isSMC_Opposing = breakdown.smc.down >= 1 && breakdown.smc.up === 0;
  const hasHighPrioritySupport = breakdown.htf.up >= 1 && breakdown.liquidity.up >= 1;
  if (isCrowdSaturatedUp && isIndicatorWeak && isSMC_Opposing && hasHighPrioritySupport) return { signal: "PUT", logic: "Crowd Overload Trap: 30 buyers liquidated despite support.", confidence: "92%", strategyName: "Crowd Overload Trap", strategyNumber: 67 };
  return null;
}

// Strategy #68: Captain's Synergy
function checkCaptainsSynergyExt(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHTF_PureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isIndicatorHealthyUp = breakdown.indicator.up >= 3 && breakdown.indicator.down <= 1;
  const noSMCOpposition = breakdown.smc.down < 2;
  const isRetailHighButSafe = breakdown.retail.up >= 20 && breakdown.retail.up < 30;
  if (isHTF_PureUp && isIndicatorHealthyUp && noSMCOpposition && isRetailHighButSafe) return { signal: "CALL", logic: "Captain's Synergy: HTF+Indicators clear path for 25 buyers.", confidence: "91%", strategyName: "Captain's Synergy", strategyNumber: 68 };
  return null;
}

// Strategy #69: Master-Magnet Purity
function checkMasterMagnetPurity(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCPureUp = breakdown.smc.up >= 1 && breakdown.smc.down === 0;
  const isLiqPureUp = breakdown.liquidity.up >= 1 && breakdown.liquidity.down === 0;
  const isHTFLoneDown = breakdown.htf.down >= 1 && breakdown.htf.up === 0;
  const isCrowdFollowingHTF = breakdown.retail.down >= 15;
  if (isSMCPureUp && isLiqPureUp && isHTFLoneDown && isCrowdFollowingHTF) return { signal: "CALL", logic: "Master-Magnet Purity: SMC+Liquidity override lone HTF to hunt 18 sellers.", confidence: "90%", strategyName: "Master-Magnet Purity", strategyNumber: 69 };
  return null;
}

// Strategy #70: Magnet Overrule
function checkMagnetOverrule(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isPureMagnetUp = breakdown.liquidity.up >= 2 && breakdown.liquidity.down === 0;
  const isWeakMasterOpp = breakdown.smc.down === 1 && breakdown.htf.down === 1;
  const isIndicatorSupportUp = breakdown.indicator.up > breakdown.indicator.down;
  const isRetailUp = breakdown.retail.up >= 20;
  if (isPureMagnetUp && isWeakMasterOpp && isIndicatorSupportUp && isRetailUp) return { signal: "CALL", logic: "Magnet Overrule: Pure Liquidity+Indicators override weak SMC/HTF.", confidence: "90%", strategyName: "Magnet Overrule", strategyNumber: 70 };
  return null;
}

// Strategy #71: Ultimate SMC Veto
function checkSMCMasterVetoExt(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isBullishSynergy = breakdown.htf.up >= 1 && breakdown.liquidity.up >= 3 && breakdown.indicator.up >= 3;
  const isSMCMasterVeto = breakdown.smc.down >= 3 && breakdown.smc.up === 0;
  const isCrowdTrappedUp = breakdown.retail.up >= 20;
  if (isBullishSynergy && isSMCMasterVeto && isCrowdTrappedUp) return { signal: "PUT", logic: "Ultimate SMC Veto: 3-0 SMC overrode 7-pt bullish setup.", confidence: "96%", strategyName: "Ultimate SMC Veto", strategyNumber: 71 };
  return null;
}

// Strategy #72: Weak Anchor Liquidation
function checkWeakAnchorLiquidation(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isMomentumUp = breakdown.indicator.up >= 4;
  const isWeakBearishMasters = breakdown.smc.down === 1 && breakdown.htf.down === 1;
  const isLiquidityTied = breakdown.liquidity.up === 1 && breakdown.liquidity.down === 1;
  const isRetailLeaningDown = (breakdown.retail.down / (breakdown.retail.up || 1)) >= 3;
  if (isMomentumUp && isWeakBearishMasters && isLiquidityTied && isRetailLeaningDown) return { signal: "CALL", logic: "Weak Anchor Liquidation: 4-1 Indicators override weak anchors.", confidence: "88%", strategyName: "Weak Anchor Liquidation", strategyNumber: 72 };
  return null;
}

// Strategy #73: Decoy Master Trap
function checkDecoyMasterTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isPureInstitutionalUp = breakdown.smc.up >= 2 && breakdown.smc.down === 0 && breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isEngineDeadlocked = breakdown.indicator.up === 3 && breakdown.indicator.down === 3;
  const isRetailLeaningDown = (breakdown.retail.down / (breakdown.retail.up || 1)) >= 2;
  if (isPureInstitutionalUp && isEngineDeadlocked && isRetailLeaningDown) return { signal: "PUT", logic: "Decoy Master Trap: Pure masters failed. Engine deadlocked.", confidence: "87%", strategyName: "Decoy Master Trap", strategyNumber: 73 };
  return null;
}

// Strategy #74: Blind Crowd Liquidation
function checkBlindCrowdLiquidation(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCMissing = breakdown.smc.up === 0 && breakdown.smc.down === 0;
  const isRetailHeavilyUp = breakdown.retail.up >= 20;
  const isAntiCrowdAnchors = breakdown.htf.down >= 1 && breakdown.liquidity.down >= 2;
  const isEngineWeak = Math.abs(breakdown.indicator.up - breakdown.indicator.down) <= 1;
  if (isSMCMissing && isRetailHeavilyUp && isAntiCrowdAnchors && isEngineWeak) return { signal: "PUT", logic: "Blind Crowd Liquidation: No SMC. HTF/Liquidity hunt 21 buyers.", confidence: "90%", strategyName: "Blind Crowd Liquidation", strategyNumber: 74 };
  return null;
}

// Strategy #75: Crowd Saturation Veto
function checkCrowdSaturationVeto(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const hasMagnetUp = breakdown.liquidity.up >= 2 && breakdown.liquidity.down === 0;
  const isCrowdHeavyUp = breakdown.retail.up >= 20;
  const areMastersAlignedDown = breakdown.smc.down >= 1 && breakdown.htf.down >= 1;
  const isEngineWeak = Math.abs(breakdown.indicator.up - breakdown.indicator.down) <= 1;
  if (hasMagnetUp && isCrowdHeavyUp && areMastersAlignedDown && isEngineWeak) return { signal: "PUT", logic: "Crowd Saturation Veto: 23 buyers liquidated by masters.", confidence: "89%", strategyName: "Crowd Saturation Veto", strategyNumber: 75 };
  return null;
}

// Strategy #76: Synchronized Bubble Pop
function checkSynchronizedBubblePop(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHTF_PureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isEngineStrongUp = breakdown.indicator.up >= 4;
  const isLiquidityLeaningUp = breakdown.liquidity.up > breakdown.liquidity.down;
  const isCrowdMassiveUp = breakdown.retail.up >= 20;
  const isSMCOpposingWeakly = breakdown.smc.down === 1 && breakdown.smc.up === 0;
  if (isHTF_PureUp && isEngineStrongUp && isLiquidityLeaningUp && isCrowdMassiveUp && isSMCOpposingWeakly) return { signal: "PUT", logic: "Synchronized Bubble Pop: Lone SMC popped the 21-buyer bubble.", confidence: "94%", strategyName: "Synchronized Bubble Pop", strategyNumber: 76 };
  return null;
}

// Strategy #77: Captain-Magnet Lockdown
function checkCaptainMagnetLockdown(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isCaptainPureDown = breakdown.htf.down >= 1 && breakdown.htf.up === 0;
  const isMagnetStrongDown = breakdown.liquidity.down >= 3;
  const isBaitActive = breakdown.indicator.up >= 4 && breakdown.retail.up >= 20;
  if (isCaptainPureDown && isMagnetStrongDown && isBaitActive) return { signal: "PUT", logic: "Captain-Magnet Lockdown: HTF+Liquidity override 4-0 indicator bait.", confidence: "95%", strategyName: "Captain-Magnet Lockdown", strategyNumber: 77 };
  return null;
}

// Strategy #78: Magnetized Liquidation
function checkMagnetizedLiquidation(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isMagnetPureDown = breakdown.liquidity.down >= 3 && breakdown.liquidity.up === 0;
  const isHTF_PureDown = breakdown.htf.down >= 1 && breakdown.htf.up === 0;
  const isBaitActive = breakdown.indicator.up >= 3 && breakdown.retail.up >= 25;
  if (isMagnetPureDown && isHTF_PureDown && isBaitActive) return { signal: "PUT", logic: "Magnetized Liquidation: 3-0 Liquidity+HTF override 3-0 indicator bait.", confidence: "97%", strategyName: "Magnetized Liquidation", strategyNumber: 78 };
  return null;
}

// Strategy #79: Lone Anchor Defeat
function checkLoneAnchorDefeat(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isDeadlocked = (breakdown.liquidity.up === breakdown.liquidity.down) && (breakdown.indicator.up === breakdown.indicator.down);
  const isSMCPureUp = breakdown.smc.up > breakdown.smc.down;
  const isHTFLoneDown = breakdown.htf.down === 1 && breakdown.htf.up === 0;
  const isModerateCrowdUp = breakdown.retail.up >= 15 && breakdown.retail.up < 20;
  if (isDeadlocked && isSMCPureUp && isHTFLoneDown && isModerateCrowdUp) return { signal: "CALL", logic: "Lone Anchor Defeat: SMC broke deadlock, defeating lone HTF.", confidence: "86%", strategyName: "Lone Anchor Defeat", strategyNumber: 79 };
  return null;
}

// Strategy #80: Engine Overheat Reversal
function checkEngineOverheatReversal(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isEngineOverheatedUp = breakdown.indicator.up >= 5;
  const isCaptainDown = breakdown.htf.down >= 1 && breakdown.htf.up === 0;
  const isMagnetDown = breakdown.liquidity.down > breakdown.liquidity.up;
  const isSMC_BullishBait = breakdown.smc.up >= 1 && breakdown.smc.down === 0;
  if (isEngineOverheatedUp && isCaptainDown && isMagnetDown && isSMC_BullishBait) return { signal: "PUT", logic: "Engine Overheat Reversal: 5-1 Indicators as bait. HTF+Magnet pull DOWN.", confidence: "91%", strategyName: "Engine Overheat Reversal", strategyNumber: 80 };
  return null;
}

// Strategy #81: Absolute Magnet Ascension
function checkAbsoluteMagnetAscension(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isMagnetSupremeUp = breakdown.liquidity.up >= 4 && breakdown.liquidity.down === 0;
  const isHTF_Missing = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  const isEngineNeutral = breakdown.indicator.up === breakdown.indicator.down;
  if (isMagnetSupremeUp && isHTF_Missing && isEngineNeutral) return { signal: "CALL", logic: "Absolute Magnet Ascension: 4-0 Liquidity dictates in HTF absence.", confidence: "95%", strategyName: "Absolute Magnet Ascension", strategyNumber: 81 };
  return null;
}

// Strategy #82: Crowd Overload Reversal
// STRICT REQUIREMENTS: HTF must be bearish (down >= 1 AND up === 0), SMC bearish (down > up), Liquidity bearish (down >= 1), Indicators bullish (up >= 3 AND up > down)
function checkCrowdOverloadReversal(breakdown: ScenarioBreakdown): ScenarioResult | null {
  // Strict HTF check: MUST be pure bearish (at least 1 down, NO bullish)
  const isHTFBearishPure = breakdown.htf.down >= 1 && breakdown.htf.up === 0;
  // SMC must be bearish dominant
  const isSMCBearish = breakdown.smc.down > breakdown.smc.up && breakdown.smc.down >= 1;
  // Liquidity must support bearish direction
  const isLiquidityBearish = breakdown.liquidity.down >= 1;
  // Indicator opposition: must be clearly bullish (>= 3 bullish AND bullish > bearish)
  const isIndicatorBullish = breakdown.indicator.up >= 3 && breakdown.indicator.up > breakdown.indicator.down;
  // Retail must be heavily bearish (trapped sellers)
  const isRetailSaturatedDown = breakdown.retail.down >= 15;
  
  // ALL conditions must be met - no partial matches
  if (isHTFBearishPure && isSMCBearish && isLiquidityBearish && isIndicatorBullish && isRetailSaturatedDown) {
    return { 
      signal: "CALL", 
      logic: `Crowd Overload Reversal: ${breakdown.retail.down} sellers trapped by pure 0-${breakdown.htf.down} HTF. Followed ${breakdown.indicator.up}-${breakdown.indicator.down} indicators UP.`, 
      confidence: "92%", 
      strategyName: "Crowd Overload Reversal", 
      strategyNumber: 82 
    };
  }
  return null;
}

// Strategy #83: Deadlock Sentiment Break
function checkDeadlockSentimentBreak(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isDoubleDeadlock = (breakdown.liquidity.up === breakdown.liquidity.down) && (breakdown.indicator.up === breakdown.indicator.down);
  const isWeakOpposition = breakdown.smc.down === 1 && breakdown.htf.down === 1;
  const isModerateBullishCrowd = breakdown.retail.up >= 15 && breakdown.retail.up < 20;
  if (isDoubleDeadlock && isWeakOpposition && isModerateBullishCrowd) return { signal: "CALL", logic: "Deadlock Sentiment Break: Weak 1-pt anchors failed vs 15 buyers.", confidence: "85%", strategyName: "Deadlock Sentiment Break", strategyNumber: 83 };
  return null;
}

// Strategy #84: Lone Captain's Revenge
function checkLoneCaptainReversal(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHeavyBearishPressure = breakdown.indicator.down >= 4 && breakdown.smc.down >= 2;
  const isCrowdSaturatedDown = breakdown.retail.down >= 20 && breakdown.retail.down < 30;
  const isLoneBullishCaptain = breakdown.htf.up === 1 && breakdown.htf.down === 0;
  const isLiquidityNeutral = Math.abs(breakdown.liquidity.up - breakdown.liquidity.down) <= 1;
  if (isHeavyBearishPressure && isCrowdSaturatedDown && isLoneBullishCaptain && isLiquidityNeutral) return { signal: "CALL", logic: "Lone Captain's Revenge: Pure 1-0 HTF overrode 4-0 indicators.", confidence: "93%", strategyName: "Lone Captain's Revenge", strategyNumber: 84 };
  return null;
}

// Strategy #85: Master-Engine Execution
function checkMasterEngineExecution(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isInstitutionalFlowDown = breakdown.smc.down >= 2 && breakdown.indicator.down >= 3;
  const isRetailSafeVolume = breakdown.retail.up < 20;
  const isLoneHTFOpposition = breakdown.htf.up === 1 && breakdown.htf.down === 0;
  if (isInstitutionalFlowDown && isRetailSafeVolume && isLoneHTFOpposition) return { signal: "PUT", logic: "Master-Engine Execution: SMC+Indicators overpower lone HTF.", confidence: "92%", strategyName: "Master-Engine Execution", strategyNumber: 85 };
  return null;
}

// Strategy #86: Perfection Paradox
function checkPerfectionParadox(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isTooPerfectUp = breakdown.htf.up >= 1 && breakdown.liquidity.up >= 2 && breakdown.indicator.up >= 3;
  const isCrowdSaturatedUp = breakdown.retail.up >= 15;
  const isSMCOpposingLone = breakdown.smc.down === 1 && breakdown.smc.up === 0;
  if (isTooPerfectUp && isCrowdSaturatedUp && isSMCOpposingLone) return { signal: "PUT", logic: "Perfection Paradox: Lone SMC triggered liquidation of 18 buyers.", confidence: "93%", strategyName: "Perfection Paradox", strategyNumber: 86 };
  return null;
}

// Strategy #87: Absolute Zero Steamroller
function checkAbsoluteZeroSteamroller(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isAbsoluteEngineDown = breakdown.indicator.down >= 6 && breakdown.indicator.up === 0;
  const isAbsoluteSMCDown = breakdown.smc.down >= 3 && breakdown.smc.up === 0;
  const isCrowdHeavyDown = breakdown.retail.down >= 20;
  const isWeakHTFOpposition = breakdown.htf.up === 1 && breakdown.liquidity.up === 1;
  if (isAbsoluteEngineDown && isAbsoluteSMCDown && isCrowdHeavyDown && isWeakHTFOpposition) return { signal: "PUT", logic: "Absolute Zero Steamroller: 9-pt landslide crushed lone HTF.", confidence: "98%", strategyName: "Absolute Zero Steamroller", strategyNumber: 87 };
  return null;
}

// Strategy #88: Engine Supremacy (6-0 Rule)
function checkEngineSupremacy(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isEngineExtremeDown = breakdown.indicator.down >= 6 && breakdown.indicator.up === 0;
  const isCrowdHeavyDown = breakdown.retail.down >= 25;
  const isSMC_Supporting = breakdown.smc.down >= 2;
  const hasStrongUpAnchors = breakdown.htf.up >= 1 && breakdown.liquidity.up >= 3;
  if (isEngineExtremeDown && isCrowdHeavyDown && isSMC_Supporting && hasStrongUpAnchors) return { signal: "PUT", logic: "Engine Supremacy: 6-0 Momentum too high for 3-1 Liquidity.", confidence: "96%", strategyName: "Engine Supremacy (6-0 Rule)", strategyNumber: 88 };
  return null;
}

// Strategy #89: Master's Sole Authority
function checkMasterSoleAuthority(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isDoubleDeadlock = (breakdown.indicator.up === breakdown.indicator.down) && (breakdown.liquidity.up === breakdown.liquidity.down);
  const isHTF_Missing = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  const isSMCPureUp = breakdown.smc.up >= 2 && breakdown.smc.down === 0;
  const isCrowdHeavyDown = breakdown.retail.down >= 25;
  if (isDoubleDeadlock && isHTF_Missing && isSMCPureUp && isCrowdHeavyDown) return { signal: "CALL", logic: "Master's Sole Authority: 2-0 SMC became absolute decider.", confidence: "94%", strategyName: "Master's Sole Authority", strategyNumber: 89 };
  return null;
}

// Strategy #90: Triple-Threat Overdrive
function checkTripleThreatOverdrive(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const bullForce = breakdown.htf.up + breakdown.liquidity.up + breakdown.indicator.up;
  const isBullishSynergySupreme = breakdown.htf.up >= 2 && bullForce >= 10;
  const isSMCOppositionWeak = breakdown.smc.down <= 2 && breakdown.smc.up === 0;
  const isRetailSafe = breakdown.retail.up < 20;
  if (isBullishSynergySupreme && isSMCOppositionWeak && isRetailSafe) return { signal: "CALL", logic: "Triple-Threat Overdrive: 11 pts crushed 2-pt SMC resistance.", confidence: "95%", strategyName: "Triple-Threat Overdrive", strategyNumber: 90 };
  return null;
}

// Strategy #91: Supreme Institutional Shield
function checkInstitutionalShield(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCPureSupremeUp = breakdown.smc.up >= 3 && breakdown.smc.down === 0;
  const isHTF_PureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isIndicatorBaitingDown = breakdown.indicator.down > breakdown.indicator.up;
  const isLiquidityNeutral = breakdown.liquidity.up === breakdown.liquidity.down;
  if (isSMCPureSupremeUp && isHTF_PureUp && isIndicatorBaitingDown && isLiquidityNeutral) return { signal: "CALL", logic: "Supreme Institutional Shield: 3-0 SMC + 1-0 HTF floor trapped sellers.", confidence: "96%", strategyName: "Supreme Institutional Shield", strategyNumber: 91 };
  return null;
}

// Strategy #92: Master Veto Rule (Captainless)
function checkMasterVetoCaptainless(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCPureSupremeDown = breakdown.smc.down >= 3 && breakdown.smc.up === 0;
  const isHTF_Missing = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  const isBullishWeak = breakdown.indicator.up > breakdown.indicator.down && breakdown.liquidity.up > breakdown.liquidity.down;
  const isCrowdTrappedUp = breakdown.retail.up >= 15 && breakdown.retail.up < 20;
  if (isSMCPureSupremeDown && isHTF_Missing && isBullishWeak && isCrowdTrappedUp) return { signal: "PUT", logic: "Master Veto Rule: 0-3 SMC overrode weak bullish signals.", confidence: "94%", strategyName: "Master Veto Rule (Captainless)", strategyNumber: 92 };
  return null;
}

// Strategy #93: Masterless Magnet Trap
function checkMasterlessMagnetTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isPureMagnetUp = breakdown.liquidity.up >= 2 && breakdown.liquidity.down === 0;
  const isCrowdTrappedDown = breakdown.retail.down >= 15 && breakdown.retail.down <= 20;
  const isHTF_Missing = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  const isSMCTied = breakdown.smc.up === breakdown.smc.down;
  if (isPureMagnetUp && isCrowdTrappedDown && isHTF_Missing && isSMCTied) return { signal: "CALL", logic: "Masterless Magnet Trap: 2-0 Liquidity liquidated 19 sellers.", confidence: "91%", strategyName: "Masterless Magnet Trap", strategyNumber: 93 };
  return null;
}

// Strategy #94: Absolute Veto Steamroller
function checkAbsoluteVetoSteamroller(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCSupremeDown = breakdown.smc.down >= 3 && breakdown.smc.up === 0;
  const isEngineSupportingDown = breakdown.indicator.down >= 3;
  const isOppositeWeak = breakdown.htf.up === 1 && breakdown.liquidity.up === 1;
  const isRetailFollowZone = breakdown.retail.down >= 15 && breakdown.retail.down < 20;
  if (isSMCSupremeDown && isEngineSupportingDown && isOppositeWeak && isRetailFollowZone) return { signal: "PUT", logic: "Absolute Veto Steamroller: 3-0 SMC + 3-1 Indicators crushed 1-pt anchors.", confidence: "94%", strategyName: "Absolute Veto Steamroller", strategyNumber: 94 };
  return null;
}

// Strategy #95: Deadlocked Master Trap
function checkDeadlockedMasterTrap(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isSMCPureSupremeDown = breakdown.smc.down >= 3 && breakdown.smc.up === 0;
  const isEngineDeadlocked = breakdown.indicator.up === breakdown.indicator.down;
  const isHTF_Missing = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  const isCrowdAlignedDown = breakdown.retail.down >= 15 && breakdown.retail.down < 20;
  if (isSMCPureSupremeDown && isEngineDeadlocked && isHTF_Missing && isCrowdAlignedDown) return { signal: "CALL", logic: "Deadlocked Master Trap: 3-0 SMC failed. Engine deadlocked.", confidence: "89%", strategyName: "Deadlocked Master Trap", strategyNumber: 95 };
  return null;
}

// Strategy #96: Triple-Anchor Alliance
function checkTripleAnchorAlliance(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHTFUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isSMCUp = breakdown.smc.up > breakdown.smc.down;
  const isLiquidityUp = breakdown.liquidity.up > breakdown.liquidity.down;
  const isIndicatorBaitDown = breakdown.indicator.down >= 5;
  const isCrowdTrappedDown = breakdown.retail.down >= 15 && breakdown.retail.down <= 20;
  if (isHTFUp && isSMCUp && isLiquidityUp && isIndicatorBaitDown && isCrowdTrappedDown) return { signal: "CALL", logic: "Triple-Anchor Alliance: HTF+SMC+Liquidity overrode 5-2 indicator bait.", confidence: "93%", strategyName: "Triple-Anchor Alliance", strategyNumber: 96 };
  return null;
}

// Strategy #97: Broker's Buffet
function checkBrokersBuffet(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isCrowdMassiveDown = breakdown.retail.down >= 20;
  const isMasterLeaningDown = breakdown.smc.down >= 3;
  const isHTFPureUp = breakdown.htf.up >= 1 && breakdown.htf.down === 0;
  const isLiquidityPureUp = breakdown.liquidity.up >= 2 && breakdown.liquidity.down === 0;
  const isEngineUp = breakdown.indicator.up > breakdown.indicator.down;
  if (isCrowdMassiveDown && isMasterLeaningDown && isHTFPureUp && isLiquidityPureUp && isEngineUp) return { signal: "CALL", logic: "Broker's Buffet: HTF+Liquidity pulled UP to liquidate 22 sellers.", confidence: "94%", strategyName: "Broker's Buffet", strategyNumber: 97 };
  return null;
}

// Strategy #98: Captainless Momentum Flush
function checkCaptainlessMomentum(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isHTF_Missing = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  const isSMC_WeakUp = (breakdown.smc.up - breakdown.smc.down) === 1;
  const isIndicator_WeakUp = (breakdown.indicator.up - breakdown.indicator.down) === 1;
  const isCrowdStrongDown = breakdown.retail.down >= 20;
  const isLiquidityDown = breakdown.liquidity.down > breakdown.liquidity.up;
  if (isHTF_Missing && isSMC_WeakUp && isIndicator_WeakUp && isCrowdStrongDown && isLiquidityDown) return { signal: "PUT", logic: "Captainless Momentum Flush: 20 sellers won. Weak bulls, no HTF.", confidence: "88%", strategyName: "Captainless Momentum Flush", strategyNumber: 98 };
  return null;
}

// Strategy #99: Safe Volume Breakthrough
function checkSafeVolumeBreakthrough(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isMarketAnchorless = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  const isLiquidityTied = breakdown.liquidity.up === breakdown.liquidity.down;
  const isOppositionWeak = breakdown.smc.down <= 1 && breakdown.indicator.down <= 3;
  const isSafeVolumeUp = breakdown.retail.up >= 12 && breakdown.retail.up <= 15;
  if (isMarketAnchorless && isLiquidityTied && isOppositionWeak && isSafeVolumeUp) return { signal: "CALL", logic: "Safe Volume Breakthrough: 14 buyers won. Anchorless, weak opposition.", confidence: "87%", strategyName: "Safe Volume Breakthrough", strategyNumber: 99 };
  return null;
}

// Strategy #100: Supreme Magnet Dominance (Centennial)
function checkCentennialMagnet(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const isMagnetSupremeUp = breakdown.liquidity.up >= 5;
  const isHTF_Missing = breakdown.htf.up === 0 && breakdown.htf.down === 0;
  const isRetailSafeVolume = breakdown.retail.up < 20;
  const isEngineSupportive = breakdown.indicator.up >= 4;
  const isSMCWeak = breakdown.smc.down <= 2;
  if (isMagnetSupremeUp && isHTF_Missing && isRetailSafeVolume && isEngineSupportive && isSMCWeak) return { signal: "CALL", logic: "Centennial Magnet: 5-2 Liquidity became sole dictator.", confidence: "97%", strategyName: "Supreme Magnet Dominance (Centennial)", strategyNumber: 100 };
  return null;
}

// === MASTER SCENARIO FILTER ===
// Evaluates ALL 100 strategies, picks highest confidence; on tie picks highest strategy number (more specific).
function runScenarioFilter(breakdown: ScenarioBreakdown): ScenarioResult | null {
  const strategies = [
    // 99% Confidence (#1-50)
    checkConsensusSurge, checkUnstoppableAnchor, checkAbsoluteTrendContinuation, checkHTFTrendTrap,
    checkUltraMassivePayoutTrap, checkTripleMasterMagnetTrap,
    // 98% Confidence
    getWhaleSignal, checkHarmonyStrategy, checkExtremistTrap, checkMultiLayerLiquidation,
    checkOvercrowdedInstitutionalTrap, checkTrendAvalanche, checkExtremeOverloadTrap,
    checkAbsoluteAlignment, checkUltimateLiquidationTrap,
    checkDoublePureAnchorSureshot, checkAbsoluteZeroSteamroller, // #60, #87
    // 97% Confidence
    checkBalancedFlow, checkTripleAnchorForce, checkAntiRetailMagnet, checkMomentumThreshold,
    checkInstitutionalSteamroller, checkMagnetizedLiquidation, checkCentennialMagnet, // #78, #100
    // 96% Confidence
    checkMasterVeto, checkLiquidityVacuum, checkCaptainMagnetTrap, checkExtremeCrowdSacrifice,
    checkBullishSteamrollerSynergy, checkSMCMasterVetoExt, checkEngineSupremacy, checkInstitutionalShield, // #57, #71, #88, #91
    // 95% Confidence
    checkWeightedDomination, checkSynergyOverpower, checkOvercrowdedTrap, checkRetailLiquidationSweep,
    checkMomentumOverpower, checkEquilibriumTrap,
    checkHighPriorityVetoExt, checkPureMasterDominance, checkCaptainMagnetLockdown, checkAbsoluteMagnetAscension, checkTripleThreatOverdrive, // #52, #62, #77, #81, #90
    // 94% Confidence
    checkHTFAnchorStrategy, checkLiquidityVeto, checkRetailLiquidityFlush, checkLiquidityVacuumReversal,
    checkCrowdMomentumSurge, checkMasterAnchorPriority, checkInstitutionalSteamrollerExtended,
    checkSynchronizedBubblePop, checkMasterSoleAuthority, checkMasterVetoCaptainless, checkAbsoluteVetoSteamroller, checkBrokersBuffet, // #53, #66, #76, #89, #92, #94, #97
    // 93% Confidence
    getDominationSignal, checkCrowdWashout, checkIndicatorOverload, checkSMCSuperiority,
    checkCaptainsAuthority, checkCaptainVsMagnet, checkPerfectBaitTrap, checkLoneCaptainReversal, checkPerfectionParadox, checkTripleAnchorAlliance, // #65, #84, #86, #96
    // 92% Confidence
    checkAnchorMagnetStrategy, checkHTFSupremacy, checkCaptainsIronRule, checkPureSMCAnchor,
    checkGhostAnchorTrap, checkCrowdOverloadTrap, checkCrowdOverloadReversal, checkMasterEngineExecution, // #64, #67, #82, #85
    // 91% Confidence
    checkCrowdMomentumSweep, checkCaptainsEnforcement, checkMomentumCrush,
    checkAnchorlessMomentum, checkCaptainsSynergyExt, checkEngineOverheatReversal, checkMasterlessMagnetTrap, // #55, #68, #80, #93
    // 90% Confidence
    checkOverloadedTrendCompletion, checkSuperMassiveLiquidation, checkSaturatedSellerTrap,
    checkMasterMagnetPurity, checkMagnetOverrule, checkBlindCrowdLiquidation, // #61, #63, #69, #70, #74
    // 89% Confidence
    checkCaptainsVeto, checkExhaustionReversal, checkWeakAnchorFailure, checkCrowdSaturationVeto, checkDeadlockedMasterTrap, // #54, #58, #75, #95
    // 88% Confidence
    checkMasterlessVoidTrap, checkMultiMasterOverride, checkWeakAnchorLiquidation, checkCaptainlessMomentum, // #51, #59, #72, #98
    // 87% Confidence
    checkMomentumExhaustion, checkDecoyMasterTrap, checkSafeVolumeBreakthrough, // #56, #73, #99
    // 86% Confidence
    checkLoneAnchorDefeat, // #79
    // 85% Confidence
    checkDeadlockSentimentBreak // #83
  ];

  // Collect ALL matches (do not short-circuit on first match)
  const matches: ScenarioResult[] = [];
  for (const strategy of strategies) {
    const result = strategy(breakdown);
    if (result) {
      matches.push(result);
    }
  }

  if (matches.length === 0) {
    return null;
  }

  // SINGLE MATCH: Return directly without extra processing
  if (matches.length === 1) {
    const winner = matches[0];
    console.log(`[SCENARIO FILTER] Single match: #${winner.strategyNumber} "${winner.strategyName}" (${winner.confidence})`);
    return winner;
  }

  // MULTIPLE MATCHES: Pick highest confidence, on tie pick highest strategy number (more specific)
  matches.sort((a, b) => {
    const confA = parseInt(a.confidence);
    const confB = parseInt(b.confidence);
    if (confB !== confA) return confB - confA; // higher confidence first
    return b.strategyNumber - a.strategyNumber; // higher number (more specific) first
  });

  const winner = matches[0];
  console.log(`[SCENARIO FILTER] ${matches.length} strategies matched. Winner: #${winner.strategyNumber} "${winner.strategyName}" (${winner.confidence})`);
  console.log(`[SCENARIO FILTER] Other matches: ${matches.slice(1).map(m => `#${m.strategyNumber} (${m.confidence})`).join(', ')}`);
  return winner;
}

// ============= CONFLICT DETECTION TYPES =============
interface CategoryBreakdown {
  name: string;
  callCount: number;
  putCount: number;
  callScore: number;
  putScore: number;
  hasConflict: boolean;
  conflictingSetups: string[];
}

interface ConflictAnalysis {
  hasInternalConflict: boolean;
  conflictPenalty: number;
  hiddenTrapWarning: boolean;
  highRisk: boolean;
  conflictDetails: CategoryBreakdown[];
  opposingSetups: string[];
  scenarioUsed?: ScenarioResult | null;
}

// Helper to extract direction from factor strings
function extractDirectionFromFactor(factor: string): 'CALL' | 'PUT' | null {
  const upperFactor = factor.toUpperCase();
  if (upperFactor.includes('BULLISH') || upperFactor.includes('CALL') || upperFactor.includes('BUY') || upperFactor.includes('LONG')) {
    return 'CALL';
  }
  if (upperFactor.includes('BEARISH') || upperFactor.includes('PUT') || upperFactor.includes('SELL') || upperFactor.includes('SHORT')) {
    return 'PUT';
  }
  return null;
}

function generateCodeBasedSignal(
  marketData: ReturnType<typeof buildMarketDataForAI>,
  marketDataH1: ReturnType<typeof buildMarketDataForAI> | null,
  marketDataM15: ReturnType<typeof buildMarketDataForAI> | null,
  marketDataM5: ReturnType<typeof buildMarketDataForAI> | null,
  market: string,
  backtestResults: { call: { winRate: number; totalTests: number; wins: number; losses: number; avgPips: number }; put: { winRate: number; totalTests: number; wins: number; losses: number; avgPips: number }; recommendation: string } | null,
  selfCorrectionInsights: string | null
) {
  console.log('[CODE-BASED-SIGNAL] Starting 11-category scoring analysis with AVOID RULES VALIDATION + 4-PILLAR TREND ENGINE...');
  
  // ============= RESET BLOCKED STRATEGIES TRACKER =============
  resetBlockedStrategies();
  
  // ============= BUILD MARKET CONDITIONS FOR AVOID RULE VALIDATION =============
  const currentTime = new Date();
  const marketConditions = buildMarketConditionsForAvoidRules(marketData, currentTime);
  
  // ============= 4-PILLAR TREND DETECTION ENGINE v3 =============
  const raw = (marketData as any).raw as { opens: number[]; highs: number[]; lows: number[]; closes: number[]; volumes: number[] } | undefined;
  let trendResult: TrendResult | null = null;
  
  if (raw && raw.closes.length >= 50) {
    const trendCandles: CandleForTrend[] = [];
    for (let i = 0; i < raw.closes.length; i++) {
      trendCandles.push({ open: raw.opens[i], high: raw.highs[i], low: raw.lows[i], close: raw.closes[i] });
    }
    trendResult = determineTrend(marketConditions, trendCandles);
    console.log(`[4-PILLAR] Trend: ${trendResult.trendName} | Pillar: ${trendResult.pillar.name} | Confidence: ${trendResult.confidence}%`);
    console.log(`[4-PILLAR] Reasons: ${trendResult.reasons.slice(-3).join(' | ')}`);
  } else {
    console.log('[4-PILLAR] Insufficient candle data for trend detection, using default RANGING');
    trendResult = { pillar: PILLAR_RANGING, trendName: 'RANGING', confidence: 40, reasons: ['Insufficient data'] };
  }
  
  // ============= AI AUTHORITY MODE: PILLAR FOLLOWS AI DIRECTION =============
  // Step 1: Score both directions freely (no pillar enforcement yet)
  // Step 2: After winner determined, FORCE pillar to match AI direction
  // Step 3: Only fire if confidence > 50%
  
  // Initial pillar detection (informational — will be overridden after scoring)
  const initialPillarDirection: 'CALL' | 'PUT' | null =
    trendResult.pillar === PILLAR_UPTREND ? 'CALL' :
    trendResult.pillar === PILLAR_DOWNTREND ? 'PUT' :
    null;
  
  console.log(`[AI AUTHORITY MODE] Initial Pillar: ${trendResult.trendName} | Will be overridden by AI direction after scoring`);
  
  // ============= BUILD INITIAL PILLAR GATE (no direction lock — both directions scored freely) =============
  const pillarGate = buildPillarAllowedIds(trendResult.pillar, null); // null = no direction enforcement
  console.log(`[AI AUTHORITY MODE] Phase 1: Scoring both directions freely (no pillar lock)`);

  
  // ============= CHECK GLOBAL SALAMI TREND RULE =============
  const salamiCheckCall = checkGlobalSalamiTrend(marketConditions, 'CALL');
  const salamiCheckPut = checkGlobalSalamiTrend(marketConditions, 'PUT');
  
  if (salamiCheckCall.blocked) {
    console.log(`[GLOBAL AVOID] ${salamiCheckCall.reason}`);
    addBlockedStrategy('ALL CALL Reversals', 'Global', salamiCheckCall.reason, 'CALL');
  }
  if (salamiCheckPut.blocked) {
    console.log(`[GLOBAL AVOID] ${salamiCheckPut.reason}`);
    addBlockedStrategy('ALL PUT Reversals', 'Global', salamiCheckPut.reason, 'PUT');
  }
  
  // Calculate scores — BOTH directions analyzed WITHOUT pillar enforcement
  // Pillar gate categorizes but does not block
  let callScore: ReturnType<typeof calculateNew7CategoryScore>;
  let putScore: ReturnType<typeof calculateNew7CategoryScore>;
  
  // Analyze BOTH directions freely
  callScore = calculateNew7CategoryScore(marketData, marketDataH1, marketDataM15, marketDataM5, 'CALL', marketConditions, pillarGate);
  putScore = calculateNew7CategoryScore(marketData, marketDataH1, marketDataM15, marketDataM5, 'PUT', marketConditions, pillarGate);
  
  console.log(`[AI AUTHORITY MODE] CALL score: ${callScore.totalScore.toFixed(2)} | PUT score: ${putScore.totalScore.toFixed(2)}`);
  console.log(`[AI AUTHORITY MODE] Direction will follow higher score. Confidence > 50% required to fire.`);
  
  // ============= 4-PILLAR SCORE BOOST =============
  // Apply pillar-based score boost: if matched setups belong to the detected pillar's rows,
  // boost that direction's score. This links the 235-setup logic to the 4-pillar framework.
  if (trendResult) {
    const pillarSetupIds = getPillarSetupIds(trendResult.pillar);
    
    // Count how many matched setups belong to the active pillar
    const callPillarMatches = (callScore.matchedSetups || []).filter(s => pillarSetupIds.includes(s.id)).length;
    const putPillarMatches = (putScore.matchedSetups || []).filter(s => pillarSetupIds.includes(s.id)).length;
    
    // Boost: Each pillar-aligned setup adds 0.5 to that direction's total score (max 3.0 boost)
    const callPillarBoost = Math.min(callPillarMatches * 0.5, 3.0);
    const putPillarBoost = Math.min(putPillarMatches * 0.5, 3.0);
    
    if (callPillarBoost > 0) {
      callScore.totalScore += callPillarBoost;
      console.log(`[4-PILLAR BOOST] CALL +${callPillarBoost.toFixed(1)} (${callPillarMatches} setups in ${trendResult.trendName} pillar)`);
    }
    if (putPillarBoost > 0) {
      putScore.totalScore += putPillarBoost;
      console.log(`[4-PILLAR BOOST] PUT +${putPillarBoost.toFixed(1)} (${putPillarMatches} setups in ${trendResult.trendName} pillar)`);
    }
    
    // (No penalty needed — incompatible direction was not analyzed at all)
  }
  
  // ============= CATEGORY BREAKDOWN WITH CALL/PUT COUNTS =============
  const categoryBreakdowns: CategoryBreakdown[] = [];
  const highPriorityCategories = ['SMC', 'HTF', 'Liquidity'];
  let totalConflictPenalty = 0;
  let hasHiddenTrap = false;
  const opposingSetups: string[] = [];
  
  // Map category names for comparison - must match exact names from calculateNew7CategoryScore
  const categoryNameMap: { [key: string]: string } = {
    'SMC (18 Setups)': 'SMC',
    'Liquidity (35 OTC Traps)': 'Liquidity',
    '36 Algo-Trap Indicators': 'Indicators',
    '235 Setups': '235 Setups',
    'HTF Analyzing (20 Master Strategies)': 'HTF',
    'Price Action & Algo': 'Price Action',
    'Filter & Rejection': 'Filters',
  };
  
  // Analyze each category for conflicts
  callScore.categories.forEach((callCat, index) => {
    const putCat = putScore.categories[index];
    if (!putCat) return;
    
    const shortName = categoryNameMap[callCat.name] || callCat.name;
    
    // IMPORTANT FIX:
    // Previously we tried to infer direction by parsing text inside factor strings.
    // That is fragile (strings can contain both bullish/bearish words), and it caused
    // scenario strategies (#1-#100) to match even when the visible Category Breakdown
    // did NOT meet their numeric requirements.
    //
    // New rule: counts come from the *directional* category lists themselves:
    // - callCount = number of CALL-side factors
    // - putCount  = number of PUT-side factors
    // Special case: 235 Setups uses matchedSetups counts (directional) as the true
    // retail setup counts.
    let callSetupCount = 0;
    let putSetupCount = 0;

    if (callCat.name.includes('235')) {
      callSetupCount = (callScore.matchedSetups?.length || 0);
      putSetupCount = (putScore.matchedSetups?.length || 0);
    } else {
      callSetupCount = (callCat.factors?.length || 0);
      putSetupCount = (putCat.factors?.length || 0);
    }

    // Build transparency list ONLY when there is a conflict (both sides have activity)
    const conflictingSetups: string[] = [];
    const hasConflict = callSetupCount > 0 && putSetupCount > 0;
    if (hasConflict) {
      for (const f of (callCat.factors || []).slice(0, 50)) conflictingSetups.push(`[CALL] ${f}`);
      for (const f of (putCat.factors || []).slice(0, 50)) conflictingSetups.push(`[PUT] ${f}`);
    }
    
    // Determine if this category has internal conflict
    
    categoryBreakdowns.push({
      name: shortName,
      callCount: callSetupCount,
      putCount: putSetupCount,
      callScore: callCat.score,
      putScore: putCat.score,
      hasConflict,
      conflictingSetups,
    });
    
    // Apply 40% penalty if conflict exists in this category
    if (hasConflict) {
      totalConflictPenalty += 0.4;
      console.log(`[CONFLICT] ${shortName}: ${callSetupCount} CALL / ${putSetupCount} PUT setups - Internal conflict detected`);
    }
  });
  
  // ============= BUILD SCENARIO BREAKDOWN FOR 50 STRATEGIES =============
  // Extract counts for each category to feed into scenario filter
  const smcBreakdown = categoryBreakdowns.find(c => c.name === 'SMC');
  const htfBreakdown = categoryBreakdowns.find(c => c.name === 'HTF');
  const liquidityBreakdown = categoryBreakdowns.find(c => c.name === 'Liquidity');
  const indicatorBreakdown = categoryBreakdowns.find(c => c.name === 'Indicators');
  const retailBreakdown = categoryBreakdowns.find(c => c.name === '235 Setups');
  
  // Retail counts already include matchedSetups (added in the 235 Setups category above)
  // so do NOT add matchedSetups again here (it doubles the retail values and breaks scenario matching).
  const retailCallCount = retailBreakdown?.callCount || 0;
  const retailPutCount = retailBreakdown?.putCount || 0;
  
  // CRITICAL FIX: Use COUNTS (what UI shows) instead of SCORES to ensure scenario matching matches UI display
  // This prevents mismatches where a strategy appears to match visually but the underlying scores differ
  const scenarioBreakdown: ScenarioBreakdown = {
    smc: { up: smcBreakdown?.callCount || 0, down: smcBreakdown?.putCount || 0 },
    htf: { up: htfBreakdown?.callCount || 0, down: htfBreakdown?.putCount || 0 },
    liquidity: { up: liquidityBreakdown?.callCount || 0, down: liquidityBreakdown?.putCount || 0 },
    indicator: { up: indicatorBreakdown?.callCount || 0, down: indicatorBreakdown?.putCount || 0 },
    retail: { up: retailCallCount, down: retailPutCount },
  };
  
  console.log(`[SCENARIO BREAKDOWN] SMC: ${scenarioBreakdown.smc.up}↑/${scenarioBreakdown.smc.down}↓ | HTF: ${scenarioBreakdown.htf.up}↑/${scenarioBreakdown.htf.down}↓ | Liq: ${scenarioBreakdown.liquidity.up}↑/${scenarioBreakdown.liquidity.down}↓ | Ind: ${scenarioBreakdown.indicator.up}↑/${scenarioBreakdown.indicator.down}↓ | Retail: ${scenarioBreakdown.retail.up}↑/${scenarioBreakdown.retail.down}↓`);
  
  // ============= STEP 2: SCENARIO FILTER (VALIDATION LAYER) =============
  // Check if current market data matches any of the 50 scenarios
  const scenarioResult = runScenarioFilter(scenarioBreakdown);
  
  // ============= STEP 3: FINAL DECISION (VETO POWER) =============
  let direction: 'CALL' | 'PUT';
  let confidence: number;
  let scenarioUsed: ScenarioResult | null = null;
  
  if (scenarioResult) {
    // ============= AI AUTHORITY MODE: No pillar blocking =============
    // Scenario determines direction directly - no pillar override
    direction = scenarioResult.signal;
    confidence = parseInt(scenarioResult.confidence);
    scenarioUsed = scenarioResult;
    console.log(`[AI AUTHORITY] Strategy #${scenarioResult.strategyNumber} "${scenarioResult.strategyName}" → ${direction} (${scenarioResult.confidence})`);
  } else {
    // NO SCENARIO MATCH: Use standard raw summation
    const rawScoreDiff = callScore.totalScore - putScore.totalScore;
    console.log(`[SCORING] No scenario match. Using raw sum: CALL ${callScore.totalScore.toFixed(2)} | PUT ${putScore.totalScore.toFixed(2)} | Diff: ${rawScoreDiff.toFixed(2)}`);
    
    direction = rawScoreDiff > 0 ? 'CALL' : 'PUT';
    
    // Calculate confidence based on score difference
    const winningScore = direction === 'CALL' ? callScore : putScore;
    const losingScore = direction === 'CALL' ? putScore : callScore;
    const scoreDiff = winningScore.totalScore - losingScore.totalScore;
    confidence = 50 + Math.min(40, scoreDiff * 5);
    
    // Apply conflict penalty (40% reduction per conflicting category, capped at 80%)
    const conflictReduction = Math.min(0.8, totalConflictPenalty);
    if (conflictReduction > 0) {
      const originalConfidence = confidence;
      confidence = confidence * (1 - conflictReduction * 0.4);
      console.log(`[CONFLICT PENALTY] Confidence reduced from ${originalConfidence.toFixed(0)}% to ${confidence.toFixed(0)}%`);
    }
    
    // Boost confidence if 235 setups matched >= 2
    const setupCategory = winningScore.categories.find(c => c.name === '235 Setups');
    if (setupCategory && setupCategory.score >= 2) confidence += 5;
    
    // Boost confidence if HTF aligns
    const htfCategory = winningScore.categories.find(c => c.name === 'HTF Analyzing');
    if (htfCategory && htfCategory.score >= 1) confidence += 5;
  }
  
  // ============= AI FORCES PILLAR ALIGNMENT =============
  // After scoring determines direction, force pillar to match:
  // AI says CALL → Pillar 1 (Uptrend DNA) locked
  // AI says PUT → Pillar 2 (Downtrend DNA) locked
  if (direction === 'CALL') {
    trendResult = { ...trendResult, pillar: PILLAR_UPTREND, trendName: 'UPTREND (AI-FORCED)' };
    console.log(`[AI→PILLAR] 🚀 AI direction CALL → Forced Pillar 1 (Uptrend DNA)`);
  } else {
    trendResult = { ...trendResult, pillar: PILLAR_DOWNTREND, trendName: 'DOWNTREND (AI-FORCED)' };
    console.log(`[AI→PILLAR] 📉 AI direction PUT → Forced Pillar 2 (Downtrend DNA)`);
  }
  const pillarLockedDirection: 'CALL' | 'PUT' = direction;

  // ============= 50% CONFIDENCE GATE =============
  // Only fire signal if confidence > 50%
  let signalFiltered = false;
  let filterReason = '';
  
  if (confidence <= 50) {
    signalFiltered = true;
    filterReason = `Confidence ${confidence.toFixed(0)}% <= 50% threshold`;
    console.log(`[AI AUTHORITY] ⚠️ Signal BLOCKED: ${filterReason}`);
  }
  
  // Cap confidence
  confidence = Math.min(95, Math.max(30, confidence));
  
  const oppositeDirection = direction === 'CALL' ? 'PUT' : 'CALL';
  const winningScore = direction === 'CALL' ? callScore : putScore;
  const losingScore = direction === 'CALL' ? putScore : callScore;
  
  // ============= HIDDEN TRAP WARNING (Veto Check) =============
  // Check if any high-priority category has setups pointing opposite to final signal
  categoryBreakdowns.forEach(cat => {
    const isHighPriority = highPriorityCategories.some(hp => cat.name.includes(hp));
    if (!isHighPriority) return;
    
    // Check if this category has setups opposing the final direction
    const opposingCount = direction === 'CALL' ? cat.putCount : cat.callCount;
    if (opposingCount > 0) {
      hasHiddenTrap = true;
      cat.conflictingSetups.forEach(setup => {
        if (!opposingSetups.includes(setup)) {
          opposingSetups.push(setup);
        }
      });
    }
  });
  
  // Also check matchedSetups for opposing direction
  const opposingMatchedSetups = losingScore.matchedSetups.filter(s => s.direction !== direction);
  opposingMatchedSetups.forEach(setup => {
    opposingSetups.push(`[235 Setup] #${setup.id}: ${setup.name} (${setup.direction})`);
  });
  
  // Build conflict analysis object with scenario info
  const conflictAnalysis: ConflictAnalysis = {
    hasInternalConflict: totalConflictPenalty > 0,
    conflictPenalty: Math.round(Math.min(0.8, totalConflictPenalty) * 40),
    hiddenTrapWarning: hasHiddenTrap,
    highRisk: hasHiddenTrap || totalConflictPenalty >= 0.4,
    conflictDetails: categoryBreakdowns,
    opposingSetups: opposingSetups.slice(0, 10),
    scenarioUsed,
  };
  
  // Build comprehensive reasoning
  const buildReasoning = (): string => {
    const parts: string[] = [];
    
    // Add scenario info FIRST if one was used (most important info)
    if (scenarioUsed) {
      parts.push(`🎯 SCENARIO #${scenarioUsed.strategyNumber}: ${scenarioUsed.strategyName} (${scenarioUsed.confidence})`);
      parts.push(`📌 Logic: ${scenarioUsed.logic}`);
    }
    
    parts.push(`📊 SIGNAL: ${direction} | Confidence: ${confidence.toFixed(0)}% | Total Score: ${winningScore.totalScore.toFixed(2)}`);
    
    // Add conflict warning if present
    if (conflictAnalysis.hasInternalConflict) {
      parts.push(`⚠️ INTERNAL CONFLICT: -${conflictAnalysis.conflictPenalty}% confidence penalty applied`);
    }
    if (conflictAnalysis.hiddenTrapWarning) {
      parts.push(`🚨 HIDDEN TRAP WARNING: ${opposingSetups.length} setups opposing signal`);
    }
    
    winningScore.categories.forEach(cat => {
      if (cat.factors.length > 0) {
        parts.push(`${cat.name}: ${cat.score.toFixed(1)} pts [${cat.factors.slice(0, 5).join(', ')}]`);
      }
    });
    
    if (winningScore.matchedSetups.length > 0) {
      parts.push(`SETUPS MATCHED: ${winningScore.matchedSetups.slice(0, 5).map(s => `#${s.id}`).join(', ')}`);
    }
    
    if (backtestResults) {
      parts.push(`BACKTEST: CALL=${backtestResults.call.winRate.toFixed(1)}% | PUT=${backtestResults.put.winRate.toFixed(1)}%`);
    }
    
    if (selfCorrectionInsights) {
      parts.push(`SELF-CORRECTION: ${selfCorrectionInsights}`);
    }
    
    return parts.join(' || ');
  };
  
  const reasoning = buildReasoning();
  
  return {
    direction: signalFiltered ? 'NO_SIGNAL' : direction,
    confidence: Math.round(confidence),
    totalScore: winningScore.totalScore,
    categories: winningScore.categories,
    matchedSetups: winningScore.matchedSetups,
    reasoning,
    callScore: callScore.totalScore,
    putScore: putScore.totalScore,
    conflictAnalysis,
    // 50% confidence gate status
    filtered: signalFiltered,
    filterReason: filterReason || null,
    // 4-Pillar Trend Engine data (informational only)
    pillarAnalysis: trendResult ? {
      trendName: trendResult.trendName,
      pillarName: trendResult.pillar.name,
      confidence: trendResult.confidence,
      lockedDirection: pillarLockedDirection, // Informational, not enforced
      reasons: trendResult.reasons.slice(-3),
    } : null,
  };
}

// ============= UTC+6 OFFSET (bot timezone) =============
const UTC6_OFFSET_MS = 6 * 60 * 60 * 1000; // 6 hours in ms

// Get current time in UTC+6
function nowUTC6(): Date {
  return new Date(Date.now() + UTC6_OFFSET_MS);
}

// Convert ISO timestamp to UTC+6 Date
function toUTC6(isoStr: string): Date {
  return new Date(new Date(isoStr).getTime() + UTC6_OFFSET_MS);
}

// ============= 35 REACTION STRATEGY ENGINE =============
// Implements all 35 OTC algorithmic reaction strategies
// Uses per-candle data: open, high, low, close, volume, time

interface ReactionStrategyResult {
  score: number;
  factors: string[];
  reactionType: 'CONTINUATION' | 'REVERSAL' | 'TRAP' | 'NEUTRAL';
  confidence: number;
}

function calculateHurstExponent(prices: number[]): number {
  // Rescaled Range (R/S) method approximation
  if (prices.length < 20) return 0.5;
  const n = prices.length;
  const mean = prices.reduce((s, v) => s + v, 0) / n;
  const deviations = prices.map(p => p - mean);
  let cumDev = 0;
  const cumulative: number[] = [];
  for (const d of deviations) { cumDev += d; cumulative.push(cumDev); }
  const R = Math.max(...cumulative) - Math.min(...cumulative);
  const stdDev = Math.sqrt(deviations.reduce((s, d) => s + d * d, 0) / n);
  if (stdDev === 0) return 0.5;
  const rs = R / stdDev;
  // H = log(R/S) / log(n/2)
  return Math.log(rs) / Math.log(n / 2);
}

function calculateZScore(value: number, data: number[]): number {
  if (data.length < 2) return 0;
  const mean = data.reduce((s, v) => s + v, 0) / data.length;
  const std = Math.sqrt(data.reduce((s, v) => s + (v - mean) ** 2, 0) / data.length);
  if (std === 0) return 0;
  return (value - mean) / std;
}

function isNearRoundNum(price: number): boolean {
  // Check .000 or .500 boundaries
  const mod1 = price % 1;
  const mod01 = price % 0.1;
  const mod001 = price % 0.01;
  return (
    Math.abs(mod001) < 0.0002 ||        // near .XX0
    Math.abs(mod001 - 0.005) < 0.0002 || // near .XX5
    Math.abs(mod01) < 0.0002 ||          // near .X00
    Math.abs(mod1) < 0.0002 ||           // near X.000
    Math.abs(mod1 - 0.5) < 0.0002        // near X.500
  );
}

function runReactionStrategyEngine(
  opens: number[],
  highs: number[],
  lows: number[],
  closes: number[],
  volumes: number[],
  times: string[],
  direction: 'CALL' | 'PUT'
): ReactionStrategyResult {
  const factors: string[] = [];
  let score = 0;
  let reversalVotes = 0;
  let continuationVotes = 0;
  let trapVotes = 0;

  const len = closes.length;
  if (len < 30) return { score: 0, factors: ['Insufficient data for reaction analysis'], reactionType: 'NEUTRAL', confidence: 0 };

  const lastI = len - 1;
  const c0 = { o: opens[lastI], h: highs[lastI], l: lows[lastI], c: closes[lastI], v: volumes[lastI] };
  const c1 = { o: opens[lastI-1], h: highs[lastI-1], l: lows[lastI-1], c: closes[lastI-1], v: volumes[lastI-1] };
  const c2 = { o: opens[lastI-2], h: highs[lastI-2], l: lows[lastI-2], c: closes[lastI-2], v: volumes[lastI-2] };

  const avgBody20 = closes.slice(-20).reduce((s, c, i) => s + Math.abs(c - opens[opens.length - 20 + i]), 0) / 20;
  const avgVol20 = volumes.slice(-20).reduce((s, v) => s + v, 0) / 20;
  const avgVol5 = volumes.slice(-5).reduce((s, v) => s + v, 0) / 5;
  const avgWickSize = closes.slice(-20).reduce((s, c, i) => {
    const idx = opens.length - 20 + i;
    return s + (highs[idx] - Math.max(c, opens[idx])) + (Math.min(c, opens[idx]) - lows[idx]);
  }, 0) / 20;

  const currentTime = nowUTC6();
  const minute = currentTime.getMinutes();
  const second = currentTime.getSeconds();

  // ─── STRATEGY 1: Wick-Fill Logic (Continuation) ────────────────────────────
  {
    const upperWick1 = c1.h - Math.max(c1.o, c1.c);
    const lowerWick1 = Math.min(c1.o, c1.c) - c1.l;
    const body1 = Math.abs(c1.c - c1.o);
    if (upperWick1 > body1 * 1.5 && c0.c > c1.h - upperWick1 * 0.5) {
      if (direction === 'CALL') {
        score += 1.2; continuationVotes++;
        factors.push('R01: Wick-Fill Logic → CALL (slow climb back into upper wick)');
      }
    }
    if (lowerWick1 > body1 * 1.5 && c0.c < c1.l + lowerWick1 * 0.5) {
      if (direction === 'PUT') {
        score += 1.2; continuationVotes++;
        factors.push('R01: Wick-Fill Logic → PUT (slow descent into lower wick)');
      }
    }
  }

  // ─── STRATEGY 2: Round Number Rejection (Reversal) ─────────────────────────
  {
    if (isNearRoundNum(c0.h) && c0.c < c0.h - (c0.h - Math.max(c0.o, c0.c)) * 0.5) {
      if (direction === 'PUT') {
        score += 1.5; reversalVotes++;
        factors.push('R02: Round Number Rejection → PUT (rejection at .000/.500)');
      }
    }
    if (isNearRoundNum(c0.l) && c0.c > c0.l + (Math.min(c0.o, c0.c) - c0.l) * 0.5) {
      if (direction === 'CALL') {
        score += 1.5; reversalVotes++;
        factors.push('R02: Round Number Rejection → CALL (bounce at .000/.500)');
      }
    }
  }

  // ─── STRATEGY 3: Volume Exhaustion (Reversal) ──────────────────────────────
  {
    const earlyVol = volumes.slice(-10, -5).reduce((s, v) => s + v, 0) / 5;
    const lateVol = volumes.slice(-5).reduce((s, v) => s + v, 0) / 5;
    const bigBody1 = Math.abs(c1.c - c1.o) > avgBody20 * 2;
    if (bigBody1 && earlyVol > avgVol20 * 1.5 && lateVol < avgVol20 * 0.6) {
      const exhaustDir = c1.c > c1.o ? 'PUT' : 'CALL';
      if (exhaustDir === direction) {
        score += 1.4; reversalVotes++;
        factors.push(`R03: Volume Exhaustion → ${direction} (burnt fuel, late vol drop)`);
      }
    }
  }

  // ─── STRATEGY 4: Stutter-Step (Continuation Trap) ──────────────────────────
  {
    let stutterCount = 0;
    for (let i = lastI - 4; i <= lastI - 1; i++) {
      if (i < 1) continue;
      const move = closes[i] - closes[i-1];
      const retrace = closes[i+1 <= lastI ? i+1 : i] - closes[i];
      if (Math.abs(move) > 0 && Math.abs(retrace) > 0 && Math.sign(move) !== Math.sign(retrace) && Math.abs(retrace) < Math.abs(move) * 0.7) {
        stutterCount++;
      }
    }
    if (stutterCount >= 3) {
      const trend5 = closes[lastI] - closes[lastI-5];
      const contDir = trend5 > 0 ? 'CALL' : 'PUT';
      if (contDir === direction) {
        score += 1.1; continuationVotes++; trapVotes++;
        factors.push(`R04: Stutter-Step → ${direction} (fake weakness, algo trap)`);
      }
    }
  }

  // ─── STRATEGY 5: Cycle Flip (Timed Reversal) UTC+6 ─────────────────────────
  {
    const is15mBoundary = (minute === 14 || minute === 29 || minute === 44 || minute === 59) && second >= 45;
    const is30mBoundary = (minute === 29 || minute === 59) && second >= 50;
    const is1hBoundary = minute === 59 && second >= 55;

    let consecSameColor = 0;
    const lastBull = closes[lastI] > opens[lastI];
    for (let i = lastI; i > Math.max(lastI - 8, 0); i--) {
      if ((closes[i] > opens[i]) === lastBull) consecSameColor++;
      else break;
    }

    if ((is15mBoundary || is30mBoundary || is1hBoundary) && consecSameColor >= 3) {
      const cycleDir = lastBull ? 'PUT' : 'CALL';
      if (cycleDir === direction) {
        const bonus = is1hBoundary ? 2.5 : is30mBoundary ? 2.0 : 1.8;
        score += bonus; reversalVotes++;
        factors.push(`R05: Cycle Flip UTC+6 → ${direction} (${consecSameColor} same-color, cycle boundary at ${minute}:${second})`);
      }
    }
  }

  // ─── STRATEGY 6: Static Price / Doji Trap ──────────────────────────────────
  {
    const doji = Math.abs(c0.c - c0.o) < avgBody20 * 0.1 && (c0.h - c0.l) > 0;
    if (doji && c0.v > avgVol20 * 0.3) {
      const prevDir = c1.c > c1.o ? 'PUT' : 'CALL';
      if (prevDir === direction) {
        score += 1.3; reversalVotes++;
        factors.push(`R06: Doji Trap → ${direction} (price locked, gap expected next candle)`);
      }
    }
  }

  // ─── STRATEGY 7: Micro-Gap Continuation ────────────────────────────────────
  {
    const prevClose = closes[lastI - 1];
    const prevHigh = highs[lastI - 1];
    const prevLow = lows[lastI - 1];
    const gapUp = opens[lastI] > prevClose && opens[lastI] > prevHigh;
    const gapDown = opens[lastI] < prevClose && opens[lastI] < prevLow;
    const gapSize = Math.abs(opens[lastI] - prevClose);

    if (gapUp && gapSize < avgBody20 * 0.5 && gapSize > 0 && direction === 'CALL') {
      score += 1.6; continuationVotes++;
      factors.push('R07: Micro-Gap Continuation → CALL (fair value floor shifted up)');
    }
    if (gapDown && gapSize < avgBody20 * 0.5 && gapSize > 0 && direction === 'PUT') {
      score += 1.6; continuationVotes++;
      factors.push('R07: Micro-Gap Continuation → PUT (fair value ceiling shifted down)');
    }
  }

  // ─── STRATEGY 8: Entropy Collapse (Reversal) ───────────────────────────────
  {
    if (times.length >= 10) {
      const last10times = times.slice(-10).map(t => new Date(t).getTime());
      const diffs = [];
      for (let i = 1; i < last10times.length; i++) diffs.push(last10times[i] - last10times[i-1]);
      const meanDiff = diffs.reduce((s, d) => s + d, 0) / diffs.length;
      const variance = diffs.reduce((s, d) => s + (d - meanDiff) ** 2, 0) / diffs.length;
      const cv = meanDiff > 0 ? Math.sqrt(variance) / meanDiff : 1; // coefficient of variation
      // Low CV = very regular/mechanical (entropy collapsed)
      if (cv < 0.1 && isNearRoundNum(c0.c)) {
        const dir = c0.c > c0.o ? 'PUT' : 'CALL';
        if (dir === direction) {
          score += 1.8; reversalVotes++;
          factors.push(`R08: Entropy Collapse → ${direction} (mechanical ticks + round number = algo instruction complete)`);
        }
      }
    }
  }

  // ─── STRATEGY 9: Delta-Velocity Divergence ─────────────────────────────────
  {
    const last5PriceDelta = Math.abs(closes[lastI] - closes[lastI-5]);
    const last5VolAvg = volumes.slice(-5).reduce((s, v) => s + v, 0) / 5;
    const pip = closes[lastI] > 100 ? 0.01 : closes[lastI] > 10 ? 0.001 : 0.0001;

    const absorption = last5VolAvg > avgVol20 * 1.5 && last5PriceDelta < pip * 3;
    const vacuum = last5VolAvg < avgVol20 * 0.5 && last5PriceDelta > pip * 5;

    if (absorption) {
      const absDir = closes[lastI] > closes[lastI-5] ? 'PUT' : 'CALL';
      if (absDir === direction) {
        score += 1.4; reversalVotes++;
        factors.push(`R09: Delta-Velocity Absorption → ${direction} (high vol, no price move = distribution)`);
      }
    }
    if (vacuum) {
      const vacDir = closes[lastI] > closes[lastI-5] ? 'CALL' : 'PUT';
      if (vacDir === direction) {
        score += 1.4; continuationVotes++;
        factors.push(`R09: Delta-Velocity Vacuum → ${direction} (low vol, price teleport = continuation)`);
      }
    }
  }

  // ─── STRATEGY 10: Z-Score Wick Reaction (Extreme Reversal) ────────────────
  {
    const last20wicks = closes.slice(-20).map((c, i) => {
      const idx = closes.length - 20 + i;
      return (highs[idx] - Math.max(c, opens[idx])) + (Math.min(c, opens[idx]) - lows[idx]);
    });
    const currentWick = (c0.h - Math.max(c0.o, c0.c)) + (Math.min(c0.o, c0.c) - c0.l);
    const wickZ = calculateZScore(currentWick, last20wicks);

    if (wickZ > 2.5) {
      const zDir = c0.h - Math.max(c0.o, c0.c) > Math.min(c0.o, c0.c) - c0.l ? 'PUT' : 'CALL';
      if (zDir === direction) {
        score += 2.0; reversalVotes++;
        factors.push(`R10: Z-Score Wick Extreme → ${direction} (Z=${wickZ.toFixed(2)}, algorithmic overshoot)`);
      }
    }
  }

  // ─── STRATEGY 11: Cluster-Close (Continuation) ─────────────────────────────
  {
    const last3closes = [closes[lastI-2], closes[lastI-1], closes[lastI]];
    const clusterRange = Math.max(...last3closes) - Math.min(...last3closes);
    const pip = closes[lastI] > 100 ? 0.01 : 0.0001;
    if (clusterRange < pip * 2 && c0.v > avgVol20 * 1.2) {
      // Breaking out of cluster
      const breakDir = c0.c > c0.o ? 'CALL' : 'PUT';
      if (breakDir === direction) {
        score += 1.3; continuationVotes++;
        factors.push(`R11: Cluster-Close Breakout → ${direction} (seal broken, new cluster target)`);
      }
    }
  }

  // ─── STRATEGY 12: Binary Pulse (1-0 Reaction) ──────────────────────────────
  {
    const midIdx = Math.floor(lastI / 2);
    if (lastI >= 20) {
      const midPrice = closes[lastI - 10];
      const currentClose = closes[lastI];
      const priceDelta30s = Math.abs(currentClose - midPrice);
      const totalRange = Math.max(...highs.slice(-10)) - Math.min(...lows.slice(-10));
      if (priceDelta30s < totalRange * 0.2 && totalRange > avgBody20 * 1.5) {
        // Round trip - neutralizing move
        const lateDir = currentClose > midPrice ? 'CALL' : 'PUT';
        if (lateDir === direction) {
          score += 1.0;
          factors.push(`R12: Binary Pulse → ${direction} (late momentum bias after round-trip)`);
        }
      }
    }
  }

  // ─── STRATEGY 13: Frequency Resonance (Advanced Reversal) ──────────────────
  {
    const micro = closes.slice(-5);
    let microOscillations = 0;
    for (let i = 1; i < micro.length; i++) {
      if (i > 1 && Math.sign(micro[i] - micro[i-1]) !== Math.sign(micro[i-1] - micro[i-2])) {
        microOscillations++;
      }
    }
    const pip = closes[lastI] > 100 ? 0.01 : 0.0001;
    const microRange = Math.max(...closes.slice(-5)) - Math.min(...closes.slice(-5));
    if (microOscillations >= 3 && microRange < pip * 1) {
      const resDir = closes[lastI] > closes[lastI-5] ? 'PUT' : 'CALL';
      if (resDir === direction) {
        score += 1.8; reversalVotes++;
        factors.push(`R13: Frequency Resonance → ${direction} (${microOscillations} micro-oscillations, algo vibrating at clearing price)`);
      }
    }
  }

  // ─── STRATEGY 14: Hidden Gap Refill (Continuation) ─────────────────────────
  {
    // Look for a 1-candle gap (jump) around candle lastI-10 that hasn't been corrected
    for (let i = lastI - 10; i < lastI - 2; i++) {
      if (i < 1) continue;
      const gap = Math.abs(opens[i] - closes[i-1]);
      if (gap > avgBody20 * 1.5) {
        const gapDir = opens[i] > closes[i-1] ? 'CALL' : 'PUT';
        const movingTowardGap = gapDir === 'CALL' ? closes[lastI] < opens[i] : closes[lastI] > opens[i];
        const movingTowardFill = gapDir === direction && movingTowardGap;
        if (movingTowardFill && avgVol5 < avgVol20 * 0.7) {
          score += 1.1; continuationVotes++;
          factors.push(`R14: Hidden Gap Refill → ${direction} (unfilled gap from candle ${lastI-i} bars ago, low-vel return)`);
          break;
        }
      }
    }
  }

  // ─── STRATEGY 15: Stall-and-Snap (Trap Reversal) ───────────────────────────
  {
    // Price stalls for 4-5 candles then snaps in one direction
    const last6prices = closes.slice(-6);
    const stall5range = Math.max(...last6prices.slice(0, 5)) - Math.min(...last6prices.slice(0, 5));
    const snap = Math.abs(last6prices[5] - last6prices[4]);
    if (stall5range < avgBody20 * 0.3 && snap > avgBody20 * 2) {
      // Snap after stall = trap
      const snapDir = last6prices[5] > last6prices[4] ? 'PUT' : 'CALL';
      if (snapDir === direction) {
        score += 1.7; trapVotes++; reversalVotes++;
        factors.push(`R15: Stall-and-Snap Trap → ${direction} (5-bar stall then fake ${snap > 0 ? 'up' : 'down'} snap)`);
      }
    }
  }

  // ─── STRATEGY 16: Volume Weighting Reaction (Trend ID) ─────────────────────
  {
    const largeBody = Math.abs(c0.c - c0.o) > avgBody20 * 2.5;
    const lowTicks = c0.v < avgVol20 * 0.4;
    const smallBody = Math.abs(c0.c - c0.o) < avgBody20 * 0.4;
    const highTicks = c0.v > avgVol20 * 1.8;

    if (largeBody && lowTicks) {
      const fakeDir = c0.c > c0.o ? 'PUT' : 'CALL';
      if (fakeDir === direction) {
        score += 1.5; reversalVotes++;
        factors.push(`R16: Large Body + Low Vol → ${direction} (Algorithm Drift = fake move, reversal expected)`);
      }
    }
    if (smallBody && highTicks) {
      const accDir = c0.c > c0.o ? 'CALL' : 'PUT';
      if (accDir === direction) {
        score += 1.3; continuationVotes++;
        factors.push(`R16: Small Body + High Vol → ${direction} (Accumulation = pressure building, breakout coming)`);
      }
    }
  }

  // ─── STRATEGY 17: 00-Second Neutralizer / Marubozu Trap ────────────────────
  {
    const body0 = Math.abs(c0.c - c0.o);
    const range0 = c0.h - c0.l;
    const isMarubozu = range0 > 0 && body0 / range0 > 0.92;
    if (isMarubozu && body0 > avgBody20 * 2 && c0.v > avgVol20 * 1.5) {
      const neutDir = c0.c > c0.o ? 'PUT' : 'CALL';
      if (neutDir === direction) {
        score += 1.6; reversalVotes++; trapVotes++;
        factors.push(`R17: Marubozu Neutralizer → ${direction} (OTC trap 80% reversal: end-of-candle vol spike)`);
      }
    }
  }

  // ─── STRATEGY 18: Hurst Exponent Filter ────────────────────────────────────
  {
    const last45prices = closes.slice(-45);
    if (last45prices.length >= 30) {
      const H = calculateHurstExponent(last45prices);
      if (H < 0.5) {
        // Mean-reverting regime
        const recentDir = closes[lastI] > closes[lastI - 5] ? 'PUT' : 'CALL';
        if (recentDir === direction) {
          score += 1.2; reversalVotes++;
          factors.push(`R18: Hurst Exponent H=${H.toFixed(2)} < 0.5 → ${direction} (mean-reverting regime, spike = trap)`);
        }
      } else if (H > 0.65) {
        // Persistent trend
        const trendDir = closes[lastI] > closes[lastI - 10] ? 'CALL' : 'PUT';
        if (trendDir === direction) {
          score += 1.0; continuationVotes++;
          factors.push(`R18: Hurst Exponent H=${H.toFixed(2)} > 0.65 → ${direction} (persistent trend regime)`);
        }
      }
    }
  }

  // ─── STRATEGY 19: Tick Jitter Pulse ────────────────────────────────────────
  {
    if (times.length >= 10) {
      const last10ms = times.slice(-10).map(t => new Date(t).getTime());
      const diffs = last10ms.slice(1).map((t, i) => t - last10ms[i]);
      const meanDiff = diffs.reduce((s, d) => s + d, 0) / diffs.length;
      const variance = diffs.reduce((s, d) => s + (d - meanDiff) ** 2, 0) / diffs.length;
      const last3diffs = diffs.slice(-3);
      const last3mean = last3diffs.reduce((s, d) => s + d, 0) / 3;
      const last3var = last3diffs.reduce((s, d) => s + (d - last3mean) ** 2, 0) / 3;
      // Check for 300%+ variance spike
      if (last3var > variance * 3 && variance > 0) {
        // Jitter spike = algo switching bias
        if (isNearRoundNum(c0.c)) {
          if (direction === 'PUT') {
            score += 1.5; trapVotes++;
            factors.push(`R19: Tick Jitter at Resistance → PUT (algo failing to break, Cycle Flip)`);
          }
        } else {
          const smoothDir = c0.c > c0.o ? 'CALL' : 'PUT';
          if (smoothDir === direction) {
            score += 1.0; continuationVotes++;
            factors.push(`R19: Low Tick Jitter + Moving → ${direction} (algo cleared, continuation confirmed)`);
          }
        }
      }
    }
  }

  // ─── STRATEGY 20: Ghost Gap Vacuum ─────────────────────────────────────────
  {
    // Check for teleport (jump with zero intermediate ticks)
    const gapUp20 = opens[lastI] - closes[lastI - 1];
    if (gapUp20 > avgBody20 * 2) {
      // Gap up = correction first
      if (direction === 'PUT') {
        score += 1.3; reversalVotes++;
        factors.push(`R20: Ghost Gap Up → PUT (vacuum created, algo will fill gap in next candle)`);
      }
    } else if (gapUp20 < -avgBody20 * 2) {
      if (direction === 'CALL') {
        score += 1.3; reversalVotes++;
        factors.push(`R20: Ghost Gap Down → CALL (vacuum below, gap fill expected)`);
      }
    }
  }

  // ─── STRATEGY 21: Markov Chain State Anomaly ───────────────────────────────
  {
    // Classify last 20 states and check transition probabilities
    const states = closes.slice(-20).map((c, i) => {
      const idx = closes.length - 20 + i;
      const diff = i > 0 ? c - closes[idx - 1] : 0;
      const speed = Math.abs(diff);
      if (speed === 0) return 'FLAT';
      if (diff > 0 && speed > avgBody20 * 0.5) return 'UP_FAST';
      if (diff > 0) return 'UP_SLOW';
      if (speed > avgBody20 * 0.5) return 'DOWN_FAST';
      return 'DOWN_SLOW';
    });
    const lastState = states[states.length - 1];
    const prevState = states[states.length - 2];
    // Count how many times prevState was followed by lastState
    let prevCount = 0, transCount = 0;
    for (let i = 1; i < states.length - 1; i++) {
      if (states[i-1] === prevState) { prevCount++; if (states[i] === lastState) transCount++; }
    }
    const transProb = prevCount > 0 ? transCount / prevCount : 0.5;
    if (transProb < 0.05 && prevCount > 0) {
      // Extremely low probability state = manual override by algo = revert to mean
      const revertDir = lastState.startsWith('UP') ? 'PUT' : 'CALL';
      if (revertDir === direction) {
        score += 1.9; reversalVotes++;
        factors.push(`R21: Markov Anomaly P=${transProb.toFixed(3)} → ${direction} (algo override, instant mean reversion)`);
      }
    }
  }

  // ─── STRATEGY 22: Autocorrelation Decay (Memory Wipe) ──────────────────────
  {
    const recent15 = closes.slice(-15);
    let autoCorr = 0;
    if (recent15.length >= 6) {
      const diffs = recent15.slice(1).map((c, i) => c - recent15[i]);
      // Pearson correlation between consecutive diffs (lag-1)
      const x = diffs.slice(0, -1);
      const y = diffs.slice(1);
      const n = x.length;
      if (n > 0) {
        const mx = x.reduce((s, v) => s + v, 0) / n;
        const my = y.reduce((s, v) => s + v, 0) / n;
        const num = x.reduce((s, v, i) => s + (v - mx) * (y[i] - my), 0);
        const den = Math.sqrt(x.reduce((s, v) => s + (v - mx) ** 2, 0) * y.reduce((s, v) => s + (v - my) ** 2, 0));
        autoCorr = den > 0 ? num / den : 0;
      }
    }
    if (Math.abs(autoCorr) < 0.05 && closes[lastI] > Math.max(...closes.slice(-5, -1))) {
      // Momentum engine switched off at new high
      if (direction === 'PUT') {
        score += 1.6; reversalVotes++;
        factors.push(`R22: Autocorrelation Decay r≈0 at new high → PUT (momentum engine switched off, collapse imminent)`);
      }
    }
  }

  // ─── STRATEGY 23: Phase-Space Attractor Collapse ───────────────────────────
  {
    const v = closes.slice(-3).map((c, i) => i > 0 ? c - closes[closes.length - 3 + i - 1] : 0);
    const velocity = v[v.length - 1];
    const accel = v.length >= 2 ? v[v.length - 1] - v[v.length - 2] : 0;
    if (Math.abs(velocity) < 0.0000001 && Math.abs(accel) < 0.0000001 && c0.v > avgVol20 * 1.5) {
      // V→0 and A→0 with high volume = spring compressed
      const compDir = closes[lastI] > closes[lastI - 5] ? 'CALL' : 'PUT';
      if (compDir === direction) {
        score += 2.0; continuationVotes++;
        factors.push(`R23: Phase-Space Attractor Collapse → ${direction} (velocity+acceleration→0, spring compressed, teleportation prep)`);
      }
    }
  }

  // ─── STRATEGY 24: Synthetic Order Book Imbalance (SOBI) ────────────────────
  {
    // Proxy: compare ticks per pip in up vs down direction using candle data
    const up5vol = volumes.slice(-5).filter((_, i) => closes[closes.length - 5 + i] > opens[opens.length - 5 + i]).reduce((s, v) => s + v, 0);
    const down5vol = volumes.slice(-5).filter((_, i) => closes[closes.length - 5 + i] < opens[opens.length - 5 + i]).reduce((s, v) => s + v, 0);
    const up5pips = Math.max(0, closes[lastI] - closes[lastI - 5]);
    const down5pips = Math.max(0, closes[lastI - 5] - closes[lastI]);

    const ticksPerPipUp = up5pips > 0 ? up5vol / up5pips : 0;
    const ticksPerPipDown = down5pips > 0 ? down5vol / down5pips : 0;
    const imbalance = ticksPerPipDown > 0 && ticksPerPipUp > 0 ? ticksPerPipUp / ticksPerPipDown : 1;

    if (imbalance > 4) {
      // 4x more resistance up = synthetic ask wall
      if (direction === 'PUT') {
        score += 1.7; reversalVotes++;
        factors.push(`R24: SOBI ${imbalance.toFixed(1)}x upside resistance → PUT (synthetic ask wall 4x thick, floor removed)`);
      }
    } else if (imbalance < 0.25) {
      if (direction === 'CALL') {
        score += 1.7; reversalVotes++;
        factors.push(`R24: SOBI ${(1/imbalance).toFixed(1)}x downside resistance → CALL (synthetic bid wall, reversal)`);
      }
    }
  }

  // ─── STRATEGY 25: Clock-Zero Neutralizer (Hourly Reversal) ─────────────────
  {
    const isHourBoundary = minute === 0 && second <= 10;
    if (isHourBoundary && Math.abs(c0.c - c0.o) > avgBody20 * 1.5) {
      const tickBurst = c0.v > avgVol20 * 2;
      if (tickBurst) {
        const neutDir = c0.c > c0.o ? 'PUT' : 'CALL';
        if (neutDir === direction) {
          score += 2.0; reversalVotes++;
          factors.push(`R25: Clock-Zero Neutralizer UTC+6 → ${direction} (hourly reset + tick burst = broker balance event)`);
        }
      }
    }
  }

  // ─── STRATEGY 26: Micro-Wick Vacuum (Stop Run) ─────────────────────────────
  {
    const prevMicroWick = Math.min(c1.h - Math.max(c1.o, c1.c), Math.min(c1.o, c1.c) - c1.l);
    const pip = closes[lastI] > 100 ? 0.01 : 0.0001;
    if (prevMicroWick > 0 && prevMicroWick < pip * 0.5) {
      // Tiny wick exists
      const currentBreak = c0.h > c1.h + pip * 5 || c0.l < c1.l - pip * 5;
      if (currentBreak) {
        const breakDir = c0.h > c1.h + pip * 5 ? 'PUT' : 'CALL';
        if (breakDir === direction) {
          score += 1.4; trapVotes++;
          factors.push(`R26: Micro-Wick Vacuum → ${direction} (stop run past tiny wick, immediate freeze = reversal trap)`);
        }
      }
    }
  }

  // ─── STRATEGY 27: Tick-Volume Exhaustion ───────────────────────────────────
  {
    const peakVol = Math.max(...volumes.slice(-10, -5));
    const currentVol = c0.v;
    const atHigh = closes[lastI] >= Math.max(...closes.slice(-10)) * 0.999;
    const atLow = closes[lastI] <= Math.min(...closes.slice(-10)) * 1.001;
    if (peakVol > avgVol20 * 2 && currentVol < avgVol20 * 0.3) {
      if (atHigh && direction === 'PUT') {
        score += 1.8; reversalVotes++;
        factors.push('R27: Volume Exhaustion at High → PUT (heartbeat stopped at peak, buy instruction disconnected)');
      }
      if (atLow && direction === 'CALL') {
        score += 1.8; reversalVotes++;
        factors.push('R27: Volume Exhaustion at Low → CALL (heartbeat stopped at trough, sell instruction disconnected)');
      }
    }
  }

  // ─── STRATEGY 28: Step-Ladder Pulse (Continuation) ─────────────────────────
  {
    let stepCount = 0;
    let lastStep = 0;
    for (let i = lastI - 8; i < lastI; i++) {
      if (i < 1) continue;
      const move = closes[i] - closes[i-1];
      const wait = Math.abs(closes[i] - opens[i]) < avgBody20 * 0.2;
      if (Math.abs(move) > avgBody20 * 0.3 && !wait) stepCount++;
    }
    const finalDrift = closes[lastI] - closes[lastI-2];
    const isStep = stepCount >= 4 && Math.abs(finalDrift) < avgBody20 * 0.3;
    if (isStep) {
      const stepDir = closes[lastI] > closes[lastI - 8] ? 'CALL' : 'PUT';
      if (stepDir === direction) {
        score += 1.2; continuationVotes++;
        factors.push(`R28: Step-Ladder Pulse → ${direction} (low-entropy trend, low drift = algo will not reverse yet)`);
      }
    }
  }

  // ─── STRATEGY 29: Level-Slam Breakout (Continuation) ──────────────────────
  {
    const hugsResistance = Math.abs(c0.c - Math.max(...closes.slice(-10))) < (closes[lastI] > 100 ? 0.01 : 0.0001) * 2;
    const highDensity = c0.v > avgVol20 * 2.5;
    if (hugsResistance && highDensity) {
      if (direction === 'CALL') {
        score += 1.5; continuationVotes++;
        factors.push('R29: Level-Slam Breakout → CALL (30+ ticks/sec hugging resistance = wall being broken)');
      }
    }
  }

  // ─── STRATEGY 30: FFT Frequency Snap ───────────────────────────────────────
  {
    // Approximate dominant cycle using autocorrelation peaks
    const series = closes.slice(-60);
    const mean = series.reduce((s, v) => s + v, 0) / series.length;
    const centered = series.map(v => v - mean);
    let peakCorr = 0, peakLag = 1;
    for (let lag = 2; lag <= 20; lag++) {
      let corr = 0;
      for (let i = lag; i < centered.length; i++) corr += centered[i] * centered[i - lag];
      corr /= (centered.length - lag);
      if (corr > peakCorr) { peakCorr = corr; peakLag = lag; }
    }
    // Check if current candle lands at crest/trough of dominant cycle
    const cyclePos = lastI % peakLag;
    const atCrest = cyclePos === 0 || cyclePos === 1;
    if (atCrest && peakLag > 1) {
      const fftDir = closes[lastI] > closes[lastI - peakLag] ? 'PUT' : 'CALL';
      if (fftDir === direction) {
        score += 1.5; reversalVotes++;
        factors.push(`R30: FFT Frequency Snap cycle=${peakLag} → ${direction} (at mathematical peak/trough of dominant wave)`);
      }
    }
  }

  // ─── STRATEGY 31: Shadow Fill (Precision Continuation) ─────────────────────
  {
    const prevBodyMid = (c1.o + c1.c) / 2;
    const bodyLarger = Math.abs(c0.c - c0.o) > Math.abs(c1.c - c1.o);
    const halfWickFilled = c0.c > c1.l + (c1.h - c1.l) * 0.5;
    if (bodyLarger && halfWickFilled && c0.v < avgVol20 * 0.7) {
      const fillDir = c1.c > c1.o ? 'CALL' : 'PUT';
      if (fillDir === direction) {
        score += 1.2; continuationVotes++;
        factors.push(`R31: Shadow Fill → ${direction} (50%+ wick filled with larger body, slow continuation)`);
      }
    }
  }

  // ─── STRATEGY 32: Binary Rejection (Double-Tap Reversal) ───────────────────
  {
    const currentHigh = c0.h;
    // Look for previous touch of same level
    for (let i = lastI - 15; i < lastI - 3; i++) {
      if (i < 0) continue;
      const distHigh = Math.abs(highs[i] - currentHigh) / currentHigh;
      if (distHigh < 0.0002) {
        if (direction === 'PUT') {
          score += 1.6; reversalVotes++; trapVotes++;
          factors.push(`R32: Binary Rejection (Double-Tap) → PUT (2nd touch ${lastI-i} bars ago, algo washes early reversers)`);
        }
        break;
      }
      const distLow = Math.abs(lows[i] - c0.l) / c0.l;
      if (distLow < 0.0002) {
        if (direction === 'CALL') {
          score += 1.6; reversalVotes++; trapVotes++;
          factors.push(`R32: Binary Rejection (Double-Tap) → CALL (2nd low touch ${lastI-i} bars ago)`);
        }
        break;
      }
    }
  }

  // ─── STRATEGY 33: Tick-Gap Displacement (Momentum Burst) ───────────────────
  {
    const pip = closes[lastI] > 100 ? 0.01 : closes[lastI] > 1 ? 0.0001 : 0.000001;
    // Detect missing pips (price moved 3+ pips in one candle without intermediate levels)
    const bigJump = Math.abs(c0.c - c0.o) > pip * 4;
    const lowVol = c0.v < avgVol20 * 0.5;
    if (bigJump && lowVol) {
      const displacDir = c0.c > c0.o ? 'CALL' : 'PUT';
      if (displacDir === direction) {
        score += 1.4; continuationVotes++;
        factors.push(`R33: Tick-Gap Displacement → ${direction} (price re-indexed, 2-3 candle continuation expected)`);
      }
    }
  }

  // ─── STRATEGY 34: Volume-Price Divergence Fake-Out ─────────────────────────
  {
    const last10vols = volumes.slice(-10);
    const volSpike = Math.max(...last10vols.slice(-2)) > avgVol20 * 2.5;
    const pipsMoved = Math.abs(closes[lastI] - closes[lastI-2]);
    const pip = closes[lastI] > 100 ? 0.01 : 0.0001;
    if (volSpike && pipsMoved < pip * 0.5) {
      // 50 ticks/sec but price barely moved = aggressive absorption
      const absorbDir = closes[lastI] > closes[lastI-5] ? 'PUT' : 'CALL';
      if (absorbDir === direction) {
        score += 1.9; reversalVotes++;
        factors.push(`R34: Volume-Price Divergence → ${direction} (50+ ticks absorbed by algo, retail CALL orders absorbed)`);
      }
    }
  }

  // ─── STRATEGY 35: Last-Second Settle / Doji Predictor ──────────────────────
  {
    const pip = closes[lastI] > 100 ? 0.01 : 0.0001;
    const nearOpen = Math.abs(closes[lastI] - opens[lastI]) < pip * 0.5;
    const volDropped = c0.v < avgVol20 * 0.2;
    if (nearOpen && volDropped && second >= 50) {
      // Locked doji - gap in opposite direction of previous trend
      const prevTrend = closes[lastI-1] > opens[lastI-1] ? 'PUT' : 'CALL';
      if (prevTrend === direction) {
        score += 1.3; reversalVotes++;
        factors.push(`R35: Last-Second Settle UTC+6 → ${direction} (price ${Math.abs(closes[lastI] - opens[lastI]).toFixed(5)} from open, vol dead, algo locked = gap reversal)`);
      }
    }
  }

  // ─── COMPOSITE REACTION TYPE ────────────────────────────────────────────────
  const totalVotes = reversalVotes + continuationVotes + trapVotes;
  let reactionType: 'CONTINUATION' | 'REVERSAL' | 'TRAP' | 'NEUTRAL' = 'NEUTRAL';
  if (totalVotes > 0) {
    if (trapVotes >= 2 || (trapVotes > 0 && reversalVotes > continuationVotes)) {
      reactionType = 'TRAP';
    } else if (reversalVotes > continuationVotes) {
      reactionType = 'REVERSAL';
    } else if (continuationVotes > reversalVotes) {
      reactionType = 'CONTINUATION';
    }
  }

  const confidence = Math.min(95, Math.round(50 + score * 3));

  console.log(`[REACTION ENGINE] ${direction}: Score=${score.toFixed(2)} Rev=${reversalVotes} Cont=${continuationVotes} Trap=${trapVotes} Type=${reactionType} Factors=${factors.length}`);

  return { score, factors, reactionType, confidence };
}

// ============= FAST AI DIRECTION CALL (AI-OFF MODE) =============
// Makes a tiny Gemini call using all available keys.
// Only used when AI mode is OFF — just picks CALL or PUT from code analysis.
const FAST_AI_KEY_NAMES = [
  'GEMINI_API_KEY','GEMINI_API_KEY_2','GEMINI_API_KEY_3','GEMINI_API_KEY_4','GEMINI_API_KEY_5',
  'GEMINI_API_KEY_6','GEMINI_API_KEY_7','GEMINI_API_KEY_8','GEMINI_API_KEY_9','GEMINI_API_KEY_10',
  'GEMINI_API_KEY_11','GEMINI_API_KEY_12','GEMINI_API_KEY_13','GEMINI_API_KEY_14','GEMINI_API_KEY_15',
  'GEMINI_API_KEY_16','GEMINI_API_KEY_17','GEMINI_API_KEY_18','GEMINI_API_KEY_19','GEMINI_API_KEY_20',
  'GEMINI_API_KEY_21','GEMINI_API_KEY_22','GEMINI_API_KEY_23','GEMINI_API_KEY_24','GEMINI_API_KEY_25',
];

function getAllFastKeys(): string[] {
  return FAST_AI_KEY_NAMES
    .map(n => {
      const raw = Deno.env.get(n) ?? '';
      return raw.replace(/[\s\u200B-\u200D\uFEFF]/g,'').trim();
    })
    .filter(k => k.startsWith('AIza') && k.length >= 20);
}

async function callFastGeminiDirection(prompt: string, timeoutMs: number = 22000): Promise<'CALL' | 'PUT' | null> {
  const model = 'gemini-2.5-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
  const keys = getAllFastKeys();
  if (keys.length === 0) return null;

  // Build body once — large prompt but tiny response (just CALL or PUT)
  const reqBody = JSON.stringify({
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    generationConfig: { temperature: 0.05, maxOutputTokens: 16 },
  });

  // Race all available keys (up to 25), first valid CALL/PUT wins
  const attempts = keys.slice(0, 25).map(async (key) => {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(`${url}?key=${key}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: reqBody,
        signal: ctrl.signal,
      });
      clearTimeout(t);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const text = (data?.candidates?.[0]?.content?.parts?.[0]?.text ?? '').trim().toUpperCase();
      if (text.startsWith('CALL') || text === 'CALL') return 'CALL' as const;
      if (text.startsWith('PUT')  || text === 'PUT')  return 'PUT'  as const;
      // Also handle responses like "The answer is CALL" 
      if (text.includes('CALL')) return 'CALL' as const;
      if (text.includes('PUT'))  return 'PUT'  as const;
      throw new Error('No direction in response');
    } catch (e) {
      clearTimeout(t);
      throw e;
    }
  });

  try {
    return await Promise.any(attempts);
  } catch {
    return null;
  }
}

// ============= MAIN HTTP HANDLER =============

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const { market, action, entryPrice, direction } = body;

    // Handle chart data request
    if (action === 'get-chart-data') {
      if (!market) {
        return new Response(
          JSON.stringify({ success: false, error: 'market is required for get-chart-data' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      try {
        console.log(`[get-chart-data] Fetching data for market: ${market}, isOTC: ${isOTCMarket(market)}`);
        
        let candles: { datetime: string; open: number; high: number; low: number; close: number }[] = [];
        
        if (isOTCMarket(market)) {
          // Fetch a larger buffer so we can reconstruct a continuous 50-candle window
          const quotexCandles = await fetchQuotexOTCCandles(market, 500);
          candles = buildNormalizedOtcChartCandles(quotexCandles, 50, 10);
        } else {
          const oandaCandles = await fetchOandaCandles(market, 'M1', 300);
          candles = oandaCandles.map((c: OandaCandle) => ({
            datetime: c.time,
            open: parseFloat(c.mid.o),
            high: parseFloat(c.mid.h),
            low: parseFloat(c.mid.l),
            close: parseFloat(c.mid.c),
          }));
        }

        return new Response(
          JSON.stringify({ 
            success: true, 
            candles,
            market,
            count: candles.length,
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      } catch (chartError) {
        console.error('Chart data error:', chartError);
        return new Response(
          JSON.stringify({ 
            success: false, 
            error: chartError instanceof Error ? chartError.message : 'Failed to fetch chart data',
          }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // Handle manual outcome recording
    if (action === 'record-outcome') {
      const { result, reasoning } = body;
      
      if (!market || !direction || !result) {
        return new Response(
          JSON.stringify({ success: false, error: 'market, direction, and result are required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      addToSelfCorrection({
        market,
        direction,
        entryPrice: entryPrice || 0,
        exitPrice: 0,
        result,
        reason: result === 'LOSS' ? (reasoning || 'Market moved against signal') : 'Signal confirmed',
        timestamp: new Date().toISOString(),
        setup: reasoning || 'Manual Entry',
        indicators: [],
        htfBias: 'Unknown',
        m1Smc: 'Unknown',
      });
      
      const insights = getSelfCorrectionInsights(market);
      const outcomes = selfCorrectionMemory.get(market) || [];
      const wins = outcomes.filter(o => o.result === 'WIN').length;
      const losses = outcomes.filter(o => o.result === 'LOSS').length;
      const winRate = outcomes.length > 0 ? (wins / outcomes.length * 100) : 0;
      
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: `${result} recorded for ${market}`,
          stats: { total: outcomes.length, wins, losses, winRate: winRate.toFixed(1) },
          insights: insights || null,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Handle check-result action
    if (action === 'check-result') {
      const { entryTime, expiryTime, lastTrade } = body;

      if (!market || !direction || !entryTime || !expiryTime) {
        return new Response(
          JSON.stringify({ success: false, error: 'market, direction, entryTime, and expiryTime are required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const entryMs = new Date(entryTime).getTime();
      const expiryMs = new Date(expiryTime).getTime();
      if (!Number.isFinite(entryMs) || !Number.isFinite(expiryMs)) {
        return new Response(
          JSON.stringify({ success: false, error: 'Invalid entryTime or expiryTime' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const entryStartMs = Math.floor(entryMs / 60000) * 60000;
      const expiryStartMs = Math.floor(expiryMs / 60000) * 60000;
      // MTG-by-window ONLY fires when the frontend explicitly requests it via body.checkMtgWindow.
      // Auto mode does NOT set this — the 120s expiry is just a wait buffer, not an MTG request.
      const wantsMtgWindow = body.checkMtgWindow === true;
      const expectedCloseMs = entryStartMs + (wantsMtgWindow ? 120000 : 60000);
      const nowMs = Date.now();

      // ============= STABILIZATION DELAY FOR FAST CANDLES =============
      // OTC APIs can lag 2-5 seconds after candle close. Wait if we're too early.
      const stabilizationBuffer = 5000; // 5 seconds
      const safeReadTime = expectedCloseMs + stabilizationBuffer;
      if (nowMs < safeReadTime) {
        const waitMs = Math.min(safeReadTime - nowMs, 8000); // cap at 8s
        console.log(`[CHECK-RESULT] Waiting ${waitMs}ms for candle data to stabilize...`);
        await new Promise(resolve => setTimeout(resolve, waitMs));
      }

      // ============= INTEGER TICK ARITHMETIC FOR PRECISION =============
      // Convert prices to integer ticks to avoid IEEE 754 rounding errors.
      // We use 8 decimal places (100M ticks per unit) which covers all forex/OTC pairs.
      const TICK_SCALE = 1e8;
      const toTicks = (price: number): bigint => BigInt(Math.round(price * TICK_SCALE));
      
      // Compute result using integer comparison (no floating-point epsilon needed)
      const computeResultFromTicks = (openTicks: bigint, closeTicks: bigint): 'win' | 'loss' => {
        const diff = closeTicks - openTicks;
        if (direction === 'CALL') return diff > 0n ? 'win' : 'loss';
        return diff < 0n ? 'win' : 'loss';
      };

      // Helper to fetch candles with retry
      const fetchCandlesWithRetry = async (retries = 2): Promise<OandaCandle[]> => {
        for (let attempt = 0; attempt <= retries; attempt++) {
          try {
            if (isOTCMarket(market)) {
              return await fetchQuotexOTCCandles(market, 100);
            } else {
              return await fetchOandaCandles(market, 'M1', 100);
            }
          } catch (e) {
            if (attempt === retries) throw e;
            await new Promise(r => setTimeout(r, 1000));
          }
        }
        throw new Error('Fetch failed after retries');
      };

      try {
        // ============= DOUBLE-FETCH VERIFICATION FOR HIGH-VOLUME CANDLES =============
        // Fetch twice with a short delay to catch unstable/lagging data
        const candles1 = await fetchCandlesWithRetry();
        
        const normalize = (c: OandaCandle[]) => c
          .filter((x) => Number.isFinite(new Date(x.time).getTime()))
          .map((x) => ({
            candle: x,
            startMs: Math.floor(new Date(x.time).getTime() / 60000) * 60000,
          }))
          .sort((a, b) => a.startMs - b.startMs);

        let candidates = normalize(candles1);
        let trade = candidates.find((x) => x.startMs === entryStartMs);

        // If trade not found or we want extra verification, wait and re-fetch
        if (!trade || wantsMtgWindow) {
          await new Promise(r => setTimeout(r, 2000));
          const candles2 = await fetchCandlesWithRetry();
          const candidates2 = normalize(candles2);
          const trade2 = candidates2.find((x) => x.startMs === entryStartMs);
          
          // Use second fetch if it has the trade or if prices differ (prefer latest)
          if (trade2) {
            const close1 = trade ? parseFloat(trade.candle.mid.c) : 0;
            const close2 = parseFloat(trade2.candle.mid.c);
            if (!trade || Math.abs(close2 - close1) > 1e-10) {
              console.log(`[CHECK-RESULT] Using second fetch (price stabilized: ${close1} -> ${close2})`);
              candidates = candidates2;
              trade = trade2;
            }
          }
        }

        if (!trade) {
          return new Response(
            JSON.stringify({
              success: false,
              error: Date.now() < expectedCloseMs
                ? 'Trade candle not closed yet'
                : 'Trade candle not available yet',
            }),
            { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        const candleOpen = parseFloat(trade.candle.mid.o);
        const candleClose = parseFloat(trade.candle.mid.c);
        const candleTime = trade.candle.time;

        // ============= BINARY OPTIONS RESULT: CANDLE OPEN vs CANDLE CLOSE =============
        // In binary options (OTC M1), the result is determined by whether the candle
        // CLOSES above or below its OPENING price in the signal's direction.
        // The client-sent entryPrice is STALE — it's captured BEFORE the 3-minute analysis
        // delay and does NOT reflect the actual candle open. Using it causes win/loss swaps.
        // FIX: ALWAYS use the candle's actual open price for result verification.
        const actualEntryPrice = candleOpen;

        // Convert to integer ticks for precise comparison
        const entryTicks = toTicks(actualEntryPrice);
        const closeTicks = toTicks(candleClose);
        const baseResult = computeResultFromTicks(entryTicks, closeTicks);

        console.log(`[CHECK-RESULT] ${market} ${direction}: Entry=${actualEntryPrice} Close=${candleClose} Diff=${candleClose - actualEntryPrice} Result=${baseResult}`);

        // Default to the main trade candle
        let reportOpen = actualEntryPrice;
        let reportClose = candleClose;
        let reportCandleTime = candleTime;

        // Final result can be MTG if we waited for 2 candles and recovery candle wins.
        let finalResult: 'win' | 'loss' | 'mtg' = baseResult;
        let isMTG = false;

        // MTG-by-window (single-signal): only if first candle is LOSS and the NEXT candle is WIN.
        if (wantsMtgWindow && baseResult === 'loss') {
          const recoveryStartMs = entryStartMs + 60000;
          const recovery = candidates.find((x) => x.startMs === recoveryStartMs);

          if (!recovery) {
            return new Response(
              JSON.stringify({
                success: false,
                error: Date.now() < expectedCloseMs
                  ? 'MTG candle not closed yet'
                  : 'MTG candle not available yet',
              }),
              { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
            );
          }

          const recoveryOpen = parseFloat(recovery.candle.mid.o);
          const recoveryClose = parseFloat(recovery.candle.mid.c);
          const recoveryOpenTicks = toTicks(recoveryOpen);
          const recoveryCloseTicks = toTicks(recoveryClose);
          const recoveryResult = computeResultFromTicks(recoveryOpenTicks, recoveryCloseTicks);

          if (recoveryResult === 'win') {
            finalResult = 'mtg';
            isMTG = true;
            reportOpen = recoveryOpen;
            reportClose = recoveryClose;
            reportCandleTime = recovery.candle.time;
            console.log(`[CHECK-RESULT] MTG WIN detected for ${market}: LOSS at ${candleTime}, WIN at ${reportCandleTime}`);
          }
        }

        // MTG-by-history (multi-signal): preserve existing behavior when lastTrade is provided.
        if (!isMTG && lastTrade && baseResult === 'win' && lastTrade.result === 'LOSS' && lastTrade.direction === direction) {
          const lastCandleTime = new Date(lastTrade.candleTime).getTime();
          const currentCandleTime = new Date(candleTime).getTime();
          const timeDiff = currentCandleTime - lastCandleTime;

          // MTG recovery: WIN exactly 60 seconds after a LOSS in the same direction
          if (timeDiff === 60 * 1000) {
            finalResult = 'mtg';
            isMTG = true;
            console.log(`[CHECK-RESULT] MTG WIN (history) for ${market}! Previous LOSS at ${lastTrade.candleTime}, current WIN at ${candleTime}`);
          }
        }
        
        const outcomeResult: 'WIN' | 'LOSS' | 'MTG' = finalResult === 'mtg' ? 'MTG' : (finalResult === 'win' ? 'WIN' : 'LOSS');
        addToSelfCorrection({
          market,
          direction,
          entryPrice: reportOpen,
          exitPrice: reportClose,
          result: outcomeResult,
          reason: outcomeResult === 'LOSS' ? 'Market moved against signal' : (outcomeResult === 'MTG' ? 'MTG recovery' : 'Signal confirmed'),
          timestamp: new Date().toISOString(),
          setup: 'Code-Based Signal',
          indicators: [],
          htfBias: 'Unknown',
          m1Smc: 'Unknown',
        });

        const outcomes = selfCorrectionMemory.get(market) || [];
        const wins = outcomes.filter(o => o.result === 'WIN').length;
        const mtgWins = outcomes.filter(o => o.result === 'MTG').length;
        const losses = outcomes.filter(o => o.result === 'LOSS').length;
        const winRatePct = outcomes.length > 0 ? ((wins + mtgWins) / outcomes.length * 100) : 0;

        return new Response(
          JSON.stringify({
            success: true,
            result: finalResult,
            isMTG,
            entryPrice: reportOpen,
            currentPrice: reportClose,
            direction,
            market,
            candleTime: reportCandleTime,
            selfCorrectionInsights: getSelfCorrectionInsights(market),
            stats: { total: outcomes.length, wins, mtgWins, losses, winRate: winRatePct.toFixed(1) },
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      } catch (error) {
        console.error('[CHECK-RESULT] Error:', error);
        return new Response(
          JSON.stringify({ success: false, error: 'Failed to fetch current price' }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }
    
    // Handle fast-signal (AI-OFF mode): code-only + tiny AI direction call in ~60s
    if (action === 'fast-signal') {
      if (!market) {
        return new Response(JSON.stringify({ success: false, error: 'market required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }

      console.log(`[FAST-SIGNAL] Starting 60s code-based analysis for ${market}`);
      const fastStart = Date.now();

      let fastCandles: OandaCandle[];
      const fastSymbol = isOTCMarket(market) ? market : convertToOandaSymbol(market);

      try {
        if (isOTCMarket(market)) {
          const raw = await fetchQuotexOTCCandles(market, 600);
          fastCandles = raw.slice(0, -1); // exclude forming candle
        } else {
          fastCandles = await fetchOandaCandles(market, 'M1', 300);
        }
        if (fastCandles.length < 100) {
          return new Response(JSON.stringify({ success: false, error: 'Not enough data' }),
            { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
        }
      } catch (e) {
        return new Response(JSON.stringify({ success: false, error: String(e) }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }

      const fastM5 = aggregateCandles(fastCandles, 5);
      const fastM15 = aggregateCandles(fastCandles, 15);
      const fastMarketData = buildMarketDataForAI(fastCandles, fastSymbol);
      const fastM5Data = fastM5.length >= 10 ? buildMarketDataForAI(fastM5, `${fastSymbol}_M5`) : null;
      const fastM15Data = fastM15.length >= 5 ? buildMarketDataForAI(fastM15, `${fastSymbol}_M15`) : null;

      resetBlockedStrategies();
      const fastConditions = buildMarketConditionsForAvoidRules(fastMarketData, nowUTC6());

      // Run both directions
      const callResult = calculateNew7CategoryScore(fastMarketData, null, fastM15Data, fastM5Data, 'CALL', fastConditions);
      const putResult  = calculateNew7CategoryScore(fastMarketData, null, fastM15Data, fastM5Data, 'PUT',  fastConditions);
      const blockedList = getBlockedStrategies();
      const blockedCnts = getBlockedStrategyCounts();
      resetBlockedStrategies();

      // Bridge (last 150 candles) for stage 2
      const bridgeCandles = fastCandles.slice(-150);
      const bridgeData = buildMarketDataForAI(bridgeCandles, `${fastSymbol}_BR`);
      const bridgeCallResult = calculateNew7CategoryScore(bridgeData, null, null, null, 'CALL', fastConditions);
      const bridgePutResult  = calculateNew7CategoryScore(bridgeData, null, null, null, 'PUT',  fastConditions);
      resetBlockedStrategies();

      const finalCallScore = callResult.totalScore + bridgeCallResult.totalScore * 0.2;
      const finalPutScore  = putResult.totalScore  + bridgePutResult.totalScore  * 0.2;

      // Code-based direction
      let codeDirection: 'CALL' | 'PUT' = finalCallScore >= finalPutScore ? 'CALL' : 'PUT';
      let codeConfidence = Math.min(95, Math.max(50, 50 + Math.abs(finalCallScore - finalPutScore) * 4));

      // Scenario filter
      const fastRaw = (fastMarketData as any).raw as any;
      const smcBD  = callResult.categories.find(c => c.name.includes('SMC'));
      const htfBD  = callResult.categories.find(c => c.name.includes('HTF'));
      const liqBD  = callResult.categories.find(c => c.name.includes('Liquidity'));
      const indBD  = callResult.categories.find(c => c.name.includes('Algo-Trap'));
      const retBD  = callResult.categories.find(c => c.name.includes('235'));
      const smcBDp = putResult.categories.find(c => c.name.includes('SMC'));
      const htfBDp = putResult.categories.find(c => c.name.includes('HTF'));
      const liqBDp = putResult.categories.find(c => c.name.includes('Liquidity'));
      const indBDp = putResult.categories.find(c => c.name.includes('Algo-Trap'));
      const retBDp = putResult.categories.find(c => c.name.includes('235'));
      const scBreak = {
        smc:       { up: smcBD?.factors?.length || 0,  down: smcBDp?.factors?.length || 0 },
        htf:       { up: htfBD?.factors?.length || 0,  down: htfBDp?.factors?.length || 0 },
        liquidity: { up: liqBD?.factors?.length || 0,  down: liqBDp?.factors?.length || 0 },
        indicator: { up: indBD?.factors?.length || 0,  down: indBDp?.factors?.length || 0 },
        retail:    { up: callResult.matchedSetups?.length || 0, down: putResult.matchedSetups?.length || 0 },
      };
      const scResult = runScenarioFilter(scBreak);
      if (scResult) { codeDirection = scResult.signal; codeConfidence = parseInt(scResult.confidence); }

      // ── Build comprehensive AI prompt with ALL strategy details ──────────
      const getFacts = (cats: any[], nameHint: string, max = 8) =>
        (cats.find((c: any) => c.name.includes(nameHint))?.factors || []).slice(0, max);

      const callSMC     = getFacts(callResult.categories, 'SMC');
      const callLiq     = getFacts(callResult.categories, 'Liquidity');
      const callInd     = getFacts(callResult.categories, 'Algo-Trap');
      const callHTF     = getFacts(callResult.categories, 'HTF');
      const callPA      = getFacts(callResult.categories, 'Price Action');
      const callReact   = callResult.categories.find((c: any) => c.name.includes('Reaction'));
      const callSetups  = (callResult.matchedSetups || []).slice(0, 8).map((s: any) => `#${s.id}:${s.name}`);
      const callICT     = getFacts(callResult.categories, 'ICT');
      const callCont    = getFacts(callResult.categories, 'Continuation');
      const callRev     = getFacts(callResult.categories, 'Reversal');
      const callOTC     = getFacts(callResult.categories, 'OTC Trap');
      const callAlgoInt = getFacts(callResult.categories, 'ALGO');
      const callMTF     = getFacts(callResult.categories, 'Multi-Timeframe');

      const putSMC      = getFacts(putResult.categories, 'SMC');
      const putLiq      = getFacts(putResult.categories, 'Liquidity');
      const putInd      = getFacts(putResult.categories, 'Algo-Trap');
      const putHTF      = getFacts(putResult.categories, 'HTF');
      const putPA       = getFacts(putResult.categories, 'Price Action');
      const putReact    = putResult.categories.find((c: any) => c.name.includes('Reaction'));
      const putSetups   = (putResult.matchedSetups || []).slice(0, 8).map((s: any) => `#${s.id}:${s.name}`);
      const putICT      = getFacts(putResult.categories, 'ICT');
      const putCont     = getFacts(putResult.categories, 'Continuation');
      const putRev      = getFacts(putResult.categories, 'Reversal');
      const putOTC      = getFacts(putResult.categories, 'OTC Trap');
      const putAlgoInt  = getFacts(putResult.categories, 'ALGO');
      const putMTF      = getFacts(putResult.categories, 'Multi-Timeframe');

      const callReactType  = callReact?.factors?.find((f: string) => f.startsWith('ReactionType:')) || '';
      const putReactType   = putReact?.factors?.find((f: string) => f.startsWith('ReactionType:'))  || '';
      const callReactFacts = (callReact?.factors || []).filter((f: string) => !f.startsWith('ReactionType:')).slice(0, 10);
      const putReactFacts  = (putReact?.factors  || []).filter((f: string) => !f.startsWith('ReactionType:')).slice(0, 10);

      const bridgeDir  = bridgeCallResult.totalScore >= bridgePutResult.totalScore ? 'CALL' : 'PUT';
      const bridgeDiff = Math.abs(bridgeCallResult.totalScore - bridgePutResult.totalScore).toFixed(2);

      const scoreTable = callResult.categories.map((cc: any) => {
        const pc = putResult.categories.find((p: any) => p.name === cc.name);
        return `  ${cc.name}: CALL=${cc.score.toFixed(2)} vs PUT=${pc?.score?.toFixed(2) ?? '0.00'}`;
      }).join('\n');

      const fastPrompt = `You are an expert OTC binary options algorithm analyst. Your ONLY output must be CALL or PUT — a single word, nothing else.

You have received COMPLETE code-based strategy analysis results for market: ${market}
Current Price: ${fastMarketData.currentPrice} | UTC+6: ${nowUTC6().toISOString()}

MARKET STATE:
Trend: ${fastMarketData.trend.emaAlignment} | ADX: ${fastMarketData.trend.adx.toFixed(1)} | RSI14: ${fastMarketData.momentum.rsi14.toFixed(1)} | RSI7: ${fastMarketData.momentum.rsi7.toFixed(1)}
Structure: ${fastMarketData.smc.marketStructure} | Zone: ${fastMarketData.smc.premiumDiscount} | BOS: ${fastMarketData.smc.lastBOS || 'none'}
BB: ${fastMarketData.volatility.bollinger.position} | MACD: ${fastMarketData.momentum.macd.crossover} | Stoch K: ${fastMarketData.momentum.stochastic.k.toFixed(1)}
Consecutive same-color: ${fastMarketData.priceAction.consecutiveSameColor} | Patterns: ${fastMarketData.priceAction.patterns.join(', ') || 'none'}

TOTAL SCORES: CALL=${finalCallScore.toFixed(3)} vs PUT=${finalPutScore.toFixed(3)} → score winner: ${finalCallScore > finalPutScore ? 'CALL' : 'PUT'}

CATEGORY BREAKDOWN:
${scoreTable}

SCENARIO FILTER (100 strategies):
${scResult ? `MATCHED #${scResult.strategyNumber}: "${scResult.strategyName}" → ${scResult.signal} (${scResult.confidence}) | Logic: ${scResult.logic}` : 'No scenario matched — pure score'}

CODE DIRECTION: ${codeDirection} at ${codeConfidence}% | Bridge (150 candles): ${bridgeDir} margin=${bridgeDiff}

35 REACTION STRATEGIES — CALL (type: ${callReactType} score: ${callReact?.score?.toFixed(2) ?? '0'}):
${callReactFacts.length > 0 ? callReactFacts.join('\n') : 'none'}

35 REACTION STRATEGIES — PUT (type: ${putReactType} score: ${putReact?.score?.toFixed(2) ?? '0'}):
${putReactFacts.length > 0 ? putReactFacts.join('\n') : 'none'}

OTC ALGORITHM TRAP DETECTION:
CALL traps: ${callOTC.join(' | ') || 'none'}
PUT traps:  ${putOTC.join(' | ') || 'none'}

ALGO INTELLIGENCE (pattern recycling/autocorr):
CALL: ${callAlgoInt.join(' | ') || 'none'}
PUT:  ${putAlgoInt.join(' | ') || 'none'}

CONTINUATION SIGNALS:
CALL: ${callCont.join(' | ') || 'none'}
PUT:  ${putCont.join(' | ') || 'none'}

REVERSAL SIGNALS:
CALL: ${callRev.join(' | ') || 'none'}
PUT:  ${putRev.join(' | ') || 'none'}

SMC (Smart Money Concepts):
CALL(${callResult.categories.find((c:any)=>c.name.includes('SMC'))?.score?.toFixed(2)??'0'}): ${callSMC.join(' | ') || 'none'}
PUT (${putResult.categories.find((c:any)=>c.name.includes('SMC'))?.score?.toFixed(2)??'0'}): ${putSMC.join(' | ') || 'none'}

LIQUIDITY TRAPS (35 OTC):
CALL(${callResult.categories.find((c:any)=>c.name.includes('Liquidity'))?.score?.toFixed(2)??'0'}): ${callLiq.join(' | ') || 'none'}
PUT (${putResult.categories.find((c:any)=>c.name.includes('Liquidity'))?.score?.toFixed(2)??'0'}): ${putLiq.join(' | ') || 'none'}

INDICATORS (42 Algo-Trap):
CALL: ${callInd.join(' | ') || 'none'}
PUT:  ${putInd.join(' | ') || 'none'}

HTF (Higher Timeframe):
CALL: ${callHTF.join(' | ') || 'none'}
PUT:  ${putHTF.join(' | ') || 'none'}

MULTI-TIMEFRAME (M5+M15):
CALL: ${callMTF.join(' | ') || 'none'}
PUT:  ${putMTF.join(' | ') || 'none'}

ICT CONCEPTS:
CALL: ${callICT.join(' | ') || 'none'}
PUT:  ${putICT.join(' | ') || 'none'}

235 SETUP MATCHES:
CALL(${callResult.matchedSetups?.length||0}): ${callSetups.join(', ') || 'none'}
PUT (${putResult.matchedSetups?.length||0}): ${putSetups.join(', ') || 'none'}

PRICE ACTION:
CALL: ${callPA.join(' | ') || 'none'}
PUT:  ${putPA.join(' | ') || 'none'}

YOUR ANALYSIS TASK:
1. Are OTC traps present? Which direction do they trap?
2. Is reaction type REVERSAL or CONTINUATION? Any TRAP patterns?
3. Do SMC + Liquidity + HTF agree?
4. Does the Scenario Filter result override raw scores?
5. What is the overall weight of evidence?

Output ONLY one word — CALL or PUT:`;

      const aiDirection = await callFastGeminiDirection(fastPrompt, 22000);
      const finalDirection = aiDirection ?? codeDirection;
      const finalConf = aiDirection ? Math.min(95, codeConfidence + 5) : codeConfidence;

      const elapsed = Date.now() - fastStart;
      console.log(`[FAST-SIGNAL] Done in ${elapsed}ms: ${finalDirection} ${finalConf}% (code:${codeDirection} ai:${aiDirection ?? 'n/a'})`);

      return new Response(JSON.stringify({
        success: true,
        market,
        symbol: fastSymbol,
        payout: latestPayout.get(market) || null,
        candleCount: fastCandles.length,
        fastMode: true,
        aiDirection: aiDirection ?? null,
        codeDirection,
        elapsedMs: elapsed,
        selfCorrection: { insights: getSelfCorrectionInsights(market) || null, isActive: false },
        backtest: null,
        analysis: {
          direction: finalDirection,
          confidence: finalConf,
          currentPrice: fastMarketData.currentPrice,
          trend: fastMarketData.trend.emaAlignment,
          support: fastMarketData.levels.support,
          resistance: fastMarketData.levels.resistance,
          rsi: fastMarketData.momentum.rsi14,
          rsi7: fastMarketData.momentum.rsi7,
          stochastic: fastMarketData.momentum.stochastic,
          macdSignal: fastMarketData.momentum.macd.crossover,
          bollingerPosition: fastMarketData.volatility.bollinger.position,
          ema20: fastMarketData.trend.ema20,
          ema50: fastMarketData.trend.ema50,
          patterns: fastMarketData.priceAction.patterns,
          atr: fastMarketData.volatility.atr,
        },
        scoring: {
          totalScore: finalCallScore > finalPutScore ? finalCallScore : finalPutScore,
          callScore: finalCallScore,
          putScore: finalPutScore,
          categories: (finalDirection === 'CALL' ? callResult : putResult).categories,
          matchedSetups: ((finalDirection === 'CALL' ? callResult : putResult).matchedSetups || []).slice(0,10).map(s => ({ id: s.id, name: s.name })),
          filtered: false,
          filterReason: null,
          conflictAnalysis: (finalDirection === 'CALL' ? callResult : putResult).categories.length > 0 ? {
            hasInternalConflict: false, conflictPenalty: 0, hiddenTrapWarning: false,
            highRisk: false, conflictDetails: [], opposingSetups: [],
          } : null,
          blockedStrategies: blockedList,
          blockedCounts: blockedCnts,
          pillarAnalysis: null,
        },
        geminiAnalysis: {
          reasoning: `[FAST-MODE] Code:${codeDirection}(${codeConfidence}%) AI:${aiDirection ?? 'n/a'} → ${finalDirection} | Scenario:${scResult ? `#${scResult.strategyNumber}` : 'none'} | ${elapsed}ms`,
          htfBias: fastM15Data?.smc.marketStructure || null,
          m1Smc: fastMarketData.smc.marketStructure,
          setupCount: (finalDirection === 'CALL' ? callResult.matchedSetups : putResult.matchedSetups)?.length || 0,
          indicatorCount: 18,
          selfCorrectionApplied: false,
          backtestApplied: false,
        },
        marketData: {
          smc: fastMarketData.smc,
          indicators: { trend: fastMarketData.trend, momentum: fastMarketData.momentum, volatility: fastMarketData.volatility, volume: fastMarketData.volume },
        },
        pillar: null,
        fallback: false,
        codeBasedAnalysis: true,
        signalFiltered: false,
      }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    // ============= MAIN SIGNAL GENERATION =============
    if (!market) {
      return new Response(
        JSON.stringify({ error: 'Market is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // OPTION A: Wait for candle close before analyzing
    // This ensures we always use complete candle data, not a forming candle
    // SKIP WAIT when called from chart-analyzer (skipWait: true) to avoid timeout
    const skipWait = body.skipWait === true || body.source === 'chart-analyzer';
    
    if (!skipWait) {
      const now = new Date();
      const currentSecond = now.getSeconds();
      
      // If we're past second 5, wait for the NEXT candle to fully form and close
      // We wait until second 3-5 of the NEXT minute to ensure data is fully updated
      if (currentSecond > 5) {
        const secondsToWait = 60 - currentSecond + 5; // Wait until second 5 of next minute
        console.log(`[LIVE-SIGNAL] Waiting ${secondsToWait}s for current candle to close and data to stabilize (current second: ${currentSecond})`);
        await new Promise(resolve => setTimeout(resolve, secondsToWait * 1000));
        console.log(`[LIVE-SIGNAL] Candle closed and data stabilized, proceeding with analysis`);
      } else {
        console.log(`[LIVE-SIGNAL] Already at candle start (second: ${currentSecond}), proceeding immediately`);
      }
    } else {
      console.log(`[LIVE-SIGNAL] Skipping wait (called from chart-analyzer or skipWait=true)`);
    }

    console.log(`[LIVE-SIGNAL] Processing ${market} with 100% CODE-BASED LOGIC (No AI)`);

    let completeCandles: OandaCandle[];
    let m15Candles: OandaCandle[] = [];
    let h1Candles: OandaCandle[] = [];
    let symbol: string;

    if (isOTCMarket(market)) {
      symbol = market;
      try {
        const quotexCandles = await fetchQuotexOTCCandles(market, 2000);
        if (quotexCandles.length < 200) {
          return new Response(
            JSON.stringify({ error: 'Not enough OTC candle data' }),
            { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
        // CRITICAL: Remove the last candle as it's the currently forming one
        // We only want to analyze COMPLETED candles
        const rawCandles = quotexCandles.slice(0, -1);
        console.log(`[LIVE-SIGNAL] Using ${rawCandles.length} COMPLETE candles (excluded current forming candle)`);
        completeCandles = rawCandles;
        m15Candles = aggregateCandles(completeCandles, 15);
        h1Candles = aggregateCandles(completeCandles, 60);
        console.log(`[LIVE-SIGNAL] M5: ${aggregateCandles(completeCandles, 5).length} candles | M15: ${m15Candles.length} candles | H1: ${h1Candles.length} candles`);
      } catch (error) {
        return new Response(
          JSON.stringify({ error: `Quotex API error: ${error instanceof Error ? error.message : 'Unknown error'}` }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    } else {
      symbol = convertToOandaSymbol(market);
      try {
        const m1Candles = await fetchOandaCandles(market, 'M1', 500);
        if (m1Candles.length < 200) {
          return new Response(
            JSON.stringify({ error: 'Not enough candle data' }),
            { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
        completeCandles = m1Candles;
        m15Candles = aggregateCandles(completeCandles, 15);
        h1Candles = aggregateCandles(completeCandles, 60);
      } catch (error) {
        return new Response(
          JSON.stringify({ error: error instanceof Error ? error.message : 'Failed to fetch market data' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // Build market data
    const m5Candles = aggregateCandles(completeCandles, 5);
    const marketData = buildMarketDataForAI(completeCandles, symbol);
    const marketDataM5 = m5Candles.length >= 20 ? buildMarketDataForAI(m5Candles, `${symbol}_M5`) : null;
    const marketDataM15 = m15Candles.length >= 20 ? buildMarketDataForAI(m15Candles, `${symbol}_M15`) : null;
    const marketDataH1 = h1Candles.length >= 10 ? buildMarketDataForAI(h1Candles, `${symbol}_H1`) : null;

    // Get self-correction insights
    const selfCorrectionInsights = getSelfCorrectionInsights(market);
    
    // Run backtest for real market
    let backtestResults = null;
    if (!isOTCMarket(market) && completeCandles.length >= 500) {
      const callBacktest = backtestSignal(completeCandles, 'CALL', completeCandles.length - 1, 100);
      const putBacktest = backtestSignal(completeCandles, 'PUT', completeCandles.length - 1, 100);
      backtestResults = {
        call: callBacktest,
        put: putBacktest,
        recommendation: callBacktest.winRate > putBacktest.winRate ? 'CALL' : 'PUT',
      };
    }

    // ============= STAGE 1: PRIMARY SIGNAL GENERATION (FULL DEPTH) =============
    // Stage 1 uses ALL available candles (up to 2000 M1) for maximum depth analysis
    // All 7 code-based categories + all upgraded AI analyzing categories run at full power
    // HTF uses aggregated M5/M15/H1 from the FULL 2000 candle dataset for deep institutional context
    console.log(`[STAGE 1] Running FULL DEPTH QUANTUM-NEXUS analysis on ${completeCandles.length} M1 candles`);
    console.log(`[STAGE 1] HTF Context: M5=${m5Candles.length} | M15=${m15Candles.length} | H1=${h1Candles.length} (from ${completeCandles.length} M1 candles)`);
    
    const stage1Result = generateCodeBasedSignal(
      marketData,        // Full 2000 M1 candle marketData
      marketDataH1,      // H1 from full dataset
      marketDataM15,     // M15 from full dataset
      marketDataM5,      // M5 from full dataset
      market,
      backtestResults,
      selfCorrectionInsights
    );
    
    console.log(`[STAGE 1] Result: ${stage1Result.direction} | Confidence: ${stage1Result.confidence}% | Score: ${stage1Result.totalScore.toFixed(2)}`);
    console.log(`[STAGE 1] Categories: ${stage1Result.categories.map(c => `${c.name}:${c.score.toFixed(1)}`).join(' | ')}`);
    
    // ============= STAGE 2: BRIDGE CANDLE VALIDATION (RECENT FOCUS) =============
    // Stage 2 re-analyzes the most recent 200 candles ("bridge window") to validate Stage 1
    // This focuses on the NEWEST market behavior to predict the 4th candle's direction
    // Stage 2 runs IDENTICAL category depth to Stage 1 but on the bridge window
    // It builds its OWN M5/M15 from the bridge window for micro-HTF context
    // Stage 2 then CROSS-VALIDATES against Stage 1 direction
    let stage2Validated = false;
    let stage2Direction: string | null = null;
    let stage2Confidence = 0;
    let stage2Score = 0;
    
    if (completeCandles.length >= 300 && stage1Result.direction !== 'NO_SIGNAL') {
      const bridgeCandles = completeCandles.slice(-200);
      const bridgeM5 = aggregateCandles(bridgeCandles, 5);
      const bridgeM15 = aggregateCandles(bridgeCandles, 15);
      const bridgeH1 = aggregateCandles(bridgeCandles, 60);
      
      // Build bridge-specific market data with its own volume, OBV, VWAP calculations
      const bridgeMarketData = buildMarketDataForAI(bridgeCandles, `${symbol}_BRIDGE`);
      const bridgeM5Data = bridgeM5.length >= 10 ? buildMarketDataForAI(bridgeM5, `${symbol}_BRIDGE_M5`) : null;
      const bridgeM15Data = bridgeM15.length >= 5 ? buildMarketDataForAI(bridgeM15, `${symbol}_BRIDGE_M15`) : null;
      const bridgeH1Data = bridgeH1.length >= 3 ? buildMarketDataForAI(bridgeH1, `${symbol}_BRIDGE_H1`) : null;
      
      console.log(`[STAGE 2] Running BRIDGE VALIDATION on last 200 candles`);
      console.log(`[STAGE 2] Bridge HTF: M5=${bridgeM5.length} | M15=${bridgeM15.length} | H1=${bridgeH1.length}`);
      
      const stage2Result = generateCodeBasedSignal(
        bridgeMarketData,
        bridgeH1Data,       // Bridge H1 for micro-HTF context
        bridgeM15Data,
        bridgeM5Data,
        market,
        null,               // No backtest for bridge (uses Stage 1's backtest)
        null                // No self-correction for bridge
      );
      
      stage2Direction = stage2Result.direction;
      stage2Confidence = stage2Result.confidence;
      stage2Score = stage2Result.totalScore;
      
      console.log(`[STAGE 2] Result: ${stage2Direction} | Confidence: ${stage2Confidence}% | Score: ${stage2Score.toFixed(2)}`);
      
      // ============= STAGE 2 CROSS-VALIDATION WITH STAGE 1 =============
      if (stage2Result.direction === stage1Result.direction) {
        // ✅ DUAL STAGE CONFIRMED — Both stages agree on direction
        stage2Validated = true;
        
        // Confidence boost based on Stage 2 strength
        // Strong Stage 2 (>70%) = +8% boost, Medium (50-70%) = +5%, Weak (<50%) = +3%
        const boostTier = stage2Confidence >= 70 ? 8 : stage2Confidence >= 50 ? 5 : 3;
        stage1Result.confidence = Math.min(95, stage1Result.confidence + boostTier);
        
        // Score boost: merge Stage 2 score contribution (20% weight)
        stage1Result.totalScore += stage2Score * 0.2;
        
        console.log(`[STAGE 2] ✅ DUAL CONFIRMED: ${stage2Result.direction} (S2: ${stage2Confidence}%) → Boosted +${boostTier}% → ${stage1Result.confidence}%`);
        
        // Add Stage 2 category insights to reasoning
        const s2TopCats = stage2Result.categories
          .filter(c => c.score > 0)
          .sort((a, b) => b.score - a.score)
          .slice(0, 3)
          .map(c => `${c.name}:${c.score.toFixed(1)}`)
          .join(', ');
        
        stage1Result.reasoning += ` || STAGE2 ✅ CONFIRMED (${stage2Confidence}%): Top→[${s2TopCats}]`;
        
      } else if (stage2Result.direction !== 'NO_SIGNAL') {
        // ⚠️ STAGE CONFLICT — Stage 2 disagrees with Stage 1
        // Apply penalty proportional to Stage 2's confidence
        const penaltyTier = stage2Confidence >= 70 ? 12 : stage2Confidence >= 50 ? 8 : 5;
        stage1Result.confidence = Math.max(30, stage1Result.confidence - penaltyTier);
        
        // If Stage 2 is significantly stronger than Stage 1, consider override
        if (stage2Score > stage1Result.totalScore * 1.3 && stage2Confidence > stage1Result.confidence + 10) {
          // Stage 2 override — recent data strongly disagrees
          console.log(`[STAGE 2] 🔄 BRIDGE OVERRIDE: Stage2 (${stage2Score.toFixed(2)}) >> Stage1 (${stage1Result.totalScore.toFixed(2)})`);
          stage1Result.direction = stage2Result.direction;
          stage1Result.confidence = Math.min(85, stage2Confidence - 5); // Slightly reduced for override
          stage1Result.reasoning += ` || STAGE2 🔄 OVERRIDE: S2=${stage2Direction}(${stage2Confidence}%) dominated S1`;
        } else {
          console.log(`[STAGE 2] ⚠️ BRIDGE CONFLICT: S1=${stage1Result.direction} vs S2=${stage2Direction} → Penalty -${penaltyTier}% → ${stage1Result.confidence}%`);
          stage1Result.reasoning += ` || STAGE2 ⚠️ CONFLICT: S2=${stage2Direction}(${stage2Confidence}%) vs S1=${stage1Result.direction}`;
        }
        
      } else {
        // Stage 2 returned NO_SIGNAL — neutral, minor penalty
        stage1Result.confidence = Math.max(35, stage1Result.confidence - 3);
        console.log(`[STAGE 2] ℹ️ BRIDGE NO SIGNAL: S2 couldn't determine direction → Minor -3%`);
        stage1Result.reasoning += ` || STAGE2 ℹ️ NO_SIGNAL (bridge inconclusive)`;
      }
    } else {
      console.log(`[STAGE 2] Skipped (${completeCandles.length < 300 ? 'insufficient candles' : 'Stage 1 NO_SIGNAL'})`);
    }
    
    // ============= FINAL SIGNAL = STAGE 1 (validated/modified by Stage 2) =============
    const signalResult = stage1Result;

    const fmt = (n: number) => symbol.includes('JPY') ? n.toFixed(3) : n.toFixed(5);

    return new Response(
      JSON.stringify({
        success: true,
        market,
        symbol,
        payout: latestPayout.get(market) || null,
        candleCount: completeCandles.length,
        selfCorrection: {
          insights: selfCorrectionInsights || null,
          isActive: !!selfCorrectionInsights,
        },
        backtest: backtestResults ? {
          call: backtestResults.call,
          put: backtestResults.put,
          recommendation: backtestResults.recommendation,
        } : null,
        analysis: {
          direction: signalResult.direction,
          confidence: signalResult.confidence,
          currentPrice: marketData.currentPrice,
          trend: marketData.trend.emaAlignment,
          support: marketData.levels.support,
          resistance: marketData.levels.resistance,
          rsi: marketData.momentum.rsi14,
          rsi7: marketData.momentum.rsi7,
          stochastic: marketData.momentum.stochastic,
          macdSignal: marketData.momentum.macd.crossover,
          bollingerPosition: marketData.volatility.bollinger.position,
          ema20: marketData.trend.ema20,
          ema50: marketData.trend.ema50,
          patterns: marketData.priceAction.patterns,
          atr: marketData.volatility.atr,
        },
        // New 7-category scoring breakdown with conflict analysis
        scoring: {
          totalScore: signalResult.totalScore,
          callScore: signalResult.callScore,
          putScore: signalResult.putScore,
          categories: signalResult.categories,
          matchedSetups: (signalResult.matchedSetups || []).slice(0, 10).map(s => ({ id: s.id, name: s.name })),
          filtered: signalResult.filtered || false,
          filterReason: signalResult.filterReason || null,
        // NEW: Conflict analysis data
          conflictAnalysis: signalResult.conflictAnalysis,
          // NEW: Blocked strategies from avoid rules validation with CALL/PUT counts
          blockedStrategies: getBlockedStrategies(),
          blockedCounts: getBlockedStrategyCounts(),
          // 4-Pillar Trend Engine analysis
          pillarAnalysis: signalResult.pillarAnalysis || null,
        },
        geminiAnalysis: {
          reasoning: signalResult.reasoning,
          htfBias: marketDataH1?.smc.marketStructure || null,
          m1Smc: marketData.smc.marketStructure,
          setupCount: (signalResult.matchedSetups || []).length,
          indicatorCount: 18,
          selfCorrectionApplied: !!selfCorrectionInsights,
          backtestApplied: !!backtestResults,
        },
        marketData: {
          smc: marketData.smc,
          indicators: {
            trend: marketData.trend,
            momentum: marketData.momentum,
            volatility: marketData.volatility,
            volume: marketData.volume,
          },
        },
        // 4-Pillar trend info at top level for easy access
        pillar: signalResult.pillarAnalysis || null,
        fallback: false,
        codeBasedAnalysis: true,
        signalFiltered: signalResult.filtered || false,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in live-signal function:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
