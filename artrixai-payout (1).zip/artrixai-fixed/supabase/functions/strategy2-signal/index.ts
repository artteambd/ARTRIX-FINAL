import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { OTC_API_BASE, extractApiTime, extractApiVolume, parseQuotexCandles } from "../_shared/quotex.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// ═══════════════════════════════════════════════════════════
// STRATEGY 2 — FULL 9-STRATEGY + LIQ(6) + SMC(5) + HTF(7) ENGINE
// Python-parity port: all avoid rules, Tier-2 cancel guard, 2/3 gate
// ═══════════════════════════════════════════════════════════

interface Candle {
  open: number; high: number; low: number; close: number; volume: number; time: string;
}

interface Signal {
  direction: 'CALL' | 'PUT';
  strategy: string;
  pair: string;
  price: number;
  confidence: number;
  notes: string;
  rsi: number;
  emaFast: number;
  emaSlow: number;
  maTrend: string;
}

const STOCK_OTC_MAP: Record<string, string> = {
  'AXP-OTC': 'AXP_otc', 'PFE-OTC': 'PFE_otc', 'INTL-OTC': 'INTL_otc',
  'JNJ-OTC': 'JNJ_otc', 'MCD-OTC': 'MCD_otc', 'FB-OTC': 'FB_otc',
  'BA-OTC': 'BA_otc', 'MSFT-OTC': 'MSFT_otc',
  'USCrude-OTC': 'USCrude_otc', 'UKBrent-OTC': 'UKBrent_otc', 'FLOUSD-OTC': 'FLOUSD_otc',
};

// ═══════════════════════════════════════════════════════════
// DATA FETCHING — 2000 M1 candles
// ═══════════════════════════════════════════════════════════

async function fetchCandles(pair: string, count = 2000): Promise<Candle[]> {
  const apiPair = STOCK_OTC_MAP[pair] || pair.replace('-OTC', '_otc');
  const url = `${OTC_API_BASE}?pair=${encodeURIComponent(apiPair)}&timeframe=M1&count=${count}`;
  console.log(`[S2] Fetching ${count} candles: ${url}`);
  let response: Response | null = null;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      response = await fetch(url, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Lovable Cloud)', 'Accept': 'application/json' }
      });
      if (response.ok) break;
      if (attempt < 3) await new Promise(r => setTimeout(r, 400 * attempt));
    } catch (e: any) {
      if (attempt === 3) throw new Error(`Fetch failed: ${e.message}`);
      await new Promise(r => setTimeout(r, 400 * attempt));
    }
  }
  if (!response || !response.ok) throw new Error('Data source request failed');
  const raw = await response.text();
  let json = raw.trim();
  if (raw.includes('<html') || raw.startsWith('<')) {
    const s1 = raw.indexOf('['), e1 = raw.lastIndexOf(']');
    const s2 = raw.indexOf('{'), e2 = raw.lastIndexOf('}');
    if (s1 !== -1 && e1 > s1) json = raw.slice(s1, e1 + 1);
    else if (s2 !== -1 && e2 > s2) json = raw.slice(s2, e2 + 1);
    else throw new Error('Invalid data format');
  }
  if (!json) throw new Error('Empty response');
  const rows = parseQuotexCandles(json);
  if (!rows || rows.length === 0) throw new Error('No data');
  const candles: Candle[] = rows.map((c: any) => ({
    open: Number(c.open ?? c.o ?? 0), high: Number(c.high ?? c.h ?? 0),
    low: Number(c.low ?? c.l ?? 0), close: Number(c.close ?? c.c ?? 0),
    volume: extractApiVolume(c), time: extractApiTime(c),
  }));
  candles.sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime());
  const nonZeroVol = candles.filter(c => c.volume > 0).length;
  console.log(`[S2] ${pair}: ${candles.length} candles, ${nonZeroVol} with volume`);
  return candles;
}

// ═══════════════════════════════════════════════════════════
// HTF CANDLE AGGREGATION — M1 → M5, M15
// ═══════════════════════════════════════════════════════════

function aggregateCandles(candles: Candle[], period: number): Candle[] {
  const result: Candle[] = [];
  for (let i = 0; i <= candles.length - period; i += period) {
    const chunk = candles.slice(i, i + period);
    result.push({
      open: chunk[0].open, high: Math.max(...chunk.map(c => c.high)),
      low: Math.min(...chunk.map(c => c.low)), close: chunk[chunk.length - 1].close,
      volume: chunk.reduce((s, c) => s + c.volume, 0), time: chunk[0].time,
    });
  }
  return result;
}

// ═══════════════════════════════════════════════════════════
// INDICATOR CALCULATIONS — Full port from indicators_2.py
// ═══════════════════════════════════════════════════════════

function ema(data: number[], period: number): number[] {
  const r: number[] = []; if (!data.length) return r;
  const k = 2 / (period + 1); r[0] = data[0];
  for (let i = 1; i < data.length; i++) r[i] = data[i] * k + r[i - 1] * (1 - k);
  return r;
}

function sma(data: number[], period: number): number[] {
  const r: number[] = new Array(data.length).fill(0);
  for (let i = period - 1; i < data.length; i++) {
    let s = 0; for (let j = i - period + 1; j <= i; j++) s += data[j];
    r[i] = s / period;
  }
  return r;
}

function rsiCalc(data: number[], period: number): number[] {
  const r: number[] = new Array(data.length).fill(50);
  if (data.length < period + 1) return r;
  let gSum = 0, lSum = 0;
  for (let i = 1; i <= period; i++) {
    const d = data[i] - data[i - 1];
    if (d > 0) gSum += d; else lSum += Math.abs(d);
  }
  let avgG = gSum / period, avgL = lSum / period;
  r[period] = avgL === 0 ? 100 : 100 - 100 / (1 + avgG / avgL);
  for (let i = period + 1; i < data.length; i++) {
    const d = data[i] - data[i - 1];
    avgG = (avgG * (period - 1) + (d > 0 ? d : 0)) / period;
    avgL = (avgL * (period - 1) + (d < 0 ? Math.abs(d) : 0)) / period;
    r[i] = avgL === 0 ? 100 : 100 - 100 / (1 + avgG / avgL);
  }
  return r;
}

function hma(data: number[], period: number): number[] {
  const half = Math.max(1, Math.floor(period / 2));
  const sqrtN = Math.max(1, Math.round(Math.sqrt(period)));
  function wma(arr: number[], p: number): number[] {
    const r: number[] = new Array(arr.length).fill(NaN);
    for (let i = p - 1; i < arr.length; i++) {
      let wSum = 0, wt = 0;
      for (let j = 0; j < p; j++) { const w = j + 1; wSum += arr[i - p + 1 + j] * w; wt += w; }
      r[i] = wSum / wt;
    }
    return r;
  }
  const wH = wma(data, half), wF = wma(data, period);
  const diff = wH.map((v, i) => 2 * v - wF[i]);
  return wma(diff, sqrtN);
}

function tema(data: number[], period: number): number[] {
  const e1 = ema(data, period), e2 = ema(e1, period), e3 = ema(e2, period);
  return e1.map((v, i) => 3 * v - 3 * e2[i] + e3[i]);
}

function mcginleyDynamic(data: number[], period: number): number[] {
  const r: number[] = new Array(data.length).fill(NaN);
  let start = 0;
  while (start < data.length && isNaN(data[start])) start++;
  if (start >= data.length) return r;
  r[start] = data[start];
  for (let i = start + 1; i < data.length; i++) {
    const prev = r[i - 1], curr = data[i];
    if (isNaN(curr) || prev === 0) { r[i] = isNaN(prev) ? curr : prev; continue; }
    const ratio = curr / prev;
    r[i] = prev + (curr - prev) / (period * Math.pow(ratio, 4) + 1e-10);
  }
  return r;
}

function fisherTransform(highs: number[], lows: number[], closes: number[], length: number): { line: number[]; signal: number[] } {
  const n = highs.length;
  const hlAvg = highs.map((h, i) => (h + lows[i]) / 2);
  const fish: number[] = new Array(n).fill(0);
  for (let i = length - 1; i < n; i++) {
    const window = hlAvg.slice(i - length + 1, i + 1);
    const hh = Math.max(...window), ll = Math.min(...window);
    let raw = 2 * (hlAvg[i] - ll) / (hh - ll + 1e-10) - 1;
    raw = Math.max(-0.999, Math.min(0.999, raw));
    fish[i] = 0.5 * Math.log((1 + raw) / (1 - raw));
  }
  const sig = [0, ...fish.slice(0, -1)];
  return { line: fish, signal: sig };
}

function cmf(highs: number[], lows: number[], closes: number[], volumes: number[], period: number): number[] {
  const n = closes.length;
  const r: number[] = new Array(n).fill(0);
  const totalVol = volumes.reduce((a, b) => a + b, 0);
  const vol = totalVol === 0 ? new Array(n).fill(1) : volumes;
  for (let i = period - 1; i < n; i++) {
    let mfvSum = 0, vSum = 0;
    for (let j = i - period + 1; j <= i; j++) {
      const mfm = ((closes[j] - lows[j]) - (highs[j] - closes[j])) / (highs[j] - lows[j] + 1e-10);
      mfvSum += mfm * vol[j]; vSum += vol[j];
    }
    r[i] = mfvSum / (vSum + 1e-10);
  }
  return r;
}

function pivotHighLow(highs: number[], lows: number[], period: number): { pivotHigh: number[]; pivotLow: number[] } {
  const n = highs.length;
  const phRaw: number[] = new Array(n).fill(NaN), plRaw: number[] = new Array(n).fill(NaN);
  for (let i = period; i < n - period; i++) {
    const windowHi = highs.slice(i - period, i + period + 1);
    const windowLo = lows.slice(i - period, i + period + 1);
    if (highs[i] === Math.max(...windowHi)) phRaw[i] = highs[i];
    if (lows[i] === Math.min(...windowLo)) plRaw[i] = lows[i];
  }
  const ph = [...phRaw], pl = [...plRaw];
  for (let i = 1; i < n; i++) { if (isNaN(ph[i]) && !isNaN(ph[i - 1])) ph[i] = ph[i - 1]; }
  for (let i = 1; i < n; i++) { if (isNaN(pl[i]) && !isNaN(pl[i - 1])) pl[i] = pl[i - 1]; }
  return { pivotHigh: ph, pivotLow: pl };
}

function mfi(highs: number[], lows: number[], closes: number[], volumes: number[], period: number): number[] {
  const n = closes.length, r: number[] = new Array(n).fill(50);
  const tp = closes.map((c, i) => (highs[i] + lows[i] + c) / 3);
  const totalVol = volumes.reduce((a, b) => a + b, 0);
  const vol = totalVol === 0 ? new Array(n).fill(1) : volumes;
  const rmf = tp.map((t, i) => t * vol[i]);
  for (let i = period; i < n; i++) {
    let posMF = 0, negMF = 0;
    for (let j = i - period + 1; j <= i; j++) {
      if (tp[j] > tp[j - 1]) posMF += rmf[j]; else negMF += rmf[j];
    }
    r[i] = 100 - 100 / (1 + posMF / (negMF + 1e-10));
  }
  return r;
}

function alma(data: number[], period: number, offset = 0.85, sigma = 6): number[] {
  const m = Math.floor(offset * (period - 1)), s = period / sigma;
  const weights: number[] = [];
  for (let i = 0; i < period; i++) weights.push(Math.exp(-((i - m) ** 2) / (2 * s ** 2)));
  const wSum = weights.reduce((a, b) => a + b, 0);
  const nw = weights.map(w => w / wSum);
  const r: number[] = new Array(data.length).fill(NaN);
  for (let i = period - 1; i < data.length; i++) {
    let v = 0;
    for (let j = 0; j < period; j++) v += data[i - period + 1 + j] * nw[j];
    r[i] = v;
  }
  return r;
}

function vortex(highs: number[], lows: number[], closes: number[], period: number): { plus: number[]; minus: number[] } {
  const n = closes.length;
  const vp: number[] = new Array(n).fill(0), vm: number[] = new Array(n).fill(0);
  const tr: number[] = [highs[0] - lows[0]];
  for (let i = 1; i < n; i++) tr[i] = Math.max(highs[i] - lows[i], Math.abs(highs[i] - closes[i - 1]), Math.abs(lows[i] - closes[i - 1]));
  for (let i = period; i < n; i++) {
    let trS = 0, vpS = 0, vmS = 0;
    for (let j = i - period + 1; j <= i; j++) {
      trS += tr[j]; vpS += Math.abs(highs[j] - lows[j - 1]); vmS += Math.abs(lows[j] - highs[j - 1]);
    }
    vp[i] = vpS / (trS + 1e-10); vm[i] = vmS / (trS + 1e-10);
  }
  return { plus: vp, minus: vm };
}

function supertrend(highs: number[], lows: number[], closes: number[], length: number, factor: number): { val: number[]; dir: number[] } {
  const n = closes.length;
  const tr: number[] = [highs[0] - lows[0]];
  for (let i = 1; i < n; i++) tr[i] = Math.max(highs[i] - lows[i], Math.abs(highs[i] - closes[i - 1]), Math.abs(lows[i] - closes[i - 1]));
  const atr = ema(tr, length);
  const hl2 = highs.map((h, i) => (h + lows[i]) / 2);
  const upper = hl2.map((v, i) => v + factor * atr[i]);
  const lower = hl2.map((v, i) => v - factor * atr[i]);
  const stVal: number[] = new Array(n).fill(0), stDir: number[] = new Array(n).fill(-1);
  stVal[0] = upper[0]; stDir[0] = -1;
  for (let i = 1; i < n; i++) {
    const fu = (upper[i] < upper[i - 1] || closes[i - 1] > upper[i - 1]) ? upper[i] : upper[i - 1];
    const fl = (lower[i] > lower[i - 1] || closes[i - 1] < lower[i - 1]) ? lower[i] : lower[i - 1];
    const pv = stVal[i - 1], pd = stDir[i - 1];
    if (pd === -1) { stDir[i] = closes[i] > pv ? 1 : -1; stVal[i] = closes[i] > pv ? fl : fu; }
    else { stDir[i] = closes[i] < pv ? -1 : 1; stVal[i] = closes[i] < pv ? fu : fl; }
  }
  return { val: stVal, dir: stDir };
}

function keltnerChannel(highs: number[], lows: number[], closes: number[], period: number, mult: number): { upper: number[]; mid: number[]; lower: number[] } {
  const mid = ema(closes, period);
  const tr: number[] = [highs[0] - lows[0]];
  for (let i = 1; i < closes.length; i++) tr[i] = Math.max(highs[i] - lows[i], Math.abs(highs[i] - closes[i - 1]), Math.abs(lows[i] - closes[i - 1]));
  const atr = ema(tr, period);
  return { upper: mid.map((m, i) => m + mult * atr[i]), mid, lower: mid.map((m, i) => m - mult * atr[i]) };
}

function williamsR(highs: number[], lows: number[], closes: number[], period: number): number[] {
  const r: number[] = new Array(closes.length).fill(-50);
  for (let i = period - 1; i < closes.length; i++) {
    let hh = -Infinity, ll = Infinity;
    for (let j = i - period + 1; j <= i; j++) { if (highs[j] > hh) hh = highs[j]; if (lows[j] < ll) ll = lows[j]; }
    r[i] = -100 * (hh - closes[i]) / (hh - ll + 1e-10);
  }
  return r;
}

function wavetrend(highs: number[], lows: number[], closes: number[], chLen: number, avgLen: number): { wt1: number[]; wt2: number[] } {
  const ap = highs.map((h, i) => (h + lows[i] + closes[i]) / 3);
  const esa = ema(ap, chLen);
  const dArr = ap.map((v, i) => Math.abs(v - esa[i]));
  const d = ema(dArr, chLen);
  const ci = ap.map((v, i) => (v - esa[i]) / (0.015 * d[i] + 1e-10));
  const wt1 = ema(ci, avgLen);
  const wt2 = sma(wt1, 4);
  return { wt1, wt2 };
}

function donchianChannel(highs: number[], lows: number[], period: number): { upper: number[]; mid: number[]; lower: number[] } {
  const n = highs.length;
  const u: number[] = new Array(n).fill(0), l: number[] = new Array(n).fill(0);
  for (let i = period - 1; i < n; i++) {
    let hh = -Infinity, ll = Infinity;
    for (let j = i - period + 1; j <= i; j++) { if (highs[j] > hh) hh = highs[j]; if (lows[j] < ll) ll = lows[j]; }
    u[i] = hh; l[i] = ll;
  }
  return { upper: u, mid: u.map((v, i) => (v + l[i]) / 2), lower: l };
}

function zlema(data: number[], period: number): number[] {
  const lag = Math.floor((period - 1) / 2);
  const adjusted = data.map((v, i) => i >= lag ? 2 * v - data[i - lag] : v);
  return ema(adjusted, period);
}

function smiCalc(highs: number[], lows: number[], closes: number[], q: number, r: number, s: number): { val: number[]; sig: number[] } {
  const n = closes.length;
  const hh: number[] = new Array(n).fill(0), ll: number[] = new Array(n).fill(0);
  for (let i = q - 1; i < n; i++) {
    let hi = -Infinity, lo = Infinity;
    for (let j = i - q + 1; j <= i; j++) { if (highs[j] > hi) hi = highs[j]; if (lows[j] < lo) lo = lows[j]; }
    hh[i] = hi; ll[i] = lo;
  }
  const M = closes.map((c, i) => c - (hh[i] + ll[i]) / 2);
  const hlDiff = hh.map((h, i) => (h - ll[i]) / 2);
  const DS = ema(ema(M, r), r);
  const DHL = ema(ema(hlDiff, r), r);
  const sv = DS.map((d, i) => 100 * d / (DHL[i] + 1e-10));
  return { val: sv, sig: ema(sv, s) };
}

function bollingerBands(data: number[], period: number, dev: number): { upper: number[]; mid: number[]; lower: number[] } {
  const mid = sma(data, period);
  const n = data.length;
  const u: number[] = new Array(n).fill(0), l: number[] = new Array(n).fill(0);
  for (let i = period - 1; i < n; i++) {
    let sq = 0;
    for (let j = i - period + 1; j <= i; j++) sq += (data[j] - mid[i]) ** 2;
    const std = Math.sqrt(sq / period);
    u[i] = mid[i] + dev * std; l[i] = mid[i] - dev * std;
  }
  return { upper: u, mid, lower: l };
}

// ═══════════════════════════════════════════════════════════
// INDICATOR HELPERS
// ═══════════════════════════════════════════════════════════

const NAN = (val: number): boolean => !isFinite(val) || isNaN(val);

function emaSlope(arr: number[], lookback = 5): number {
  if (arr.length < lookback + 1) return 0;
  const vals = arr.slice(-lookback);
  const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
  if (mean === 0) return 0;
  return (vals[vals.length - 1] - vals[0]) / (Math.abs(mean) + 1e-10) * 100;
}

function isEmaSteep(arr: number[], dir: string, threshold = 0.03, lookback = 5): boolean {
  const slope = emaSlope(arr, lookback);
  return dir === 'up' ? slope > threshold : slope < -threshold;
}

function isEmaFlat(arr: number[], threshold = 0.015, lookback = 8): boolean {
  return Math.abs(emaSlope(arr, lookback)) < threshold;
}

function volReal(volumes: number[], lookback = 5): boolean {
  return volumes.slice(-lookback).reduce((a, b) => a + b, 0) > 0;
}

function volumeSpike(volumes: number[], idx: number, lookback = 8): boolean {
  const n = volumes.length;
  const i = idx < 0 ? n + idx : idx;
  const sum = volumes.slice(Math.max(0, i - lookback - 2), i + 1).reduce((a, b) => a + b, 0);
  if (sum === 0) return true;
  let cnt = 0, s = 0;
  for (let j = Math.max(0, i - lookback); j < i; j++) { if (volumes[j] > 0) { s += volumes[j]; cnt++; } }
  if (cnt === 0) return true;
  return volumes[i] > (s / cnt) * 1.5;
}

function volumeDryingUp(volumes: number[], startIdx: number, lookback = 5): boolean {
  if (volumes.length < lookback + 1) return true;
  const vols = volumes.slice(Math.max(0, startIdx - lookback), startIdx + 1);
  const nonzero = vols.filter(v => v > 0);
  if (nonzero.length < 2) return true;
  return nonzero[nonzero.length - 1] < nonzero[0] * 0.9;
}

function confirmationVolumeHigher(volumes: number[], idx: number, lookback = 3): boolean {
  const n = volumes.length;
  const i = idx < 0 ? n + idx : idx;
  const sum = volumes.slice(Math.max(0, i - lookback - 3), i + 1).reduce((a, b) => a + b, 0);
  if (sum === 0) return true;
  const cv = volumes[i];
  let cnt = 0, s = 0;
  for (let j = Math.max(0, i - lookback - 1); j < i; j++) { if (volumes[j] > 0) { s += volumes[j]; cnt++; } }
  if (cnt === 0) return true;
  return cv > (s / cnt) * 0.85;
}

function volumeLow(volumes: number[], idx: number, lookback = 5): boolean {
  const n = volumes.length;
  const i = idx < 0 ? n + idx : idx;
  const sum = volumes.slice(Math.max(0, i - lookback - 2), i + 1).reduce((a, b) => a + b, 0);
  if (sum === 0) return true;
  let cnt = 0, s = 0;
  for (let j = Math.max(0, i - lookback); j < i; j++) { if (volumes[j] > 0) { s += volumes[j]; cnt++; } }
  if (cnt === 0) return true;
  return volumes[i] < (s / cnt) * 0.70;
}

function pip(close: number): number {
  if (close >= 500) return 0.10;
  if (close >= 50) return 0.010;
  return 0.00010;
}

function swingHigh(arr: number[], period: number, endIdx: number): number {
  const start = Math.max(0, endIdx - period);
  let hh = -Infinity;
  for (let i = start; i <= endIdx; i++) if (arr[i] > hh) hh = arr[i];
  return hh;
}

function swingLow(arr: number[], period: number, endIdx: number): number {
  const start = Math.max(0, endIdx - period);
  let ll = Infinity;
  for (let i = start; i <= endIdx; i++) if (arr[i] < ll) ll = arr[i];
  return ll;
}

function avgBody(opens: number[], closes: number[], n: number, endIdx: number): number {
  const start = Math.max(0, endIdx - n);
  let s = 0, c = 0;
  for (let i = start; i < endIdx; i++) { s += Math.abs(closes[i] - opens[i]); c++; }
  return c > 0 ? s / c : 1e-6;
}

function avgVol(volumes: number[], n: number, endIdx: number): number {
  const start = Math.max(0, endIdx - n);
  let s = 0, c = 0;
  for (let i = start; i < endIdx; i++) { if (volumes[i] > 0) { s += volumes[i]; c++; } }
  return c > 0 ? s / c : 0;
}

// ═══════════════════════════════════════════════════════════
// COMPUTED INDICATOR DATAFRAME
// ═══════════════════════════════════════════════════════════

interface IndicatorData {
  candles: Candle[];
  closes: number[]; opens: number[]; highs: number[]; lows: number[]; volumes: number[];
  ema50: number[]; hma12: number[]; mfi3: number[];
  alma20: number[]; viPlus14: number[]; viMinus14: number[]; stVal: number[]; stDir: number[];
  kcUpper: number[]; kcMid: number[]; kcLower: number[]; wr14: number[];
  wt1: number[]; wt2: number[]; bb50Upper: number[]; bb50Mid: number[]; bb50Lower: number[];
  dcUpper: number[]; dcMid: number[]; dcLower: number[]; zlema21: number[]; smiVal: number[]; smiSig: number[];
  tema15: number[]; viPlus10: number[]; viMinus10: number[];
  mcginley21: number[]; fisherLine: number[]; fisherSig: number[];
  mcginley22: number[];
  tema13: number[]; cmf10: number[]; pivotHigh2: number[]; pivotLow2: number[];
  rsi14: number[]; ema20: number[];
  m5: Candle[]; m15: Candle[];
}

function computeIndicators(candles: Candle[]): IndicatorData {
  const closes = candles.map(c => c.close), opens = candles.map(c => c.open);
  const highs = candles.map(c => c.high), lows = candles.map(c => c.low);
  const volumes = candles.map(c => c.volume);
  const e50 = ema(closes, 50), h12 = hma(closes, 12), m3 = mfi(highs, lows, closes, volumes, 3);
  const a20 = alma(closes, 20, 0.85, 6);
  const v14 = vortex(highs, lows, closes, 14), st = supertrend(highs, lows, closes, 10, 3.0);
  const kc = keltnerChannel(highs, lows, closes, 20, 2.0), w14 = williamsR(highs, lows, closes, 14);
  const wt = wavetrend(highs, lows, closes, 10, 21), bb50 = bollingerBands(closes, 50, 2.5);
  const dc = donchianChannel(highs, lows, 20), zl21 = zlema(closes, 21);
  const sm = smiCalc(highs, lows, closes, 13, 25, 2);
  const t15 = tema(closes, 15), v10 = vortex(highs, lows, closes, 10);
  const mg21 = mcginleyDynamic(closes, 21), ft = fisherTransform(highs, lows, closes, 10);
  const mg22 = mcginleyDynamic(closes, 22), t13 = tema(closes, 13);
  const c10 = cmf(highs, lows, closes, volumes, 10), ph = pivotHighLow(highs, lows, 2);
  const r14 = rsiCalc(closes, 14), e20 = ema(closes, 20);
  const m5 = aggregateCandles(candles, 5), m15 = aggregateCandles(candles, 15);
  console.log(`[S2] ${candles.length} M1 → ${m5.length} M5 → ${m15.length} M15`);
  return {
    candles, closes, opens, highs, lows, volumes,
    ema50: e50, hma12: h12, mfi3: m3,
    alma20: a20, viPlus14: v14.plus, viMinus14: v14.minus, stVal: st.val, stDir: st.dir,
    kcUpper: kc.upper, kcMid: kc.mid, kcLower: kc.lower, wr14: w14,
    wt1: wt.wt1, wt2: wt.wt2, bb50Upper: bb50.upper, bb50Mid: bb50.mid, bb50Lower: bb50.lower,
    dcUpper: dc.upper, dcMid: dc.mid, dcLower: dc.lower, zlema21: zl21, smiVal: sm.val, smiSig: sm.sig,
    tema15: t15, viPlus10: v10.plus, viMinus10: v10.minus,
    mcginley21: mg21, fisherLine: ft.line, fisherSig: ft.signal,
    mcginley22: mg22, tema13: t13, cmf10: c10,
    pivotHigh2: ph.pivotHigh, pivotLow2: ph.pivotLow,
    rsi14: r14, ema20: e20, m5, m15,
  };
}

// ═══════════════════════════════════════════════════════════
// STRATEGY 1: LIQUID SNAP-BACK (Full avoid rules from Python)
// ═══════════════════════════════════════════════════════════

function stratLiquidSnapBack(d: IndicatorData, pair: string): Signal | null {
  const n = d.closes.length;
  if (n < 60) return null;
  const last = n - 1, prev = n - 2, prev2 = n - 3;
  const e50 = d.ema50[prev], h12 = d.hma12[prev];
  const mfi3_p = d.mfi3[prev], mfi3_pp = d.mfi3[prev2];
  const closeP = d.closes[prev], lowP = d.lows[prev], highP = d.highs[prev], openP = d.opens[prev];
  const isBullP = closeP > openP;
  const entryPrice = d.closes[last];
  if (NAN(e50) || NAN(h12) || NAN(mfi3_p)) return null;

  // HMA Anchor Rule
  const tolHma = Math.abs(h12) * 0.003;
  const nearHma = Math.abs(closeP - h12) < tolHma || (lowP <= h12 && h12 <= highP);
  if (!nearHma) return null;

  // DEATH ZONE 1: Flat-Line HMA
  if (isEmaFlat(d.hma12.slice(0, prev + 1), 0.015, 5)) return null;

  // Pullback count
  let pullbackLen = 0;
  for (let i = last - 2; i > Math.max(0, last - 7); i--) {
    if (d.closes[i] < d.opens[i]) pullbackLen++; else break;
  }
  if (pullbackLen < 2 || pullbackLen > 4) return null;

  // DEATH ZONE 2: Big-Wick Pullback
  for (let i = last - 2; i > Math.max(0, last - 2 - pullbackLen); i--) {
    const b_i = Math.abs(d.closes[i] - d.opens[i]);
    const r_i = d.highs[i] - d.lows[i];
    if (r_i > 0 && b_i > 0 && (r_i - b_i) / r_i > 0.65) return null;
  }

  const hasVol = volReal(d.volumes);

  // BUY
  if (closeP > e50) {
    if (!isEmaSteep(d.hma12.slice(0, prev + 1), 'up', 0.03, 5)) return null;
    // In-zone check
    const zoneMin = Math.min(h12, e50), zoneMax = Math.max(h12, e50);
    if (!(zoneMin <= closeP && closeP <= zoneMax) && !nearHma) return null;
    const gapPct = Math.abs(h12 - e50) / (Math.abs(e50) + 1e-10) * 100;
    if (gapPct < 0.15) return null;
    // 3-candle wait rule
    let consAbove = 0;
    for (let i = prev; i > Math.max(0, prev - 12); i--) {
      if (d.closes[i] > d.ema50[i]) consAbove++; else break;
    }
    if (consAbove < 3) return null;
    // Full body break avoid
    for (let i = last - pullbackLen - 1; i < prev; i++) {
      if (i < 0) continue;
      const rc = d.closes[i], ro = d.opens[i], re = d.ema50[i];
      const body = Math.abs(rc - ro), rng = d.highs[i] - d.lows[i];
      if (rc < ro && rc < re && rng > 0 && body / rng > 0.75) return null;
    }
    // MFI snap-back
    if (!(mfi3_pp <= 10 && mfi3_p > mfi3_pp && (mfi3_p - mfi3_pp) >= 2.0)) return null;
    // MFI divergence
    if (pullbackLen >= 2) {
      const firstPbIdx = last - 1 - pullbackLen, lastPbIdx = last - 2;
      if (firstPbIdx >= 0) {
        const firstPbMfi = d.mfi3[firstPbIdx], lastPbMfi = d.mfi3[lastPbIdx];
        const priceFell = d.closes[lastPbIdx] <= d.closes[firstPbIdx];
        const mfiRecovering = lastPbMfi >= firstPbMfi || mfi3_p > lastPbMfi;
        if (priceFell && !mfiRecovering) return null;
      }
    }
    if (!isBullP) return null;
    // Body-to-wick ratio
    const upperWick = highP - Math.max(openP, closeP);
    const bodySize = Math.abs(closeP - openP);
    if (bodySize > 0 && upperWick > bodySize) return null;
    // Volume 2X pullback
    const triggerVol = d.volumes[prev];
    if (hasVol) {
      const pbVols: number[] = [];
      for (let i = prev - 1; i > Math.max(0, prev - 1 - pullbackLen); i--) if (d.volumes[i] > 0) pbVols.push(d.volumes[i]);
      if (pbVols.length > 0) {
        const avgPb = pbVols.reduce((a, b) => a + b, 0) / pbVols.length;
        if (avgPb > 0 && triggerVol < avgPb * 2.0) return null;
        if (triggerVol <= d.volumes[prev - 1]) return null;
      }
      if (!volumeDryingUp(d.volumes, prev - 1, pullbackLen)) return null;
    }
    return { direction: 'CALL', strategy: 'LIQUID SNAP-BACK', pair, price: entryPrice, confidence: 88,
      notes: `EMA50↑|HMA12 touch|MFI3=${mfi3_p.toFixed(1)} V-hook|gap=${gapPct.toFixed(2)}%`,
      rsi: mfi3_p, emaFast: h12, emaSlow: e50, maTrend: 'uptrend_snapback' };
  }

  // SELL (mirror)
  if (closeP < e50) {
    if (!isEmaSteep(d.hma12.slice(0, prev + 1), 'down', 0.03, 5)) return null;
    const zoneMin = Math.min(h12, e50), zoneMax = Math.max(h12, e50);
    if (!(zoneMin <= closeP && closeP <= zoneMax) && !nearHma) return null;
    const gapPct = Math.abs(h12 - e50) / (Math.abs(e50) + 1e-10) * 100;
    if (gapPct < 0.15) return null;
    let consBelow = 0;
    for (let i = prev; i > Math.max(0, prev - 12); i--) {
      if (d.closes[i] < d.ema50[i]) consBelow++; else break;
    }
    if (consBelow < 3) return null;
    for (let i = last - pullbackLen - 1; i < prev; i++) {
      if (i < 0) continue;
      const rc = d.closes[i], ro = d.opens[i], re = d.ema50[i];
      const body = Math.abs(rc - ro), rng = d.highs[i] - d.lows[i];
      if (rc > ro && rc > re && rng > 0 && body / rng > 0.75) return null;
    }
    if (!(mfi3_pp >= 90 && mfi3_p < mfi3_pp && (mfi3_pp - mfi3_p) >= 2.0)) return null;
    if (pullbackLen >= 2) {
      const firstPbIdx = last - 1 - pullbackLen, lastPbIdx = last - 2;
      if (firstPbIdx >= 0) {
        const priceFell = d.closes[lastPbIdx] >= d.closes[firstPbIdx];
        const mfiRecovering = d.mfi3[lastPbIdx] <= d.mfi3[firstPbIdx] || mfi3_p < d.mfi3[lastPbIdx];
        if (priceFell && !mfiRecovering) return null;
      }
    }
    const isBearP = closeP < openP;
    if (!isBearP) return null;
    const lowerWick = Math.min(openP, closeP) - lowP;
    const bodySize = Math.abs(closeP - openP);
    if (bodySize > 0 && lowerWick > bodySize) return null;
    const triggerVol = d.volumes[prev];
    if (hasVol) {
      const pbVols: number[] = [];
      for (let i = prev - 1; i > Math.max(0, prev - 1 - pullbackLen); i--) if (d.volumes[i] > 0) pbVols.push(d.volumes[i]);
      if (pbVols.length > 0) {
        const avgPb = pbVols.reduce((a, b) => a + b, 0) / pbVols.length;
        if (avgPb > 0 && triggerVol < avgPb * 2.0) return null;
        if (triggerVol <= d.volumes[prev - 1]) return null;
      }
      if (!volumeDryingUp(d.volumes, prev - 1, pullbackLen)) return null;
    }
    return { direction: 'PUT', strategy: 'LIQUID SNAP-BACK', pair, price: entryPrice, confidence: 88,
      notes: `EMA50↓|HMA12 touch|MFI3=${mfi3_p.toFixed(1)} V-hook|gap=${gapPct.toFixed(2)}%`,
      rsi: mfi3_p, emaFast: h12, emaSlow: e50, maTrend: 'downtrend_snapback' };
  }
  return null;
}

// ═══════════════════════════════════════════════════════════
// STRATEGY 2: PURE TREND (Full avoid rules)
// ═══════════════════════════════════════════════════════════

function stratPureTrend(d: IndicatorData, pair: string): Signal | null {
  const n = d.closes.length;
  if (n < 60) return null;
  const last = n - 1, prev = n - 2;
  const stDir = d.stDir[prev], stVal = d.stVal[prev], al = d.alma20[prev];
  const viP = d.viPlus14[prev], viM = d.viMinus14[prev];
  const closeP = d.closes[prev], lowP = d.lows[prev], highP = d.highs[prev], openP = d.opens[prev];
  const entryPrice = d.closes[last];
  if (NAN(al) || NAN(viP) || NAN(viM)) return null;
  if (Math.abs(viP - viM) < 0.05) return null;
  if (isEmaFlat(d.alma20.slice(0, prev + 1), 0.015, 8)) return null;
  const tolAl = Math.abs(al) * 0.003;
  const nearAl = Math.abs(closeP - al) < tolAl || (lowP <= al && al <= highP);
  if (!nearAl) return null;
  const hasVol = volReal(d.volumes);

  // BUY
  if (stDir === 1 && viP > viM) {
    if (viP <= 1.10 || viM >= 0.90) return null;
    if (!isEmaSteep(d.alma20.slice(0, prev + 1), 'up', 0.02, 5)) return null;
    // Supertrend squeeze avoid
    if (!NAN(stVal) && closeP <= stVal * 1.001) return null;
    // Freshness rule
    let stChangeIdx: number | null = null;
    for (let i = prev; i > Math.max(0, prev - 80); i--) {
      if (d.stDir[i] !== 1) { stChangeIdx = i + 1; break; }
    }
    if (stChangeIdx !== null) {
      const candlesInTrend = prev - stChangeIdx;
      if (candlesInTrend >= 15) {
        let almaTouched = false;
        for (let i = stChangeIdx; i < prev; i++) {
          const alI = d.alma20[i], loI = d.lows[i], hiI = d.highs[i], clI = d.closes[i];
          const tolI = Math.abs(alI) * 0.003;
          if (Math.abs(clI - alI) < tolI || (loI <= alI && alI <= hiI)) { almaTouched = true; break; }
        }
        if (!almaTouched) return null;
      }
    }
    if (closeP <= openP) return null;
    if (closeP <= al) return null;
    const bodySize = Math.abs(closeP - openP), rng = highP - lowP;
    if (rng > 0 && bodySize / rng < 0.20) return null;
    // Rejection wick
    const lowerWick = Math.min(openP, closeP) - lowP;
    if (rng > 0 && lowerWick / rng < 0.10) return null;
    // Pullback speed
    for (let i = prev - 1; i > Math.max(0, prev - 5); i--) {
      if (d.closes[i] < d.opens[i]) {
        const bi = Math.abs(d.closes[i] - d.opens[i]), ri = d.highs[i] - d.lows[i];
        if (ri > 0 && bi / ri > 0.85) return null;
      } else break;
    }
    // Volume
    const trigVol = d.volumes[prev], lastPbVol = d.volumes[prev - 1];
    if (hasVol && lastPbVol > 0 && trigVol <= lastPbVol) return null;
    if (!volumeSpike(d.volumes, prev, 5) && !confirmationVolumeHigher(d.volumes, prev, 4) && hasVol) return null;

    return { direction: 'CALL', strategy: 'PURE TREND', pair, price: entryPrice, confidence: 88,
      notes: `ST GREEN|VI+=${viP.toFixed(3)}>1.10|ALMA20 bounce↑`,
      rsi: viP, emaFast: al, emaSlow: stVal, maTrend: 'pure_uptrend' };
  }

  // SELL
  if (stDir === -1 && viM > viP) {
    if (viM <= 1.10 || viP >= 0.90) return null;
    if (!isEmaSteep(d.alma20.slice(0, prev + 1), 'down', 0.02, 5)) return null;
    if (!NAN(stVal) && closeP >= stVal * 0.999) return null;
    let stChangeIdx: number | null = null;
    for (let i = prev; i > Math.max(0, prev - 80); i--) {
      if (d.stDir[i] !== -1) { stChangeIdx = i + 1; break; }
    }
    if (stChangeIdx !== null) {
      const candlesInTrend = prev - stChangeIdx;
      if (candlesInTrend >= 15) {
        let almaTouched = false;
        for (let i = stChangeIdx; i < prev; i++) {
          const alI = d.alma20[i], loI = d.lows[i], hiI = d.highs[i], clI = d.closes[i];
          if (Math.abs(clI - alI) < Math.abs(alI) * 0.003 || (loI <= alI && alI <= hiI)) { almaTouched = true; break; }
        }
        if (!almaTouched) return null;
      }
    }
    if (closeP >= openP) return null;
    if (closeP >= al) return null;
    const bodySize = Math.abs(closeP - openP), rng = highP - lowP;
    if (rng > 0 && bodySize / rng < 0.20) return null;
    const upperWick = highP - Math.max(openP, closeP);
    if (rng > 0 && upperWick / rng < 0.10) return null;
    for (let i = prev - 1; i > Math.max(0, prev - 5); i--) {
      if (d.closes[i] > d.opens[i]) {
        const bi = Math.abs(d.closes[i] - d.opens[i]), ri = d.highs[i] - d.lows[i];
        if (ri > 0 && bi / ri > 0.85) return null;
      } else break;
    }
    const trigVol = d.volumes[prev], lastPbVol = d.volumes[prev - 1];
    if (hasVol && lastPbVol > 0 && trigVol <= lastPbVol) return null;
    if (!volumeSpike(d.volumes, prev, 5) && !confirmationVolumeHigher(d.volumes, prev, 4) && hasVol) return null;

    return { direction: 'PUT', strategy: 'PURE TREND', pair, price: entryPrice, confidence: 88,
      notes: `ST RED|VI-=${viM.toFixed(3)}>1.10|ALMA20 reject↓`,
      rsi: viM, emaFast: al, emaSlow: stVal, maTrend: 'pure_downtrend' };
  }
  return null;
}

// ═══════════════════════════════════════════════════════════
// STRATEGY 3: FFLC VPA (Full avoid rules)
// ═══════════════════════════════════════════════════════════

function stratFFLCVPA(d: IndicatorData, pair: string): Signal | null {
  const n = d.closes.length;
  if (n < 30) return null;
  const prev = n - 2, prev2 = n - 3, last = n - 1;
  const kcLower = d.kcLower[prev], kcUpper = d.kcUpper[prev], kcMid = d.kcMid[prev];
  const wr = d.wr14[prev], wrPP = d.wr14[prev2];
  const closeP = d.closes[prev], openP = d.opens[prev], lowP = d.lows[prev], highP = d.highs[prev];
  const lastClose = d.closes[last], lastOpen = d.opens[last];
  if (NAN(kcLower) || NAN(kcUpper) || NAN(wr)) return null;
  const kcHeight = kcUpper - kcLower;
  if (kcHeight <= 0) return null;
  const hasVol = volReal(d.volumes);
  const entryPrice = d.closes[last];

  // KC Angle Rule: KC bands must not be steeply sloped
  const kcMidSlope = Math.abs(emaSlope(d.kcMid.slice(0, prev + 1), 5));
  if (kcMidSlope > 0.06) return null;

  // Band Width Filter: KC must not be squeezed
  if (n >= 10) {
    const widths: number[] = [];
    for (let i = prev - 8; i <= prev; i++) {
      if (i >= 0) widths.push(d.kcUpper[i] - d.kcLower[i]);
    }
    if (widths.length >= 4) {
      const avgW = widths.reduce((a, b) => a + b, 0) / widths.length;
      if (avgW > 0 && kcHeight < avgW * 0.70) return null;
    }
  }

  // Band Walk Trap: 3+ consecutive outside
  let consecLower = 0, consecUpper = 0;
  for (let i = prev; i > Math.max(0, prev - 8); i--) {
    if (d.lows[i] <= d.kcLower[i] * 1.001) consecLower++; else break;
  }
  for (let i = prev; i > Math.max(0, prev - 8); i--) {
    if (d.highs[i] >= d.kcUpper[i] * 0.999) consecUpper++; else break;
  }

  // News Shadow: single candle spans entire KC
  const prevRng = highP - lowP;
  if (prevRng > kcHeight * 0.90) return null;

  // Flat Middle Line avoid
  if (n >= 5) {
    let tinyCount = 0;
    for (let i = prev - 3; i <= prev; i++) {
      if (i < 0) continue;
      const b = Math.abs(d.closes[i] - d.opens[i]), mid = d.kcMid[i];
      if (Math.abs(d.closes[i] - mid) < kcHeight * 0.05 && b < kcHeight * 0.03) tinyCount++;
    }
    if (tinyCount >= 3) return null;
  }

  const prevBear = closeP < openP;
  const prevBull = closeP > openP;

  // BUY
  const touchedLower = lowP <= kcLower || Math.abs(lowP - kcLower) < kcHeight * 0.015;
  if (prevBear && touchedLower && wr < -80 && wrPP <= -80 && wr > wrPP) {
    if (consecLower >= 3) return null;
    // Marubozu avoid
    const bodyP = Math.abs(closeP - openP);
    if (prevRng > 0 && bodyP / prevRng > 0.85) {
      const lwP = Math.min(openP, closeP) - lowP;
      if (prevRng > 0 && lwP / prevRng < 0.10) return null;
    }
    // Wick >= 40%
    const lowerWick = Math.min(openP, closeP) - lowP;
    if (prevRng > 0 && lowerWick / prevRng < 0.40) return null;
    // WR V-shape hook
    const wrDelta = wr - wrPP;
    if (wrDelta < 3.0) return null;
    // 2-Sigma Magnet
    const distToMid = kcMid - closeP;
    if (distToMid < kcHeight * 0.30) return null;
    // Volume spike on trap
    if (!volumeSpike(d.volumes, prev, 8) && !confirmationVolumeHigher(d.volumes, prev, 4) && hasVol) return null;
    // Volume exhaustion
    if (hasVol) {
      const volStrike = d.volumes[prev], volConfirm = d.volumes[last];
      if (volStrike > 0 && volConfirm > volStrike * 0.70) return null;
    }
    // Confirmation: last must be GREEN + inside KC
    if (lastClose <= lastOpen) return null;
    if (lastClose <= kcLower) return null;
    // Micro-engulfing
    if (bodyP > 0) {
      const confirmBody = Math.abs(lastClose - lastOpen);
      if (confirmBody < bodyP * 0.60) return null;
    }

    return { direction: 'CALL', strategy: 'FFLC VPA', pair, price: entryPrice, confidence: 88,
      notes: `KC Lower touch|WR=${wr.toFixed(1)}<-80 hook↑|Color→GREEN`,
      rsi: wr, emaFast: kcLower, emaSlow: kcUpper, maTrend: 'kc_lower_absorption' };
  }

  // SELL
  const touchedUpper = highP >= kcUpper || Math.abs(highP - kcUpper) < kcHeight * 0.015;
  if (prevBull && touchedUpper && wr > -20 && wrPP >= -20 && wr < wrPP) {
    if (consecUpper >= 3) return null;
    const bodyP = Math.abs(closeP - openP);
    if (prevRng > 0 && bodyP / prevRng > 0.85) {
      const uwP = highP - Math.max(openP, closeP);
      if (prevRng > 0 && uwP / prevRng < 0.10) return null;
    }
    const upperWick = highP - Math.max(openP, closeP);
    if (prevRng > 0 && upperWick / prevRng < 0.40) return null;
    const wrDelta = wrPP - wr;
    if (wrDelta < 3.0) return null;
    const distToMid = closeP - kcMid;
    if (distToMid < kcHeight * 0.30) return null;
    if (!volumeSpike(d.volumes, prev, 8) && !confirmationVolumeHigher(d.volumes, prev, 4) && hasVol) return null;
    if (hasVol) {
      const volStrike = d.volumes[prev], volConfirm = d.volumes[last];
      if (volStrike > 0 && volConfirm > volStrike * 0.70) return null;
    }
    if (lastClose >= lastOpen) return null;
    if (lastClose >= kcUpper) return null;
    if (bodyP > 0 && Math.abs(lastClose - lastOpen) < bodyP * 0.60) return null;

    return { direction: 'PUT', strategy: 'FFLC VPA', pair, price: entryPrice, confidence: 88,
      notes: `KC Upper touch|WR=${wr.toFixed(1)}>-20 hook↓|Color→RED`,
      rsi: wr, emaFast: kcUpper, emaSlow: kcLower, maTrend: 'kc_upper_exhaustion' };
  }
  return null;
}

// ═══════════════════════════════════════════════════════════
// STRATEGY 4: WIDE RANGING (Full avoid rules)
// ═══════════════════════════════════════════════════════════

function stratWideRanging(d: IndicatorData, pair: string): Signal | null {
  const n = d.closes.length;
  if (n < 60) return null;
  const prev2 = n - 3, prev3 = n - 4, prev = n - 2, last = n - 1;
  const bbUpper = d.bb50Upper[prev2], bbLower = d.bb50Lower[prev2], bbMid = d.bb50Mid[prev2];
  const wt1P = d.wt1[prev2], wt1PP = d.wt1[prev3], wt2P = d.wt2[prev2], wt2PP = d.wt2[prev3];
  if (NAN(bbUpper) || NAN(bbLower) || NAN(wt1P)) return null;
  const bbWidth = bbUpper - bbLower;
  if (bbWidth <= 0) return null;
  const bbMidSafe = NAN(bbMid) ? (bbUpper + bbLower) / 2 : bbMid;
  const hasVol = volReal(d.volumes);

  // Band Walk Avoid: expanding >20%
  if (n >= 9) {
    const widths: number[] = [];
    for (let i = n - 9; i < prev2; i++) widths.push(d.bb50Upper[i] - d.bb50Lower[i]);
    if (widths.length >= 4 && widths[0] > 0 && widths[widths.length - 1] > widths[0] * 1.20) return null;
  }
  // Parallel Band Rule
  if (n >= 7) {
    const rw: number[] = [];
    for (let i = n - 6; i < prev; i++) rw.push(d.bb50Upper[i] - d.bb50Lower[i]);
    if (rw.length >= 4) {
      const earlyAvg = (rw[0] + rw[1]) / 2, lateAvg = (rw[rw.length - 2] + rw[rw.length - 1]) / 2;
      if (earlyAvg > 0 && lateAvg > earlyAvg * 1.05) return null;
    }
  }
  // Expanding Jaw
  if (n >= 6) {
    const uArr = d.bb50Upper.slice(n - 5, prev), lArr = d.bb50Lower.slice(n - 5, prev);
    if (uArr.length >= 3) {
      const uRise = uArr[uArr.length - 1] > uArr[0], lFall = lArr[lArr.length - 1] < lArr[0];
      if (uRise && lFall) {
        const uChg = (uArr[uArr.length - 1] - uArr[0]) / (Math.abs(uArr[0]) + 1e-10);
        const lChg = (lArr[0] - lArr[lArr.length - 1]) / (Math.abs(lArr[0]) + 1e-10);
        if (uChg > 0.003 && lChg > 0.003) return null;
      }
    }
  }

  const p2Low = d.lows[prev2], p2High = d.highs[prev2], p2Close = d.closes[prev2], p2Open = d.opens[prev2];
  const p2Body = Math.abs(p2Close - p2Open), p2Rng = p2High - p2Low;
  const cClose = d.closes[prev], cOpen = d.opens[prev];
  const cBody = Math.abs(cClose - cOpen);
  const entryPrice = d.closes[last];

  // BUY
  const touchedLower = p2Low <= bbLower || Math.abs(p2Low - bbLower) < Math.abs(bbLower) * 0.001;
  const wtCrossUp = wt1PP <= wt2PP && wt1P > wt2P;
  const wtExtLow = wt1PP <= -60 || wt1P <= -60;
  if (p2Close < p2Open && touchedLower && wtCrossUp && wtExtLow) {
    // Consecutive touches
    let consecTch = 0;
    for (let i = prev2; i > Math.max(0, prev2 - 8); i--) {
      if (d.lows[i] <= d.bb50Lower[i] * 1.001) consecTch++; else break;
    }
    if (consecTch >= 3) return null;
    // Marubozu avoid
    if (p2Rng > 0 && p2Body / p2Rng > 0.85) {
      const lwP2 = Math.min(p2Open, p2Close) - p2Low;
      if (p2Rng > 0 && lwP2 / p2Rng < 0.10) return null;
    }
    // Wick >= 40%
    const lowerWick = Math.min(p2Open, p2Close) - p2Low;
    if (p2Rng > 0 && lowerWick / p2Rng < 0.40) return null;
    // WT V-shape hook sharp
    if (wt1P - wt1PP < 3.0) return null;
    if (n >= 6) {
      const wt1Pre = d.wt1[n - 5];
      if (!NAN(wt1Pre) && wt1PP > wt1Pre + 2.0) return null;
    }
    // 2-Sigma Magnet
    const distToMid = bbMidSafe - p2Close;
    if (distToMid < bbWidth * 0.30) return null;
    // Volume spike on strike
    if (!volumeSpike(d.volumes, prev2, 8) && !confirmationVolumeHigher(d.volumes, prev2, 4) && hasVol) return null;
    // Volume exhaustion
    if (hasVol) {
      const volStrike = d.volumes[prev2], volConfirm = d.volumes[prev];
      if (volStrike > 0 && volConfirm > volStrike * 0.70) return null;
    }
    // Confirm GREEN + inside BB
    if (cClose <= cOpen) return null;
    if (cClose <= bbLower) return null;
    // Micro-engulfing
    if (p2Body > 0 && cBody < p2Body * 0.60) return null;

    return { direction: 'CALL', strategy: 'WIDE RANGING', pair, price: entryPrice, confidence: 88,
      notes: `BB(50,2.5) lower|WT=${wt1P.toFixed(1)}≤-60 V-cross↑`,
      rsi: wt1P, emaFast: bbUpper, emaSlow: bbLower, maTrend: 'bb_lower_bounce' };
  }

  // SELL
  const touchedUpper = p2High >= bbUpper || Math.abs(p2High - bbUpper) < Math.abs(bbUpper) * 0.001;
  const wtCrossDn = wt1PP >= wt2PP && wt1P < wt2P;
  const wtExtHigh = wt1PP >= 60 || wt1P >= 60;
  if (p2Close > p2Open && touchedUpper && wtCrossDn && wtExtHigh) {
    let consecTch = 0;
    for (let i = prev2; i > Math.max(0, prev2 - 8); i--) {
      if (d.highs[i] >= d.bb50Upper[i] * 0.999) consecTch++; else break;
    }
    if (consecTch >= 3) return null;
    if (p2Rng > 0 && p2Body / p2Rng > 0.85) {
      const uwP2 = p2High - Math.max(p2Open, p2Close);
      if (p2Rng > 0 && uwP2 / p2Rng < 0.10) return null;
    }
    const upperWick = p2High - Math.max(p2Open, p2Close);
    if (p2Rng > 0 && upperWick / p2Rng < 0.40) return null;
    if (wt1PP - wt1P < 3.0) return null;
    if (n >= 6) {
      const wt1Pre = d.wt1[n - 5];
      if (!NAN(wt1Pre) && wt1PP < wt1Pre - 2.0) return null;
    }
    const distToMid = p2Close - bbMidSafe;
    if (distToMid < bbWidth * 0.30) return null;
    if (!volumeSpike(d.volumes, prev2, 8) && !confirmationVolumeHigher(d.volumes, prev2, 4) && hasVol) return null;
    if (hasVol) {
      const volStrike = d.volumes[prev2], volConfirm = d.volumes[prev];
      if (volStrike > 0 && volConfirm > volStrike * 0.70) return null;
    }
    if (cClose >= cOpen) return null;
    if (cClose >= bbUpper) return null;
    if (p2Body > 0 && cBody < p2Body * 0.60) return null;

    return { direction: 'PUT', strategy: 'WIDE RANGING', pair, price: entryPrice, confidence: 88,
      notes: `BB(50,2.5) upper|WT=${wt1P.toFixed(1)}≥+60 V-cross↓`,
      rsi: wt1P, emaFast: bbUpper, emaSlow: bbLower, maTrend: 'bb_upper_crash' };
  }
  return null;
}

// ═══════════════════════════════════════════════════════════
// STRATEGY 5: MEDIUM RANGING (Full avoid rules)
// ═══════════════════════════════════════════════════════════

function stratMediumRanging(d: IndicatorData, pair: string): Signal | null {
  const n = d.closes.length;
  if (n < 60) return null;
  const prev2 = n - 3, prev3 = n - 4, prev = n - 2, last = n - 1;
  const dcMid = d.dcMid[prev2], zl = d.zlema21[prev2];
  const smiV = d.smiVal[prev2], smiS = d.smiSig[prev2];
  const smiVPP = d.smiVal[prev3], smiSPP = d.smiSig[prev3];
  const closeP = d.closes[prev2], openP = d.opens[prev2];
  const entryPrice = d.closes[last];
  if (NAN(dcMid) || NAN(zl) || NAN(smiV)) return null;
  const hasVol = volReal(d.volumes);

  // Expanding DC avoid
  if (n >= 8) {
    const dcWidths: number[] = [];
    for (let i = n - 8; i < prev2; i++) dcWidths.push(d.dcUpper[i] - d.dcLower[i]);
    if (dcWidths.length >= 3) {
      const earlyAvg = dcWidths[0], lateAvg = dcWidths[dcWidths.length - 1];
      if (earlyAvg > 0 && lateAvg > earlyAvg * 1.15) return null;
    }
  }

  // BUY
  if (closeP > openP) {
    const fusion = Math.min(dcMid, zl) > openP * 0.999 && closeP > Math.max(dcMid, zl) * 1.0001;
    if (!fusion) return null;
    // 60% body rule
    const bodyP = Math.abs(closeP - openP), rngP = d.highs[prev2] - d.lows[prev2];
    if (rngP > 0 && bodyP / rngP < 0.60) return null;
    const smiCrossUp = smiVPP < smiSPP && smiV > smiS;
    const smiZeroCross = smiVPP <= 0 && smiV > 0;
    if (!smiCrossUp || !smiZeroCross) return null;
    if (smiV >= 40) return null;
    // SMI oscillation avoid
    if (n >= 6) {
      let smiCrosses = 0;
      for (let i = n - 6; i < prev2; i++) {
        if ((d.smiVal[i] > 0 && d.smiVal[i + 1] <= 0) || (d.smiVal[i] <= 0 && d.smiVal[i + 1] > 0)) smiCrosses++;
      }
      if (smiCrosses >= 3) return null;
    }
    // ZLEMA Retest
    const prevClose = d.closes[prev], zlPrev = d.zlema21[prev];
    if (!NAN(zlPrev) && zlPrev > 0 && prevClose <= zlPrev) return null;
    // Top-3 Volume
    if (hasVol) {
      const vol2 = d.volumes[prev2];
      const recent5 = d.volumes.slice(Math.max(0, prev2 - 5), prev2).filter(v => v > 0).sort((a, b) => b - a);
      if (recent5.length >= 3 && vol2 < recent5[2]) return null;
    }

    return { direction: 'CALL', strategy: 'MEDIUM RANGING', pair, price: entryPrice, confidence: 88,
      notes: `DC Fusion Break↑|SMI=${smiV.toFixed(1)} zero-cross↑|ZLEMA Retest✓`,
      rsi: smiV, emaFast: zl, emaSlow: dcMid, maTrend: 'dc_fusion_up' };
  }

  // SELL
  if (closeP < openP) {
    const fusion = Math.max(dcMid, zl) < openP * 1.001 && closeP < Math.min(dcMid, zl) * 0.9999;
    if (!fusion) return null;
    const bodyP = Math.abs(closeP - openP), rngP = d.highs[prev2] - d.lows[prev2];
    if (rngP > 0 && bodyP / rngP < 0.60) return null;
    const smiCrossDn = smiVPP > smiSPP && smiV < smiS;
    const smiZeroCross = smiVPP >= 0 && smiV < 0;
    if (!smiCrossDn || !smiZeroCross) return null;
    if (smiV <= -40) return null;
    if (n >= 6) {
      let smiCrosses = 0;
      for (let i = n - 6; i < prev2; i++) {
        if ((d.smiVal[i] > 0 && d.smiVal[i + 1] <= 0) || (d.smiVal[i] <= 0 && d.smiVal[i + 1] > 0)) smiCrosses++;
      }
      if (smiCrosses >= 3) return null;
    }
    const prevClose = d.closes[prev], zlPrev = d.zlema21[prev];
    if (!NAN(zlPrev) && zlPrev > 0 && prevClose >= zlPrev) return null;
    if (hasVol) {
      const vol2 = d.volumes[prev2];
      const recent5 = d.volumes.slice(Math.max(0, prev2 - 5), prev2).filter(v => v > 0).sort((a, b) => b - a);
      if (recent5.length >= 3 && vol2 < recent5[2]) return null;
    }

    return { direction: 'PUT', strategy: 'MEDIUM RANGING', pair, price: entryPrice, confidence: 88,
      notes: `DC Fusion Break↓|SMI=${smiV.toFixed(1)} zero-cross↓|ZLEMA Retest✓`,
      rsi: smiV, emaFast: zl, emaSlow: dcMid, maTrend: 'dc_fusion_dn' };
  }
  return null;
}

// ═══════════════════════════════════════════════════════════
// STRATEGY 6: MICRO TYPE 1 (Full avoid rules)
// ═══════════════════════════════════════════════════════════

function stratMicroType1(d: IndicatorData, pair: string): Signal | null {
  const n = d.closes.length;
  if (n < 25) return null;
  const prev = n - 2, prev2 = n - 3, last = n - 1;
  const tema15P = d.tema15[prev], viP = d.viPlus10[prev], viM = d.viMinus10[prev];
  const viPPP = d.viPlus10[prev2], viMPP = d.viMinus10[prev2];
  const closeP = d.closes[prev], openP = d.opens[prev], lowP = d.lows[prev], highP = d.highs[prev];
  if (NAN(tema15P) || NAN(viP)) return null;
  const entryPrice = d.closes[last];
  const tolT = Math.abs(tema15P) * 0.004;
  const nearT = lowP <= tema15P * 1.001 || Math.abs(closeP - tema15P) < tolT;
  const hasVol = volReal(d.volumes);

  // CALL
  if (closeP > tema15P && nearT) {
    if (!isEmaSteep(d.tema15.slice(0, prev + 1), 'up', 0.008, 5)) return null;
    if (closeP >= openP) return null; // prev must be red (trap)

    // Count trap candles
    let trapCount = 1;
    for (let i = prev - 1; i > Math.max(0, prev - 4); i--) {
      if (d.closes[i] < d.opens[i]) trapCount++; else break;
    }
    if (trapCount < 1 || trapCount > 3) return null;

    // Bait verification
    const baitIdx = prev - trapCount;
    if (baitIdx < 1) return null;
    const baitClose = d.closes[baitIdx], baitOpen = d.opens[baitIdx];
    const baitBody = Math.abs(baitClose - baitOpen);
    const avgBodyPre = avgBody(d.opens, d.closes, 5, baitIdx);
    if (!(baitClose > baitOpen && baitBody > avgBodyPre * 1.3)) return null;

    // 0.90 Floor Rule
    for (let i = prev - trapCount + 1; i <= prev; i++) {
      if (d.viPlus10[i] < 0.90) return null;
    }
    // TEMA Cross Trap Avoid
    for (let i = prev - trapCount + 1; i <= prev; i++) {
      const rc = d.closes[i], ri = d.highs[i] - d.lows[i];
      const bi = Math.abs(rc - d.opens[i]);
      if (rc < d.tema15[i] && ri > 0 && bi / ri > 0.65) return null;
    }
    // Doji Cluster avoid
    let dojiCount = 0;
    for (let i = prev - trapCount + 1; i <= prev; i++) {
      const ri = d.highs[i] - d.lows[i], bi = Math.abs(d.closes[i] - d.opens[i]);
      if (ri > 0 && bi / ri < 0.15) dojiCount++;
    }
    if (dojiCount >= trapCount) return null;
    // TEMA Space avoid
    for (let i = prev - trapCount + 1; i <= prev; i++) {
      const mid = (d.closes[i] + d.opens[i]) / 2, rt = d.tema15[i];
      if (rt > 0 && Math.abs(mid - rt) / rt > 0.008) return null;
    }
    // 50% Golden Zone
    const baitBodyLo = Math.min(baitOpen, baitClose);
    const baitMid = baitBodyLo + baitBody * 0.50;
    let trapLowAll = Infinity;
    for (let i = prev - trapCount + 1; i <= prev; i++) trapLowAll = Math.min(trapLowAll, d.lows[i]);
    if (trapLowAll < baitMid) return null;
    // Volume Ratio Rule
    if (hasVol) {
      const baitVol = d.volumes[baitIdx];
      if (baitVol > 0) {
        let trapVolTotal = 0;
        for (let i = prev - trapCount + 1; i <= prev; i++) trapVolTotal += d.volumes[i];
        if (trapVolTotal > baitVol * 0.50) return null;
      }
    }
    // VI- Momentum Sink
    if (viMPP <= 1.10) return null;
    if (viM >= viMPP) return null;
    // Vortex Sharp Angle
    if (Math.abs(viP - viM) < 0.05) return null;
    // Vortex Cross UP
    const viCrossUp = viPPP <= viMPP && viP > viM;
    const viRising = viP > viM && viP > viPPP;
    if (!viCrossUp && !viRising) return null;

    return { direction: 'CALL', strategy: 'MICRO TYPE 1', pair, price: entryPrice, confidence: 88,
      notes: `TEMA15↑|VI+ floor≥0.90|Vortex cross↑|bait+trap✓`,
      rsi: viP, emaFast: tema15P, emaSlow: 0, maTrend: 'vortex_spring_blast' };
  }

  // PUT (mirror)
  const nearTSell = highP >= tema15P * 0.999 || Math.abs(closeP - tema15P) < tolT;
  if (closeP < tema15P && nearTSell) {
    if (!isEmaSteep(d.tema15.slice(0, prev + 1), 'down', 0.008, 5)) return null;
    if (closeP <= openP) return null;
    let trapCount = 1;
    for (let i = prev - 1; i > Math.max(0, prev - 4); i--) {
      if (d.closes[i] > d.opens[i]) trapCount++; else break;
    }
    if (trapCount < 1 || trapCount > 3) return null;
    const baitIdx = prev - trapCount;
    if (baitIdx < 1) return null;
    const baitClose = d.closes[baitIdx], baitOpen = d.opens[baitIdx];
    const baitBody = Math.abs(baitClose - baitOpen);
    const avgBodyPre = avgBody(d.opens, d.closes, 5, baitIdx);
    if (!(baitClose < baitOpen && baitBody > avgBodyPre * 1.3)) return null;
    for (let i = prev - trapCount + 1; i <= prev; i++) if (d.viMinus10[i] < 0.90) return null;
    for (let i = prev - trapCount + 1; i <= prev; i++) {
      const rc = d.closes[i], ri = d.highs[i] - d.lows[i], bi = Math.abs(rc - d.opens[i]);
      if (rc > d.tema15[i] && ri > 0 && bi / ri > 0.65) return null;
    }
    let dojiCount = 0;
    for (let i = prev - trapCount + 1; i <= prev; i++) {
      const ri = d.highs[i] - d.lows[i], bi = Math.abs(d.closes[i] - d.opens[i]);
      if (ri > 0 && bi / ri < 0.15) dojiCount++;
    }
    if (dojiCount >= trapCount) return null;
    for (let i = prev - trapCount + 1; i <= prev; i++) {
      const mid = (d.closes[i] + d.opens[i]) / 2, rt = d.tema15[i];
      if (rt > 0 && Math.abs(mid - rt) / rt > 0.008) return null;
    }
    const baitBodyHi = Math.max(baitOpen, baitClose);
    const baitMid = baitBodyHi - baitBody * 0.50;
    let trapHighAll = -Infinity;
    for (let i = prev - trapCount + 1; i <= prev; i++) trapHighAll = Math.max(trapHighAll, d.highs[i]);
    if (trapHighAll > baitMid) return null;
    if (hasVol) {
      const baitVol = d.volumes[baitIdx];
      if (baitVol > 0) {
        let trapVolTotal = 0;
        for (let i = prev - trapCount + 1; i <= prev; i++) trapVolTotal += d.volumes[i];
        if (trapVolTotal > baitVol * 0.50) return null;
      }
    }
    if (viPPP <= 1.10) return null;
    if (viP >= viPPP) return null;
    if (Math.abs(viP - viM) < 0.05) return null;
    const viCrossDn = viPPP >= viMPP && viP < viM;
    const viFalling = viM > viP && viM > viMPP;
    if (!viCrossDn && !viFalling) return null;

    return { direction: 'PUT', strategy: 'MICRO TYPE 1', pair, price: entryPrice, confidence: 88,
      notes: `TEMA15↓|VI- floor≥0.90|Vortex cross↓|bait+trap✓`,
      rsi: viM, emaFast: tema15P, emaSlow: 0, maTrend: 'vortex_spring_crash' };
  }
  return null;
}

// ═══════════════════════════════════════════════════════════
// STRATEGY 7: MICRO TYPE 2 (Full avoid rules)
// ═══════════════════════════════════════════════════════════

function stratMicroType2(d: IndicatorData, pair: string): Signal | null {
  const n = d.closes.length;
  if (n < 25) return null;
  const prev = n - 2, prev2 = n - 3, last = n - 1;
  const mg21 = d.mcginley21[prev], fishP = d.fisherLine[prev], fishSigP = d.fisherSig[prev];
  const fishPP = d.fisherLine[prev2], fishSigPP = d.fisherSig[prev2];
  const closeP = d.closes[prev], openP = d.opens[prev], lowP = d.lows[prev], highP = d.highs[prev];
  if (NAN(mg21) || NAN(fishP)) return null;
  const entryPrice = d.closes[last];
  const tolMg = Math.abs(mg21) * 0.005;
  const prevRng = highP - lowP;
  const prevBody = Math.abs(closeP - openP);
  const hasVol = volReal(d.volumes);

  // Shadow Box avoid
  if (prevBody > 0) {
    const uw = highP - Math.max(openP, closeP), lw = Math.min(openP, closeP) - lowP;
    if (uw >= prevBody * 0.25 && lw >= prevBody * 0.25) return null;
  }

  // News Spread avoid
  let newsCount = 0;
  for (let offset = 3; offset < 7; offset++) {
    const idx = last - offset;
    if (idx < 0) break;
    const rc = d.closes[idx], ro = d.opens[idx], rng = d.highs[idx] - d.lows[idx], body = Math.abs(rc - ro);
    const mgV = d.mcginley21[idx];
    if (rc < ro && rc < mgV && rng > 0 && body / rng > 0.80) newsCount++;
  }
  if (newsCount >= 2) return null;

  // CALL
  if (closeP < openP) {
    if (!isEmaSteep(d.mcginley21.slice(0, prev + 1), 'up', 0.004, 6)) return null;
    const nearMg = lowP <= mg21 * 1.002 || Math.abs(closeP - mg21) < tolMg;
    if (!nearMg) return null;
    // Gap rejection
    const gapToMg = Math.abs(closeP - mg21) / (Math.abs(mg21) + 1e-10);
    if (gapToMg > 0.008 && lowP > mg21) return null;
    // Double Touch Trap
    for (let offset = 3; offset < 13; offset++) {
      const idx = last - offset;
      if (idx < 0) break;
      const lo = d.lows[idx], cl = d.closes[idx], mgV = d.mcginley21[idx];
      if (lo <= mgV * 1.002 || Math.abs(cl - mgV) < tolMg) return null;
    }
    // Existing body avoid
    if (prevRng > 0 && closeP > mg21 && prevBody / prevRng > 0.70) return null;
    if (fishP > -1.5 || fishSigP > -1.5) return null;
    const fishCrossUp = fishPP <= fishSigPP && fishP >= fishSigP;
    if (!fishCrossUp) return null;
    // Fisher V-shape
    if (n >= 5) {
      let vShape = false;
      for (let i = prev - 3; i < prev; i++) {
        if (i >= 0 && d.fisherLine[i] < d.fisherLine[i + 1]) { vShape = true; break; }
      }
      if (!vShape) return null;
    }
    // Doji + low vol avoid
    const isDoji = prevRng > 0 && prevBody / prevRng < 0.10;
    if (isDoji && (!hasVol || volumeLow(d.volumes, prev, 5))) return null;
    // Wick + volume
    const hasLW = prevRng > 0 && (Math.min(openP, closeP) - lowP) / prevRng >= 0.15;
    if (hasVol) {
      const vs = volumeSpike(d.volumes, prev, 8);
      if (vs && !hasLW) return null;
      if (!vs && !(prevRng > 0 && (Math.min(openP, closeP) - lowP) / prevRng >= 0.20)) return null;
    } else if (!(prevRng > 0 && (Math.min(openP, closeP) - lowP) / prevRng >= 0.20)) return null;
    // Micro-Gap avoid
    if (prevRng > 0 && Math.abs(d.opens[last] - closeP) > prevRng * 0.10) return null;

    return { direction: 'CALL', strategy: 'MICRO TYPE 2', pair, price: entryPrice, confidence: 88,
      notes: `McGinley21↑|Fisher=${fishP.toFixed(2)}≤-1.5 cross↑`,
      rsi: fishP, emaFast: mg21, emaSlow: 0, maTrend: 'mcginley_fisher_trap_buy' };
  }

  // PUT
  if (closeP > openP) {
    if (!isEmaSteep(d.mcginley21.slice(0, prev + 1), 'down', 0.004, 6)) return null;
    const nearMg = highP >= mg21 * 0.997 || Math.abs(closeP - mg21) < tolMg;
    if (!nearMg) return null;
    const gapToMg = Math.abs(closeP - mg21) / (Math.abs(mg21) + 1e-10);
    if (gapToMg > 0.008 && highP < mg21) return null;
    for (let offset = 3; offset < 13; offset++) {
      const idx = last - offset;
      if (idx < 0) break;
      const hi = d.highs[idx], cl = d.closes[idx], mgV = d.mcginley21[idx];
      if (hi >= mgV * 0.997 || Math.abs(cl - mgV) < tolMg) return null;
    }
    if (prevRng > 0 && closeP < mg21 && prevBody / prevRng > 0.70) return null;
    if (fishP < 1.5 || fishSigP < 1.5) return null;
    const fishCrossDn = fishPP >= fishSigPP && fishP <= fishSigP;
    if (!fishCrossDn) return null;
    if (n >= 5) {
      let vShape = false;
      for (let i = prev - 3; i < prev; i++) {
        if (i >= 0 && d.fisherLine[i] > d.fisherLine[i + 1]) { vShape = true; break; }
      }
      if (!vShape) return null;
    }
    const isDoji = prevRng > 0 && prevBody / prevRng < 0.10;
    if (isDoji && (!hasVol || volumeLow(d.volumes, prev, 5))) return null;
    const hasUW = prevRng > 0 && (highP - Math.max(openP, closeP)) / prevRng >= 0.15;
    if (hasVol) {
      const vs = volumeSpike(d.volumes, prev, 8);
      if (vs && !hasUW) return null;
      if (!vs && !(prevRng > 0 && (highP - Math.max(openP, closeP)) / prevRng >= 0.20)) return null;
    } else if (!(prevRng > 0 && (highP - Math.max(openP, closeP)) / prevRng >= 0.20)) return null;
    if (prevRng > 0 && Math.abs(d.opens[last] - closeP) > prevRng * 0.10) return null;

    return { direction: 'PUT', strategy: 'MICRO TYPE 2', pair, price: entryPrice, confidence: 88,
      notes: `McGinley21↓|Fisher=${fishP.toFixed(2)}≥+1.5 cross↓`,
      rsi: fishP, emaFast: mg21, emaSlow: 0, maTrend: 'mcginley_fisher_trap_sell' };
  }
  return null;
}

// ═══════════════════════════════════════════════════════════
// STRATEGY 8: MICRO TYPE 3 (Full avoid rules)
// ═══════════════════════════════════════════════════════════

function stratMicroType3(d: IndicatorData, pair: string): Signal | null {
  const n = d.closes.length;
  if (n < 25) return null;
  const prev = n - 2, prev2 = n - 3, last = n - 1;
  const mg22 = d.mcginley22[prev], fishP = d.fisherLine[prev], fishSigP = d.fisherSig[prev];
  const fishPP = d.fisherLine[prev2], fishSigPP = d.fisherSig[prev2];
  const closeP = d.closes[prev], openP = d.opens[prev], lowP = d.lows[prev], highP = d.highs[prev];
  if (NAN(mg22) || NAN(fishP)) return null;
  const entryPrice = d.closes[last];
  const tolMg = Math.abs(mg22) * 0.005;
  const prevRng = highP - lowP;
  const prevBody = Math.abs(closeP - openP);
  const hasVol = volReal(d.volumes);

  // Clock sync: skip 5-min boundaries
  const now = new Date();
  if (now.getUTCMinutes() % 5 === 0) return null;

  // Shadow Box avoid
  if (prevBody > 0) {
    const uw = highP - Math.max(openP, closeP), lw = Math.min(openP, closeP) - lowP;
    if (uw >= prevBody * 0.25 && lw >= prevBody * 0.25) return null;
  }

  // CALL
  if (closeP < openP) {
    if (!isEmaSteep(d.mcginley22.slice(0, prev + 1), 'up', 0.004, 6)) return null;
    const nearMg = lowP <= mg22 * 1.002 || Math.abs(closeP - mg22) < tolMg;
    if (!nearMg) return null;
    // Gap rejection
    const gapToMg = Math.abs(closeP - mg22) / (Math.abs(mg22) + 1e-10);
    if (gapToMg > 0.008 && lowP > mg22) return null;
    // Double Touch Trap
    for (let offset = 3; offset < 13; offset++) {
      const idx = last - offset;
      if (idx < 0) break;
      const lo = d.lows[idx], cl = d.closes[idx], mgV = d.mcginley22[idx];
      if (lo <= mgV * 1.002 || Math.abs(cl - mgV) < tolMg) return null;
    }
    if (fishP > -1.5 || fishSigP > -1.5 || fishPP > -1.5) return null;
    const fishCrossUp = fishPP <= fishSigPP && fishP >= fishSigP;
    if (!fishCrossUp) return null;
    // Fisher Elastic Snap: must have gone <= -2.0
    let elasticSnap = false;
    for (let offset = 2; offset < 7; offset++) {
      const idx = last - offset;
      if (idx >= 0 && d.fisherLine[idx] <= -2.0) { elasticSnap = true; break; }
    }
    if (!elasticSnap) return null;
    // 2x Wick-to-Body
    const lowerWick = Math.min(openP, closeP) - lowP;
    if (prevBody === 0 || lowerWick < prevBody * 2.0) return null;
    // Volume-Squeeze Pre-Condition
    if (hasVol) {
      const touchVol = d.volumes[prev];
      const sqVols: number[] = [];
      for (let offset = 3; offset < 6; offset++) {
        const idx = last - offset;
        if (idx >= 0 && d.volumes[idx] > 0) sqVols.push(d.volumes[idx]);
      }
      if (sqVols.length >= 2) {
        const avgSq = sqVols.reduce((a, b) => a + b, 0) / sqVols.length;
        if (avgSq > 0 && !(touchVol > avgSq * 1.80)) return null;
      }
    }
    // Volume Climax Wave
    if (hasVol) {
      const touchVol = d.volumes[prev];
      for (let offset = 3; offset < 6; offset++) {
        const idx = last - offset;
        if (idx >= 0 && d.volumes[idx] > touchVol) return null;
      }
    }
    // Speeding Train avoid
    let redCount = 0, prevVol = 0, volInc = true;
    for (let offset = 3; offset < 8; offset++) {
      const idx = last - offset;
      if (idx < 0) break;
      const rc = d.closes[idx], ro = d.opens[idx], rng = d.highs[idx] - d.lows[idx], body = Math.abs(rc - ro);
      if (rc < ro) {
        if (rng > 0 && body / rng < 0.40) break;
        redCount++;
        const v = d.volumes[idx];
        if (prevVol > 0 && v < prevVol) volInc = false;
        prevVol = v;
      } else break;
    }
    if (redCount >= 4 && volInc) return null;
    // Micro-Gap avoid
    if (prevRng > 0 && Math.abs(d.opens[last] - closeP) > prevRng * 0.10) return null;
    // Doji + low vol
    const isDoji = prevRng > 0 && prevBody / prevRng < 0.10;
    if (isDoji && (!hasVol || volumeLow(d.volumes, prev, 5))) return null;

    return { direction: 'CALL', strategy: 'MICRO TYPE 3', pair, price: entryPrice, confidence: 88,
      notes: `McGinley22↑|Fisher=${fishP.toFixed(2)}≤-2.0 snap↑|2×Wick✓`,
      rsi: fishP, emaFast: mg22, emaSlow: 0, maTrend: 'early_v_hook_snatch' };
  }

  // PUT
  if (closeP > openP) {
    if (!isEmaSteep(d.mcginley22.slice(0, prev + 1), 'down', 0.004, 6)) return null;
    const nearMg = highP >= mg22 * 0.997 || Math.abs(closeP - mg22) < tolMg;
    if (!nearMg) return null;
    const gapToMg = Math.abs(closeP - mg22) / (Math.abs(mg22) + 1e-10);
    if (gapToMg > 0.008 && highP < mg22) return null;
    for (let offset = 3; offset < 13; offset++) {
      const idx = last - offset;
      if (idx < 0) break;
      const hi = d.highs[idx], cl = d.closes[idx], mgV = d.mcginley22[idx];
      if (hi >= mgV * 0.997 || Math.abs(cl - mgV) < tolMg) return null;
    }
    if (fishP < 1.5 || fishSigP < 1.5 || fishPP < 1.5) return null;
    const fishCrossDn = fishPP >= fishSigPP && fishP <= fishSigP;
    if (!fishCrossDn) return null;
    let elasticSnap = false;
    for (let offset = 2; offset < 7; offset++) {
      const idx = last - offset;
      if (idx >= 0 && d.fisherLine[idx] >= 2.0) { elasticSnap = true; break; }
    }
    if (!elasticSnap) return null;
    const upperWick = highP - Math.max(openP, closeP);
    if (prevBody === 0 || upperWick < prevBody * 2.0) return null;
    if (hasVol) {
      const touchVol = d.volumes[prev];
      const sqVols: number[] = [];
      for (let offset = 3; offset < 6; offset++) {
        const idx = last - offset;
        if (idx >= 0 && d.volumes[idx] > 0) sqVols.push(d.volumes[idx]);
      }
      if (sqVols.length >= 2) {
        const avgSq = sqVols.reduce((a, b) => a + b, 0) / sqVols.length;
        if (avgSq > 0 && !(touchVol > avgSq * 1.80)) return null;
      }
    }
    if (hasVol) {
      const touchVol = d.volumes[prev];
      for (let offset = 3; offset < 6; offset++) {
        const idx = last - offset;
        if (idx >= 0 && d.volumes[idx] > touchVol) return null;
      }
    }
    let greenCount = 0; let prevVolS = 0; let volIncS = true;
    for (let offset = 3; offset < 8; offset++) {
      const idx = last - offset;
      if (idx < 0) break;
      const rc = d.closes[idx], ro = d.opens[idx], rng = d.highs[idx] - d.lows[idx], body = Math.abs(rc - ro);
      if (rc > ro) {
        if (rng > 0 && body / rng < 0.40) break;
        greenCount++;
        const v = d.volumes[idx];
        if (prevVolS > 0 && v < prevVolS) volIncS = false;
        prevVolS = v;
      } else break;
    }
    if (greenCount >= 4 && volIncS) return null;
    if (prevRng > 0 && Math.abs(d.opens[last] - closeP) > prevRng * 0.10) return null;
    const isDoji = prevRng > 0 && prevBody / prevRng < 0.10;
    if (isDoji && (!hasVol || volumeLow(d.volumes, prev, 5))) return null;

    return { direction: 'PUT', strategy: 'MICRO TYPE 3', pair, price: entryPrice, confidence: 88,
      notes: `McGinley22↓|Fisher=${fishP.toFixed(2)}≥+2.0 snap↓|2×Wick✓`,
      rsi: fishP, emaFast: mg22, emaSlow: 0, maTrend: 'early_inverted_v_drop' };
  }
  return null;
}

// ═══════════════════════════════════════════════════════════
// STRATEGY 9: MICRO TYPE 4 (Full avoid rules)
// ═══════════════════════════════════════════════════════════

function stratMicroType4(d: IndicatorData, pair: string): Signal | null {
  const n = d.closes.length;
  if (n < 25) return null;
  const prev = n - 2, prev2 = n - 3, last = n - 1;
  const tema13P = d.tema13[prev], cmf10P = d.cmf10[prev], cmf10PP = d.cmf10[prev2];
  const ph2 = d.pivotHigh2[prev], pl2 = d.pivotLow2[prev];
  const closeP = d.closes[prev], openP = d.opens[prev], highP = d.highs[prev], lowP = d.lows[prev];
  if (NAN(tema13P) || NAN(cmf10P)) return null;
  const entryPrice = d.closes[last];
  const prevRng = highP - lowP;
  const prevBody = Math.abs(closeP - openP);

  // TEMA max angle: not too steep
  const temaSlope = Math.abs(emaSlope(d.tema13.slice(0, prev + 1), 5));
  if (temaSlope > 0.06) return null;

  // CALL
  if (closeP > tema13P) {
    if (!isEmaSteep(d.tema13.slice(0, prev + 1), 'up', 0.008, 5)) return null;
    if (NAN(ph2) || !(closeP > ph2 && openP <= ph2 * 1.002)) return null;
    if (cmf10P <= 0.10 || cmf10P <= cmf10PP) return null;
    // CMF momentum tilt: rising for 3 candles
    let cmfRising = true;
    for (let offset = 2; offset < 5; offset++) {
      const idx = last - offset;
      if (idx < 1) break;
      if (d.cmf10[idx] < d.cmf10[idx - 1]) { cmfRising = false; break; }
    }
    if (!cmfRising) return null;
    // Clean break: upper wick <= 15% body
    const upperWick = highP - Math.max(openP, closeP);
    if (prevBody > 0 && upperWick > prevBody * 0.15) return null;
    // Elastic Band: close not too far from TEMA
    if (tema13P > 0 && Math.abs(closeP - tema13P) / Math.abs(tema13P) > 0.015) return null;
    // 70/30 Body rule
    if (prevRng > 0 && prevBody / prevRng < 0.70) return null;
    // Vol 1.5x avg5
    if (volReal(d.volumes)) {
      const vol5: number[] = [];
      for (let i = Math.max(0, prev - 5); i < prev; i++) if (d.volumes[i] > 0) vol5.push(d.volumes[i]);
      if (vol5.length >= 2) {
        const avg5 = vol5.reduce((a, b) => a + b, 0) / vol5.length;
        if (avg5 > 0 && d.volumes[prev] < avg5 * 1.5) return null;
      }
    }

    return { direction: 'CALL', strategy: 'MICRO TYPE 4', pair, price: entryPrice, confidence: 88,
      notes: `TEMA13↑|PivotHigh break↑|CMF=${cmf10P.toFixed(3)}>0.10↑`,
      rsi: cmf10P, emaFast: tema13P, emaSlow: ph2, maTrend: 'institutional_pump' };
  }

  // PUT
  if (closeP < tema13P) {
    if (!isEmaSteep(d.tema13.slice(0, prev + 1), 'down', 0.008, 5)) return null;
    if (NAN(pl2) || !(closeP < pl2 && openP >= pl2 * 0.998)) return null;
    if (cmf10P >= -0.10 || cmf10P >= cmf10PP) return null;
    let cmfFalling = true;
    for (let offset = 2; offset < 5; offset++) {
      const idx = last - offset;
      if (idx < 1) break;
      if (d.cmf10[idx] > d.cmf10[idx - 1]) { cmfFalling = false; break; }
    }
    if (!cmfFalling) return null;
    const lowerWick = Math.min(openP, closeP) - lowP;
    if (prevBody > 0 && lowerWick > prevBody * 0.15) return null;
    if (tema13P > 0 && Math.abs(closeP - tema13P) / Math.abs(tema13P) > 0.015) return null;
    if (prevRng > 0 && prevBody / prevRng < 0.70) return null;
    if (volReal(d.volumes)) {
      const vol5: number[] = [];
      for (let i = Math.max(0, prev - 5); i < prev; i++) if (d.volumes[i] > 0) vol5.push(d.volumes[i]);
      if (vol5.length >= 2) {
        const avg5 = vol5.reduce((a, b) => a + b, 0) / vol5.length;
        if (avg5 > 0 && d.volumes[prev] < avg5 * 1.5) return null;
      }
    }

    return { direction: 'PUT', strategy: 'MICRO TYPE 4', pair, price: entryPrice, confidence: 88,
      notes: `TEMA13↓|PivotLow break↓|CMF=${cmf10P.toFixed(3)}<-0.10↓`,
      rsi: cmf10P, emaFast: tema13P, emaSlow: pl2, maTrend: 'institutional_dump' };
  }
  return null;
}

// ═══════════════════════════════════════════════════════════
// LIQ ENGINE — TIER-2 CANCEL GUARD (20 traps)
// ═══════════════════════════════════════════════════════════

function liqConsec(d: IndicatorData, color: string, endIdx: number): number {
  let count = 0;
  for (let i = endIdx - 1; i >= 0 && count < 10; i--) {
    const isGreen = d.closes[i] > d.opens[i];
    if ((color === 'green' && isGreen) || (color === 'red' && !isGreen)) count++;
    else break;
  }
  return count;
}

function liqPushCount(d: IndicatorData, endIdx: number): number {
  let pushes = 0, prevH = -Infinity;
  for (let i = Math.max(0, endIdx - 8); i < endIdx; i++) {
    if (d.highs[i] > prevH) { pushes++; prevH = d.highs[i]; }
  }
  return pushes;
}

function liqTier2Cancel(d: IndicatorData): boolean {
  const n = d.closes.length;
  if (n < 5) return false;
  const prev = n - 2, prev2Idx = n - 3;
  const closeP = d.closes[prev], openP = d.opens[prev], highP = d.highs[prev], lowP = d.lows[prev];
  const bodyP = Math.abs(closeP - openP);
  const p = pip(closeP);
  const avgB = avgBody(d.opens, d.closes, 14, prev);
  const avgV = avgVol(d.volumes, 14, prev);
  const vP = d.volumes[prev];
  const ema20P = d.ema20[prev];
  const uwP = highP - Math.max(openP, closeP), lwP = Math.min(openP, closeP) - lowP;
  const p2c = d.closes[prev2Idx], p2o = d.opens[prev2Idx], p2h = d.highs[prev2Idx];
  const hundredPip = 100 * p;

  // T01: Round Number Vacuum
  const dist000 = Math.min(fractional, Math.abs(fractional - hundredPip));
  if (dist000 < 3 * p) return true;
  // T02: Half-Number Wall
  if (Math.abs(fractional - 50 * p) < p) return true;
  // T03: Wick-Fill Bait
  if (bodyP > 0 && (uwP > bodyP * 0.60 || lwP > bodyP * 0.60)) return true;
  // T04: Failed Wick Fill
  const prevUWick = p2h - Math.max(p2o, p2c);
  const currFill = closeP - p2c;
  if (prevUWick > p && currFill > 0 && (currFill / prevUWick) < 0.50) return true;
  // T05: Gap Slingshot
  if (Math.abs(openP - p2c) > 2 * p) return true;
  // T06: Unfinished Business
  const sH = swingHigh(d.highs, 20, prev), sL = swingLow(d.lows, 20, prev);
  if (0 < Math.abs(lowP - sH) && Math.abs(lowP - sH) < p) return true;
  if (0 < Math.abs(highP - sL) && Math.abs(highP - sL) < p) return true;
  // T07: EMA20 Rubber Band
  if (Math.abs(closeP - ema20P) > 15 * p) return true;
  // T08: V-Shape Origin Hunt
  if (closeP > openP) {
    const priorH = swingHigh(d.highs, 12, prev - 1);
    const dist = Math.abs(closeP - priorH);
    if (0 < dist && dist < 5 * p) return true;
  }
  // T13: Inside Bar Pixel Break
  if (n >= 4) {
    const motherH = d.highs[prev2Idx];
    const pixelBrk = highP - motherH;
    if (0 < pixelBrk && pixelBrk < 0.2 * p) return true;
  }
  // T14: News Candle Fade
  if (avgB > 0 && bodyP > 5 * avgB) return true;
  // T22: Opening Price Magnet
  if (avgV > 0 && vP < avgV * 0.50) {
    const dayOpen = d.opens[0];
    if (Math.abs(closeP - dayOpen) > 5 * p) return true;
  }
  // T23: Efficiency Tail
  const p2UWick = p2h - Math.max(p2o, p2c);
  const p2Body = Math.abs(p2c - p2o);
  if (p2Body > 0 && p2UWick > p2Body * 2.0 && Math.abs(highP - p2h) < 3 * p) return true;
  // T27: Godzilla Exhaustion
  if (avgB > 0 && bodyP > 3 * avgB) return true;
  // T28: 3-Push Staircase
  if (liqPushCount(d, n) >= 3 && closeP < p2c) return true;
  // T30: Dead Zone Ping-Pong
  if (avgV > 0 && vP < avgV * 0.30) return true;
  // T32: Correction Candle
  if (liqConsec(d, 'green', n) >= 6 || liqConsec(d, 'red', n) >= 6) return true;

  return false;
}

// ═══════════════════════════════════════════════════════════
// LIQ ENGINE — 6 STRATEGY BLOCKS
// ═══════════════════════════════════════════════════════════

function stratLiqSweepReversal(d: IndicatorData, pair: string): Signal | null {
  if (d.closes.length < 30 || liqTier2Cancel(d)) return null;
  const n = d.closes.length, prev = n - 2, last = n - 1;
  const closeP = d.closes[prev], openP = d.opens[prev], highP = d.highs[prev], lowP = d.lows[prev];
  const bodyP = Math.abs(closeP - openP);
  const p = pip(closeP), ep = d.closes[last];
  const sH = swingHigh(d.highs, 20, prev - 1), sL = swingLow(d.lows, 20, prev - 1);
  const rsi = d.rsi14[prev];
  const uwP = highP - Math.max(openP, closeP), lwP = Math.min(openP, closeP) - lowP;

  // Turtle Soup + Grandmaster Sweep
  if (highP > sH && closeP < sH && (highP - sH) < 2 * p && uwP > bodyP * 0.30) {
    if (rsi > 65) return { direction: 'PUT', strategy: 'LIQ SWEEP REVERSAL', pair, price: ep, confidence: 88,
      notes: `TurtleSoup↓ sweep=${((highP-sH)/p).toFixed(1)}pips|RSI=${rsi.toFixed(0)}>65`,
      rsi, emaFast: sH, emaSlow: sL, maTrend: 'liq_turtle_put' };
  }
  if (lowP < sL && closeP > sL && (sL - lowP) < 2 * p && lwP > bodyP * 0.30) {
    if (rsi < 35) return { direction: 'CALL', strategy: 'LIQ SWEEP REVERSAL', pair, price: ep, confidence: 88,
      notes: `TurtleSoup↑ sweep=${((sL-lowP)/p).toFixed(1)}pips|RSI=${rsi.toFixed(0)}<35`,
      rsi, emaFast: sH, emaSlow: sL, maTrend: 'liq_turtle_call' };
  }
  // Stop Hunt BOS
  if (highP > sH && closeP < d.closes[n - 3] && bodyP > avgBody(d.opens, d.closes, 10, prev) * 1.5) {
    return { direction: 'PUT', strategy: 'LIQ STOP HUNT BOS', pair, price: ep, confidence: 88,
      notes: `StopHuntBOS↓|swept sH=${sH.toFixed(5)}|strong reversal body`,
      rsi, emaFast: sH, emaSlow: sL, maTrend: 'liq_stop_hunt_put' };
  }
  if (lowP < sL && closeP > d.closes[n - 3] && bodyP > avgBody(d.opens, d.closes, 10, prev) * 1.5) {
    return { direction: 'CALL', strategy: 'LIQ STOP HUNT BOS', pair, price: ep, confidence: 88,
      notes: `StopHuntBOS↑|swept sL=${sL.toFixed(5)}|strong reversal body`,
      rsi, emaFast: sH, emaSlow: sL, maTrend: 'liq_stop_hunt_call' };
  }
  return null;
}

function stratLiqFVG(d: IndicatorData, pair: string): Signal | null {
  if (d.closes.length < 30 || liqTier2Cancel(d)) return null;
  const n = d.closes.length, prev = n - 2, last = n - 1;
  const closeP = d.closes[prev], ep = d.closes[last];
  const p = pip(closeP), rsi = d.rsi14[prev];

  // FVG detection
  for (let i = prev; i > Math.max(2, prev - 20); i--) {
    if (i - 2 < 0) break;
    const c1h = d.highs[i - 2], c3l = d.lows[i];
    if (c3l > c1h) {
      const ce = (c3l + c1h) / 2;
      if (Math.abs(closeP - ce) < 2 * p) {
        return { direction: 'CALL', strategy: 'LIQ FVG', pair, price: ep, confidence: 88,
          notes: `BullishFVG CE=${ce.toFixed(5)}|close near CE`,
          rsi, emaFast: c3l, emaSlow: c1h, maTrend: 'liq_fvg_call' };
      }
    }
    const c1l = d.lows[i - 2], c3h = d.highs[i];
    if (c3h < c1l) {
      const ce = (c1l + c3h) / 2;
      if (Math.abs(closeP - ce) < 2 * p) {
        return { direction: 'PUT', strategy: 'LIQ FVG', pair, price: ep, confidence: 88,
          notes: `BearishFVG CE=${ce.toFixed(5)}|close near CE`,
          rsi, emaFast: c1l, emaSlow: c3h, maTrend: 'liq_fvg_put' };
      }
    }
  }
  return null;
}

function stratLiqOBBlocks(d: IndicatorData, pair: string): Signal | null {
  if (d.closes.length < 30 || liqTier2Cancel(d)) return null;
  const n = d.closes.length, prev = n - 2, last = n - 1;
  const closeP = d.closes[prev], ep = d.closes[last];
  const p = pip(closeP), rsi = d.rsi14[prev];
  const avgB = avgBody(d.opens, d.closes, 10, prev);

  for (let i = prev - 2; i > Math.max(1, prev - 20); i--) {
    const cc = d.closes[i], co = d.opens[i], body = Math.abs(cc - co);
    if (body < avgB * 0.30 || i + 2 >= prev) continue;
    const n2c = d.closes[i + 2];
    if (cc < co && n2c > cc + avgB * 1.5) {
      const obMid = (cc + co) / 2;
      if (Math.abs(closeP - obMid) < 3 * p) {
        return { direction: 'CALL', strategy: 'LIQ OB', pair, price: ep, confidence: 88,
          notes: `BullishOB mid=${obMid.toFixed(5)}|retest`,
          rsi, emaFast: co, emaSlow: cc, maTrend: 'liq_ob_call' };
      }
    }
    if (cc > co && n2c < co - avgB * 1.5) {
      const obMid = (cc + co) / 2;
      if (Math.abs(closeP - obMid) < 3 * p) {
        return { direction: 'PUT', strategy: 'LIQ OB', pair, price: ep, confidence: 88,
          notes: `BearishOB mid=${obMid.toFixed(5)}|retest`,
          rsi, emaFast: cc, emaSlow: co, maTrend: 'liq_ob_put' };
      }
    }
  }
  return null;
}

function stratLiqContinuation(d: IndicatorData, pair: string): Signal | null {
  if (d.closes.length < 30 || liqTier2Cancel(d)) return null;
  const n = d.closes.length, prev = n - 2, last = n - 1;
  const closeP = d.closes[prev], openP = d.opens[prev];
  const bodyP = Math.abs(closeP - openP);
  const ep = d.closes[last], p = pip(closeP), rsi = d.rsi14[prev];
  const avgB = avgBody(d.opens, d.closes, 14, prev);
  const sL = swingLow(d.lows, 20, prev - 1), sH = swingHigh(d.highs, 20, prev - 1);

  // Vacuum Move
  if (avgB > 0 && bodyP > avgB * 1.80) {
    const level = closeP > openP ? sL : sH;
    const dLevel = Math.abs(closeP - level);
    if (dLevel > 10 * p) {
      const dir: 'CALL' | 'PUT' = closeP > openP ? 'CALL' : 'PUT';
      return { direction: dir, strategy: 'LIQ VACUUM MOVE', pair, price: ep, confidence: 88,
        notes: `LiqVacuum body=${(bodyP/avgB).toFixed(1)}×avg|dist=${(dLevel/p).toFixed(1)}pips`,
        rsi, emaFast: sH, emaSlow: sL, maTrend: 'liq_vacuum' };
    }
  }
  return null;
}

function stratLiqHTFMagnet(d: IndicatorData, pair: string): Signal | null {
  if (d.closes.length < 100 || liqTier2Cancel(d)) return null;
  const n = d.closes.length, prev = n - 2, last = n - 1;
  const closeP = d.closes[prev], ep = d.closes[last];
  const p = pip(closeP), rsi = d.rsi14[prev];
  const htfH = swingHigh(d.highs, 100, prev - 1), htfL = swingLow(d.lows, 100, prev - 1);

  if (Math.abs(closeP - htfH) < 8 * p) {
    return { direction: 'PUT', strategy: 'LIQ HTF MAGNET', pair, price: ep, confidence: 88,
      notes: `HTFMagnet↓ near htfH=${htfH.toFixed(5)}`,
      rsi, emaFast: htfH, emaSlow: htfL, maTrend: 'htf_magnet_put' };
  }
  if (Math.abs(closeP - htfL) < 8 * p) {
    return { direction: 'CALL', strategy: 'LIQ HTF MAGNET', pair, price: ep, confidence: 88,
      notes: `HTFMagnet↑ near htfL=${htfL.toFixed(5)}`,
      rsi, emaFast: htfH, emaSlow: htfL, maTrend: 'htf_magnet_call' };
  }
  return null;
}

// ═══════════════════════════════════════════════════════════
// SMC ENGINE — 5 STRATEGY BLOCKS
// ═══════════════════════════════════════════════════════════

function smcChoch(d: IndicatorData, lookback = 5): string | null {
  const prev = d.closes.length - 2;
  if (prev < lookback) return null;
  const start = Math.max(0, prev - lookback);
  const prevHigh = swingHigh(d.highs, lookback, prev - 1);
  const prevLow = swingLow(d.lows, lookback, prev - 1);
  if (d.closes[prev] > prevHigh) return 'BULLISH_CHOCH';
  if (d.closes[prev] < prevLow) return 'BEARISH_CHOCH';
  return null;
}

function stratSmcFvgZone(d: IndicatorData, pair: string): Signal | null {
  const n = d.closes.length;
  if (n < 30) return null;
  const prev = n - 2, last = n - 1;
  const closeP = d.closes[prev], ep = d.closes[last];
  const p = pip(closeP), rsi = d.rsi14[prev];

  for (let i = prev; i > Math.max(2, prev - 25); i--) {
    if (i - 2 < 0) break;
    const c1h = d.highs[i - 2], c3l = d.lows[i];
    if (c3l > c1h) {
      const ce = (c3l + c1h) / 2;
      if (Math.abs(closeP - ce) < 1.5 * p) {
        return { direction: 'CALL', strategy: 'SMC FVG ZONE', pair, price: ep, confidence: 88,
          notes: `SMC BullFVG CE=${ce.toFixed(5)}`,
          rsi, emaFast: c3l, emaSlow: c1h, maTrend: 'smc_fvg_call' };
      }
    }
    const c1l = d.lows[i - 2], c3h = d.highs[i];
    if (c3h < c1l) {
      const ce = (c1l + c3h) / 2;
      if (Math.abs(closeP - ce) < 1.5 * p) {
        return { direction: 'PUT', strategy: 'SMC FVG ZONE', pair, price: ep, confidence: 88,
          notes: `SMC BearFVG CE=${ce.toFixed(5)}`,
          rsi, emaFast: c1l, emaSlow: c3h, maTrend: 'smc_fvg_put' };
      }
    }
  }
  return null;
}

function stratSmcSweepInducement(d: IndicatorData, pair: string): Signal | null {
  const n = d.closes.length;
  if (n < 30) return null;
  const prev = n - 2, last = n - 1;
  const closeP = d.closes[prev], openP = d.opens[prev], highP = d.highs[prev], lowP = d.lows[prev];
  const bodyP = Math.abs(closeP - openP);
  const ep = d.closes[last], p = pip(closeP), rsi = d.rsi14[prev];
  const sH = swingHigh(d.highs, 20, prev - 1), sL = swingLow(d.lows, 20, prev - 1);
  const avgB = avgBody(d.opens, d.closes, 20, prev);

  // Displacement
  if (bodyP > avgB * 2.5) {
    if (closeP > openP) return { direction: 'CALL', strategy: 'SMC DISPLACEMENT', pair, price: ep, confidence: 88,
      notes: `Displacement↑ body=${(bodyP/avgB).toFixed(1)}×avg`,
      rsi, emaFast: sH, emaSlow: sL, maTrend: 'smc_disp_call' };
    return { direction: 'PUT', strategy: 'SMC DISPLACEMENT', pair, price: ep, confidence: 88,
      notes: `Displacement↓ body=${(bodyP/avgB).toFixed(1)}×avg`,
      rsi, emaFast: sH, emaSlow: sL, maTrend: 'smc_disp_put' };
  }

  // Sweep
  if (lowP < sL && closeP > sL) return { direction: 'CALL', strategy: 'SMC SWEEP', pair, price: ep, confidence: 88,
    notes: `SMC Sweep↑ sL=${sL.toFixed(5)}`,
    rsi, emaFast: sH, emaSlow: sL, maTrend: 'smc_sweep_call' };
  if (highP > sH && closeP < sH) return { direction: 'PUT', strategy: 'SMC SWEEP', pair, price: ep, confidence: 88,
    notes: `SMC Sweep↓ sH=${sH.toFixed(5)}`,
    rsi, emaFast: sH, emaSlow: sL, maTrend: 'smc_sweep_put' };

  return null;
}

function stratSmcBlocks(d: IndicatorData, pair: string): Signal | null {
  const n = d.closes.length;
  if (n < 30) return null;
  const prev = n - 2, last = n - 1;
  const closeP = d.closes[prev], ep = d.closes[last];
  const p = pip(closeP), rsi = d.rsi14[prev];
  const avgB = avgBody(d.opens, d.closes, 10, prev);

  // Order Block detection
  for (let i = prev - 2; i > Math.max(1, prev - 20); i--) {
    const cc = d.closes[i], co = d.opens[i], ch = d.highs[i], cl = d.lows[i];
    const body = Math.abs(cc - co);
    if (body < avgB * 0.30 || i + 2 >= prev) continue;
    const n2c = d.closes[i + 2];
    if (cc < co && n2c > ch + avgB) {
      if (closeP >= cl && closeP <= ch) {
        return { direction: 'CALL', strategy: 'SMC OB', pair, price: ep, confidence: 88,
          notes: `SMC BullOB [${cl.toFixed(5)}-${ch.toFixed(5)}]`,
          rsi, emaFast: ch, emaSlow: cl, maTrend: 'smc_ob_call' };
      }
    }
    if (cc > co && n2c < cl - avgB) {
      if (closeP >= cl && closeP <= ch) {
        return { direction: 'PUT', strategy: 'SMC OB', pair, price: ep, confidence: 88,
          notes: `SMC BearOB [${cl.toFixed(5)}-${ch.toFixed(5)}]`,
          rsi, emaFast: ch, emaSlow: cl, maTrend: 'smc_ob_put' };
      }
    }
  }

  // Breaker Block
  for (let i = prev - 3; i > Math.max(1, prev - 25); i--) {
    const cc = d.closes[i], co = d.opens[i], ch = d.highs[i], cl = d.lows[i];
    const body = Math.abs(cc - co);
    if (body < avgB * 0.50 || i + 3 >= prev) continue;
    const n3c = d.closes[i + 3];
    if (cc < co && n3c < cl) {
      if (closeP >= cl && closeP <= ch) {
        return { direction: 'PUT', strategy: 'SMC BREAKER', pair, price: ep, confidence: 88,
          notes: `SMC Breaker→PUT [${cl.toFixed(5)}-${ch.toFixed(5)}]`,
          rsi, emaFast: ch, emaSlow: cl, maTrend: 'smc_breaker_put' };
      }
    }
    if (cc > co && n3c > ch) {
      if (closeP >= cl && closeP <= ch) {
        return { direction: 'CALL', strategy: 'SMC BREAKER', pair, price: ep, confidence: 88,
          notes: `SMC Breaker→CALL [${cl.toFixed(5)}-${ch.toFixed(5)}]`,
          rsi, emaFast: ch, emaSlow: cl, maTrend: 'smc_breaker_call' };
      }
    }
  }
  return null;
}

function stratSmcStructure(d: IndicatorData, pair: string): Signal | null {
  const n = d.closes.length;
  if (n < 15) return null;
  const prev = n - 2, last = n - 1;
  const closeP = d.closes[prev], ep = d.closes[last];
  const rsi = d.rsi14[prev];
  const sH = swingHigh(d.highs, 20, prev - 1), sL = swingLow(d.lows, 20, prev - 1);

  const choch = smcChoch(d, 5);
  if (choch === 'BULLISH_CHOCH') {
    return { direction: 'CALL', strategy: 'SMC CHOCH', pair, price: ep, confidence: 88,
      notes: `BULLISH_CHOCH breakLevel=${swingHigh(d.highs, 5, prev - 1).toFixed(5)}`,
      rsi, emaFast: sH, emaSlow: sL, maTrend: 'smc_choch_call' };
  }
  if (choch === 'BEARISH_CHOCH') {
    return { direction: 'PUT', strategy: 'SMC CHOCH', pair, price: ep, confidence: 88,
      notes: `BEARISH_CHOCH breakLevel=${swingLow(d.lows, 5, prev - 1).toFixed(5)}`,
      rsi, emaFast: sH, emaSlow: sL, maTrend: 'smc_choch_put' };
  }

  // Premium/Discount
  const eq = (sH + sL) / 2;
  const p = pip(closeP);
  if (closeP < eq && rsi < 30) {
    return { direction: 'CALL', strategy: 'SMC DISCOUNT', pair, price: ep, confidence: 88,
      notes: `DISCOUNT zone|RSI=${rsi.toFixed(0)}<30`,
      rsi, emaFast: eq, emaSlow: sL, maTrend: 'smc_discount_call' };
  }
  if (closeP > eq && rsi > 70) {
    return { direction: 'PUT', strategy: 'SMC PREMIUM', pair, price: ep, confidence: 88,
      notes: `PREMIUM zone|RSI=${rsi.toFixed(0)}>70`,
      rsi, emaFast: sH, emaSlow: eq, maTrend: 'smc_premium_put' };
  }
  return null;
}

function stratSmcHTFCombo(d: IndicatorData, pair: string): Signal | null {
  const m5 = d.m5;
  if (m5.length < 15) return null;
  const n = d.closes.length, prev = n - 2, last = n - 1;
  const closeP = d.closes[prev], ep = d.closes[last];
  const rsi = d.rsi14[prev], p = pip(closeP);
  const bodyP = Math.abs(closeP - d.opens[prev]);

  // HTF Wick Sniper
  const m5Prev = m5[m5.length - 2];
  const m5Body = Math.abs(m5Prev.close - m5Prev.open);
  const m5UW = m5Prev.high - Math.max(m5Prev.open, m5Prev.close);
  const m5LW = Math.min(m5Prev.open, m5Prev.close) - m5Prev.low;

  if (m5Body > 0 && m5UW > m5Body * 1.5) {
    const m5Mid = (Math.max(m5Prev.open, m5Prev.close) + m5Prev.high) / 2;
    const uw = d.highs[prev] - Math.max(d.opens[prev], closeP);
    if (closeP >= m5Mid && closeP <= m5Prev.high && bodyP > 0 && uw > bodyP * 2.0) {
      return { direction: 'PUT', strategy: 'SMC HTF WICK SNIPER', pair, price: ep, confidence: 88,
        notes: `HTFWickSniper↓ M5 upper wick zone`,
        rsi, emaFast: m5Prev.high, emaSlow: m5Mid, maTrend: 'htf_wick_sniper_put' };
    }
  }
  if (m5Body > 0 && m5LW > m5Body * 1.5) {
    const m5MidL = (Math.min(m5Prev.open, m5Prev.close) + m5Prev.low) / 2;
    const lw = Math.min(d.opens[prev], closeP) - d.lows[prev];
    if (closeP <= m5MidL && closeP >= m5Prev.low && bodyP > 0 && lw > bodyP * 2.0) {
      return { direction: 'CALL', strategy: 'SMC HTF WICK SNIPER', pair, price: ep, confidence: 88,
        notes: `HTFWickSniper↑ M5 lower wick zone`,
        rsi, emaFast: m5MidL, emaSlow: m5Prev.low, maTrend: 'htf_wick_sniper_call' };
    }
  }
  return null;
}

// ═══════════════════════════════════════════════════════════
// HTF ENGINE — 7 STRATEGY BLOCKS
// ═══════════════════════════════════════════════════════════

function stratHTFWickFVG(d: IndicatorData, pair: string): Signal | null {
  const m5 = d.m5;
  if (m5.length < 5) return null;
  const n = d.closes.length, prev = n - 2, last = n - 1;
  const closeP = d.closes[prev], ep = d.closes[last];
  const p = pip(closeP), rsi = d.rsi14[prev];

  // M5 Wick Fill
  for (const tf of [m5, d.m15]) {
    if (tf.length < 2) continue;
    const htfRow = tf[tf.length - 2];
    const body = Math.abs(htfRow.close - htfRow.open);
    if (body === 0) continue;
    const uWick = htfRow.high - Math.max(htfRow.open, htfRow.close);
    const lWick = Math.min(htfRow.open, htfRow.close) - htfRow.low;
    if (uWick > body * 0.60 && Math.abs(closeP - htfRow.high) < 3 * p) {
      return { direction: 'PUT', strategy: 'HTF WICK FILL', pair, price: ep, confidence: 88,
        notes: `HTF wick fill↓ at ${htfRow.high.toFixed(5)}`,
        rsi, emaFast: htfRow.high, emaSlow: htfRow.low, maTrend: 'htf_wick_fill_put' };
    }
    if (lWick > body * 0.60 && Math.abs(closeP - htfRow.low) < 3 * p) {
      return { direction: 'CALL', strategy: 'HTF WICK FILL', pair, price: ep, confidence: 88,
        notes: `HTF wick fill↑ at ${htfRow.low.toFixed(5)}`,
        rsi, emaFast: htfRow.high, emaSlow: htfRow.low, maTrend: 'htf_wick_fill_call' };
    }
  }
  return null;
}

function stratHTFInsideBar(d: IndicatorData, pair: string): Signal | null {
  const m15 = d.m15;
  if (m15.length < 3) return null;
  const n = d.closes.length, prev = n - 2, last = n - 1;
  const closeP = d.closes[prev], ep = d.closes[last], rsi = d.rsi14[prev];

  const m15Curr = m15[m15.length - 2], m15Prev = m15[m15.length - 3];
  if (m15Curr.high < m15Prev.high && m15Curr.low > m15Prev.low) {
    if (closeP > m15Prev.high) {
      return { direction: 'CALL', strategy: 'HTF INSIDE BAR', pair, price: ep, confidence: 88,
        notes: `InsideBar[15M] break↑ MB=[${m15Prev.low.toFixed(5)}-${m15Prev.high.toFixed(5)}]`,
        rsi, emaFast: m15Prev.high, emaSlow: m15Prev.low, maTrend: 'htf_ib_call' };
    }
    if (closeP < m15Prev.low) {
      return { direction: 'PUT', strategy: 'HTF INSIDE BAR', pair, price: ep, confidence: 88,
        notes: `InsideBar[15M] break↓ MB=[${m15Prev.low.toFixed(5)}-${m15Prev.high.toFixed(5)}]`,
        rsi, emaFast: m15Prev.high, emaSlow: m15Prev.low, maTrend: 'htf_ib_put' };
    }
  }
  return null;
}

function stratHTFM5Choch(d: IndicatorData, pair: string): Signal | null {
  const m5 = d.m5;
  if (m5.length < 15) return null;
  const n = d.closes.length, last = n - 1;
  const ep = d.closes[last], rsi = d.rsi14[n - 2], p = pip(d.closes[n - 2]);
  const sH = swingHigh(d.highs, 20, n - 3), sL = swingLow(d.lows, 20, n - 3);

  const i = m5.length - 1;
  const prevHighM5 = Math.max(...m5.slice(Math.max(0, i - 12), i).map(c => c.high));
  const prevLowM5 = Math.min(...m5.slice(Math.max(0, i - 12), i).map(c => c.low));

  if (m5[i].close > prevHighM5) {
    return { direction: 'CALL', strategy: 'HTF M5 CHOCH', pair, price: ep, confidence: 88,
      notes: `M5 BULLISH_CHOCH break=${prevHighM5.toFixed(5)}`,
      rsi, emaFast: prevHighM5, emaSlow: sL, maTrend: 'm5_choch_call' };
  }
  if (m5[i].close < prevLowM5) {
    return { direction: 'PUT', strategy: 'HTF M5 CHOCH', pair, price: ep, confidence: 88,
      notes: `M5 BEARISH_CHOCH break=${prevLowM5.toFixed(5)}`,
      rsi, emaFast: sH, emaSlow: prevLowM5, maTrend: 'm5_choch_put' };
  }
  return null;
}

function stratHTFSessionSweep(d: IndicatorData, pair: string): Signal | null {
  const n = d.closes.length;
  if (n < 60) return null;
  const prev = n - 2, last = n - 1;
  const closeP = d.closes[prev], highP = d.highs[prev], lowP = d.lows[prev];
  const ep = d.closes[last], rsi = d.rsi14[prev], p = pip(closeP);

  // Session H/L (use last 60 candles as session proxy)
  const sessH = swingHigh(d.highs, 60, prev - 1), sessL = swingLow(d.lows, 60, prev - 1);
  const sweepPips = 3 * p;

  if (highP > sessH + sweepPips && closeP < sessH) {
    return { direction: 'PUT', strategy: 'HTF SESSION SWEEP', pair, price: ep, confidence: 88,
      notes: `SessionSweep↓ sessH=${sessH.toFixed(5)} pierced`,
      rsi, emaFast: sessH, emaSlow: sessL, maTrend: 'htf_session_put' };
  }
  if (lowP < sessL - sweepPips && closeP > sessL) {
    return { direction: 'CALL', strategy: 'HTF SESSION SWEEP', pair, price: ep, confidence: 88,
      notes: `SessionSweep↑ sessL=${sessL.toFixed(5)} pierced`,
      rsi, emaFast: sessH, emaSlow: sessL, maTrend: 'htf_session_call' };
  }
  return null;
}

function stratHTFMomentum(d: IndicatorData, pair: string): Signal | null {
  const m5 = d.m5;
  if (m5.length < 10) return null;
  const n = d.closes.length, last = n - 1;
  const ep = d.closes[last], rsi = d.rsi14[n - 2], p = pip(d.closes[n - 2]);

  // M5 Displacement
  const m5Closes = m5.map(c => c.close), m5Opens = m5.map(c => c.open);
  const m5AvgB = avgBody(m5Opens, m5Closes, 10, m5.length - 1);
  const m5Last = m5[m5.length - 1];
  const m5LastBody = Math.abs(m5Last.close - m5Last.open);
  const m5LastRng = m5Last.high - m5Last.low;

  if (m5AvgB > 0 && m5LastBody > m5AvgB * 2.0 && m5LastRng > 0) {
    const wickRatio = (m5LastRng - m5LastBody) / m5LastRng;
    if (wickRatio < 0.50) {
      const dir: 'CALL' | 'PUT' = m5Last.close > m5Last.open ? 'CALL' : 'PUT';
      return { direction: dir, strategy: 'HTF M5 DISPLACEMENT', pair, price: ep, confidence: 88,
        notes: `M5Disp body=${(m5LastBody/m5AvgB).toFixed(1)}×avg wickR=${wickRatio.toFixed(2)}`,
        rsi, emaFast: m5Last.high, emaSlow: m5Last.low, maTrend: 'm5_disp' };
    }
  }
  return null;
}

function stratHTFPatterns(d: IndicatorData, pair: string): Signal | null {
  const m15 = d.m15;
  if (m15.length < 5) return null;
  const n = d.closes.length, last = n - 1;
  const closeP = d.closes[n - 2], ep = d.closes[last], rsi = d.rsi14[n - 2], p = pip(closeP);

  // M15 color switches (choppiness)
  let switches = 0;
  for (let i = m15.length - 5; i < m15.length - 1; i++) {
    if (i < 1) continue;
    const prevGreen = m15[i - 1].close > m15[i - 1].open;
    const currGreen = m15[i].close > m15[i].open;
    if (prevGreen !== currGreen) switches++;
  }
  if (switches >= 3) return null; // choppy

  // HTF Failure Swing
  if (m15.length >= 6) {
    const m15Prev = m15[m15.length - 2];
    const m15Last5High = Math.max(...m15.slice(m15.length - 6, m15.length - 1).map(c => c.high));
    if (m15Prev.high < m15Last5High) {
      const ltfStrLow = swingLow(d.lows, 5, n - 3);
      if (closeP < ltfStrLow) {
        const bodyP = Math.abs(closeP - d.opens[n - 2]);
        const prev2Body = Math.abs(d.closes[n - 3] - d.opens[n - 3]);
        if (bodyP > prev2Body * 1.5) {
          return { direction: 'PUT', strategy: 'HTF FAILURE SWING', pair, price: ep, confidence: 88,
            notes: `HTF failHigh|M1 BOS below ${ltfStrLow.toFixed(5)}`,
            rsi, emaFast: m15Last5High, emaSlow: ltfStrLow, maTrend: 'htf_fail_swing_put' };
        }
      }
    }
    const m15Last5Low = Math.min(...m15.slice(m15.length - 6, m15.length - 1).map(c => c.low));
    if (m15Prev.low > m15Last5Low) {
      const ltfStrHigh = swingHigh(d.highs, 5, n - 3);
      if (closeP > ltfStrHigh) {
        const bodyP = Math.abs(closeP - d.opens[n - 2]);
        const prev2Body = Math.abs(d.closes[n - 3] - d.opens[n - 3]);
        if (bodyP > prev2Body * 1.5) {
          return { direction: 'CALL', strategy: 'HTF FAILURE SWING', pair, price: ep, confidence: 88,
            notes: `HTF failLow|M1 BOS above ${ltfStrHigh.toFixed(5)}`,
            rsi, emaFast: ltfStrHigh, emaSlow: m15Last5Low, maTrend: 'htf_fail_swing_call' };
        }
      }
    }
  }
  return null;
}

// ═══════════════════════════════════════════════════════════
// MASTER ANALYZER — All strategies + 2/3 Gate
// ═══════════════════════════════════════════════════════════

const MAIN_STRATEGIES: Array<{ name: string; fn: (d: IndicatorData, pair: string) => Signal | null }> = [
  { name: 'PURE TREND', fn: stratPureTrend },
  { name: 'FFLC VPA', fn: stratFFLCVPA },
  { name: 'WIDE RANGING', fn: stratWideRanging },
  { name: 'MEDIUM RANGING', fn: stratMediumRanging },
  { name: 'MICRO TYPE 1', fn: stratMicroType1 },
  { name: 'MICRO TYPE 2', fn: stratMicroType2 },
  { name: 'MICRO TYPE 3', fn: stratMicroType3 },
  { name: 'MICRO TYPE 4', fn: stratMicroType4 },
  { name: 'LIQUID SNAP-BACK', fn: stratLiquidSnapBack },
];

const LIQ_STRATEGIES: Array<{ name: string; fn: (d: IndicatorData, pair: string) => Signal | null }> = [
  { name: 'LIQ SWEEP REVERSAL', fn: stratLiqSweepReversal },
  { name: 'LIQ FVG', fn: stratLiqFVG },
  { name: 'LIQ OB', fn: stratLiqOBBlocks },
  { name: 'LIQ CONTINUATION', fn: stratLiqContinuation },
  { name: 'LIQ HTF MAGNET', fn: stratLiqHTFMagnet },
];

const SMC_STRATEGIES: Array<{ name: string; fn: (d: IndicatorData, pair: string) => Signal | null }> = [
  { name: 'SMC FVG ZONE', fn: stratSmcFvgZone },
  { name: 'SMC SWEEP', fn: stratSmcSweepInducement },
  { name: 'SMC BLOCKS', fn: stratSmcBlocks },
  { name: 'SMC STRUCTURE', fn: stratSmcStructure },
  { name: 'SMC HTF COMBO', fn: stratSmcHTFCombo },
];

const HTF_STRATEGIES: Array<{ name: string; fn: (d: IndicatorData, pair: string) => Signal | null }> = [
  { name: 'HTF WICK FVG', fn: stratHTFWickFVG },
  { name: 'HTF INSIDE BAR', fn: stratHTFInsideBar },
  { name: 'HTF M5 CHOCH', fn: stratHTFM5Choch },
  { name: 'HTF SESSION SWEEP', fn: stratHTFSessionSweep },
  { name: 'HTF MOMENTUM', fn: stratHTFMomentum },
  { name: 'HTF PATTERNS', fn: stratHTFPatterns },
];

function runGroup(strategies: Array<{ name: string; fn: (d: IndicatorData, pair: string) => Signal | null }>, d: IndicatorData, pair: string): boolean {
  for (const { fn } of strategies) {
    try { if (fn(d, pair) !== null) return true; } catch {}
  }
  return false;
}

let rotationIdx = 0;

function analyzeS2(d: IndicatorData, pair: string): { signal: Signal | null; gateTags: string[]; confirmed: number } {
  const matches: Signal[] = [];
  for (const { fn } of MAIN_STRATEGIES) {
    try { const sig = fn(d, pair); if (sig) matches.push(sig); } catch {}
  }
  if (matches.length === 0) return { signal: null, gateTags: [], confirmed: 0 };

  const pickIdx = rotationIdx % matches.length;
  const mainSignal = matches[pickIdx];
  rotationIdx = (rotationIdx + 1) % MAIN_STRATEGIES.length;

  // Category gate: ≥2 of 3
  const liqOk = runGroup(LIQ_STRATEGIES, d, pair);
  const smcOk = runGroup(SMC_STRATEGIES, d, pair);
  const htfOk = runGroup(HTF_STRATEGIES, d, pair);

  const confirmed = (liqOk ? 1 : 0) + (smcOk ? 1 : 0) + (htfOk ? 1 : 0);
  const gateTags: string[] = [];
  if (liqOk) gateTags.push('LIQ✓');
  if (smcOk) gateTags.push('SMC✓');
  if (htfOk) gateTags.push('HTF✓');

  if (confirmed < 2) return { signal: null, gateTags, confirmed };

  mainSignal.notes += ` | Gate:[${gateTags.join('+')}]`;
  return { signal: mainSignal, gateTags, confirmed };
}

// ═══════════════════════════════════════════════════════════
// RESULT VERIFICATION — Updated system (entry = candle open)
// ═══════════════════════════════════════════════════════════

async function checkResult(pair: string, direction: string, entryTime: string): Promise<{ result: string; entryPrice: number; exitPrice: number }> {
  try {
    await new Promise(r => setTimeout(r, 62000));
    const candles = await fetchCandles(pair, 10);
    if (candles.length < 3) return { result: 'PENDING', entryPrice: 0, exitPrice: 0 };
    const entryCandle = candles[candles.length - 2];
    const actualEntry = entryCandle.open;
    const exitPrice = entryCandle.close;
    const entryTick = BigInt(Math.round(actualEntry * 100000000));
    const exitTick = BigInt(Math.round(exitPrice * 100000000));
    let result: string;
    if (entryTick === exitTick) result = 'MTG';
    else if (direction === 'CALL') result = exitTick > entryTick ? 'WIN' : 'LOSS';
    else result = exitTick < entryTick ? 'WIN' : 'LOSS';
    return { result, entryPrice: actualEntry, exitPrice };
  } catch { return { result: 'PENDING', entryPrice: 0, exitPrice: 0 }; }
}

// ═══════════════════════════════════════════════════════════
// BATCH PROCESSING — Multi-pair parallel analysis
// ═══════════════════════════════════════════════════════════

interface PairResult {
  pair: string; direction: 'CALL' | 'PUT' | null; confidence: number;
  strategy: string; notes: string; matched: boolean;
  gateTags: string[]; confirmed: number; entryPrice: number;
}

async function analyzePair(pair: string): Promise<PairResult> {
  try {
    const candles = await fetchCandles(pair, 2000);
    const d = computeIndicators(candles);
    const { signal, gateTags, confirmed } = analyzeS2(d, pair);
    if (!signal) return { pair, direction: null, confidence: 0, strategy: 'NONE',
      notes: `No match (gate: ${confirmed}/3)`, matched: false, gateTags, confirmed, entryPrice: 0 };
    return { pair, direction: signal.direction, confidence: signal.confidence,
      strategy: signal.strategy, notes: signal.notes, matched: true,
      gateTags, confirmed, entryPrice: signal.price };
  } catch (err: any) {
    console.error(`[S2] Error analyzing ${pair}:`, err.message);
    return { pair, direction: null, confidence: 0, strategy: 'ERROR', notes: err.message,
      matched: false, gateTags: [], confirmed: 0, entryPrice: 0 };
  }
}

// ═══════════════════════════════════════════════════════════
// HTTP HANDLER
// ═══════════════════════════════════════════════════════════

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });
  try {
    const body = await req.json();
    const { pairs, action, pair: singlePair, market } = body;

    if (action === 'check-result') {
      const { pair: rPair, direction: rDir, entryTime } = body;
      const result = await checkResult(rPair, rDir, entryTime);
      return new Response(JSON.stringify({ success: true, ...result }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (action === 'batch-scan') {
      if (!pairs || !Array.isArray(pairs) || pairs.length === 0)
        return new Response(JSON.stringify({ error: 'No pairs provided' }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 });
      console.log(`[S2] Batch scanning ${pairs.length} pairs`);
      const startTime = Date.now();
      const results = await Promise.all(pairs.map((p: string) => analyzePair(p)));
      const matched = results.filter(r => r.matched);
      const elapsed = Date.now() - startTime;
      console.log(`[S2] Batch complete in ${elapsed}ms. Matched: ${matched.length}/${results.length}`);
      return new Response(JSON.stringify({
        success: true, results, matched,
        totalPairs: results.length, matchedCount: matched.length, elapsedMs: elapsed,
      }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    const pairName = singlePair || market;
    if (!pairName) return new Response(JSON.stringify({ error: 'No pair provided' }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 });
    console.log(`[S2] Single pair analysis: ${pairName}`);
    const result = await analyzePair(pairName);
    return new Response(JSON.stringify({ success: true, ...result }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (err: any) {
    console.error('[S2] Fatal error:', err);
    return new Response(JSON.stringify({ error: err.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 });
  }
});
