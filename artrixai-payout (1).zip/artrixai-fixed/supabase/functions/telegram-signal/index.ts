import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { encode as encodeBase64 } from "https://deno.land/std@0.168.0/encoding/base64.ts";
import { Image, TextLayout } from "https://deno.land/x/imagescript@1.3.0/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TelegramRequest {
  botToken: string;
  chatId: string;
  message: string;
  photoUrl?: string | null;
  chartBase64?: string | null; // Base64 chart image (no overlay needed)
  chartImage?: string | null; // Same as chartBase64, for result charts with built-in overlay
  direction?: 'CALL' | 'PUT';
  signalData?: {
    market: string;
    direction: 'CALL' | 'PUT';
    time: string;
    expiry: string;
    confidence: number;
  } | null;
  resultData?: {
    market: string;
    time: string;
    result: 'WIN' | 'LOSS' | 'MTG';
    wins: number;
    losses: number;
    winRate: number;
  } | null;
}

const formatMarket = (market: string) => {
  return market.replace('/', '').toUpperCase();
};

// --- Image helpers ---

type OverlayImage = { base64: string; mimeType: string };

function toArrayBuffer(u8: Uint8Array): ArrayBuffer {
  // Deno std base64 encoder expects string | ArrayBuffer (not Uint8Array)
  return u8.buffer.slice(u8.byteOffset, u8.byteOffset + u8.byteLength) as ArrayBuffer;
}

function extractBase64FromDataUrl(dataUrl: string): OverlayImage | null {
  if (!dataUrl.startsWith("data:")) return null;
  const comma = dataUrl.indexOf(",");
  if (comma === -1) return null;

  const meta = dataUrl.slice(5, comma); // e.g. image/png;base64
  const base64 = dataUrl.slice(comma + 1);
  const mimeType = meta.split(";")[0] || "image/png";
  return { base64, mimeType };
}

function normalizeBase64ForAtob(input: string): string {
  let b64 = input.trim();
  if (b64.startsWith("data:")) {
    const parsed = extractBase64FromDataUrl(b64);
    if (parsed) b64 = parsed.base64;
  }

  // Remove whitespace/newlines, convert URL-safe base64, and pad
  b64 = b64.replace(/\s+/g, "").replace(/-/g, "+").replace(/_/g, "/");
  const pad = b64.length % 4;
  if (pad) b64 += "=".repeat(4 - pad);
  return b64;
}

let fontCache: Uint8Array | null = null;
const FALLBACK_FONT_URL =
  "https://raw.githubusercontent.com/openmaptiles/fonts/master/roboto/Roboto-Bold.ttf";
async function getFontBytes(): Promise<Uint8Array> {
  if (fontCache) return fontCache;
  // Prefer bundled font; fallback to remote download if runtime blocks file access.
  try {
    fontCache = await Deno.readFile(new URL("./Roboto-Bold.ttf", import.meta.url));
    return fontCache;
  } catch (err) {
    console.warn(
      "[telegram-signal] Local font read failed; downloading fallback font...",
      err,
    );
    const res = await fetch(FALLBACK_FONT_URL);
    if (!res.ok) throw new Error(`Failed to fetch fallback font: ${res.status}`);
    fontCache = new Uint8Array(await res.arrayBuffer());
    return fontCache;
  }
}

function rgba(r: number, g: number, b: number, a: number): number {
  return Image.rgbaToColor(r, g, b, a);
}

async function renderTextFitWithShadow(params: {
  font: Uint8Array;
  text: string;
  color: number;
  shadowColor: number;
  maxWidth: number;
  startSize: number;
  minSize: number;
  shadowOffsetPx: number;
}): Promise<{ text: Image; shadow: Image }> {
  const [text, shadow] = await Promise.all([
    renderTextFit({
      font: params.font,
      text: params.text,
      color: params.color,
      maxWidth: params.maxWidth,
      startSize: params.startSize,
      minSize: params.minSize,
    }),
    renderTextFit({
      font: params.font,
      text: params.text,
      color: params.shadowColor,
      maxWidth: params.maxWidth,
      startSize: params.startSize,
      minSize: params.minSize,
    }),
  ]);

  return { text, shadow };
}

async function renderTextFit(params: {
  font: Uint8Array;
  text: string;
  color: number;
  maxWidth: number;
  startSize: number;
  minSize: number;
  align?: "left" | "center" | "right";
}): Promise<Image> {
  let size = params.startSize;
  const align = params.align ?? "center";

  while (size >= params.minSize) {
    const layout = new TextLayout({
      maxWidth: params.maxWidth,
      wrapStyle: "word",
      verticalAlign: align, // ImageScript naming is a bit reversed
      horizontalAlign: "middle",
    });

    const textImg = await Image.renderText(params.font, size, params.text, params.color, layout);
    if (textImg.width <= params.maxWidth || size === params.minSize) return textImg;
    size = Math.max(params.minSize, Math.floor(size * 0.9));
  }

  // fallback (should never hit)
  return await Image.renderText(params.font, params.minSize, params.text, params.color);
}

// Generate signal overlay using pure code - matches reference design exactly
// Clean design: Cyan "PAIR | DIRECTION" centered, White "Time | Expiry" below, dark bottom bar
async function generateSignalOverlayImage(
  photoUrl: string,
  signalData: { market: string; direction: "CALL" | "PUT"; time: string; expiry: string; confidence: number }
): Promise<OverlayImage | null> {
  const pair = formatMarket(signalData.market);
  const expiry = signalData.expiry || "M1";
  const time = signalData.time;

  try {
    console.log("[telegram-signal] Fetching base image for signal overlay...");

    const imageResponse = await fetch(photoUrl);
    if (!imageResponse.ok) {
      console.error("[telegram-signal] Failed to fetch image:", imageResponse.status);
      return null;
    }

    const inputBytes = new Uint8Array(await imageResponse.arrayBuffer());
    const base = await Image.decode(inputBytes);
    const font = await getFontBytes();

    const W = base.width;
    const H = base.height;
    const unit = Math.max(14, Math.round(Math.min(W, H) * 0.025));

    // Colors matching reference image exactly
    const cyan = rgba(0, 220, 220, 255);      // Bright cyan for main signal text
    const white = rgba(255, 255, 255, 255);   // Pure white for time/expiry
    const darkGray = rgba(40, 40, 40, 255);   // Dark gray for bottom bar (higher opacity)
    const shadow = rgba(0, 0, 0, 220);        // Strong shadow to increase readability
    const shadowOffset = Math.max(2, Math.round(unit * 0.15));

    // Main signal text: "PAIR | DIRECTION" - Cyan, centered, NO background box
    const headerText = `${pair} | ${signalData.direction}`;
    const headerImgs = await renderTextFitWithShadow({
      font,
      text: headerText,
      color: cyan,
      shadowColor: shadow,
      maxWidth: Math.round(W * 0.9),
      startSize: Math.round(unit * 3.5),
      minSize: Math.round(unit * 2.5),
      shadowOffsetPx: shadowOffset,
    });
    const headerX = Math.round((W - headerImgs.text.width) / 2);
    const headerY = Math.round(H * 0.35); // Vertically centered
    base.composite(headerImgs.shadow, headerX + shadowOffset, headerY + shadowOffset);
    base.composite(headerImgs.text, headerX, headerY);

    // Sub text: "Time: XX:XX | Expiry: M1" - White, centered, NO background box
    const subText = `Time: ${time} | Expiry: ${expiry}`;
    const subImgs = await renderTextFitWithShadow({
      font,
      text: subText,
      color: white,
      shadowColor: shadow,
      maxWidth: Math.round(W * 0.9),
      startSize: Math.round(unit * 2.5),
      minSize: Math.round(unit * 1.8),
      shadowOffsetPx: shadowOffset,
    });
    const subX = Math.round((W - subImgs.text.width) / 2);
    const subY = headerY + headerImgs.text.height + Math.round(unit * 1.2);
    base.composite(subImgs.shadow, subX + shadowOffset, subY + shadowOffset);
    base.composite(subImgs.text, subX, subY);

    // Bottom brand bar - dark gray strip at bottom
    const barH = Math.round(H * 0.08);
    base.drawBox(0, H - barH, W, barH, darkGray);

    const brandText = "ARTRIX PREMIUM BOT - PROFESSIONAL TRADING";
    const brandImgs = await renderTextFitWithShadow({
      font,
      text: brandText,
      color: white,
      shadowColor: rgba(0, 0, 0, 180),
      maxWidth: Math.round(W * 0.92),
      startSize: Math.round(unit * 1.2),
      minSize: Math.round(unit * 0.9),
      shadowOffsetPx: Math.max(1, Math.round(unit * 0.1)),
    });
    const brandX = Math.round((W - brandImgs.text.width) / 2);
    const brandY = H - barH + Math.round((barH - brandImgs.text.height) / 2);
    base.composite(brandImgs.shadow, brandX + 1, brandY + 1);
    base.composite(brandImgs.text, brandX, brandY);

    // Encode to PNG and return base64
    const png = await base.encode(2);
    return { base64: encodeBase64(toArrayBuffer(png)), mimeType: "image/png" };
  } catch (error) {
    console.error("[telegram-signal] Error generating signal overlay:", error);
    return null;
  }
}

// Generate result overlay using pure code - matches reference design exactly
// Clean design: Cyan status header, White pair/time/stats, dark bottom bar
async function generateResultOverlayImage(
  photoUrl: string,
  resultData: { market: string; time: string; result: "WIN" | "LOSS" | "MTG"; wins: number; losses: number; winRate: number }
): Promise<OverlayImage | null> {
  const pair = formatMarket(resultData.market);
  const winRate = Math.round(resultData.winRate);

  try {
    console.log("[telegram-signal] Fetching base image for result overlay...");

    const imageResponse = await fetch(photoUrl);
    if (!imageResponse.ok) {
      console.error("[telegram-signal] Failed to fetch image:", imageResponse.status);
      return null;
    }

    const inputBytes = new Uint8Array(await imageResponse.arrayBuffer());
    const base = await Image.decode(inputBytes);
    const font = await getFontBytes();

    const W = base.width;
    const H = base.height;
    const unit = Math.max(14, Math.round(Math.min(W, H) * 0.025));

    // Colors matching reference image exactly
    const cyan = rgba(0, 220, 220, 255);      // Cyan for WIN/MTG header
    const red = rgba(255, 80, 80, 255);       // Red for LOSS header
    const white = rgba(255, 255, 255, 255);   // White for all other text
    const lightGray = rgba(200, 200, 200, 255); // Light gray for stats
    const darkGray = rgba(40, 40, 40, 255);   // Dark gray for bottom bar (higher opacity)
    const shadow = rgba(0, 0, 0, 220);
    const shadowOffset = Math.max(2, Math.round(unit * 0.15));

    // Determine header text and color based on result
    let headerText: string;
    let headerColor: number;
    
    if (resultData.result === "MTG") {
      headerText = "MTG WIN";
      headerColor = cyan;
    } else if (resultData.result === "WIN") {
      headerText = "WIN TRADE";
      headerColor = cyan;
    } else {
      headerText = "LOSS TRADE";
      headerColor = red;
    }

    // Main header: "WIN TRADE" / "LOSS TRADE" / "MTG WIN" - Cyan/Red, centered
    const headerImgs = await renderTextFitWithShadow({
      font,
      text: headerText,
      color: headerColor,
      shadowColor: shadow,
      maxWidth: Math.round(W * 0.9),
      startSize: Math.round(unit * 3.5),
      minSize: Math.round(unit * 2.5),
      shadowOffsetPx: shadowOffset,
    });
    const headerX = Math.round((W - headerImgs.text.width) / 2);
    const headerY = Math.round(H * 0.28);
    base.composite(headerImgs.shadow, headerX + shadowOffset, headerY + shadowOffset);
    base.composite(headerImgs.text, headerX, headerY);

    // Pair name: "EURUSD" - White, centered
    const pairImgs = await renderTextFitWithShadow({
      font,
      text: pair,
      color: white,
      shadowColor: shadow,
      maxWidth: Math.round(W * 0.9),
      startSize: Math.round(unit * 2.8),
      minSize: Math.round(unit * 2.0),
      shadowOffsetPx: shadowOffset,
    });
    const pairX = Math.round((W - pairImgs.text.width) / 2);
    const pairY = headerY + headerImgs.text.height + Math.round(unit * 1.5);
    base.composite(pairImgs.shadow, pairX + shadowOffset, pairY + shadowOffset);
    base.composite(pairImgs.text, pairX, pairY);

    // Time | Result: "14:19 | WIN" - White, centered
    const timeResultText = `${resultData.time} | ${resultData.result}`;
    const timeResultImgs = await renderTextFitWithShadow({
      font,
      text: timeResultText,
      color: white,
      shadowColor: shadow,
      maxWidth: Math.round(W * 0.9),
      startSize: Math.round(unit * 2.4),
      minSize: Math.round(unit * 1.8),
      shadowOffsetPx: shadowOffset,
    });
    const timeResultX = Math.round((W - timeResultImgs.text.width) / 2);
    const timeResultY = pairY + pairImgs.text.height + Math.round(unit * 1.2);
    base.composite(timeResultImgs.shadow, timeResultX + shadowOffset, timeResultY + shadowOffset);
    base.composite(timeResultImgs.text, timeResultX, timeResultY);

    // Stats line 1: "Wins: X | Losses: Y" - Light gray, centered
    const statsLine1 = `Wins: ${resultData.wins} | Losses: ${resultData.losses}`;
    const stats1Imgs = await renderTextFitWithShadow({
      font,
      text: statsLine1,
      color: lightGray,
      shadowColor: shadow,
      maxWidth: Math.round(W * 0.9),
      startSize: Math.round(unit * 2.0),
      minSize: Math.round(unit * 1.5),
      shadowOffsetPx: shadowOffset,
    });
    const stats1X = Math.round((W - stats1Imgs.text.width) / 2);
    const stats1Y = timeResultY + timeResultImgs.text.height + Math.round(unit * 1.5);
    base.composite(stats1Imgs.shadow, stats1X + shadowOffset, stats1Y + shadowOffset);
    base.composite(stats1Imgs.text, stats1X, stats1Y);

    // Stats line 2: "Win Rate: XX%" - Light gray, centered
    const statsLine2 = `Win Rate: ${winRate}%`;
    const stats2Imgs = await renderTextFitWithShadow({
      font,
      text: statsLine2,
      color: lightGray,
      shadowColor: shadow,
      maxWidth: Math.round(W * 0.9),
      startSize: Math.round(unit * 2.0),
      minSize: Math.round(unit * 1.5),
      shadowOffsetPx: shadowOffset,
    });
    const stats2X = Math.round((W - stats2Imgs.text.width) / 2);
    const stats2Y = stats1Y + stats1Imgs.text.height + Math.round(unit * 0.8);
    base.composite(stats2Imgs.shadow, stats2X + shadowOffset, stats2Y + shadowOffset);
    base.composite(stats2Imgs.text, stats2X, stats2Y);

    // Bottom brand bar - dark gray strip at bottom
    const barH = Math.round(H * 0.08);
    base.drawBox(0, H - barH, W, barH, darkGray);

    const brandText = "ARTRIX PREMIUM BOT - TRADING RESULTS";
    const brandImgs = await renderTextFitWithShadow({
      font,
      text: brandText,
      color: white,
      shadowColor: rgba(0, 0, 0, 180),
      maxWidth: Math.round(W * 0.92),
      startSize: Math.round(unit * 1.2),
      minSize: Math.round(unit * 0.9),
      shadowOffsetPx: Math.max(1, Math.round(unit * 0.1)),
    });
    const brandX = Math.round((W - brandImgs.text.width) / 2);
    const brandY = H - barH + Math.round((barH - brandImgs.text.height) / 2);
    base.composite(brandImgs.shadow, brandX + 1, brandY + 1);
    base.composite(brandImgs.text, brandX, brandY);

    // Encode to PNG and return base64
    const png = await base.encode(2);
    return { base64: encodeBase64(toArrayBuffer(png)), mimeType: "image/png" };
  } catch (error) {
    console.error("[telegram-signal] Error generating result overlay:", error);
    return null;
  }
}


// Send base64 image to Telegram
async function sendBase64PhotoToTelegram(
  botToken: string,
  chatId: string,
  base64Image: string,
  caption: string,
  mimeType: string = 'image/png'
): Promise<any> {
  try {
    const binaryString = atob(normalizeBase64ForAtob(base64Image));
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    const formData = new FormData();
    formData.append('chat_id', chatId);
    formData.append('caption', caption);
    formData.append('parse_mode', 'HTML');
    formData.append('photo', new Blob([bytes], { type: mimeType }), 'signal.png');

    const response = await fetch(`https://api.telegram.org/bot${botToken}/sendPhoto`, {
      method: 'POST',
      body: formData,
    });

    const result = await response.json();
    console.log('Telegram sendPhoto result:', result.ok ? 'success' : result.description);
    return result;
  } catch (e) {
    console.error('sendBase64PhotoToTelegram error:', e);
    return { ok: false, fallbackNeeded: true };
  }
}

// Send original photo with caption
async function sendPhotoWithCaption(
  botToken: string,
  chatId: string,
  photoUrl: string,
  caption: string
): Promise<any> {
  const response = await fetch(
    `https://api.telegram.org/bot${botToken}/sendPhoto`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        photo: photoUrl,
        caption: caption,
        parse_mode: 'HTML',
      }),
    }
  );
  return await response.json();
}

// Generate signal caption (old format - used as fallback and for results)
function generateSignalCaption(
  signalData: { market: string; direction: 'CALL' | 'PUT'; time: string; expiry: string; confidence: number }
): string {
  const pair = formatMarket(signalData.market);
  const timeframe = signalData.expiry || 'M1';
  const time = signalData.time;
  const action = signalData.direction === 'CALL' ? '<b>𝙲𝙰𝙻𝙻</b> 🟢' : '<b>𝙿𝚄𝚃</b> 🔴';
  const confidence = Number.isFinite(signalData.confidence) ? Math.round(signalData.confidence) : 80;

  return `<b>🚧 ARTRIX PREMIUM BOT 🚧</b>

╔════════💠════════╗ 
<b>📊 𝙿𝙰𝙸𝚁</b>             ⊱  <b>${pair}</b>         
<b>⌛ 𝚃𝙸𝙼𝙴𝙵𝚁𝙰𝙼𝙴</b> ⊱  <b>${timeframe}</b>             
<b>🎯 𝙰𝙲𝚃𝙸𝙾𝙽</b>        ⊱  ${action}        
<b>🕒 𝙴𝙽𝚃𝚁𝚈 𝚃𝙸𝙼𝙴</b> ⊱ <b>${time}</b>          
╚════════💠════════╝ 

<b>⚡️ 𝙲𝙾𝙽𝙵𝙸𝙳𝙴𝙽𝙲𝙴 : ${confidence}% 🔥</b>             
<b>⚙️ 𝚂𝚃𝙰𝚃𝚄𝚂 : TRADE SENT SUCCESSFULLY</b>`;
}

function generateResultCaption(
  resultData: { market: string; time: string; result: 'WIN' | 'LOSS' | 'MTG'; wins: number; losses: number; winRate: number; direction?: 'CALL' | 'PUT' }
): string {
  const marketText = formatMarket(resultData.market);
  const winRate = Math.round(resultData.winRate);

  // MTG WIN format
  if (resultData.result === 'MTG') {
    const directionText = resultData.direction === 'CALL' ? '🟢 <b>𝗖𝗔𝗟𝗟</b>' : '🔴 <b>𝗣𝗨𝗧</b>';
    return `<b>𒆜•——‼️ 𝚁 | 𝙴 | 𝚂 | 𝚄 | 𝙻 | 𝚃 ‼️——•𒆜</b>  

╭━━━━━━━━━・━━━━━━━━━╮ 
<b>🚀𝙰𝚂𝚂𝙴𝚃</b>            ☞ <b>${marketText}</b>
<b>⏰𝚃𝙸𝙼𝙴</b>               ☞ <b>${resultData.time}</b>
<b>🎯𝙳𝙸𝚁𝙴𝙲𝚃𝙸𝙾𝙽</b> ☞ ${directionText}  
╰━━━━━━━━━・━━━━━━━━━╯ 
<b>✅✅✅ 𝗠𝗧𝗚 𝗪𝗜𝗡 ✅✅✅</b>
╭━━━━━━━━━・━━━━━━━━━╮ 
<b>🏆 𝚆𝚒𝚗: ${resultData.wins}</b>    |  <b>𝙻𝚘𝚜𝚜: ${resultData.losses}</b> • <b>${winRate}%</b>
╰━━━━━━━━━・━━━━━━━━━╯`;
  }

  // WIN format
  if (resultData.result === 'WIN') {
    return `<b>𒆜•——‼️ 𝚁 | 𝙴 | 𝚂 | 𝚄 | 𝙻 | 𝚃 ‼️——•𒆜</b>  

╭━━━━━━━━𖥠━━━━━━━━╮ 
<b>📊 ${marketText}</b>    | <b>🕓 ${resultData.time}</b>
╰━━━━━━━━𖥠━━━━━━━━╯ 
<b>✅✅✅ 𝗦𝗨𝗥𝗘𝗦𝗛𝗢𝗧 ✅✅✅</b>
╭━━━━━━━━𖥠━━━━━━━━╮ 
<b>🚀 𝚆𝚒𝚗:${resultData.wins}</b> ┃<b>✖️𝙻𝚘𝚜𝚜:${resultData.losses}</b> ◈ <b>${winRate}%</b>
╰━━━━━━━━𖥠━━━━━━━━╯  

<b>🌐𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖: @Tredwithjakaria</b> 
<b>𒆜•——‼️ A | R | T | R | I | X ‼️——•𒆜</b>`;
  }

  // LOSS format
  return `<b>𒆜•——‼️ 𝚁 | 𝙴 | 𝚂 | 𝚄 | 𝙻 | 𝚃 ‼️——•𒆜</b>  

╭━━━━━━━━𖥠━━━━━━━━╮ 
<b>📊 ${marketText}</b>    | <b>🕓 ${resultData.time}</b>
╰━━━━━━━━𖥠━━━━━━━━╯ 
<b>❌❌❌ 𝗟𝗢𝗦𝗦 ❌❌❌</b>
╭━━━━━━━━𖥠━━━━━━━━╮ 
<b>🚀 𝚆𝚒𝚗:${resultData.wins}</b> ┃<b>✖️𝙻𝚘𝚜𝚜:${resultData.losses}</b> ◈ <b>${winRate}%</b>
╰━━━━━━━━𖥠━━━━━━━━╯  

<b>🌐𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖: @Tredwithjakaria</b> 
<b>𒆜•——‼️ A | R | T | R | I | X ‼️——•𒆜</b>`;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { botToken, chatId, message, photoUrl, chartBase64, chartImage, signalData, resultData }: TelegramRequest = await req.json();

    if (!botToken || !chatId || !message) {
      return new Response(
        JSON.stringify({ success: false, error: 'Missing required fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let success = false;
    let responseData: any = null;

    // Use chartImage (for results) or chartBase64 (for signals) if available
    const chartData = chartImage || chartBase64;

    // Chart image signal/result - Send chart directly without any overlay (overlay is already applied in TelegramChart)
    if (chartData) {
      try {
        console.log('Processing signal/result with chart image (overlay already applied)...');
        
        // Clean up the base64 string (remove data URL prefix if present)
        let cleanBase64 = chartData;
        if (chartData.startsWith('data:')) {
          const comma = chartData.indexOf(',');
          if (comma !== -1) {
            cleanBase64 = chartData.slice(comma + 1);
          }
        }
        
        const photoResult = await sendBase64PhotoToTelegram(botToken, chatId, cleanBase64, message, 'image/png');
        
        if (photoResult.ok) {
          success = true;
          responseData = photoResult;
          console.log('Chart image sent successfully');
        } else {
          throw new Error('Failed to send chart image');
        }
      } catch (chartError) {
        console.error('Chart image send error:', chartError);
        // Fallback to text only
        const textResponse = await fetch(
          `https://api.telegram.org/bot${botToken}/sendMessage`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_id: chatId,
              text: message,
              parse_mode: 'HTML',
            }),
          }
        );
        const textResult = await textResponse.json();
        success = textResult.ok;
        responseData = textResult;
      }
    }

    // Result signal - Use code-based overlay matching reference design
    else if (photoUrl && resultData) {
      try {
        console.log('Processing result signal with code-based overlay...');
        
        const overlayResult = await generateResultOverlayImage(photoUrl, resultData);
        
        if (overlayResult) {
          console.log('Sending result overlay image to Telegram');
          const caption = generateResultCaption(resultData);
          const photoResult = await sendBase64PhotoToTelegram(botToken, chatId, overlayResult.base64, caption, overlayResult.mimeType);
          
          if (photoResult.ok) {
            success = true;
            responseData = photoResult;
            console.log('Result overlay image sent successfully');
          } else {
            throw new Error('Failed to send result overlay image');
          }
        } else {
          throw new Error('Result image overlay generation failed');
        }
      } catch (resultError) {
        console.error('Result processing error, using fallback caption:', resultError);
        const caption = generateResultCaption(resultData);
        const fallbackResult = await sendPhotoWithCaption(botToken, chatId, photoUrl, caption);
        success = fallbackResult.ok;
        responseData = fallbackResult;
      }
    }
    // Signal with image - Use Gemini 2.5 Flash for image overlay ONLY
    else if (photoUrl && signalData) {
      try {
        console.log('Processing signal with Gemini 2.5 Flash image overlay...');
        
        const overlayResult = await generateSignalOverlayImage(photoUrl, signalData);
        
        if (overlayResult) {
          console.log('Sending Gemini-edited signal image to Telegram');
          const photoResult = await sendBase64PhotoToTelegram(botToken, chatId, overlayResult.base64, message, overlayResult.mimeType);
          
          if (photoResult.ok) {
            success = true;
            responseData = photoResult;
            console.log('Signal overlay image sent successfully');
          } else {
            throw new Error('Failed to send edited image');
          }
        } else {
          throw new Error('Gemini image editing returned no image');
        }
      } catch (photoError) {
        console.error('Signal processing error, using fallback caption:', photoError);
        const caption = generateSignalCaption(signalData);
        const fallbackResult = await sendPhotoWithCaption(botToken, chatId, photoUrl, caption);
        success = fallbackResult.ok;
        responseData = fallbackResult;
      }
    }
    // Just photo with message
    else if (photoUrl) {
      const photoResult = await sendPhotoWithCaption(botToken, chatId, photoUrl, message);
      success = photoResult.ok;
      responseData = photoResult;
    }
    // Text only
    else {
      const textResponse = await fetch(
        `https://api.telegram.org/bot${botToken}/sendMessage`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: chatId,
            text: message,
            parse_mode: 'HTML',
          }),
        }
      );
      const textResult = await textResponse.json();
      success = textResult.ok;
      responseData = textResult;
    }

    if (!success) {
      console.error('Telegram API error:', responseData);
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: responseData?.description || 'Failed to send message' 
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ success: true, data: responseData }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: any) {
    console.error('Telegram signal error:', error);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
