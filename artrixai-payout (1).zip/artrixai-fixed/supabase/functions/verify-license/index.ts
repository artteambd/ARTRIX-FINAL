import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Vercel backend URL
const BACKEND_URL = 'https://chart-x-seven.vercel.app';

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { license_key, device_fingerprint, device_info } = await req.json();
    
    console.log('Verifying license:', license_key, 'Device:', device_fingerprint?.slice(0, 16));

    if (!license_key) {
      console.log('No license key provided');
      return new Response(
        JSON.stringify({ valid: false, status: false, error: 'No license key provided' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verify through backend with device info
    const response = await fetch(`${BACKEND_URL}/api/licenses/verify`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ 
        licenseKey: license_key,
        deviceFingerprint: device_fingerprint,
        deviceInfo: device_info
      }),
    });

    const data = await response.json();
    console.log('Backend API response:', JSON.stringify(data));

    // Check for device lock error
    if (data.deviceLocked) {
      return new Response(
        JSON.stringify({
          valid: false,
          status: false,
          deviceLocked: true,
          message: data.message || 'This license is already registered to another device.',
        }),
        { 
          status: 200, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Transform backend response to expected format
    if (data.valid && data.user) {
      const user = data.user;
      return new Response(
        JSON.stringify({
          valid: true,
          status: 'active',
          credits: user.credits,
          membership: user.membership,
          tier: user.membership,
          expiry_date: user.expiresAt,
          email: user.email,
          name: user.name,
          isBlocked: user.isBlocked,
          warnings: user.warnings || [],
          deviceRegistered: data.deviceRegistered || false,
        }),
        { 
          status: 200, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    return new Response(
      JSON.stringify({
        valid: false,
        status: false,
        message: data.message || 'Invalid license',
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  } catch (error) {
    console.error('License verification error:', error);
    return new Response(
      JSON.stringify({ valid: false, status: false, error: 'License verification failed' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
