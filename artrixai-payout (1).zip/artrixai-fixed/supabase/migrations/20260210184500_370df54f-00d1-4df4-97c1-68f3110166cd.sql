
-- Create processing_jobs table for background signal generation
CREATE TABLE public.processing_jobs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  status TEXT NOT NULL DEFAULT 'processing',
  progress INTEGER NOT NULL DEFAULT 0,
  result JSONB,
  error TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Allow public access (no auth required for signal generation)
ALTER TABLE public.processing_jobs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read processing jobs"
ON public.processing_jobs FOR SELECT
USING (true);

CREATE POLICY "Anyone can insert processing jobs"
ON public.processing_jobs FOR INSERT
WITH CHECK (true);

CREATE POLICY "Anyone can update processing jobs"
ON public.processing_jobs FOR UPDATE
USING (true);

-- Auto-delete old jobs (older than 1 hour) to keep table clean
CREATE OR REPLACE FUNCTION public.cleanup_old_jobs()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM public.processing_jobs WHERE created_at < now() - INTERVAL '1 hour';
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER cleanup_old_processing_jobs
AFTER INSERT ON public.processing_jobs
FOR EACH STATEMENT
EXECUTE FUNCTION public.cleanup_old_jobs();
